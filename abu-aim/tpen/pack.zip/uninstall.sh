#!/system/bin/sh
#############################################################
# uninstall.sh —— 卸载整合包本体时执行
#
# 互锁规则：本套模块连成一体，删掉任何一个 = 整套移除。
# 所以这里不只是清安装材料，而是执行和互锁触发时一样的完整拆除 + 回滚：
#   * 删除本套全部模块目录（六个组件 + 守护 + 本体）
#   * 删除配置/数据目录（OMK 密钥与配置、Zygisk Next 配置、HMA 数据）
#   * 抹掉内部储存里的本包文件（覆盖改写 + 直接删除，不走回收站）
#   * 还原被改过的 MT 管理器 / 面具设置，抹掉 LSPosed 里的 FuseFixer 记录
# 重启后系统回到"没装过本套"的状态。
#############################################################

NVBASE=${NVBASE:-/data/adb}
SHELL_DIR=$NVBASE/hide_env_pack
[ -f "$SHELL_DIR/he_boot.sh" ] && . "$SHELL_DIR/he_boot.sh"
PACK_DIR=${HE_CODE_ROOT:-$SHELL_DIR}   # v1.5.1 随机部署：业务代码在 /data/adb/.h<hex>

echo "- 一键隐藏环境：执行完整拆除（互锁规则：删一个 = 整套移除）"

if [ -f "$PACK_DIR/common/hide_env_config.sh" ] && [ -f "$PACK_DIR/common/hide_env_tripwire.sh" ]; then
  . "$PACK_DIR/common/pack_shim.sh" 2>/dev/null
  . "$PACK_DIR/common/hide_env_config.sh" 2>/dev/null
  . "$PACK_DIR/common/hide_env_tripwire.sh" 2>/dev/null
  # 不在卸载脚本里重启：管理器卸载结束会提示重启，时机交给用户
  HIDE_TW_REBOOT=echo
  HIDE_PURGE_FORCE=1
  export HIDE_TW_REBOOT HIDE_PURGE_FORCE
  if command -v he_tw_wipe_exec >/dev/null 2>&1; then
    he_tw_wipe_exec "管理器卸载整合包"
    echo "- 已删除本套模块 / 配置 / 内部储存残留，并回滚改动；重启后完全生效"
    exit 0
  fi
fi

# 兜底（工作目录已不在时）：至少把本套模块目录和开机脚本点名删掉
echo "- 工作目录不完整，走兜底清理"
for id in hide_env_guard hide_env_pack zygisksu zygisk_lsposed oh_my_keymint hma_oss_zygisk hma-uidfake Tenc-ano_tmp; do
  rm -rf "$NVBASE/modules/$id" 2>/dev/null
done
rm -f "$NVBASE/service.d/hide_env_watch.sh" 2>/dev/null
rm -rf "$PACK_DIR" 2>/dev/null

# v1.5.1：随机根（/data/adb/.h<hex>）与探针也要一起清，否则卸载后还留着几十 MB 和一个哨兵
for d in /data/adb/.h* /cache/.h*; do
  [ -d "$d" ] || continue
  [ -f "$d/common/pack_install.sh" ] || continue
  rm -rf "$d" 2>/dev/null
done
# 探针：先按清单删，清单没了就按标记删（只认带我们标记的，绝不动别人的文件）
for f in /data/adb/hide_env_pack/state/probe.list /data/adb/.h*/state/probe.list; do
  [ -s "$f" ] || continue
  while IFS='|' read -r n pp t; do
    [ -f "$pp" ] && rm -f "$pp" 2>/dev/null
  done <"$f"
done
for f in /data/adb/.k* /data/local/tmp/.k* /cache/.k* /data/misc/.k* /data/local/.k*; do
  [ -f "$f" ] || continue
  head -2 "$f" 2>/dev/null | grep -q "wjn-probe-2026" && rm -f "$f" 2>/dev/null
done
rm -rf /data/adb/.hide_env_lic /data/adb/.hide_env_kb /data/adb/.hide_env_* 2>/dev/null
echo "- 已删除本套模块 / 随机根 / 探针 / 开机脚本（兜底路径）；重启后生效"
exit 0
