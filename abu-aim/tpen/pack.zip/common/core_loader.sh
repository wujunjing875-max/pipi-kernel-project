#!/system/bin/sh
# core_loader.sh —— 明文引导层：向服务器申请“每设备短时效密钥 + 加密核心块”，
# native 验签/解密后 source 执行；没有服务器密钥时核心块不可用。
# 业务逻辑不在本文件；本文件只做取钥、验签、解密、执行、擦除。

he_core_url() { he_lic_server; }

he_core_nonce() {
  he_cn=$(od -An -N8 -tx1 /dev/urandom 2>/dev/null | tr -d ' \n')
  case "$he_cn" in ''|*[!0-9a-fA-F]*) he_cn=$(date +%s%N 2>/dev/null | md5sum 2>/dev/null | cut -c1-16) ;; esac
  printf '%s' "$he_cn"
}

he_core_fetch() { # 成功输出解密后的 core.sh 路径；失败返回 1
  he_cf_url=$(he_core_url)
  [ -n "$he_cf_url" ] || return 1
  he_cf_tok=$(he_lic_get token 2>/dev/null)
  [ -n "$he_cf_tok" ] || { echo "! 未激活：没有核心密钥令牌" >&2; return 1; }
  he_cf_hw=$(he_lic_hwid)
  he_cf_nonce=$(he_core_nonce)
  he_cf_id=$(head -n 1 "${HIDE_PAYLOAD:-$HIDE_ENV_DIR/payload}/pack.id" 2>/dev/null | tr -d '\r\n')
  [ -n "$he_cf_id" ] || he_cf_id="v1.1.34"
  he_cf_ver=$(sed -n 's/^versionCode=//p' "$HIDE_ENV_DIR/module.prop" 2>/dev/null | tr -d '\r\n' | head -n 1)
  [ -n "$he_cf_ver" ] || he_cf_ver=234
  he_cf_body=$(printf '{"token":"%s","hwid":"%s","nonce":"%s","core_id":"%s","ver":"%s"}' \
    "$he_cf_tok" "$he_cf_hw" "$he_cf_nonce" "$he_cf_id" "$he_cf_ver")
  he_cf_resp=$(he_lic_http_post "$he_cf_url/api/corekey" "$he_cf_body" 10) || {
    echo "! 连不上核心密钥服务器" >&2; return 1; }
  if ! he_lic_jok "$he_cf_resp"; then
    he_cf_code=$(he_lic_jget "$he_cf_resp" code)
    he_cf_msg=$(he_lic_jget "$he_cf_resp" msg)
    echo "! 核心密钥被拒绝：${he_cf_msg:-$he_cf_code}" >&2
    return 1
  fi
  he_cf_key=$(he_lic_jget "$he_cf_resp" key)
  he_cf_b64=$(he_lic_jget "$he_cf_resp" core_b64)
  he_cf_sha=$(he_lic_jget "$he_cf_resp" core_sha256)
  he_cf_sig=$(he_lic_jget "$he_cf_resp" sig)
  he_cf_exp=$(he_lic_jget "$he_cf_resp" expire_at)
  case "$he_cf_key" in ''|*[!0-9a-fA-F]*) echo "! 核心密钥格式不对" >&2; return 1 ;; esac
  [ ${#he_cf_key} -eq 64 ] || { echo "! 核心密钥长度不对" >&2; return 1; }
  [ -n "$he_cf_b64" ] && [ -n "$he_cf_sig" ] || { echo "! 核心块/签名缺失" >&2; return 1; }
  he_cf_dir=$HIDE_ENV_DIR/.rt
  mkdir -p "$he_cf_dir" 2>/dev/null; chmod 0700 "$he_cf_dir" 2>/dev/null
  he_cf_enc=$he_cf_dir/core.enc.$$
  he_cf_out=$he_cf_dir/core.sh.$$
  he_cf_canon=$he_cf_dir/core.canon.$$
  printf '%s' "$he_cf_b64" | base64 -d >"$he_cf_enc" 2>/dev/null || {
    rm -f "$he_cf_enc"; echo "! 核心块解码失败" >&2; return 1; }
  he_cf_have=$(sha256sum "$he_cf_enc" 2>/dev/null | awk '{print $1}')
  [ "$he_cf_have" = "$he_cf_sha" ] || { rm -f "$he_cf_enc"; echo "! 核心块哈希不一致" >&2; return 1; }
  printf 'core|%s|%s|%s|%s|%s|%s' "$he_cf_tok" "$he_cf_hw" "$he_cf_nonce" "$he_cf_id" "$he_cf_exp" "$he_cf_sha" >"$he_cf_canon"
  he_cf_g=$(he_guard_bin); [ -x "$he_cf_g" ] || { rm -f "$he_cf_enc" "$he_cf_canon"; return 1; }
  "$he_cf_g" coreverify "$he_cf_canon" "$he_cf_sig" >/dev/null 2>&1 || {
    rm -f "$he_cf_enc" "$he_cf_canon"; echo "! 核心块签名校验失败" >&2; return 1; }
  printf '%s\n' "$he_cf_key" | "$he_cf_g" decrypt - "$he_cf_enc" "$he_cf_out" >/dev/null 2>&1 || {
    "$he_cf_g" wipe "$he_cf_enc" >/dev/null 2>&1
    rm -f "$he_cf_enc" "$he_cf_canon" "$he_cf_out"
    echo "! 核心块解密失败" >&2; return 1; }
  "$he_cf_g" wipe "$he_cf_enc" >/dev/null 2>&1
  rm -f "$he_cf_enc" "$he_cf_canon"
  printf '%s' "$he_cf_out"
}

he_core_run() { # he_core_run <cmd> [arg]：取核心、source、执行、擦除
  he_cr_cmd=${1:-status}
  he_cr_arg=${2:-}
  he_cr_f=$(he_core_fetch) || return 1
  he_cr_g=$(he_guard_bin)
  CORE_CMD=$he_cr_cmd
  CORE_ARG1=$he_cr_arg
  export CORE_CMD CORE_ARG1
  . "$he_cr_f"
  he_cr_rc=$?
  "$he_cr_g" wipe "$he_cr_f" >/dev/null 2>&1
  rm -f "$he_cr_f" 2>/dev/null
  return $he_cr_rc
}
