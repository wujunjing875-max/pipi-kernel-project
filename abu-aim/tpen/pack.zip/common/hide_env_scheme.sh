#!/system/bin/sh
# hide_env_scheme.sh —— 环境方案切换（2026-10-15 按用户给的标准动作清单重排）
#   A 骁龙 / 天玑（自研整套）：Zygisk Next + LSPosed·Vector + FuseFixer(LSP 模块) + HMA-OSS
#                              + OMK 密钥线 + 阿灵 + 云端功能；天玑自动跳 LSPosed/FuseFixer/Soter
#   B 老款（四合一）：Zygisk Next + TrickyStore + Tricky Addon + 腾讯解决设备标记 v5.0
#                     （TS 线：配密钥 / 配包名 / 开机自动加包名 / 自动换最新安全补丁）
#   北海方案已彻底移除（2026-10-17）：层脚本已从包内删除，不再加载、不再有入口。
#   C 有始有终（ARMIAS v10.5 口径）：Zygisk Next + HMA-OSS + OMK + susfs4ksu + Hybrid-Mount
#                                    + AsoulOpt + 解设备标记(ysyz) + 小鹿防人脸（见 hide_env_face.sh）
#   用法： install.sh scheme a|b|c|status
#   规矩：只做「启用/禁用 + 补装缺失件」，【从不卸载】任何模块；密钥模块（OMK ↔ TrickyStore）强制二选一。
HE_MODBASE=${HE_MODBASE:-/data/adb/modules}
HE_PAYLOAD=${HIDE_PAYLOAD:-/data/adb/hide_env_pack/payload}

he_sc_have() { [ -f "$HE_MODBASE/$1/module.prop" ]; }
he_sc_on()   { he_sc_have "$1" && [ ! -e "$HE_MODBASE/$1/disable" ]; }
he_sc_en() {
  d=$HE_MODBASE/$1
  [ -f "$d/module.prop" ] || return 1
  if [ -e "$d/disable" ]; then rm -f "$d/disable" 2>/dev/null; he_say "   [+] 启用系统组件"; fi
  return 0
}
he_sc_dis() {
  d=$HE_MODBASE/$1
  [ -f "$d/module.prop" ] || return 1
  if [ ! -e "$d/disable" ]; then touch "$d/disable" 2>/dev/null; he_say "   [-] 停用系统组件"; fi
  return 0
}
he_sc_install() {   # <payload文件名> <模块id>
  f="$HE_PAYLOAD/$1"
  he_sc_have "$2" && return 0
  [ -f "$f" ] || { he_say "   ! 包里没有这个组件（这版没带）"; return 1; }
  he_say "   [↓] 补装系统组件"
  if command -v pack_install_one >/dev/null 2>&1; then
    # pack_install_one 只接受 payload 里的“文件名”，内部会再拼 $PACK_PAYLOAD；
    # 传绝对路径会变成 .../payload//data/.../payload/x.zip（方案补装全静默失败的根因）
    pack_install_one "$1" "$2" >/dev/null 2>&1 || pack_sh "$HIDE_ENV_DIR/install.sh" "$2" >/dev/null 2>&1
  fi
  he_sc_have "$2"
}

# Zygisk Next 的"装上了"不等于"能启动"：目录在但 lib/zygisk/zygiskd 丢了时，
# 管理器会显示模块存在、开机却没有任何 Zygisk 注入。方案切换时做一次健康检查并强制重装。
he_sc_zn_ok() {
  he_zn_d=$HE_MODBASE/zygisksu
  [ -d "$he_zn_d" ] || return 1
  [ -f "$he_zn_d/module.prop" ] || return 1
  [ -x "$he_zn_d/bin/zygiskd" ] && return 0
  for he_zn_f in \
    "$he_zn_d/lib/arm64-v8a/libzygisk.so" "$he_zn_d/lib/armeabi-v7a/libzygisk.so" \
    "$he_zn_d/zygisk/arm64-v8a.so" "$he_zn_d/zygisk/armeabi-v7a.so"; do
    [ -f "$he_zn_f" ] && return 0
  done
  return 1
}

he_sc_zn_ensure() {
  he_sc_zn_ok && return 0
  he_say "   [!] Zygisk Next 目录在但核心文件不全 → 重新安装一次"
  if command -v pack_install_one >/dev/null 2>&1; then
    pack_install_one zygisk-next.zip "Zygisk Next" >/dev/null 2>&1
  fi
  he_sc_zn_ok
}
he_sc_call() {   # 顺序执行清单动作：有就调（让它的输出照常打给用户看），没有就跳过
  command -v "$1" >/dev/null 2>&1 || { he_say "   (跳过 $1：这版没有这一步)"; return 0; }
  "$@"
  return 0
}

he_ts_keybox() {
  ts=${HE_TS_DIR:-/data/adb/tricky_store}
  [ -d "$ts" ] || return 1
  he_tk_src=""
  for he_tk_c in "$OMK_DIR/keybox.xml" "$HE_KB_MIRROR" "$HE_PAYLOAD/keybox.xml"; do
    [ -n "$he_tk_c" ] || continue
    [ -s "$he_tk_c" ] && { he_tk_src=$he_tk_c; break; }
  done
  if [ -z "$he_tk_src" ] && command -v he_payload_get >/dev/null 2>&1; then
    he_tk_tmp=$(he_payload_get keybox.xml 2>/dev/null)
    [ -s "$he_tk_tmp" ] && he_tk_src=$he_tk_tmp
  fi
  if [ -z "$he_tk_src" ]; then
    he_say "   [!] TS 密钥：找不到可用 keybox（先跑 A 方案配好 OMK 密钥，或把 keybox.xml 放到 /sdcard/hide_env_keybox.xml）"
    command -v he_mark >/dev/null 2>&1 && he_mark ts_keybox fail "没有可用 keybox（OMK/镜像/payload 都没有）"
    return 1
  fi
  cp -f "$he_tk_src" "$ts/keybox.xml" 2>/dev/null
  chmod 600 "$ts/keybox.xml" 2>/dev/null
  chown 0:0 "$ts/keybox.xml" 2>/dev/null
  if [ -s "$ts/keybox.xml" ]; then
    he_say "   [√] TS 密钥：已写入 $ts/keybox.xml（来源 $(basename "$he_tk_src")）"
    command -v he_mark >/dev/null 2>&1 && he_mark ts_keybox ok "已写入 $ts/keybox.xml（来源 $(basename "$he_tk_src")）"
    return 0
  fi
  he_say "   [!] TS 密钥：写入失败（$ts 不可写？）"
  command -v he_mark >/dev/null 2>&1 && he_mark ts_keybox fail "写入 $ts/keybox.xml 失败"
  return 1
}

# ── 老款方案第 3 步：TS 线自动化（配密钥 / 配包名 / 自动换最新安全补丁）──
#   补丁日期取系统 prop（没有就用今天）；target.txt = GMS/Vending + 检测器 + 所有第三方
#   ★ 不再给每个包加 "!"：README 里 "!" 是「强制证书生成模式」（TEE 损坏机才需要），
#     全量加 "!" 会让正常 TEE 机器也走生成模式，检测反而过不了。默认交给 TS 自动判断。
he_ts_autoconfig() {
  ts=${HE_TS_DIR:-/data/adb/tricky_store}
  [ -d "$ts" ] || { he_say "   (TS 未装，跳过 TS 自动化)"; return 0; }
  he_ts_keybox
  d=$(getprop ro.build.version.security_patch 2>/dev/null)
  [ -n "$d" ] || d=$(date +%Y-%m-%d 2>/dev/null)
  [ -n "$d" ] || d="2026-10-01"
  [ -s "$ts/security_patch.txt" ] && cp -f "$ts/security_patch.txt" "$ts/security_patch.txt.bak" 2>/dev/null
  printf 'system=prop\nboot=%s\nvendor=%s\n' "$d" "$d" > "$ts/security_patch.txt" 2>/dev/null
  chmod 644 "$ts/security_patch.txt" 2>/dev/null
  command -v he_mark >/dev/null 2>&1 && he_mark ts_patch ok "security_patch.txt=$d"
  if command -v pm >/dev/null 2>&1; then
    [ -s "$ts/target.txt" ] && cp -f "$ts/target.txt" "$ts/target.txt.bak" 2>/dev/null
    if command -v timeout >/dev/null 2>&1; then
      he_ts_pkgs=$(timeout 8 pm list packages -3 2>/dev/null)
    else
      he_ts_pkgs=$(pm list packages -3 2>/dev/null)
    fi
    {
      printf 'com.google.android.gms\n'
      printf 'com.android.vending\n'
      printf 'com.chunqiunativecheck\n'
      printf '%s\n' "$he_ts_pkgs" | sed 's/^package://' | grep -v '^$' 2>/dev/null
    } | awk '!seen[$0]++' > "$ts/target.txt.tmp" 2>/dev/null && mv -f "$ts/target.txt.tmp" "$ts/target.txt" 2>/dev/null
    chmod 644 "$ts/target.txt" 2>/dev/null
    he_ts_n=$(grep -c . "$ts/target.txt" 2>/dev/null)
    case "$he_ts_n" in ''|*[!0-9]*) he_ts_n=0 ;; esac
    he_say "   [√] TS 线：security_patch.txt=$d；target.txt 已重建（$he_ts_n 个包，未强制加 !）"
    command -v he_mark >/dev/null 2>&1 && he_mark ts_target ok "target.txt 已重建（$he_ts_n 个包，自动模式）"
  else
    he_say "   [√] TS 线：security_patch.txt=$d（这台没有 pm，target.txt 跳过）"
    command -v he_mark >/dev/null 2>&1 && he_mark ts_target todo "这台没有 pm，target.txt 未重建"
  fi
  return 0
}

he_scheme_status() {
  he_say "══════ 环境方案现状 ══════"
  printf '   %-18s %s\n' "框架服务" "$(he_sc_on zygisksu && echo 开 || (he_sc_have zygisksu && echo 停 || echo 无))"
  printf '   %-18s %s\n' "密钥服务" "$(he_sc_on oh_my_keymint && echo 开 || (he_sc_have oh_my_keymint && echo 停 || echo 无))"
  printf '   %-18s %s\n' "证书服务" "$(he_sc_on tricky_store && echo 开 || (he_sc_have tricky_store && echo 停 || echo 无))"
  printf '   %-18s %s\n' "证书工具" "$(he_sc_on TA_utl && echo 开 || (he_sc_have TA_utl && echo 停 || echo 无))"
  printf '   %-18s %s\n' "游戏环境" "$(he_sc_on tencent_game_assist && echo 开 || (he_sc_have tencent_game_assist && echo 停 || echo 无))"
  printf '   %-18s %s\n' "应用兼容" "$(he_sc_on hma_oss_zygisk && echo 开 || (he_sc_have hma_oss_zygisk && echo 停 || echo 无))"
  printf '   %-18s %s\n' "框架兼容" "$(he_sc_on zygisk_lsposed && echo 开 || (he_sc_on zygisk_vector && echo "开(Vector)" || echo 停/无))"
  printf '   %-18s %s\n' "游戏助手" "$(he_sc_on Tenc-ano_tmp && echo 开 || (he_sc_have Tenc-ano_tmp && echo 停 || echo 无))"
  if he_sc_on oh_my_keymint && ! he_sc_on tricky_store; then he_say "   → 判定：A 方案（骁龙/天玑 · 自研整套）"
  elif he_sc_on tricky_store; then he_say "   → 判定：B 方案（老款 · 四合一 TS 线）"
  else he_say "   → 判定：没检测到密钥模块（先 install.sh scheme a 或 b）"; fi
}

he_scheme_apply() {
  he_sc=$1
  # 方案切换会合法地停用/启用不同的密钥模块（A 用 OMK、B 用 TrickyStore、C 用 OMK）。
  # 互锁默认把"停用本套模块"当拆包：这里先开合法换件窗口并留下 rebase 标记，
  # 避免切方案后下一次命令/开机被 A/B 校验误判成拆包、自毁、重启。
  case "$he_sc" in
    a|A|骁龙|天玑|自研|自研整套|b|B|老款|四合一|4合1|c|C|裸奔|有始有终|ARMIAS)
      he_sc_state=${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state
      mkdir -p "$he_sc_state" 2>/dev/null
      printf '%s\n' "方案切换 $he_sc" >"$he_sc_state/tw_rebase_pending" 2>/dev/null
      command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 1800 "方案切换 $he_sc"
      ;;
  esac
  case "$he_sc" in
    a|A|骁龙|天玑|自研|自研整套)
      he_say "══════ 切换环境方案：A · 骁龙 / 天玑（自研整套）══════"
      he_sc_mtk=0
      if command -v pack_soc_is_mtk >/dev/null 2>&1; then
        pack_soc_is_mtk 2>/dev/null && he_sc_mtk=1
      else
        case "$(getprop ro.board.platform 2>/dev/null)$(getprop ro.hardware 2>/dev/null)" in
          *mediatek*|*dimen*|*mt6*|*mt8*|*mt9*) he_sc_mtk=1 ;;
        esac
      fi
      he_sdk=$(getprop ro.build.version.sdk 2>/dev/null); case "$he_sdk" in ""|*[!0-9]*) he_sdk=0 ;; esac
      if [ "$he_sc_mtk" = "1" ]; then
        he_sc_dis zygisk_lsposed 2>/dev/null
        he_sc_dis zygisk_vector 2>/dev/null
        he_say "   [√] 天玑平台：跳过 LSPosed / FuseFixer / UID Fake / 微信指纹"
      elif [ "$he_sdk" -ge 36 ]; then
        if he_sc_have zygisk_vector; then
          he_sc_en zygisk_vector; he_sc_dis zygisk_lsposed
          he_say "   [√] 安卓 $he_sdk：用 Vector（已停用 LSPosed）"
        else
          he_sc_call pack_vector_ready
          he_sc_install vector.zip zygisk_vector
          if he_sc_have zygisk_vector; then
            he_sc_en zygisk_vector; he_sc_dis zygisk_lsposed
            he_say "   [√] 安卓 $he_sdk：已自动安装 Vector"
          else
            he_sc_dis zygisk_lsposed
            he_say "   [!] 安卓 $he_sdk：Vector 安装失败（包内 alt/vector.zip 缺失或刷入失败）"
          fi
        fi
      else
        he_sc_install lsposed.zip zygisk_lsposed
        he_sc_en zygisk_lsposed
        he_sc_dis zygisk_vector 2>/dev/null
      fi
      he_sc_install zygisk-next.zip zygisksu
      he_sc_zn_ensure || he_say "   ! Zygisk Next 仍未装好（详见 install.log）"
      he_sc_install omk.zip oh_my_keymint
      he_sc_install hma-oss.zip hma_oss_zygisk
      if [ "$he_sc_mtk" != "1" ]; then
        he_sc_install hma-uidfake.zip hma-uidfake
      fi
      he_sc_install aling-tenc.zip Tenc-ano_tmp
      for m in zygisksu hma_oss_zygisk oh_my_keymint Tenc-ano_tmp; do he_sc_en "$m"; done
      if [ "$he_sc_mtk" != "1" ]; then he_sc_en hma-uidfake; fi
      he_sc_dis tricky_store; he_sc_dis TA_utl; he_sc_dis tencent_game_assist
      he_say "── 按标准动作清单逐项执行 ──"
      se_line=1
      if [ "$he_sc_mtk" = "1" ]; then
        he_say "   1/9 天玑方案：跳过 LSP 模块（FuseFixer）"
      else
        he_say "   1/9 LSP 模块（FuseFixer）：装好并在框架里勾选启用"
        he_sc_call he_fuse_app_ensure
        he_sc_call he_lsp_selfheal
      fi
      he_say "   2/9 Zygisk Next：排除列表策略 → 仅还原挂载"
      he_sc_call he_zn_settings
      he_say "   3/9 HMA-OSS：还原配置 + 管理器"
      he_sc_call he_hma_config; he_sc_call he_hma_grant_root; he_sc_call he_hma_manager
      he_say "   4/9 阿灵：Whitelist520 里删掉 dfm 包名（原文件留 .bak）"
      he_sc_call he_aling_dfm_fix
      he_say "   5/9 MT2：路径归位/去重"
      he_sc_call he_mt2_path
      he_say "   6/9 OMK：选有效密钥"
      he_sc_call he_omk_keybox
      he_say "   7/9 OMK：PIF 指纹（默认 9 Pro）"
      he_sc_call he_omk_pif
      if [ "$he_sc_mtk" = "1" ]; then
        he_say "   8/11 天玑方案：跳过微信指纹修复"
      else
        he_say "   8/11 OMK：修复微信指纹（软件 Soter TA）"
        he_sc_call he_omk_soter
        he_say "   9/11 OMK：Soter HAL + 自签名证书"
        he_sc_call he_omk_soter_hal
      fi
      he_say "   10/11 OMK：同步系统安全补丁"
      he_sc_call he_omk_security_patch
      he_say "   11/11 OMK：按名单添加包名（autoscoop 自动同步）"
      he_sc_call he_omk_scoop; he_sc_call he_omk_autoscoop
      he_say "- 密钥线：OMK；隐藏线：HMA-OSS；标记线：阿灵；天玑自动跳过 LSP 线"
      ;;
    b|B|老款|四合一|4合1)
      he_say "══════ 切换环境方案：B · 老款（四合一）══════"
      he_sc_install zygisk-next.zip zygisksu
      he_sc_zn_ensure || he_say "   ! Zygisk Next 仍未装好（详见 install.log）"
      he_sc_install tricky-store.zip tricky_store
      he_sc_install tricky-addon.zip TA_utl
      he_sc_install tencent-guard.zip tencent_game_assist
      for m in zygisksu tricky_store TA_utl tencent_game_assist; do he_sc_en "$m"; done
      he_sc_dis oh_my_keymint
      he_sc_dis hma_oss_zygisk; he_sc_dis hma-uidfake; he_sc_dis Tenc-ano_tmp
      he_say "── 按标准动作清单逐项执行 ──"
      he_say "   1/3 Zygisk Next：排除列表策略 → 仅还原挂载"
      he_sc_call he_zn_settings
      he_say "   2/3 MT2：路径归位/去重"
      he_sc_call he_mt2_path
      he_say "   3/3 内置 TS 脚本：配有效密钥 + 配所有包名 + 自动换最新安全补丁"
      he_sc_call he_ts_autoconfig
      he_say "- 密钥线：TrickyStore（+ Addon 配 target.txt）；标记线：腾讯游戏防标记 v5.0"
      he_say "- 注：OMK 已停用（两个密钥模块同开会互相顶）；要用 A 线再切回 scheme a"
      ;;
    c|C|裸奔|有始有终|ARMIAS)
      # 2026-10-15 起 C = 「有始有终」（ARMIAS 那套）；2026-10-17 北海层脚本已从包内删除
      if command -v he_friend_apply >/dev/null 2>&1; then
        he_friend_apply
      else
        he_say "! 这版没有带上「有始有终」方案脚本（common/hide_env_face.sh），请重刷最新包"
        return 1
      fi
      ;;
    status|状态|"")
      he_scheme_status
      return 0 ;;
    *)
      he_say "用法：install.sh scheme a|b|c|status（A 骁龙·天玑自研整套 / B 老款四合一 / C 有始有终）"
      return 1 ;;
  esac
  printf '%s' "$he_sc" | tr 'A-Z' 'a-z' > "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/scheme.txt" 2>/dev/null
  # 方案切换完成：把当前"哪个模块启用/停用"记成新基线，互锁不再把这次合法换件当拆包
  if command -v he_tw_snapshot >/dev/null 2>&1; then
    he_tw_snapshot >/dev/null 2>&1
    rm -f "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state/tw_rebase_pending" 2>/dev/null
  fi
  he_say ""
  he_say "→ 手动三步（脚本做不了的）：①MT2 设置里关「回收站」、首页目录设为《好游快爆》；②重启一次完全生效；③重启后清空后台，打开春秋复测（全过即成功）"
  he_say "→ 现在状态："; he_scheme_status
  printf 'WGN_SCHEME_OK\n'
  return 0
}

# ---------------------------------------------------------------
# v1.5.1「方案自检」：跑完一键启动后，逐条核对方案里每一步到底生效没有
#   目的：客户截图发过来，一眼看出"第几步没生效"，不用再猜。
#   只读，不改任何东西。输出 LICRESULT|verify-ok / verify-fail。
# ---------------------------------------------------------------
he_verify_step() { # he_verify_step <序号> <名称> <状态键...>
  he_vf_n=$1; he_vf_name=$2; shift 2
  he_vf_bad=0; he_vf_hit=0; he_vf_msg=""
  for he_vf_k in "$@"; do
    he_vf_s=$(he_state_of "$he_vf_k" 2>/dev/null)
    case "$he_vf_s" in
      ok*)  he_vf_hit=$((he_vf_hit + 1)) ;;
      skip) he_vf_hit=$((he_vf_hit + 1)) ;;
      "")   he_vf_msg="$he_vf_msg $he_vf_k:未执行" ;;
      *)    he_vf_msg="$he_vf_msg $he_vf_k:$he_vf_s" ;;
    esac
  done
  if [ "$he_vf_hit" -ge 1 ] && [ -z "$he_vf_msg" ]; then
    he_say "  [√] 第 $he_vf_n 步 $he_vf_name"
    return 0
  elif [ "$he_vf_hit" -ge 1 ]; then
    he_say "  [~] 第 $he_vf_n 步 $he_vf_name ——$he_vf_msg"
    return 1
  else
    he_say "  [×] 第 $he_vf_n 步 $he_vf_name 没生效 ——$he_vf_msg"
    HE_VF_FAIL=$((HE_VF_FAIL + 1))
    return 1
  fi
}

he_verify_mod() { # he_verify_mod <序号> <名称> <模块id...>
  he_vm_n=$1; he_vm_name=$2; shift 2
  for he_vm_id in "$@"; do
    if [ -f "${HE_MODBASE:-/data/adb/modules}/$he_vm_id/module.prop" ]; then
      if [ -f "${HE_MODBASE:-/data/adb/modules}/$he_vm_id/disable" ]; then
        he_say "  [~] 第 $he_vm_n 步 $he_vm_name：$he_vm_id 已禁用"
        return 1
      fi
      return 0
    fi
  done
  he_say "  [×] 第 $he_vm_n 步 $he_vm_name：模块没装上（$*）"
  HE_VF_FAIL=$((HE_VF_FAIL + 1))
  return 1
}

he_verify_plan() {
  he_init 2>/dev/null
  HE_VF_FAIL=0
  he_say "══════ 方案执行自检（逐条比对，只读）══════"

  # 判定当前方案
  he_vp_plan="?"
  if he_sc_on oh_my_keymint 2>/dev/null; then he_vp_plan="A"
  elif he_sc_on tricky_store 2>/dev/null; then he_vp_plan="B"
  else he_vp_plan="?"; fi

  case "$he_vp_plan" in
    A)
      he_say "- 当前方案：A · 骁龙/天玑（自研整套）"
      he_verify_mod 1 "框架服务 Zygisk Next" zygisksu
      he_verify_mod 2 "密钥服务 OMK" oh_my_keymint
      he_verify_mod 3 "应用隐藏 HMA-OSS" hma_oss_zygisk
      he_verify_mod 4 "游戏助手 阿灵" Tenc-ano_tmp
      he_verify_step 5 "Zygisk Next 排除策略＝仅还原挂载" zn_denylist zn_linker
      he_verify_step 6 "HMA 配置已还原（含面具包名）" hma_config hma_manager
      he_verify_step 7 "框架 + FuseFixer 已启用" lspd fuse_app fuse_fixer
      he_verify_step 8 "dfm 设备标记已清除" aling_dfm
      he_verify_step 9 "MT 首页 = /data/好游快爆" mt2_path
      he_verify_step 10 "云端有效密钥已写入" omk_keybox omk_verify
      he_verify_step 11 "PIF 指纹 = 9 Pro" omk_pif
      he_verify_step 12 "微信指纹（Soter）" omk_soter
      he_verify_step 13 "OMK 包名 + 自动添加" omk_scoop autoscoop
      ;;
    B)
      he_say "- 当前方案：B · 老款四合一（TS 线）"
      he_verify_mod 1 "框架服务 Zygisk Next" zygisksu
      he_verify_mod 2 "证书服务 TrickyStore" tricky_store
      he_verify_mod 3 "证书工具 TA_utl" TA_utl
      he_verify_mod 4 "腾讯游戏助手" tencent_game_assist
      he_verify_step 5 "Zygisk Next 排除策略＝仅还原挂载" zn_denylist zn_linker
      he_verify_step 6 "MT 首页 = /data/好游快爆" mt2_path
      he_verify_step 7 "TS 密钥已配置" ts_keybox
      he_verify_step 8 "TS 包名清单已重建" ts_target
      he_verify_step 9 "安全补丁已更新" ts_patch
      ;;
    *)
      he_say "- 当前方案：未识别（既没有 OMK 也没有 TrickyStore 在用）"
      he_say "  → 先点「⚡ 一键启动」选一个方案，或 install.sh scheme a|b"
      HE_VF_FAIL=$((HE_VF_FAIL + 1))
      ;;
  esac

  # 互锁 / 探针（与方案无关，但影响"能不能长期稳")
  he_say "  —— 安全件："
  command -v he_tw_status >/dev/null 2>&1 && he_tw_status 2>/dev/null | sed -n '1,2p' | sed 's/^/  /'
  command -v he_pb_status >/dev/null 2>&1 && he_pb_status 2>/dev/null | sed -n '1,2p' | sed 's/^/  /'

  if [ "$HE_VF_FAIL" = "0" ]; then
    he_say "→ 结论：方案各步已生效（人工只剩：重启后清后台 → 开春秋复测）"
    printf 'LICRESULT|verify-ok|方案各步已生效\n'
  else
    he_say "→ 结论：有 $HE_VF_FAIL 步没生效（上面标 [×] 的那几步）。处理：①点对应应急按钮 ②或重跑一键启动 ③还不行点「📋 诊断报告」发给客服"
    printf 'LICRESULT|verify-fail|有 %s 步没生效\n' "$HE_VF_FAIL"
  fi
  return 0
}
