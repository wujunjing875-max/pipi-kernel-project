#!/system/bin/sh
# hide_env_mods.sh —— 组件管理 / 其他模块配置
# 输出格式（TAB 分隔）：id \t name \t 状态 \t 有网页 \t 属于本套
HE_MODS_DIR=${NVBASE:-/data/adb}/modules

he_mods__prop() {  # 读 module.prop 的某字段
  sed -n "s/^$2=//p" "$1/module.prop" 2>/dev/null | head -n 1
}

he_mods_is_ours() {
  case "$1" in
    hide_env_pack|hide_env_guard|hma_oss_zygisk|hma-uidfake|hma_uidfake|oh_my_keymint|zygisk_vector|zygisksu|model_spoof|tricky_store|TA_utl|susfs4ksu|hybrid-mount|zygisk_lsposed) echo 1 ;;
    *) echo 0 ;;
  esac
}

# 内嵌组件（被吸进主模块的，不再以模块形式出现）
he_mods_list_components() {
  he_cd="${PACK_DIR:-/data/adb/hide_env_pack}/components"
  [ -d "$he_cd" ] || return 0
  for he_dir in "$he_cd"/*; do
    [ -d "$he_dir" ] || continue
    he_cid=$(basename "$he_dir")
    he_cname=""
    [ -f "$he_dir/module.prop" ] && he_cname=$(he_mods__prop "$he_dir" name)
    [ -n "$he_cname" ] || he_cname="$he_cid"
    he_cst="启用"
    [ -f "$he_dir/disable" ] && he_cst="停用"
    printf '%s\t%s\t%s\t%s\t%s\n' "comp:$he_cid" "$he_cname" "$he_cst" "0" "1"
  done
}

he_mods_list() {
  he_mods_list_components
  [ -d "$HE_MODS_DIR" ] || return 0
  for he_d in "$HE_MODS_DIR"/*; do
    [ -d "$he_d" ] || continue
    he_id=$(basename "$he_d")
    [ "$he_id" = "hide_env_pack" ] && { printf '%s\t%s\t%s\t%s\t%s\n' "$he_id" "一键隐藏环境楠楠守护（主模块）" "启用" "1" "1"; continue; }
    he_name=$(he_mods__prop "$he_d" name)
    [ -n "$he_name" ] || he_name="$he_id"
    case "$he_id" in zygisksu|zygisk_next) he_name="Zygisk Next" ;; esac
    he_st="启用"
    [ -f "$he_d/disable" ] && he_st="停用"
    [ -f "$he_d/remove" ] && he_st="待删除"
    [ -f "$he_d/update" ] && he_st="待更新"
    he_web=0
    [ -f "$he_d/webroot/index.html" ] && he_web=1
    he_ours=$(he_mods_is_ours "$he_id")
    printf '%s\t%s\t%s\t%s\t%s\n' "$he_id" "$he_name" "$he_st" "$he_web" "$he_ours"
  done
}

he_mods_set() {  # <id> on|off
  he_id=${1#comp:}; he_id=${he_id#mod:}
  case "$1" in comp:*) he_cd="${PACK_DIR:-/data/adb/hide_env_pack}/components/$he_id"
      [ -d "$he_cd" ] || { echo "没有这个组件：$he_id"; return 1; }
      if [ "$2" = "off" ] || [ "$2" = "disable" ]; then touch "$he_cd/disable"; echo "已停用组件（重启生效）：$he_id"; else rm -f "$he_cd/disable"; echo "已启用组件（重启生效）：$he_id"; fi
      return 0 ;;
  esac
  he_to=$2
  he_d=$HE_MODS_DIR/$he_id
  [ -d "$he_d" ] || { echo "没有这个模块：$he_id"; return 1; }
  case "$he_to" in
    off|disable)
      touch "$he_d/disable" 2>/dev/null
      echo "已停用（重启生效）：$(he_mods__prop "$he_d" name)"
      ;;
    on|enable)
      rm -f "$he_d/disable" 2>/dev/null
      echo "已启用（重启生效）：$(he_mods__prop "$he_d" name)"
      ;;
    *) echo "用法：mods set <id> on|off"; return 1 ;;
  esac
  return 0
}

he_mods_del() {
  he_id=$1
  he_d=$HE_MODS_DIR/$he_id
  [ -d "$he_d" ] || { echo "没有这个模块：$he_id"; return 1; }
  case "$he_id" in
    hide_env_pack|hide_env_guard) echo "本套核心模块不允许从这里删除"; return 1 ;;
  esac
  mkdir -p "$he_d"
  touch "$he_d/remove" 2>/dev/null
  echo "已标记删除（重启后由管理器移除）：$(he_mods__prop "$he_d" name)"
  return 0
}

he_mods_web() {
  he_d=$HE_MODS_DIR/$1
  [ -f "$he_d/webroot/index.html" ] || { echo "这个模块没有网页"; return 1; }
  echo "$he_d/webroot/index.html"
}

# 统一组件显示名（只在刷入/重设基线前调用，避免互锁误判）
he_mods_pretty() {
  he_d=${NVBASE:-/data/adb}/modules
  [ -d "$he_d" ] || return 0
  he_any=0
  while IFS=: read -r he_id he_nm; do
    [ -n "$he_id" ] || continue
    he_p=$he_d/$he_id/module.prop
    [ -f "$he_p" ] || continue
    sed -i "s/^name=.*/name=楠楠守护·$he_nm/" "$he_p" 2>/dev/null
    he_any=$((he_any + 1))
  done <<'NNEOF'
hide_env_guard:守护
oh_my_keymint:密钥
zygisksu:框架内核
zygisk_lsposed:框架
zygisk_vector:框架
susfs4ksu:内核隐藏
tricky_store:证书核心
TA_utl:证书目标
hma_oss_zygisk:应用兼容
hma-uidfake:应用隔离
hybrid_mount:混合挂载
tencent_guard:游戏防护
Tenc-ano_tmp:游戏兼容
model_spoof:改机型
NNEOF
  if [ "$he_any" -gt 0 ]; then
    echo "- 组件显示名已统一（$he_any 个）"
    return 2
  fi
  return 0
}

# 直接执行时的分发（被 source 时不跑）
case "${0##*/}" in
  *mods.sh)
    case "${1:-}" in
      list) he_mods_list ;;
      set)  he_mods_set "${2:-}" "${3:-}" ;;
      del)  he_mods_del "${2:-}" ;;
      web)  he_mods_web "${2:-}" ;;
      pretty) he_mods_pretty ;;
      *)    echo "用法：hide_env_mods.sh list | set <id> on|off | del <id> | web <id>" ;;
    esac
    ;;
esac

