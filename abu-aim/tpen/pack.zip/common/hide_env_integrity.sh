#!/system/bin/sh
# hide_env_integrity.sh —— 全树完整性自检（只读；只上报，降级由服务器决定）
HE_IC_DIR=${PACK_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}}
HE_IC_STATE=$HE_IC_DIR/state/integrity
HE_IC_ROOTF=$HE_IC_DIR/bin/root.hash
HE_IC_MAN=$HE_IC_DIR/bin/manifest.full

he_ic__sha() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" 2>/dev/null | awk '{print $1}'
    return
  fi
  for bb in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /system/bin/busybox; do
    [ -x "$bb" ] || continue
    "$bb" sha256sum "$1" 2>/dev/null | awk '{print $1}'
    return
  done
}

he_ic_root() { cat "$HE_IC_ROOTF" 2>/dev/null; }

he_ic__scan() {
  [ -f "$HE_IC_MAN" ] || { echo "9999 manifest_missing"; return; }
  he_probe=$(he_ic__sha "$HE_IC_MAN")
  case "$he_probe" in
    ''|*[!0-9a-f]*) echo "9999 no_sha_tool"; return ;;
  esac
  cd "$HE_IC_DIR" 2>/dev/null || { echo "9999 chdir_fail"; return; }
  he_bad=0
  he_badn=""
  while IFS= read -r he_line; do
    case "$he_line" in ''|\#*) continue ;; esac
    he_h=${he_line%%  *}
    he_p=${he_line#*  }
    [ -n "$he_h" ] || continue
    he_a=$(he_ic__sha "$he_p")
    if [ "$he_a" != "$he_h" ]; then
      he_bad=$((he_bad + 1))
      [ "$he_bad" -le 8 ] && he_badn="$he_badn$he_p,"
    fi
  done < "$HE_IC_MAN"
  echo "$he_bad $he_badn"
}

he_ic__server() {
  if command -v he_lic_server >/dev/null 2>&1; then
    he_lic_server 2>/dev/null
    return
  fi
  he_u=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HE_IC_DIR/config/license_url.txt" 2>/dev/null | head -n 1)
  [ -n "$he_u" ] || he_u="https://wjntool.top/lsp"
  printf '%s' "$he_u"
}

he_ic__hwid() {
  he_w=$(sed -n 's/^hwid=//p' "$HE_IC_DIR/license/state" 2>/dev/null | head -1)
  [ -n "$he_w" ] || { command -v he_lic_hwid >/dev/null 2>&1 && he_w=$(he_lic_hwid 2>/dev/null); }
  printf '%s' "$he_w"
}

he_ic__report() {
  he_root=$1
  he_bad=$2
  he_badn=$3
  he_srv=$(he_ic__server)
  [ -n "$he_srv" ] || return 0
  he_hw=$(he_ic__hwid)
  he_ver=$(head -n 1 "$HE_IC_DIR/payload/pack.id" 2>/dev/null | tr -d '\r\n')
  he_ts=$(date +%s)
  mkdir -p "$HE_IC_DIR/tmp" "$HE_IC_DIR/state" 2>/dev/null
  he_tmp=$HE_IC_DIR/tmp/ic.$$
  he_body=$(printf '{"ver":"%s","root":"%s","bad":%s,"badfiles":"%s","hwid":"%s","ts":%s}' "$he_ver" "$he_root" "$he_bad" "$he_badn" "$he_hw" "$he_ts")
  curl -s --connect-timeout 4 -m 8 -X POST -H 'Content-Type: application/json' --data-binary "$he_body" "${he_srv%/}/api/integrity" >"$he_tmp" 2>/dev/null
  he_resp=$(cat "$he_tmp" 2>/dev/null)
  rm -f "$he_tmp" 2>/dev/null
  he_ok=0
  case "$he_resp" in *'"ok": true'*|*'"ok":true'*) he_ok=1 ;; esac
  he_enf=0
  case "$he_resp" in *'"enforce": true'*|*'"enforce":true'*) he_enf=1 ;; esac
  {
    printf 'root=%s\n' "$he_root"
    printf 'bad=%s\n' "$he_bad"
    printf 'badfiles=%s\n' "$he_badn"
    printf 'ok=%s\n' "$he_ok"
    printf 'enforce=%s\n' "$he_enf"
    printf 'checked_at=%s\n' "$he_ts"
  } > "$HE_IC_STATE" 2>/dev/null
  return 0
}

he_ic_boot() {
  mkdir -p "$HE_IC_DIR/state" 2>/dev/null
  [ -f "$HE_IC_MAN" ] || return 0
  he_root=$(he_ic_root)
  [ -n "$he_root" ] || return 0
  he_r=$(he_ic__scan)
  he_bad=${he_r%% *}
  he_badn=${he_r#* }
  he_ic__report "$he_root" "$he_bad" "$he_badn"
  return 0
}

he_ic_enforced_bad() {
  [ -f "$HE_IC_STATE" ] || return 1
  he_enf=$(awk -F= '/^enforce=/{print $2}' "$HE_IC_STATE" 2>/dev/null)
  he_ok=$(awk -F= '/^ok=/{print $2}' "$HE_IC_STATE" 2>/dev/null)
  he_bad=$(awk -F= '/^bad=/{print $2}' "$HE_IC_STATE" 2>/dev/null)
  [ "$he_enf" = "1" ] || return 1
  [ "$he_ok" = "1" ] && return 1
  case "$he_bad" in ''|0|9999) return 1 ;; esac
  return 0
}

he_ic_quick() {
  [ -f "$HE_IC_MAN" ] || return 0
  [ -s "$HE_IC_ROOTF" ] || return 0
  [ -s "$HE_IC_DIR/bin/heguard" ] || return 0
  return 0
}
