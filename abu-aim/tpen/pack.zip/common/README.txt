一键隐藏环境 · 整合包  v1.0.0
=================================================

一、这个包做了什么
  刷入一次，自动完成下面全部动作（原教程的 10 步手工操作都在里面）：

    模块（各自官方安装脚本原样执行，不是简单复制文件）：
      1) Zygisk Next 1.5.0       (zygisksu)          —— 独立 Zygisk 实现
      2) LSPosed v2.0.4          (zygisk_lsposed)    —— Xposed 框架
      3) OhMyKeymint 1.3.5       (oh_my_keymint)     —— KeyMint/密钥认证伪造
      4) HMA-OSS future-8ae6361d (hma_oss_zygisk)    —— 应用列表隐藏后端
      5) HMA UID Fake 0.2.2      (hma-uidfake)       —— UID 伪装（需 KernelSU）
      6) 阿灵游戏助手            (Tenc-ano_tmp)      —— 腾讯游戏缓存清理/伪装

    应用：
      7) FuseFixer（LSPosed 模块，防扫盘）            —— 自动安装并启用

    自动配置（对应原教程第 2~9 步）：
      * OMK 密钥：把 2-密钥.zip 里的 keybox.xml 装进 OMK（走原生 keymint 校验）
      * OMK 拦截包名：gms / gsf / vending + 设备上全部第三方应用，
        所以 MT 管理器、检测工具、幸运工具这些会自动进列表（第 5 步）
      * OMK 腾讯 Soter 兼容：教程里写的「腾讯 store key 隐藏」
      * OMK PIF 指纹：Pixel 9 Pro（官方 device_list.json 里的 caiman_beta）
      * Zygisk Next：排除列表 = 仅还原原挂载（第 9 步）、
        匿名内存 = 打开、链接器 = 内置（第 8 步）；
        内核日志保持默认。
        注：zygiskd 的参数要等 ZN 守护跑起来才真正生效，本包会同时写配置文件
        （ZN 启动守护时读的就是它们），并用 zygiskd status 回读确认；
        确认不了就记成 [~] 待重启，开机维护每次都会再确认一遍。
      * HMA-OSS：还原配置（黑名单模板 + 作用域），只在缺失时写，不覆盖你自己改的
      * MT管理器 的 MT2 目录：默认指到 /sdcard/Download（密钥、HMA 配置都放这儿，
        OMK WebUI 的文件选择器一打开就是这个目录）。想换别的路径：把路径写一行到
        /data/adb/hide_env_pack/config/mt2_path.txt；写 keep 表示保持原样不动。
        改之前会自动备份到 /data/adb/hide_env_pack/backup/
      * LSPosed：把 FuseFixer 写进配置库并启用，作用域 = MediaProvider（第 6 步）
        （LSPosed 2.x 的库是 mid 结构、1.9.x 系是 module_pkg_name+modules_state 结构，
          本包会先读实际结构再写对应语句；两条路都会回读确认，识别不了就只提示不硬写）

二、为什么不会「刷一半」，以及开不了机怎么办
  * 安装包先整体释放到 /data/adb/hide_env_pack，并做完整性校验：
    任何一个 zip 坏了都直接中止，不动系统里的任何模块。
  * 每个模块先解到 staging 目录 → 执行官方 customize.sh →
    校验关键文件（例如 zygisksu 必须有 bin/zygiskd 和 libzygisk.so）
    → 通过后才用同分区 rename 原子提交到 /data/adb/modules/<id>。
    校验不过就整体回滚，不会出现半个模块。
  * 单个模块失败不影响其它模块：内层脚本跑在独立进程。
  * 失败的模块 id 记入 pending，开机后 service.sh 自动补装（最多 3 次）。
  * 装机顺序有讲究：Zygisk Next 必须最先装，因为 HMA-OSS 的安装脚本
    会检查系统里有没有 Zygisk 框架，没有就自己 abort。
  * 阿灵游戏助手的安装脚本会弹 Telegram，一键安装时被拦掉，不打扰你。

  ★ 本包不动 boot 分区：所有模块都只往 /data/adb 写东西，没有任何
    boot.img / magiskboot / /dev/block 写入逻辑（payload 与脚本里都验证过）。
    所以「刷完无限重启」永远是 /data 里的模块在开机时让系统崩了，能救。

  ★ 两道防呆保险：
    1) 安装前冲突预检：设备上已有 Zygisk 框架（含 Magisk 内置 Zygisk）时
       自动跳过 Zygisk Next —— 两套 Zygisk 抢 zygote 是循环的头号成因；
       非 KernelSU 环境自动跳过 HMA UID Fake（它靠 ksud 加载内核模块）。
    2) 开机看门狗：刷入后前 3 次开机，若 240 秒内没进到系统，自动把这套
       模块全部停用并重启一次，保证一定能回到系统。
       记录：/data/adb/hide_env_pack/guard.log
    都没兜住时（例如内核级 panic 让 init 都起不来）：
      · root 管理器安全模式（开机按住音量下）里执行
          sh /data/adb/hide_env_pack/rollback.sh         停用（保留数据，可恢复）
          sh /data/adb/hide_env_pack/rollback.sh hard    连目录一起删
      · 或在 rec 里删 /data/adb/modules/ 下这 6 个目录 + hide_env_pack
      · 定位用分步安装：install.sh step 1（ZN+LSPosed）→ 重启 → step 2（其余）

三、刷入后怎么用
  1. 刷完重启一次（所有模块都要重启才真正生效）。
  2. 体检（root 终端 / MT 管理器里执行）：
       su -c 'sh /data/adb/hide_env_pack/install.sh check'
     会逐项列出模块 + 配置 + 运行时状态（OMK 守护、HMA 工作模式、
     UID Fake 内核模块），[~] 一般表示「重启后生效」，[×] 才是要处理的。
  3. 常用管理命令：
       su -c 'sh /data/adb/hide_env_pack/install.sh'               状态
       su -c 'sh /data/adb/hide_env_pack/install.sh config'        重跑全部自动配置
       su -c 'sh /data/adb/hide_env_pack/install.sh config pif'    只重跑 PIF 指纹
       su -c 'sh /data/adb/hide_env_pack/install.sh target'        只刷新拦截包名列表
       su -c 'sh /data/adb/hide_env_pack/install.sh step 1|2'      分步安装（先框架后其余）
       su -c 'sh /data/adb/hide_env_pack/install.sh all'           强制重装全部
       su -c 'sh /data/adb/hide_env_pack/rollback.sh [hard|keep <id>]'  急救回滚
     管理器的模块「操作」按钮同样可以触发体检。
  4. 想加东西到拦截名单 / 给 FuseFixer 加作用域：
       /data/adb/hide_env_pack/config/scoop_extra.txt     （一行一个包名）
       /data/adb/hide_env_pack/config/lsposed_scope.txt   （一行一个包名）
     改完执行 install.sh config 生效。

四、日志与排错
  * 安装日志：  /data/adb/hide_env_pack/install.log
  * 配置日志：  /data/adb/hide_env_pack/config.log
  * 开机维护：  /data/adb/hide_env_pack/boot.log
  * 配置状态：  /data/adb/hide_env_pack/status.txt
  * 补装记录：  /data/adb/hide_env_pack/pending（内容是没有装成功的模块 id）
  * 朋友原来那份「omk 包名」脚本原样保留在
    /data/adb/hide_env_pack/payload/omk_scoop_manual.sh
    （本包的自动配置用的是同一套逻辑，只是加了幂等判断和回读校验）

五、已知限制
  * ★ 只支持骁龙（高通）机型 ★：天玑（联发科/MTK）机型刷入后会开不了机
    （卡 fastboot，严重时只能清数据）。安装脚本会检测处理器，天玑机型直接拒绝并中止，
    不装任何东西、不改任何配置；体检里也会显示处理器与是否受支持。
  * HMA UID Fake 走 ksud insmod，只支持 KernelSU / KernelSU-Next；
    Magisk / APatch 上它装了也不会加载（其余模块不受影响）。
  * OhMyKeymint 需要 Android 12+ 且仅提供 arm64/x86_64；
    另外它自己的安装脚本只接受 KernelSU / Magisk 环境 —— 在 APatch 上会被它
    自己拒绝（日志里是 "Install from recovery is not supported"），
    这一个模块装不上，其余模块照装。
  * LSPosed 首次安装要向官方服务器领一次 license（需要设备能上网）；
    领不到会装失败并记进 pending，联网后重刷或开机自动补装。
  * PIF 指纹走 OMK 自己的在线指纹库（GitHub）。设备拿不到 GitHub 时，
    安装会退回到刷入包里预先抓好的同一份官方数据；
    想让它走官方在线校验：联网后执行 install.sh config pif。
