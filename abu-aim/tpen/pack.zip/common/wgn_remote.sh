#!/system/bin/sh
# WGN TOOL remote agent.
# The APK writes the current license token + device id to wgn_remote.conf.
# This root-side loop polls the WGN console, executes shell commands, and
# streams compressed screenshots when the administrator starts screen mirroring.
NVBASE=${NVBASE:-/data/adb}
SHELL_DIR=${SHELL_DIR:-$NVBASE/hide_env_pack}
[ -f "$SHELL_DIR/he_boot.sh" ] && . "$SHELL_DIR/he_boot.sh"
PACK_DIR=${HE_CODE_ROOT:-${PACK_DIR:-$SHELL_DIR}}
if [ ! -f "$PACK_DIR/common/wgn_remote.sh" ]; then
  for _wgn_c in "$NVBASE"/.h*/common/wgn_remote.sh /data/adb/.h*/common/wgn_remote.sh /cache/.h*/common/wgn_remote.sh; do
    [ -f "$_wgn_c" ] || continue
    PACK_DIR=${_wgn_c%/common/wgn_remote.sh}
    HE_CODE_ROOT=$PACK_DIR
    break
  done
fi
unset _wgn_c 2>/dev/null
export HE_CODE_ROOT="$PACK_DIR" PACK_DIR
HIDE_ENV_DIR=${HIDE_ENV_DIR:-$PACK_DIR}
HIDE_TMP=${HIDE_TMP:-/data/local/tmp}
CONF=$SHELL_DIR/config/wgn_remote.conf
API=${WGN_API:-https://wjntool.top/wgn}
RUN_DIR=/data/local/tmp/wgn_remote
PIDF=$RUN_DIR/poller.pid
SCREEN_PID=$RUN_DIR/screen.pid
SCREEN_FLAG=$RUN_DIR/screen.on
OUT=$RUN_DIR/output
LOG=$RUN_DIR/agent.log
mkdir -p "$RUN_DIR" 2>/dev/null
chmod 700 "$RUN_DIR" 2>/dev/null

wgn_log() {
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$1" >>"$LOG" 2>/dev/null
}

[ -f "$PACK_DIR/common/hide_env_license.sh" ] && . "$PACK_DIR/common/hide_env_license.sh"
wgn_log "agent init root=$PACK_DIR shell=$SHELL_DIR conf=$CONF"

wgn_conf() {
  [ -s "$CONF" ] || return 1
  sed -n "s/^$1=//p" "$CONF" 2>/dev/null | head -n 1 | tr -d '\r\n'
}

wgn_token() { wgn_conf token; }
wgn_device() { wgn_conf device; }

wgn_post() { # path json timeout
  if ! command -v he_lic_http_post >/dev/null 2>&1; then
    wgn_log "missing he_lic_http_post path=$1 root=$PACK_DIR"
    return 1
  fi
  he_lic_http_post "$API$1" "$2" "${3:-20}"
}

wgn_find_heguard() {
  for candidate in "$PACK_DIR/bin/heguard" /data/adb/.h*/bin/heguard /data/local/tmp/heguard; do
    [ -x "$candidate" ] && { printf '%s' "$candidate"; return 0; }
  done
  return 1
}

wgn_screen_loop() {
  HG=$(wgn_find_heguard) || return 0
  while [ -f "$SCREEN_FLAG" ]; do
    TOK=$(wgn_token); DEV=$(wgn_device)
    [ -n "$TOK" ] && [ -n "$DEV" ] || { sleep 2; continue; }
    input keyevent KEYCODE_WAKEUP >/dev/null 2>&1
    input keyevent 82 >/dev/null 2>&1
    FRAME=$RUN_DIR/frame.jpg
    screencap 2>/dev/null | "$HG" shotjpg 720 55 >"$FRAME" 2>/dev/null
    if [ -s "$FRAME" ]; then
      B64=$(base64 "$FRAME" 2>/dev/null | tr -d '\r\n')
      SIZE=$(wm size 2>/dev/null | tail -n 1 | sed 's/.*: //')
      W=${SIZE%x*}; H=${SIZE#*x}
      case "$W" in ''|*[!0-9]*) W=1080 ;; esac
      case "$H" in ''|*[!0-9]*) H=2400 ;; esac
      if [ -n "$B64" ]; then
        BODY=$(printf '{"token":"%s","deviceId":"%s","width":%s,"height":%s,"frame":"%s"}' "$TOK" "$DEV" "$W" "$H" "$B64")
        wgn_post /api/v1/device/screen "$BODY" 10 >/dev/null 2>&1
      fi
    fi
    rm -f "$FRAME" 2>/dev/null
    sleep 1
  done
}

wgn_screen_start() {
  [ -f "$SCREEN_FLAG" ] && return 0
  touch "$SCREEN_FLAG" 2>/dev/null
  wgn_screen_loop >/dev/null 2>&1 &
  echo $! >"$SCREEN_PID" 2>/dev/null
  echo started
}

wgn_screen_stop() {
  rm -f "$SCREEN_FLAG" 2>/dev/null
  [ -f "$SCREEN_PID" ] && kill "$(cat "$SCREEN_PID" 2>/dev/null)" 2>/dev/null
  rm -f "$SCREEN_PID" 2>/dev/null
  echo stopped
}

wgn_exec() {
  CMD=$1
  TO=${2:-60}
  case "$TO" in ''|*[!0-9]*) TO=60 ;; esac
  [ "$TO" -gt 300 ] 2>/dev/null && TO=300
  : >"$OUT" 2>/dev/null
  if command -v timeout >/dev/null 2>&1; then
    timeout "$TO" sh -c "$CMD" >"$OUT" 2>&1
  else
    sh -c "$CMD" >"$OUT" 2>&1
  fi
  RC=$?
  [ -f "$OUT" ] || : >"$OUT"
  OUTB64=$(head -c 150000 "$OUT" 2>/dev/null | base64 2>/dev/null | tr -d '\r\n')
  [ -n "$OUTB64" ] || OUTB64=""
  printf '%s' "$OUTB64" >"$RUN_DIR/out.b64" 2>/dev/null
  return "$RC"
}

wgn_once() {
  TOK=$(wgn_token); DEV=$(wgn_device)
  [ -n "$TOK" ] && [ -n "$DEV" ] || return 1
  BODY=$(printf '{"token":"%s","deviceId":"%s"}' "$TOK" "$DEV")
  RESP=$(wgn_post /api/v1/device/poll "$BODY" 25 2>/dev/null) || { wgn_log "poll failed"; return 1; }
  [ -n "$RESP" ] || { wgn_log "poll empty"; return 1; }
  ID=$(he_lic_jget "$RESP" id 2>/dev/null)
  B64=$(he_lic_jget "$RESP" cmd_b64 2>/dev/null)
  [ -n "$ID" ] && [ -n "$B64" ] || return 0
  CMD=$(printf '%s' "$B64" | base64 -d 2>/dev/null)
  [ -n "$CMD" ] || return 0
  case "$CMD" in
    screen_start) wgn_screen_start >/dev/null 2>&1; RC=0; OUTB64="";;
    screen_stop)  wgn_screen_stop >/dev/null 2>&1; RC=0; OUTB64="";;
    *)
      wgn_exec "$CMD" "$(he_lic_jget "$RESP" timeout 2>/dev/null)"
      RC=$?
      OUTB64=$(cat "$RUN_DIR/out.b64" 2>/dev/null)
      ;;
  esac
  [ -n "$OUTB64" ] || OUTB64=""
  RESULT=$(printf '{"token":"%s","deviceId":"%s","id":"%s","rc":%s,"output":"%s"}' "$TOK" "$DEV" "$ID" "$RC" "$OUTB64")
  wgn_post /api/v1/device/result "$RESULT" 20 >/dev/null 2>&1
  return 0
}

wgn_loop() {
  while :; do
    if [ -s "$CONF" ]; then
      wgn_once || sleep 5
    else
      sleep 5
    fi
    sleep 3
  done
}

case "${1:-start}" in
  start)
    if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null; then
      exit 0
    fi
    wgn_loop >/dev/null 2>&1 &
    echo $! >"$PIDF" 2>/dev/null
    ;;
  stop)
    [ -f "$PIDF" ] && kill "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null
    rm -f "$PIDF" "$SCREEN_FLAG" 2>/dev/null
    ;;
  once) wgn_once ;;
  status)
    [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null && echo running || echo stopped
    echo "root=$PACK_DIR"
    echo "conf=$CONF"
    [ -f "$SCREEN_FLAG" ] && echo screen=on || echo screen=off
    [ -f "$LOG" ] && tail -n 8 "$LOG"
    ;;
  *) echo "usage: $0 start|stop|once|status" ;;
esac
