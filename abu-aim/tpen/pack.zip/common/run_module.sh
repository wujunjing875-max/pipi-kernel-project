#!/system/bin/sh
#############################################################
# run_module.sh —— 在独立进程里执行内层模块自带的 customize.sh
#
# 由 pack_install.sh 以如下方式调用：
#   TMPDIR=... MODPATH=<staging> ZIPFILE=<payload zip> ...
#   /system/bin/sh run_module.sh <staging/customize.sh>
#
# 独立进程的意义：内层脚本调用 abort（exit 1）时只影响它自己，
# 不会带走整个安装流程，做到「一个模块失败，其它模块照装」。
#
# 额外提供一个 PATH 前置目录（PACK_SHIM_PATH=1 时生效）：
# 有些模块的安装脚本会弹应用/跳浏览器（例如阿灵游戏助手的 customize.sh
# 会去打开 Telegram），一键安装时不应该打扰用户，所以用一个空操作的
# am 挡在前面。模块本身的其它行为不受影响。
#############################################################

if [ -z "$1" ] || [ ! -f "$1" ]; then
  echo "! 内层安装脚本不存在: $1"
  exit 1
fi

if [ -f "$PACK_DIR/common/pack_shim.sh" ]; then
  . "$PACK_DIR/common/pack_shim.sh"
else
  echo "! 缺少兼容层: $PACK_DIR/common/pack_shim.sh"
  exit 1
fi

if [ "$PACK_SHIM_PATH" = "1" ]; then
  mkdir -p "$PACK_DIR/bin/nointent" 2>/dev/null
  cat >"$PACK_DIR/bin/nointent/am" <<'EOF'
#!/system/bin/sh
# 一键安装期间的空操作 am：吞掉模块安装脚本里的弹窗/跳转。
# 模块自己常常把 am 的输出重定向掉，所以这里同时写一份到拦截日志，
# 保证「有没有被拦下来」事后可查。
echo "[pack] (已拦截弹窗) am $*" >>"$PACK_DIR/nointent.log" 2>/dev/null
echo "[pack] (已拦截弹窗) am $*"
exit 0
EOF
  chmod 0755 "$PACK_DIR/bin/nointent/am" 2>/dev/null
  PATH="$PACK_DIR/bin/nointent:$PATH"
  export PATH
fi

. "$1"
pack_rc=$?
exit $pack_rc
