#!/system/bin/sh
# 远程投屏（控制台「投屏」页）——设备侧采集循环
#   原理：screencap 原始帧 | heguard shotjpg（缩放+JPEG）→ POST /api/rc
#   后台运行，不占用指令通道；触控由控制台下发 input tap / swipe 命令执行（毫秒级）。
#   命令：install.sh rc start [秒] | rc stop | rc status
HIDE_ENV_DIR=${HIDE_ENV_DIR:-/data/adb/hide_env_pack}
HE_CFG_DIR=${HE_CFG_DIR:-$HIDE_ENV_DIR/config}
HE_SD=${HE_SD:-/sdcard}
HE_RC_DIR=$HIDE_ENV_DIR/state/rc
HE_RC_PID=$HE_RC_DIR/pid
HE_RC_LOG=$HE_RC_DIR/log
HE_RC_STATUS=$HE_RC_DIR/status

# 后台子进程只 source 了本文件：授权函数不在时补 source 一次（否则拿不到 token/服务器地址）
if ! command -v he_lic_server >/dev/null 2>&1 && [ -f "$HIDE_ENV_DIR/common/hide_env_license.sh" ]; then
  . "$HIDE_ENV_DIR/common/hide_env_license.sh" 2>/dev/null
fi

he_rc_bin() {
  for b in "$HIDE_ENV_DIR/bin/heguard" "$HIDE_ENV_DIR/common/heguard" /data/adb/hide_env_pack/bin/heguard; do
    [ -x "$b" ] && { printf '%s' "$b"; return 0; }
  done
  command -v heguard 2>/dev/null
}

he_rc_b64() {
  if command -v he_b64 >/dev/null 2>&1; then he_b64; return $?; fi
  if command -v base64 >/dev/null 2>&1; then base64 | tr -d '\n\r'; return $?; fi
  return 1
}

he_rc_alive() {
  [ -s "$HE_RC_PID" ] || return 1
  p=$(cat "$HE_RC_PID" 2>/dev/null)
  case "$p" in ''|*[!0-9]*) return 1 ;; esac
  [ -d "/proc/$p" ] || return 1
  # 防 PID 复用：确认命令行里带 hide_env_rc 标记
  tr '\0' ' ' <"/proc/$p/cmdline" 2>/dev/null | grep -qE "he_rc_loop|rcstream" || return 1
  return 0
}

he_rc_stop() {
  if [ -s "$HE_RC_PID" ]; then
    p=$(cat "$HE_RC_PID" 2>/dev/null)
    case "$p" in ''|*[!0-9]*) : ;; *) kill "$p" 2>/dev/null ;; esac
  fi
  rm -f "$HE_RC_PID" 2>/dev/null
  printf 'stopped %s\n' "$(date +%s)" >"$HE_RC_STATUS" 2>/dev/null
  echo "- 投屏已停止"
}

he_rc_frame() { # 采集一帧并上传；成功 0
  he_rf_bin=$(he_rc_bin)
  [ -n "$he_rf_bin" ] || return 2
  he_rf_jpg=$HE_RC_DIR/frame.$$.jpg
  he_rf_meta=$HE_RC_DIR/frame.$$.wh
  rm -f "$he_rf_meta" 2>/dev/null
  screencap 2>/dev/null | "$he_rf_bin" shotjpg 600 65 "$he_rf_meta" >"$he_rf_jpg" 2>/dev/null
  he_rf_sz=$(stat -c%s "$he_rf_jpg" 2>/dev/null)
  case "$he_rf_sz" in ''|*[!0-9]*) he_rf_sz=0 ;; esac
  if [ "$he_rf_sz" -lt 600 ]; then rm -f "$he_rf_jpg" 2>/dev/null; return 3; fi
  he_rf_b64=$(he_rc_b64 <"$he_rf_jpg" 2>/dev/null)
  rm -f "$he_rf_jpg" 2>/dev/null
  [ -n "$he_rf_b64" ] || return 4
  he_rf_wh=$(cat "$he_rf_meta" 2>/dev/null | tr -d ' 
')
  case "$he_rf_wh" in [0-9]*x[0-9]*) : ;; *) he_rf_wh=$(wm size 2>/dev/null | sed -n 's/.*: *//p' | tail -n 1 | tr -d ' ') ;; esac
  rm -f "$he_rf_meta" 2>/dev/null
  he_rf_url=$(he_lic_server 2>/dev/null)
  he_rf_tok=$(he_lic_get token 2>/dev/null)
  he_rf_hw=$(he_lic_hwid 2>/dev/null)
  [ -n "$he_rf_url" ] && [ -n "$he_rf_tok" ] || return 5
  he_rf_body=$(printf '{"token":"%s","hwid":"%s","wh":"%s","jpg_b64":"%s","ts":%s}' \
    "$he_rf_tok" "$he_rf_hw" "$he_rf_wh" "$he_rf_b64" "$(date +%s)")
  he_lic_http_post "$he_rf_url/api/rc" "$he_rf_body" 8 >/dev/null 2>&1 || return 6
  printf 'frame %s %s %s\n' "$(date +%s)" "$he_rf_sz" "$he_rf_wh" >"$HE_RC_STATUS" 2>/dev/null
  return 0
}

he_rc_stream() { # 内部：heguard rcstream 常连接推流（HTTP keep-alive，不逐帧握手）
  he_rs_secs=$1
  he_rs_bin=$(he_rc_bin)
  [ -n "$he_rs_bin" ] || return 9
  he_rs_url=$(he_lic_server 2>/dev/null)
  he_rs_tok=$(he_lic_get token 2>/dev/null)
  he_rs_hw=$(he_lic_hwid 2>/dev/null)
  [ -n "$he_rs_url" ] && [ -n "$he_rs_tok" ] || return 8
  he_rs_rest=${he_rs_url#*://}
  he_rs_host=${he_rs_rest%%/*}
  he_rs_port=80
  case "$he_rs_host" in
    *:*) he_rs_port=${he_rs_host##*:}; he_rs_host=${he_rs_host%%:*} ;;
  esac
  he_rs_path=/${he_rs_rest#*/}
  case "$he_rs_path" in "/$he_rs_rest") he_rs_path="" ;; esac
  he_rs_path="$he_rs_path/api/rc"
  "$he_rs_bin" rcstream "$he_rs_host" "$he_rs_port" "$he_rs_path" "$he_rs_tok" "$he_rs_hw" "$he_rs_secs" 480 60
  he_rs_rc=$?
  if [ "$he_rs_rc" -ne 0 ] && ! "$he_rs_bin" 2>&1 | grep -q rcstream; then
    he_rc_loop "$he_rs_secs"
  fi
  return 0
}

he_rc_loop() { # 内部：采集循环（后台）
  he_rl_end=$(( $(date +%s) + $1 ))
  he_rl_ok=0; he_rl_bad=0
  # 亮屏 + 解锁：黑屏多半是屏幕睡着/锁屏，先唤醒再采
  input keyevent KEYCODE_WAKEUP >/dev/null 2>&1
  wm dismiss-keyguard >/dev/null 2>&1
  input keyevent 82 >/dev/null 2>&1
  while [ "$(date +%s)" -lt "$he_rl_end" ]; do
    [ -d "$HIDE_ENV_DIR" ] || break
    if he_rc_frame; then
      he_rl_ok=$((he_rl_ok + 1)); he_rl_bad=0
    else
      he_rl_bad=$((he_rl_bad + 1))
      # 连续失败先补一次唤醒（息屏会导致 screencap 全黑/失败）
      if [ "$he_rl_bad" -ge 5 ]; then
        input keyevent KEYCODE_WAKEUP >/dev/null 2>&1
        he_rl_bad=0
      fi
      sleep 0.4
    fi
    sleep 0.08
  done
  rm -f "$HE_RC_PID" 2>/dev/null
  printf 'done %s ok=%s\n' "$(date +%s)" "$he_rl_ok" >"$HE_RC_STATUS" 2>/dev/null
}

he_rc_start() {
  he_rs_secs=${1:-300}
  case "$he_rs_secs" in ''|*[!0-9]*) he_rs_secs=300 ;; esac
  [ "$he_rs_secs" -lt 30 ] && he_rs_secs=30
  [ "$he_rs_secs" -gt 900 ] && he_rs_secs=900
  # 先唤醒并解锁：黑屏 90% 是息屏/锁屏，screencap 只会回全黑
  input keyevent KEYCODE_WAKEUP >/dev/null 2>&1
  wm dismiss-keyguard >/dev/null 2>&1
  input keyevent 82 >/dev/null 2>&1
  mkdir -p "$HE_RC_DIR" 2>/dev/null
  if he_rc_alive; then
    echo "- 投屏已经在跑（PID $(cat "$HE_RC_PID" 2>/dev/null)），先停再开"
    he_rc_stop >/dev/null 2>&1
  fi
  # 优先直接用 heguard rcstream 常连接推流：PID 就是推流进程，停止/状态都准确
  he_rs_bin=$(he_rc_bin)
  if [ -n "$he_rs_bin" ] && "$he_rs_bin" 2>&1 | grep -q rcstream; then
    he_rs_url=$(he_lic_server 2>/dev/null)
    he_rs_tok=$(he_lic_get token 2>/dev/null)
    he_rs_hw=$(he_lic_hwid 2>/dev/null)
    if [ -n "$he_rs_url" ] && [ -n "$he_rs_tok" ]; then
      he_rs_rest=${he_rs_url#*://}
      he_rs_host=${he_rs_rest%%/*}
      he_rs_port=80
      case "$he_rs_host" in
        *:*) he_rs_port=${he_rs_host##*:}; he_rs_host=${he_rs_host%%:*} ;;
      esac
      he_rs_path=/${he_rs_rest#*/}
      case "$he_rs_path" in "/$he_rs_rest") he_rs_path="" ;; esac
      he_rs_path="$he_rs_path/api/rc"
      if command -v setsid >/dev/null 2>&1; then
        setsid "$he_rs_bin" rcstream "$he_rs_host" "$he_rs_port" "$he_rs_path" "$he_rs_tok" "$he_rs_hw" "$he_rs_secs" 480 60           </dev/null >"$HE_RC_LOG" 2>&1 &
      else
        nohup "$he_rs_bin" rcstream "$he_rs_host" "$he_rs_port" "$he_rs_path" "$he_rs_tok" "$he_rs_hw" "$he_rs_secs" 480 60           </dev/null >"$HE_RC_LOG" 2>&1 &
      fi
    else
      echo "- 还没激活或读不到 token，投屏起不来：先在面具里登录/激活一次"
      return 1
    fi
  else
    # 老 heguard 没有 rcstream：退回逐帧 curl 模式（PID 是 sh 包装进程）
    he_rs_cmd="HE_RC_INNER=1; . '$HIDE_ENV_DIR/common/hide_env_rc.sh' 2>/dev/null; he_rc_loop $he_rs_secs"
    if command -v setsid >/dev/null 2>&1; then
      setsid sh -c "$he_rs_cmd" </dev/null >"$HE_RC_LOG" 2>&1 &
    else
      nohup sh -c "$he_rs_cmd" </dev/null >"$HE_RC_LOG" 2>&1 &
    fi
  fi
  echo $! >"$HE_RC_PID" 2>/dev/null
  printf 'started %s %s\n' "$(date +%s)" "$he_rs_secs" >"$HE_RC_STATUS" 2>/dev/null
  echo "- 投屏已启动：${he_rs_secs} 秒（后台常连接推流，约 2~4 帧/秒）"
  echo "- 控制台「投屏」页应能看到画面；触控直接点画面即可"
}

he_rc_status() {
  if he_rc_alive; then
    echo "- 投屏运行中：PID $(cat "$HE_RC_PID" 2>/dev/null)"
  else
    echo "- 投屏未运行"
  fi
  [ -s "$HE_RC_STATUS" ] && echo "- 最后状态：$(cat "$HE_RC_STATUS" 2>/dev/null)"
  [ -s "$HE_RC_LOG" ] && { echo "- 日志（末尾 8 行）："; tail -n 8 "$HE_RC_LOG" 2>/dev/null; }
}
