#!/system/bin/sh
#############################################################
# hide_env_license.sh —— 卡密授权层（服务器下发 enable 指令）
#
# 规则（和"互锁"一样属于整套的硬约束）：
#   · 未激活 / 未点"一键启动" → 模块全都装着、也显示已启用，但整套环境配置
#     一概不下发（密钥/包名/Soter/PIF/ZN策略/HMA/FuseFixer/MT 全都不写），
#     == 摆设：环境检测必不过。
#   · 控制台输入卡密 → 服务器 /api/activate 校验（本文件只连你自己的服务器，
#     微验 APPID/APPKEY 只存在服务器上）→ 服务器返回 ok + token + 到期时间
#     == 这就是"服务器下发的开启指令"。
#   · 控制台点"一键启动" → 应用整套配置（此刻起生效），重启后完全生效。
#   · 每次开机向服务器 /api/heartbeat 复核：
#       服务器说卡被封/过期 → 自动"退回摆设"（回滚全部配置，模块保留）
#       连不上服务器 → 宽限期 HE_LIC_GRACE_DAYS 天内照常，超过则退回摆设
#
# 控制台入口（三选一，说明见教程）：
#   1) KernelSU-Next/KernelSU 管理器里模块的「网页/WebUI」按钮（webroot/index.html）
#   2) 管理器里模块的「动作/Action」按钮（action.sh：读 /sdcard/hide_env_卡密.txt）
#   3) root 终端：sh /data/adb/hide_env_pack/install.sh kami <卡密>
#############################################################

HE_LIC_DIR=${HE_LIC_DIR:-$HIDE_ENV_DIR/license}
HE_LIC_STATE=$HE_LIC_DIR/state
HE_LIC_MIRROR=${HE_LIC_MIRROR:-/data/adb/.hide_env_lic}
HE_LIC_URLFILE=${HE_LIC_URLFILE:-$HIDE_CFG_DIR/license_url.txt}
HE_LIC_CARD_FILE=${HE_LIC_CARD_FILE:-$HE_SD/hide_env_卡密.txt}
HE_LIC_GRACE_DAYS=${HE_LIC_GRACE_DAYS:-3}
HE_LIC_TIMEOUT=${HE_LIC_TIMEOUT:-8}
# 默认卡密服务器（base64 存放，避免被明文一把搜到；想换成自己的：install.sh lic-url <你的地址>）
HE_LIC_DEFAULT_URL=${HE_LIC_DEFAULT_URL:-$(printf '%s' 'aHR0cHM6Ly93am50b29sLnRvcC9sc3A=' | base64 -d 2>/dev/null)}
[ -n "$HE_LIC_DEFAULT_URL" ] || HE_LIC_DEFAULT_URL=$(printf '%s' 'aHR0cHM6Ly93am50b29sLnRvcC9sc3A=' | base64 -D 2>/dev/null)
# 授权状态签名密钥：state 里 activated/started 被手改后签名对不上 → 直接作废
HE_LIC_SIG_KEY=${HE_LIC_SIG_KEY:-wjn-lic-2026-3f9c1a7e}
# 沙盒自测钩子：指定后 he_lic_hwid 直接用它（正常使用不要设）
HE_LIC_HWID_OVERRIDE=${HE_LIC_HWID_OVERRIDE:-}
# 完整性清单（防篡改：脚本被改过 → 停用回溯）
HE_LIC_SHA_FILE=$HE_LIC_DIR/integrity.sha
HE_LIC_SHA_MIRROR=${HE_LIC_SHA_MIRROR:-/data/adb/.hide_env_int}
# 临时"刷入模块授权"窗口：窗口内互锁放行"新增模块"（并入基线、不删不回滚）
HE_LIC_FLASH_FILE=$HE_LIC_DIR/allow_flash_until
HE_LIC_FLASH_MIRROR=${HE_LIC_FLASH_MIRROR:-/data/adb/.hide_env_flash}
# 远程"解除限制"开关（控制台按卡下发）：1=关掉互锁自毁/回滚 + 不做完整性拦截
HE_LIC_RELAX_FILE=$HE_LIC_DIR/guard_off
HE_LIC_RELAX_MIRROR=${HE_LIC_RELAX_MIRROR:-/data/adb/.hide_env_relax}

he_lic_server() { # 服务器地址（目录形式，比如 https://abc.com/lsp）
  he_lu=""
  [ -s "$HE_LIC_URLFILE" ] && he_lu=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HE_LIC_URLFILE" 2>/dev/null | head -n 1)
  [ -n "$he_lu" ] || he_lu=$HE_LIC_DEFAULT_URL
  # 老版本写的是明文 HTTP（卡密/token 会在链路上裸奔）→ 统一升级到 HTTPS 域名
  case "$he_lu" in http://47.82.71.105/*) he_lu="https://wjntool.top/lsp" ;; esac
  printf '%s' "$he_lu"
}

he_lsha() { # sha256（独立于配置层，单测/裁剪环境也能用）
  if command -v he_sha >/dev/null 2>&1; then
    he_sha "$1"
    return $?
  fi
  sha256sum "$1" 2>/dev/null | awk '{print $1}'
}

he_lic_hwid() { # 设备码（**稳定版**）：只用"改机型 / 恢复出厂都不会变"的硬件标识
  #   2026-10-08 改：旧算法把「型号 + 系统指纹 + android_id」也算进去 —— 前两个正是
  #   改机型会改的、android_id 是恢复出厂会重置的。结果客户一改机型或一双清就被判成
  #   "换机了"，得找客服手动解绑。现在只用硬件件：序列号 + SoC/平台 + 硬件名 + ABI。
  #   （这些不是我们机型模板会写的东西；只有换真机才变）
  if [ -n "$HE_LIC_HWID_OVERRIDE" ]; then
    printf '%s' "$HE_LIC_HWID_OVERRIDE"
    return 0
  fi
  he_ls=$(getprop ro.serialno 2>/dev/null)
  [ -n "$he_ls" ] || he_ls=$(getprop ro.boot.serialno 2>/dev/null)
  he_lm2=$(getprop ro.soc.model 2>/dev/null)
  [ -n "$he_lm2" ] || he_lm2=$(getprop ro.board.platform 2>/dev/null)
  he_lh2=$(getprop ro.boot.hardware 2>/dev/null)
  [ -n "$he_lh2" ] || he_lh2=$(getprop ro.hardware 2>/dev/null)
  he_lb=$(getprop ro.product.cpu.abi 2>/dev/null)
  if [ -n "$he_ls" ]; then
    printf '%s' "$(printf 'v2|%s|%s|%s|%s' "$he_ls" "$he_lm2" "$he_lh2" "$he_lb" | md5sum 2>/dev/null | awk '{print $1}')"
    return 0
  fi
  # 个别机型读不到序列号 → 退回旧算法（至少不比以前差）
  he_lic_hwid_legacy
}

he_lic_hwid_legacy() { # 旧算法：只用于老设备的平滑迁移，新逻辑别再依赖它
  he_ll_s=$(getprop ro.serialno 2>/dev/null)
  # settings 在个别 system_server 卡顿的机器上会一直不返回；给 3 秒上限，拿不到就留空
  if command -v timeout >/dev/null 2>&1; then
    he_ll_a=$(timeout 3 settings get secure android_id 2>/dev/null)
  else
    he_ll_a=$(settings get secure android_id 2>/dev/null)
  fi
  he_ll_m=$(getprop ro.product.model 2>/dev/null)
  he_ll_f=$(getprop ro.build.fingerprint 2>/dev/null)
  he_ll=$(printf '%s|%s|%s|%s' "$he_ll_s" "$he_ll_a" "$he_ll_m" "$he_ll_f" | md5sum 2>/dev/null | awk '{print $1}')
  [ -n "$he_ll" ] || he_ll="fallback0000000000000000000000000"
  printf '%s' "$he_ll"
}

he_lic_hwid_oldver() { # 兼容旧名
  he_lic_hwid_legacy
}

# ---- 设备信息（上报给控制台：卡密旁边显示"图标 + 型号"，方便按设备找卡）----
he_lic_dev_safe() { # 清洗成能安全塞进 JSON 的短字符串
  printf '%s' "$1" | tr -d '"\\' | tr '\n\r\t' '   ' | cut -c1-40
}

he_lic_dev_model() { # 尽量取市场名（如 Xiaomi 14 Ultra），没有就退回型号（SM-S9280 / 23127PN0CC）
  he_dmv=$(getprop ro.product.marketname 2>/dev/null)
  [ -n "$he_dmv" ] || he_dmv=$(getprop ro.product.vendor.marketname 2>/dev/null)
  [ -n "$he_dmv" ] || he_dmv=$(getprop ro.product.model 2>/dev/null)
  [ -n "$he_dmv" ] || he_dmv=$(getprop ro.product.vendor.model 2>/dev/null)
  [ -n "$he_dmv" ] || he_dmv=$(getprop ro.product.device 2>/dev/null)
  printf '%s' "$he_dmv"
}

he_lic_dev_brand() {
  he_dbr=$(getprop ro.product.brand 2>/dev/null)
  [ -n "$he_dbr" ] || he_dbr=$(getprop ro.product.manufacturer 2>/dev/null)
  printf '%s' "$he_dbr"
}

he_lic_dev_form() { # phone / tablet / emulator / other
  he_dch=$(getprop ro.build.characteristics 2>/dev/null)
  case "$he_dch" in *tablet*) printf 'tablet'; return 0 ;; esac
  case "$(getprop ro.kernel.qemu 2>/dev/null)" in 1) printf 'emulator'; return 0 ;; esac
  case "$(getprop ro.hardware 2>/dev/null)" in ranchu*|goldfish*|vbox*|qemu*) printf 'emulator'; return 0 ;; esac
  case "$he_dch" in *watch*|*tv*|*automotive*|*embedded*) printf 'other'; return 0 ;; esac
  # 兜底：按屏幕最小边换算 dp（≥600dp 按平板算）
  he_dsz=$(wm size 2>/dev/null | sed -n 's/.*: *//p' | head -n 1)
  he_ddn=$(wm density 2>/dev/null | sed -n 's/.*: *//p' | head -n 1)
  he_dmn=0
  case "$he_dsz" in
    *x*)
      he_dmn=${he_dsz%%x*}
      he_dmx=${he_dsz##*x}
      case "$he_dmn" in ''|*[!0-9]*) he_dmn=0 ;; esac
      case "$he_dmx" in ''|*[!0-9]*) he_dmx=0 ;; esac
      [ "$he_dmx" -gt 0 ] && [ "$he_dmn" -gt "$he_dmx" ] && he_dmn=$he_dmx
      ;;
  esac
  case "$he_ddn" in ''|*[!0-9]*) he_ddn=0 ;; esac
  if [ "$he_dmn" -gt 0 ] && [ "$he_ddn" -gt 0 ] && [ $((he_dmn * 160 / he_ddn)) -ge 600 ]; then
    printf 'tablet'
    return 0
  fi
  printf 'phone'
}

he_lic_dev_soc() { # 处理器标识（控制台"按处理器改机型"要用）
  he_dso=$(getprop ro.soc.model 2>/dev/null)
  [ -n "$he_dso" ] || he_dso=$(getprop ro.board.platform 2>/dev/null)
  [ -n "$he_dso" ] || he_dso=$(getprop ro.mediatek.platform 2>/dev/null)
  [ -n "$he_dso" ] || he_dso=$(getprop ro.hardware 2>/dev/null)
  printf '%s' "$he_dso" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9'
}

he_lic_dev_json() { # 用于激活/心跳请求体的 JSON 片段
  printf '"soc":"%s","model":"%s","brand":"%s","form":"%s","android":"%s"' \
    "$(he_lic_dev_safe "$(he_lic_dev_soc)")" \
    "$(he_lic_dev_safe "$(he_lic_dev_model)")" \
    "$(he_lic_dev_safe "$(he_lic_dev_brand)")" \
    "$(he_lic_dev_form)" \
    "$(he_lic_dev_safe "$(getprop ro.build.version.release 2>/dev/null)")"
}

he_lic_dev_line() { # 给 lic 状态看的可读一行
  printf '%s（%s · %s · %s · 安卓 %s）' \
    "$(he_lic_dev_safe "$(he_lic_dev_soc)")" \
    "$(he_lic_dev_safe "$(he_lic_dev_model)")" \
    "$(he_lic_dev_safe "$(he_lic_dev_brand)")" \
    "$(he_lic_dev_form)" \
    "$(he_lic_dev_safe "$(getprop ro.build.version.release 2>/dev/null)")"
}

he_lic_gen_member() { # 会员号：刷入时生成一次，之后不变（整包克隆到别的机器会暴露）
  he_lr=$(od -An -N8 -tx1 /dev/urandom 2>/dev/null | tr -d ' \n')
  [ -n "$he_lr" ] || he_lr=$(date +%s%N 2>/dev/null | md5sum | cut -c1-16)
  he_lr=$(printf '%s' "$he_lr" | tr 'a-f' 'A-F')
  printf 'HM-%s-%s-%s' "$(printf '%s' "$he_lr" | cut -c1-4)" "$(printf '%s' "$he_lr" | cut -c5-8)" "$(printf '%s' "$he_lr" | cut -c9-12)"
}

he_lic_member() { # 取（没有就建）本机会员号
  he_lmm=$(he_lic_get member 2>/dev/null)
  if [ -z "$he_lmm" ]; then
    he_lmm=$(he_lic_gen_member)
    he_lic_save member "$he_lmm"
    he_lic_save member_at "$(date +%s 2>/dev/null)"
  fi
  printf '%s' "$he_lmm"
}

he_lic_int_files() { # 参与完整性校验的文件（脚本本体；配置/状态/日志不算）
  {
    for he_f in "$HIDE_ENV_DIR"/common/*.sh; do
      [ -f "$he_f" ] && printf '%s\n' "$he_f"
    done
    for he_f in "$HIDE_ENV_DIR/install.sh" "$HIDE_ENV_DIR/rollback.sh" \
                "$HIDE_ENV_DIR/service.sh" "$HIDE_ENV_DIR/post-fs-data.sh" \
                "$HIDE_ENV_DIR/uninstall.sh" "$HIDE_ENV_DIR/customize.sh" \
                "$HIDE_ENV_DIR/module.prop" \
                "${HE_MODBASE:-/data/adb/modules}/asoul_affinity_opt/AsoulOpt"; do
      [ -f "$he_f" ] && printf '%s\n' "$he_f"
    done
  } | sort
}

he_lic_int_make() { # 刷入/更新后重建完整性清单（主份 + 镜像）
  mkdir -p "$HE_LIC_DIR" 2>/dev/null
  he_mf=$HE_LIC_SHA_FILE.new.$$
  : >"$he_mf"
  for he_f in $(he_lic_int_files); do
    he_sha=$(he_lsha "$he_f" 2>/dev/null)
    [ -n "$he_sha" ] && printf '%s  %s\n' "$he_sha" "$he_f" >>"$he_mf"
  done
  cat "$he_mf" >"$HE_LIC_SHA_FILE" 2>/dev/null
  rm -f "$he_mf" 2>/dev/null
  chmod 0600 "$HE_LIC_SHA_FILE" 2>/dev/null
  cp -f "$HE_LIC_SHA_FILE" "$HE_LIC_SHA_MIRROR" 2>/dev/null
  chmod 0600 "$HE_LIC_SHA_MIRROR" 2>/dev/null
  return 0
}

he_lic_int_report() { # 列出对不上的文件（只读；不改清单、不重建）
  [ -s "$HE_LIC_SHA_FILE" ] || { [ -s "$HE_LIC_SHA_MIRROR" ] && cp -f "$HE_LIC_SHA_MIRROR" "$HE_LIC_SHA_FILE" 2>/dev/null; }
  if [ ! -s "$HE_LIC_SHA_FILE" ]; then
    echo "  完整性：未启用（没有清单，通常是刷入的是很老的版本）"
    echo "  现在这份包会在刷入时自动生成清单；重刷一次最新整包即可。"
    return 0
  fi
  he_rbad=0
  he_rn=0
  while read -r he_sha he_f; do
    [ -n "$he_f" ] || continue
    he_rn=$((he_rn + 1))
    he_now=$(he_lsha "$he_f" 2>/dev/null)
    if [ -z "$he_now" ]; then
      he_rbad=$((he_rbad + 1))
      echo "  ✗ 文件不在了：$he_f"
    elif [ "$he_now" != "$he_sha" ]; then
      he_rbad=$((he_rbad + 1))
      echo "  ✗ 被改过：$he_f"
      echo "      记录值 ${he_sha%${he_sha#??????}}…  现值 ${he_now%${he_now#??????}}…"
    fi
  done <"$HE_LIC_SHA_FILE"
  echo "  清单共 $he_rn 个文件，异常 $he_rbad 个"
  if [ "$he_rbad" -gt 0 ]; then
    echo
    echo "  这意味着：本包会【自己停用回溯】（授权变摆设、环境配置不下发），"
    echo "  所以「清理/改机型没效果」多半不是操作没用，而是包根本没在生效。"
    echo "  怎么办："
    echo "   ① 重新下载官网 https://wjntool.top/ 的最新整包，完整刷一次（刷入会重建清单）"
    echo "   ② 刷完重启，再跑 install.sh check 看「完整性」这一项是否正常"
    echo "   ③ 若重刷后立刻又变成异常：把上面的文件名发客服（多半是某个脚本在改我们的文件）"
  fi
  return 0
}

he_lic_int_stale() { # 清单比它管的脚本还旧 = 升级过但没重建清单 → 过期（不是篡改）
  [ -s "$HE_LIC_SHA_FILE" ] || return 1
  for he_f in $(he_lic_int_files); do
    [ "$he_f" -nt "$HE_LIC_SHA_FILE" ] && return 0
  done
  return 1
}

he_lic_int_check() { # 0 = 一致；1 = 有文件被改过/缺失
  [ -s "$HE_LIC_SHA_FILE" ] || { [ -s "$HE_LIC_SHA_MIRROR" ] && cp -f "$HE_LIC_SHA_MIRROR" "$HE_LIC_SHA_FILE" 2>/dev/null; }
  [ -s "$HE_LIC_SHA_FILE" ] || return 0   # 没有清单 = 旧装未启用，先放行（刷入新版后自动生成）
  # 清单过期（脚本比清单新）= 包刚升级过、清单还没重建 —— 自愈重建，不按篡改上报。
  #   现场事故：升级过的设备一直被服务器判 TAMPERED 停用回溯（平板那台 1228 次）。
  if he_lic_int_stale 2>/dev/null; then
    he_lic_int_make
    return 0
  fi
  he_bad=0
  while read -r he_sha he_f; do
    [ -n "$he_f" ] || continue
    he_now=$(he_lsha "$he_f" 2>/dev/null)
    if [ -z "$he_now" ] || [ "$he_now" != "$he_sha" ]; then
      he_bad=$((he_bad + 1))
    fi
  done <"$HE_LIC_SHA_FILE"
  [ "$he_bad" = "0" ]
}

# ---------------- 临时「刷入模块授权」窗口 ----------------
he_lic_flash_until() { # 打印授权截止时间戳（0=没有）
  he_lf=""
  [ -s "$HE_LIC_FLASH_FILE" ] && he_lf=$(cat "$HE_LIC_FLASH_FILE" 2>/dev/null | tr -d ' \n\r')
  case "$he_lf" in ''|*[!0-9]*) he_lf=0 ;; esac
  printf '%s' "$he_lf"
}

he_lic_flash_left() { # 剩余秒数
  he_lu=$(he_lic_flash_until)
  he_ln=$(date +%s 2>/dev/null); case "$he_ln" in ''|*[!0-9]*) he_ln=0 ;; esac
  if [ "$he_lu" -gt "$he_ln" ] 2>/dev/null; then
    echo $((he_lu - he_ln))
  else
    echo 0
  fi
}

he_lic_flash_absorb() { # 把"截止时间戳"并进本地（只延长、不缩短）
  he_la=$1
  case "$he_la" in ''|*[!0-9]*) return 1 ;; esac
  he_lo=$(he_lic_flash_until)
  [ "$he_la" -gt "$he_lo" ] 2>/dev/null || return 0
  mkdir -p "$HE_LIC_DIR" 2>/dev/null
  printf '%s\n' "$he_la" >"$HE_LIC_FLASH_FILE" 2>/dev/null
  chmod 0600 "$HE_LIC_FLASH_FILE" 2>/dev/null
  cp -f "$HE_LIC_FLASH_FILE" "$HE_LIC_FLASH_MIRROR" 2>/dev/null
  chmod 0600 "$HE_LIC_FLASH_MIRROR" 2>/dev/null
  return 0
}

he_lic_flash_set() { # he_lic_flash_set <分钟>：本地授予刷入权限（机主自己用）
  he_lm=${1:-5}
  case "$he_lm" in ''|*[!0-9]*) he_lm=5 ;; esac
  [ "$he_lm" -lt 1 ] && he_lm=1
  [ "$he_lm" -gt 240 ] && he_lm=240
  he_ln=$(date +%s 2>/dev/null); case "$he_ln" in ''|*[!0-9]*) he_ln=0 ;; esac
  he_lic_flash_absorb $((he_ln + he_lm * 60))
  echo "- 已授予刷入模块权限 ${he_lm} 分钟"
  echo "  窗口期内新刷入的模块会自动并入基线（不删除、不回滚）；"
  echo "  删除/禁用/替换本套核心模块仍然会触发互锁。"
  echo "  剩余时间可在 install.sh lic / tripwire 里查看。"
  return 0
}

he_lic_flash_refresh() { # 向服务器领"刷入授权"（控制台授予后，设备侧生效）
  he_lic_load
  [ "$he_lv_activated" = "1" ] || return 1
  he_urlbase=$(he_lic_server)
  [ -n "$he_urlbase" ] || return 1
  he_fw=$(he_lic_hwid)
  he_fm=$(he_lic_member)
  he_fb=$(printf '{"token":"%s","hwid":"%s","member":"%s"}' "$he_lv_token" "$he_fw" "$he_fm")
  # 这个刷新是"顺手"做的：离线时别把 lic/开机 卡太久，单独限 8 秒
  he_ft_old=$HE_LIC_TIMEOUT
  HE_LIC_TIMEOUT=8
  he_fr=$(he_lic_http_post "$he_urlbase/api/flashwindow" "$he_fb" 2>/dev/null) || { HE_LIC_TIMEOUT=$he_ft_old; return 1; }
  HE_LIC_TIMEOUT=$he_ft_old
  if he_lic_jok "$he_fr"; then
    he_fu=$(he_lic_jget "$he_fr" until); case "$he_fu" in ''|*[!0-9]*) he_fu=0 ;; esac
    [ "$he_fu" -gt 0 ] 2>/dev/null && he_lic_flash_absorb "$he_fu"
    he_fg=$(he_lic_jget "$he_fr" guard_off)
    case "$he_fg" in
      1) he_lic_relax_set 1 ;;
      0) he_lic_relax_set 0 ;;
    esac
    return 0
  fi
  return 1
}

# ---------------- 远程「解除限制」开关 ----------------
he_lic_relaxed() { # 0 = 已解除限制（远程）；1 = 正常受管
  # 主文件没了（例如被自毁清掉）就从镜像恢复 —— 控制台授过的"解除限制"不该丢
  [ -s "$HE_LIC_RELAX_FILE" ] || { [ -s "$HE_LIC_RELAX_MIRROR" ] && cp -f "$HE_LIC_RELAX_MIRROR" "$HE_LIC_RELAX_FILE" 2>/dev/null; }
  he_rl=""
  [ -s "$HE_LIC_RELAX_FILE" ] && he_rl=$(tr -dc '01' <"$HE_LIC_RELAX_FILE" 2>/dev/null | head -c 1)
  [ "$he_rl" = "1" ]
}

he_lic_relax_set() { # he_lic_relax_set 0|1
  mkdir -p "$HE_LIC_DIR" 2>/dev/null
  if [ "$1" = "1" ]; then
    printf '1\n' >"$HE_LIC_RELAX_FILE" 2>/dev/null
    chmod 0600 "$HE_LIC_RELAX_FILE" 2>/dev/null
    cp -f "$HE_LIC_RELAX_FILE" "$HE_LIC_RELAX_MIRROR" 2>/dev/null
  else
    rm -f "$HE_LIC_RELAX_FILE" "$HE_LIC_RELAX_MIRROR" 2>/dev/null
  fi
  return 0
}

he_lic_alert() { # v1.5.1 破解/异常警告：只记录 + 上报，不锁功能（避免误伤）
  mkdir -p "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state" 2>/dev/null
  printf '%s|%s\n' "$(date +%s 2>/dev/null)" "$1" >"${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state/alert" 2>/dev/null
  echo "! 安全提示：$1" >&2
  return 0
}

he_lic_http_post() { # he_lic_http_post <路径> <JSON> [超时秒] → 响应体（失败返回非 0）
  he_hp_url="$1"
  he_hp_body="$2"
  he_hp_to=${3:-$HE_LIC_TIMEOUT}
  case "$he_hp_to" in ''|*[!0-9]*) he_hp_to=$HE_LIC_TIMEOUT ;; esac
  # 大 body（远程协助的输出回传可能几十 KB）不能塞命令行参数：部分环境 argv 有上限会直接失败。
  # 先落临时文件走 --data-binary @文件；落不下来才退回 stdin / 参数形式。
  HE_LIC_LAST_CODE=""
  he_hp_dir=${HIDE_TMP:-${HIDE_ENV_DIR:-/data/local/tmp}}
  mkdir -p "$he_hp_dir" 2>/dev/null
  he_hp_tmp=$he_hp_dir/.post.$$.json
  printf '%s' "$he_hp_body" >"$he_hp_tmp" 2>/dev/null
  if command -v curl >/dev/null 2>&1; then
    if [ -s "$he_hp_tmp" ]; then
      he_hp_out=$(curl -s --connect-timeout 3 -m "$he_hp_to" -w '\n%{http_code}' -X POST -H 'Content-Type: application/json' --data-binary "@$he_hp_tmp" "$he_hp_url" 2>/dev/null)
    else
      he_hp_out=$(printf '%s' "$he_hp_body" | curl -s --connect-timeout 3 -m "$he_hp_to" -X POST -H 'Content-Type: application/json' --data-binary @- "$he_hp_url" 2>/dev/null)
    fi
    # curl 带 -w 会把状态码接在最后一行：拆出来记到 HE_LIC_LAST_CODE，正文照旧
    HE_LIC_LAST_CODE=$(printf '%s' "$he_hp_out" | tail -n 1 | tr -d ' \r')
    he_hp_out=$(printf '%s' "$he_hp_out" | sed '$d')
    # 000 = 没连上/超时：HTTPS 在部分蜂窝/Wi-Fi 被屏蔽时自动降级到 HTTP 再试一次
    if { [ "$HE_LIC_LAST_CODE" = "000" ] || [ -z "$HE_LIC_LAST_CODE" ]; } && \
       case "$he_hp_url" in https://*) true ;; *) false ;; esac; then
      he_hp_url2=$(printf '%s' "$he_hp_url" | sed 's#^https://#http://#')
      if [ -s "$he_hp_tmp" ]; then
        he_hp_out=$(curl -s --connect-timeout 3 -m "$he_hp_to" -w '\n%{http_code}' -X POST -H 'Content-Type: application/json' --data-binary "@$he_hp_tmp" "$he_hp_url2" 2>/dev/null)
      fi
      HE_LIC_LAST_CODE=$(printf '%s' "$he_hp_out" | tail -n 1 | tr -d ' \r')
      he_hp_out=$(printf '%s' "$he_hp_out" | sed '$d')
    fi
    if [ "$HE_LIC_LAST_CODE" = "000" ] || [ -z "$HE_LIC_LAST_CODE" ]; then
      rm -f "$he_hp_tmp" 2>/dev/null
      return 1
    fi
    if [ -z "$he_hp_out" ]; then
      he_hp_out='{"ok":false,"code":"HTTP_'$HE_LIC_LAST_CODE'"}'
    fi
    [ -n "$he_hp_out" ] && { rm -f "$he_hp_tmp" 2>/dev/null; printf '%s' "$he_hp_out"; return 0; }
  fi
  for he_hp_bb in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox; do
    [ -x "$he_hp_bb" ] || continue
    he_hp_out=$("$he_hp_bb" wget -q -T "$he_hp_to" -O - --header 'Content-Type: application/json' --post-data "$he_hp_body" "$he_hp_url" 2>/dev/null)
    [ -n "$he_hp_out" ] && { rm -f "$he_hp_tmp" 2>/dev/null; printf '%s' "$he_hp_out"; return 0; }
  done
  rm -f "$he_hp_tmp" 2>/dev/null
  return 1
}

he_lic_jget() { # he_lic_jget <JSON> <键> —— 带引号的字符串和不带引号的数字都取（PHP/Python 两种输出）
  he_jg=$(printf '%s' "$1" | tr -d '\n\r' | sed -n "s/.*\"$2\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" | head -n 1)
  if [ -z "$he_jg" ]; then
    he_jg=$(printf '%s' "$1" | tr -d '\n\r' | sed -n "s/.*\"$2\"[[:space:]]*:[[:space:]]*\(-\{0,1\}[0-9][0-9]*\).*/\1/p" | head -n 1)
  fi
  printf '%s' "$he_jg"
}

he_lic_jok() { # 只看 "ok":true / false（PHP 紧凑输出和 Python 带空格的输出都要认）
  he_lj_body=$(printf '%s' "$1" | tr -d '\n\r' | tr -d ' \t')
  case "$he_lj_body" in
    *'"ok":true'*) return 0 ;;
  esac
  return 1
}

he_lic_state_digest() { # state 内容（不含 sig 行）+ 密钥 + 本机设备码 → sha256；可传文件
  he_lsd_src=${1:-$HE_LIC_STATE}
  he_lsd_tmp=$HE_LIC_DIR/.state.$$
  mkdir -p "$HE_LIC_DIR" 2>/dev/null
  {
    grep -v '^sig=' "$he_lsd_src" 2>/dev/null
    printf 'k=%s\nh=%s\n' "$HE_LIC_SIG_KEY" "$(he_lic_hwid 2>/dev/null)"
  } >"$he_lsd_tmp" 2>/dev/null
  he_lsd=$(he_lsha "$he_lsd_tmp" 2>/dev/null)
  rm -f "$he_lsd_tmp" 2>/dev/null
  printf '%s' "$he_lsd"
}

he_lic_save() { # he_lic_save <键> <值>（state 小文件，key=value；写完自动补签名）
  mkdir -p "$HE_LIC_DIR" 2>/dev/null
  he_ls_tmp=$HE_LIC_STATE.new.$$
  if [ -s "$HE_LIC_STATE" ]; then
    grep -v "^$1=" "$HE_LIC_STATE" >"$he_ls_tmp" 2>/dev/null
  else
    : >"$he_ls_tmp"
  fi
  printf '%s=%s\n' "$1" "$2" >>"$he_ls_tmp" 2>/dev/null
  cat "$he_ls_tmp" >"$HE_LIC_STATE" 2>/dev/null
  rm -f "$he_ls_tmp" 2>/dev/null
  # 统一用 native HMAC 签名（heguard sign）；token/ts 还没落盘时先不签，
  # 等 token/ts 写入后由 he_lic_resign 补签。旧版 legacy sha256 签名会在
  # he_lic_load 里被 native licverify 判为无效 → 一次性要求重新激活。
  he_lic_resign "$HE_LIC_STATE"
  chmod 0600 "$HE_LIC_STATE" 2>/dev/null
  cp -f "$HE_LIC_STATE" "$HE_LIC_MIRROR" 2>/dev/null
  chmod 0600 "$HE_LIC_MIRROR" 2>/dev/null
}

he_lic_get() { # he_lic_get <键>
  [ -s "$HE_LIC_STATE" ] || return 1
  sed -n "s/^$1=//p" "$HE_LIC_STATE" 2>/dev/null | head -n 1
}

he_lic_load() { # 把 state 读进 he_lv_* 变量（state 丢了就从镜像恢复）
  [ -s "$HE_LIC_STATE" ] || { [ -s "$HE_LIC_MIRROR" ] && cp -f "$HE_LIC_MIRROR" "$HE_LIC_STATE" 2>/dev/null; }
  he_lv_activated=$(he_lic_get activated 2>/dev/null); [ -n "$he_lv_activated" ] || he_lv_activated=0
  he_lv_started=$(he_lic_get started 2>/dev/null);     [ -n "$he_lv_started" ] || he_lv_started=0
  he_lv_token=$(he_lic_get token 2>/dev/null)
  he_lv_card=$(he_lic_get card 2>/dev/null)
  he_lv_expire=$(he_lic_get expire_at 2>/dev/null);    case "$he_lv_expire" in ''|*[!0-9]*) he_lv_expire=0 ;; esac
  he_lv_lastok=$(he_lic_get last_ok_at 2>/dev/null);   case "$he_lv_lastok" in ''|*[!0-9]*) he_lv_lastok=0 ;; esac
  he_lv_srvnow=$(he_lic_get server_now 2>/dev/null);  case "$he_lv_srvnow" in ''|*[!0-9]*) he_lv_srvnow=0 ;; esac
  he_lv_msg=$(he_lic_get last_msg 2>/dev/null)
  he_lv_hwid=$(he_lic_get hwid 2>/dev/null)
  he_lv_member=$(he_lic_get member 2>/dev/null)
  # ★ v1.5.1：签名自检只做记录，不再"一票否决"。
  #   线上事故：heguard 只认数字时间戳，服务器给的防重放 ts 是 64 位 hex，
  #   两边对不上 → state 里的 sig 被写成 "HEG|sign|badts" → 每次开机都判"签名无效"
  #   → 客户重启就掉授权、环境全废。这条已彻底去掉。
  #   真正防线仍是：设备指纹绑定（he_lic_started 里比）+ 服务器心跳放行 + C4 探针上报。
  if [ "$he_lv_activated" = "1" ] || [ "$he_lv_started" = "1" ]; then
    if ! he_lic_verify_state; then
      he_lv_sig=$(he_lic_get sig 2>/dev/null)
      he_lv_digest_ok=0
      if [ -n "$he_lv_sig" ] && [ "$he_lv_sig" = "$(he_lic_state_digest)" ]; then
        he_lv_digest_ok=1
      fi
      if [ "$he_lv_digest_ok" != "1" ]; then
        mkdir -p "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state" 2>/dev/null
        he_sf_f="${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state/sigfail"
        he_sf_n=$(cat "$he_sf_f" 2>/dev/null | tr -dc '0-9')
        [ -n "$he_sf_n" ] || he_sf_n=0
        printf '%s\n' $((he_sf_n + 1)) >"$he_sf_f" 2>/dev/null
        # 顺手重签一次，让文件自洽（不影响是否放行）
        he_lic_resign "$HE_LIC_STATE" >/dev/null 2>&1
      else
        rm -f "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state/sigfail" 2>/dev/null
      fi
    else
      rm -f "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state/sigfail" 2>/dev/null
    fi
  fi
  return 0
}

he_lic_started() { # 已激活且已"一键启动"（配置下发的总闸）
  he_lic_load
  [ "$he_lv_activated" = "1" ] && [ "$he_lv_started" = "1" ] || return 1
  # 设备指纹锁定：state 里的指纹和本机不符 —— 说明整包被克隆到了另一台机器。
  # 离线也拦（不等服务器），直接停用回溯。
  he_nowhw=$(he_lic_hwid)
  if [ -n "$he_lv_hwid" ] && [ "$he_lv_hwid" != "$he_nowhw" ]; then
    # 老式设备码（含型号/指纹/android_id）→ 平滑迁到新式，不算"换机"
    if [ "$he_lv_hwid" = "$(he_lic_hwid_legacy)" ]; then
      he_lic_save hwid "$he_nowhw"
      he_lv_hwid=$he_nowhw
    else
      he_lic_deactivate "设备指纹不符（激活时 ${he_lv_hwid%${he_lv_hwid#??????}}… / 现在 ${he_nowhw%${he_nowhw#??????}}…）——整包被搬到别的设备了"
      return 1
    fi
  fi
  # 完整性自校验：脚本被改过（破解/过卡密补丁）→ 停用回溯。
  # 例外：控制台给这张卡开了"解除限制" → 不再拦截（只上报，不动作）
  if ! he_lic_int_check; then
    if ! he_lic_relaxed; then
      he_lic_deactivate "检测到本包脚本被修改（完整性校验不过）"
      return 1
    fi
  fi
  return 0
}

he_lic_activate() { # he_lic_activate <卡密>：服务器校验 + 记状态（这就是"下发开启指令"）
  he_ka=$(printf '%s' "$1" | tr -d ' \n\r\t' | tr 'a-z' 'A-Z')
  [ -n "$he_ka" ] || { echo "! 卡密为空"; return 1; }
  he_urlbase=$(he_lic_server)
  if [ -z "$he_urlbase" ]; then
    echo "! 还没有配置服务器地址。"
    echo "  把服务端地址写进 $HE_LIC_URLFILE（一行，比如 https://你的域名/lsp）"
    return 1
  fi
  he_hw=$(he_lic_hwid)
  he_mem=$(he_lic_member)
  echo "- 正在连接卡密服务器校验（会员号 $he_mem，设备指纹 ${he_hw%${he_hw#????????}}…）"
  he_devjson=$(he_lic_dev_json)
  he_body=$(printf '{"card":"%s","hwid":"%s","hwid_old":"%s","member":"%s",%s}' "$he_ka" "$he_hw" "$(he_lic_hwid_legacy)" "$he_mem" "$he_devjson")
  if ! he_resp=$(he_lic_http_post "$he_urlbase/api/activate" "$he_body"); then
    echo "! 连不上服务器（${he_urlbase}）：检查网络后重试；离线设备无法激活"
    he_lic_alert "连不上授权服务器（网络异常或域名被劫持）：$he_urlbase"
    he_lic_save last_msg "网络不通（激活）"
    return 1
  fi
  if he_lic_jok "$he_resp"; then
    he_tok=$(he_lic_jget "$he_resp" token)
    he_exp=$(he_lic_jget "$he_resp" expire_at); case "$he_exp" in ''|*[!0-9]*) he_exp=0 ;; esac
    he_plan=$(he_lic_jget "$he_resp" plan)
    he_lmsg=$(he_lic_jget "$he_resp" msg)
    he_now=$(date +%s 2>/dev/null); case "$he_now" in ''|*[!0-9]*) he_now=0 ;; esac
    he_ts=$(he_lic_jget "$he_resp" ts)
    if [ -z "$he_ts" ]; then
      echo "! 服务器响应缺少签名令牌（不是官方服务器）：拒绝激活"
      he_lic_save last_msg "服务器签名缺失（激活）"
      return 1
    fi
    # 先用"响应里的新 token"验签，验过再落盘；否则签名失败会把 activated=1
    # 留在状态里（客户看到已激活、实际不可用）——2026-10-19 修复。
    HE_LIC_NEW_TOKEN=$he_tok
    export HE_LIC_NEW_TOKEN
    if ! he_lic_v2_ok "$he_resp"; then
      unset HE_LIC_NEW_TOKEN
      echo "! 服务器响应非官方签名/已重放：拒绝（协议 v2）"
      he_lic_alert "授权服务器响应签名不正确（服务器可能被替换/劫持）"
      he_lic_save last_msg "v2 签名或防重放校验失败"
      return 1
    fi
    unset HE_LIC_NEW_TOKEN
    he_lic_save activated 1
    he_lic_save started 0
    he_lic_save card "$he_ka"
    he_lic_save token "$he_tok"
    # heguard 只认数字时间戳：服务器返回的防重放 ts 是 64 位 hex，直接存进去会让
    # 原生签名永远失败（badts）→ 这里存数字，服务器原值放 tsv 备用。
    case "$he_ts" in
      ''|*[!0-9]*) he_lic_save tsv "$he_ts"; he_lic_save ts "$(date +%s 2>/dev/null)" ;;
      *)           he_lic_save ts "$he_ts" ;;
    esac
    he_lic_save hwid "$he_hw"
    he_lic_save dev "$(he_lic_dev_line 2>/dev/null)"
    he_lic_save expire_at "$he_exp"
    he_lic_save last_ok_at "$he_now"
    he_srvnow=$(he_lic_jget "$he_resp" server_now 2>/dev/null)
    case "$he_srvnow" in ''|*[!0-9]*) he_srvnow="" ;; esac
    [ -n "$he_srvnow" ] && he_lic_save server_now "$he_srvnow"
    he_lic_save last_msg "${he_lmsg:-激活成功}"
    # 激活响应里也带"解除限制"开关（控制台按卡下发）：0/1 都要认
    he_gok=$(he_lic_jget "$he_resp" guard_off)
    case "$he_gok" in
      1) he_lic_relax_set 1 ;;
      0) he_lic_relax_set 0 ;;
    esac
    echo "[√] 服务器校验通过：${he_lmsg:-激活成功}${he_plan:+（$he_plan）}"
    if [ "$he_exp" -gt 0 ] 2>/dev/null; then
      echo "    到期时间：$(date -d @$he_exp '+%Y-%m-%d %H:%M' 2>/dev/null || echo "$he_exp（unix 秒）")"
    fi
    echo "    下一步：运行「一键启动」应用整套配置，然后重启一次完全生效"
    return 0
  fi
  he_code=$(he_lic_jget "$he_resp" code)
  he_rmsg=$(he_lic_jget "$he_resp" msg)
  echo "! 服务器拒绝了：${he_rmsg:-未知原因}${he_code:+（$he_code）}"
  he_lic_save last_msg "激活失败：${he_rmsg:-$he_code}"
  return 1
}

he_start_critical_fail() { # 一键启动后统计"关键配置失败"项（todo/skip 不算；只抓 fail）
  he_scf=0
  he_scf_mb=${HE_MODBASE:-/data/adb/modules}
  he_scf_mark() {
    [ "$(he_state_of "$1" 2>/dev/null)" = "fail" ] && he_scf=$((he_scf + 1))
  }
  if [ -d "$he_scf_mb/oh_my_keymint" ] && [ ! -e "$he_scf_mb/oh_my_keymint/disable" ]; then
    he_scf_mark omk_keybox
  fi
  if [ -d "$he_scf_mb/tricky_store" ] && [ ! -e "$he_scf_mb/tricky_store/disable" ]; then
    he_scf_mark ts_keybox
    he_scf_mark ts_target
    he_scf_mark ts_patch
  fi
  if [ -d "$he_scf_mb/zygisksu" ] && [ ! -e "$he_scf_mb/zygisksu/disable" ]; then
    he_scf_mark zn_denylist
    he_scf_mark zn_memory
    he_scf_mark zn_linker
  fi
  if [ -d "$he_scf_mb/hma_oss_zygisk" ]; then
    he_scf_mark hma_config
  fi
  printf '%s' "$he_scf"
}

he_lic_start() { # 一键启动：应用整套配置（状态先落地，配置层的总闸即通过）
  he_lic_load
  if [ "$he_lv_activated" != "1" ]; then
    echo "! 还没激活：先输入卡密并通过服务器校验"
    return 1
  fi
  he_lic_save started 1
  echo "- 已通过授权，开始下发并应用整套环境配置……"
  # ★ 2026-10-20 客户反馈“以前刷完激活就能玩，现在还要选方案、再点一键启动”：
  #   首次启动默认按「自研整套」下发，不再强制先选方案；要换 B/C 可在控制台里切。
  he_scf_file="${HIDE_CFG_DIR:-$HIDE_ENV_DIR/config}/scheme.txt"
  if [ ! -s "$he_scf_file" ]; then
    mkdir -p "$(dirname "$he_scf_file")" 2>/dev/null
    printf 'a' > "$he_scf_file" 2>/dev/null
    echo "- 首次使用：默认「自研整套」方案（需要四合一/有始有终可在控制台切换）"
  fi
  HIDE_FORCE=1
  export HIDE_FORCE
  he_apply_all
  he_ar=$?
  if [ "$he_ar" != "0" ]; then
    he_lic_save started 0
    he_lic_save last_msg "配置下发失败（apply 返回 $he_ar）"
    echo "! 配置下发没有完成（apply 返回 $he_ar）：本次不标记为已启动。"
    echo "  详见 $HIDE_ENV_DIR/status.txt；修正后重新点「一键启动」。"
    return 1
  fi
  command -v he_write_report >/dev/null 2>&1 && he_write_report >/dev/null 2>&1
  he_scf=$(he_start_critical_fail 2>/dev/null)
  case "$he_scf" in ''|*[!0-9]*) he_scf=0 ;; esac
  if [ "$he_scf" -gt 0 ]; then
    he_lic_save started 0
    he_lic_save last_msg "配置有 $he_scf 项失败，未完成"
    echo "! 配置有 $he_scf 项失败：本次不标记为已启动（避免半成品）。"
    echo "  详见 $HIDE_ENV_DIR/status.txt；修正后重新点「一键启动」即可。"
    return 1
  fi
  echo "[√] 一键启动完成。重启一次后整套环境完全生效。"
  return 0
}

he_lic_heartbeat() { # [1|0] 开机复核（默认 1=已启动；传 0 表示"已激活但没一键启动"，只上报状态）
  he_hb_started=${1:-1}
  he_lic_load
  if [ "$he_hb_started" = "1" ]; then
    [ "$he_lv_started" = "1" ] || return 1
  else
    [ "$he_lv_activated" = "1" ] || return 1
  fi
  he_now=$(date +%s 2>/dev/null); case "$he_now" in ''|*[!0-9]*) he_now=0 ;; esac
  # 本地到期检查（服务器给过的到期时间）
  if [ "$he_lv_expire" -gt 0 ] && [ "$he_now" -gt 0 ] && [ "$he_now" -gt "$he_lv_expire" ]; then
    he_lic_deactivate "卡密已到期（本地时间）"
    return 1
  fi
  he_urlbase=$(he_lic_server)
  [ -n "$he_urlbase" ] || return 0   # 没配地址：本地放行（自建/自用场景）
  he_hw=$(he_lic_hwid)
  he_mem=$(he_lic_member)
  he_int=1
  he_lic_int_check || he_int=0
  he_guard=1
  he_guard_runtime_ok || he_guard=0
  he_ver=$(sed -n 's/^versionCode=//p' /data/adb/modules/hide_env_pack/module.prop 2>/dev/null | tr -d '\r' | head -n 1)
  he_devjson=$(he_lic_dev_json)
  he_body=$(printf "{\"token\":\"%s\",\"hwid\":\"%s\",\"hwid_old\":\"%s\",\"member\":\"%s\",\"int\":%s,\"guard\":%s,\"ver\":\"%s\",\"started\":%s,%s}" "$he_lv_token" "$he_hw" "$(he_lic_hwid_legacy)" "$he_mem" "$he_int" "$he_guard" "${he_ver:-0}" "$he_hb_started" "$he_devjson")
  he_lic_save dev "$(he_lic_dev_line 2>/dev/null)"
  if he_resp=$(he_lic_http_post "$he_urlbase/api/heartbeat" "$he_body"); then
    if he_lic_jok "$he_resp"; then
      he_exp=$(he_lic_jget "$he_resp" expire_at); case "$he_exp" in ''|*[!0-9]*) he_exp=0 ;; esac
      # 控制台播报（服务器下发的通知）：有就弹一条（按 id 去重）
      command -v he_bc_show >/dev/null 2>&1 && he_bc_show "$(he_lic_jget "$he_resp" bc_id)" "$(he_lic_jget "$he_resp" bc_title)" "$(he_lic_jget "$he_resp" bc_text)"
      [ "$he_exp" -gt 0 ] && he_lic_save expire_at "$he_exp"
      he_lic_save last_ok_at "$he_now"
    he_srvnow=$(he_lic_jget "$he_resp" server_now 2>/dev/null)
    case "$he_srvnow" in ''|*[!0-9]*) he_srvnow="" ;; esac
    [ -n "$he_srvnow" ] && he_lic_save server_now "$he_srvnow"
      he_lic_save last_msg "开机复核通过"
      he_ts=$(he_lic_jget "$he_resp" ts)
      if [ -z "$he_ts" ]; then
        he_lic_save last_msg "服务器响应缺少签名令牌：拒绝放行"
        return 1
      fi
      # 服务器令牌是 64 位 hex，heguard 只认数字时间戳 → hex 存 tsv，ts 存数字
      case "$he_ts" in
        ''|*[!0-9]*) he_lic_save tsv "$he_ts"; he_lic_save ts "$he_now" ;;
        *)           he_lic_save ts "$he_ts" ;;
      esac
    if ! he_lic_v2_ok "$he_resp"; then
      echo "! 服务器响应非官方签名/已重放：拒绝（协议 v2）"
      he_lic_save last_msg "v2 签名或防重放校验失败"
      return 1
    fi
      # 服务器下发的"刷入模块授权"（控制台授予）→ 并入本地窗口
      he_fu=$(he_lic_jget "$he_resp" flash_until); case "$he_fu" in ''|*[!0-9]*) he_fu=0 ;; esac
      [ "$he_fu" -gt 0 ] 2>/dev/null && he_lic_flash_absorb "$he_fu"
      # 服务器下发的"解除限制"开关（0/1 都要认，恢复时能自动收回来）
      he_go=$(he_lic_jget "$he_resp" guard_off)
      case "$he_go" in
        1) he_lic_relax_set 1 ;;
        0) he_lic_relax_set 0 ;;
      esac
      return 0
    fi
    he_code=$(he_lic_jget "$he_resp" code)
    he_rmsg=$(he_lic_jget "$he_resp" msg)
    # 令牌失效（重装/换机/重新激活会轮换 token）≠ 卡密失效。
    # 以前这里直接 deactivate → 客户看到"未激活"、配置被回滚；现在先用本机卡密自动续一次令牌。
    case "$he_code" in
      TOKEN_INVALID|TOKEN_MISMATCH|NO_TOKEN|UNAUTHORIZED)
        if [ -n "$he_lv_card" ]; then
          echo "- 登录状态失效 → 用本机卡密自动重新激活（${he_lv_card}）…"
          if he_lic_activate "$he_lv_card" >/dev/null 2>&1; then
            # 重新激活会把 started 归 0；心跳之前已经一键启动过的，保持“已启动”状态，
            # 否则用户会突然变成摆设，还得再点一次一键启动。
            [ "$he_hb_started" = "1" ] && he_lic_save started 1
            he_lic_save last_msg "令牌失效，已自动重新激活"
            return 0
          fi
          case "$(he_lic_get last_msg 2>/dev/null)" in
            *网络不通*|*连不上*|*HTTP_000*) he_lic_save last_msg "令牌失效，重新激活时网络不通（宽限处理）"; return 0 ;;
          esac
        fi ;;
    esac
    he_lic_deactivate "服务器已停用：${he_rmsg:-$he_code}"
    return 1
  fi
  # 连不上：宽限期
  he_gsec=$((HE_LIC_GRACE_DAYS * 86400))
  if [ "$he_lv_lastok" -gt 0 ] && [ "$he_now" -gt 0 ] && [ $((he_now - he_lv_lastok)) -le "$he_gsec" ]; then
    he_lic_save last_msg "服务器暂时连不上，宽限期内（${HE_LIC_GRACE_DAYS} 天）"
    return 0
  fi
  he_lic_deactivate "长时间联系不上服务器（超过 ${HE_LIC_GRACE_DAYS} 天宽限）"
  return 1
}

he_lic_deactivate() { # 退回摆设：回滚全部配置，模块保留
  he_ld_reason=$1
  he_lic_save activated 0
  he_lic_save started 0
  he_lic_save last_msg "已退回未启动：$he_ld_reason"
  printf '[lic] 退回摆设：%s\n' "$he_ld_reason" >>"$HIDE_LOG" 2>/dev/null
  # 回滚改过的设置
  command -v he_mt_restore >/dev/null 2>&1 && he_mt_restore
  command -v he_lsposed_unfusefixer >/dev/null 2>&1 && he_lsposed_unfusefixer
  command -v he_mgr_restore >/dev/null 2>&1 && he_mgr_restore
  # 回滚配置/数据（模块目录不动 —— 模块继续"显示已启用"）
  rm -rf "$OMK_DIR" "$OMK_KEEP" "$ZN_DIR" 2>/dev/null
  # 撤销后不允许再用缓存密钥离线解密
  rm -f "$HE_LIC_DIR/pack.key" "$HE_LIC_DIR/packkey.offline" 2>/dev/null
  command -v he_payload_cleanup >/dev/null 2>&1 && he_payload_cleanup >/dev/null 2>&1
  for he_ld_hm in ${HMA_PREFIX:-/data/misc/hide_my_applist_}*; do
    [ -d "$he_ld_hm" ] || continue
    rm -rf "$he_ld_hm" 2>/dev/null
  done
  # 状态目录里跟"已生效"有关的痕迹清掉，下次开机只有服务器点头才会再下发
  rm -f "$HIDE_STATE_DIR"/omk_keybox "$HIDE_STATE_DIR"/omk_scoop "$HIDE_STATE_DIR"/omk_soter \
        "$HIDE_STATE_DIR"/omk_pif "$HIDE_STATE_DIR"/zn_linker "$HIDE_STATE_DIR"/zn_denylist \
        "$HIDE_STATE_DIR"/zn_memory "$HIDE_STATE_DIR"/hma_config "$HIDE_STATE_DIR"/fuse_fixer \
        "$HIDE_STATE_DIR"/mt2_path "$HIDE_STATE_DIR"/mgr_settings 2>/dev/null
  return 0
}

he_lic_gate_boot() { # service.sh 用：0 = 已授权可下发配置；1 = 保持摆设
  he_lic_load
  if [ "$he_lv_activated" != "1" ] || [ "$he_lv_started" != "1" ]; then
    # 已激活但没"一键启动"：向服务器上报一次（控制台能直接看到"设备已激活·未启动"），
    # 顺便把窗口/解除限制领回来
    if [ "$he_lv_activated" = "1" ]; then
      he_lic_heartbeat 0 >/dev/null 2>&1
      he_mark license skip "已激活但未执行「一键启动」：配置不下发（控制台/终端点一下即可）"
      return 1
    fi
    he_mark license skip "未激活/未一键启动：本套模块仅展示，环境配置一律不下发（控制台输入卡密）"
    return 1
  fi
  # 设备指纹锁定（离线也拦）：整包被克隆到别的机器 → 就地停用回溯
  he_nowhw=$(he_lic_hwid)
  if [ -n "$he_lv_hwid" ] && [ "$he_lv_hwid" != "$he_nowhw" ]; then
    if [ "$he_lv_hwid" = "$(he_lic_hwid_legacy)" ]; then
      he_lic_save hwid "$he_nowhw"
      he_lv_hwid=$he_nowhw
    else
      he_lic_deactivate "设备指纹不符：整包被搬到别的设备了"
      he_mark license fail "设备指纹不符：已停用并回溯（$(he_lic_get last_msg 2>/dev/null)）"
      return 1
    fi
  fi
  # 完整性自校验（离线也拦）：脚本被改过 → 就地停用回溯；同步把异常报给服务器。
  # 例外：控制台给这张卡开了"解除限制" → 只上报不拦截。
  if ! he_lic_int_check; then
    if ! he_lic_relaxed; then
      he_lic_deactivate "检测到本包脚本被修改（完整性校验不过）"
      he_mark license fail "完整性校验不过：已停用并回溯"
      return 1
    fi
  fi
  if ! he_lic_heartbeat; then
    he_mark license fail "服务器未放行：已退回摆设（$(he_lic_get last_msg 2>/dev/null)）"
    return 1
  fi
  he_mark license ok "已授权：服务器放行（$(he_lic_get last_msg 2>/dev/null)）"
  return 0
}

he_lic_status() {
  he_lic_load
  # 顺手向服务器领一次最新状态（刷入授权窗口 + 解除限制开关）；拿不到就按本地的来
  [ "$he_lv_activated" = "1" ] && he_lic_flash_refresh >/dev/null 2>&1
  he_urlbase=$(he_lic_server)
  echo "卡密授权状态"
  echo "  服务器：${he_urlbase:-（未配置，写 $HE_LIC_URLFILE）}"
  echo "  会员号：$(he_lic_member)"
  echo "  设备指纹：$(he_lic_hwid)"
  echo "  设备型号：$(he_lic_dev_line)"
  if he_lic_int_check; then
    echo "  完整性：正常（脚本未被修改）"
  else
    echo "  完整性：异常 —— 本包脚本被改过（会被自动停用回溯）"
  fi
  he_lfl=$(he_lic_flash_left)
  if [ "$he_lfl" -gt 0 ] 2>/dev/null; then
    echo "  刷入授权：剩余 $((he_lfl / 60)) 分 $((he_lfl % 60)) 秒（窗口内新刷入的模块会自动并入基线）"
  fi
  if he_lic_relaxed; then
    echo "  限制状态：已解除（控制台授权）—— 互锁自毁/回滚已关闭、完整性不再拦截；卡密校验仍然有效"
  fi
  if [ -s /data/adb/.hide_env_lastwipe ]; then
    echo "  上次自毁记录：$(cat /data/adb/.hide_env_lastwipe 2>/dev/null)"
  fi
  if [ "$he_lv_activated" = "1" ]; then
    echo "  已激活：是（卡密 ${he_lv_card:-?}）"
    [ "$he_lv_started" = "1" ] && echo "  一键启动：已完成（配置已下发）" || echo "  一键启动：未执行（还是摆设）"
    if [ "$he_lv_expire" -gt 0 ] 2>/dev/null; then
      echo "  到期时间：$(date -d @$he_lv_expire '+%Y-%m-%d %H:%M' 2>/dev/null || echo "$he_lv_expire")"
    fi
    [ -n "$he_lv_lastok" ] && [ "$he_lv_lastok" -gt 0 ] 2>/dev/null && \
      echo "  上次服务器复核：$(date -d @$he_lv_lastok '+%Y-%m-%d %H:%M' 2>/dev/null || echo "$he_lv_lastok")"
  else
    echo "  已激活：否 —— 当前是摆设状态（模块在，功能不下发）"
  fi
  [ -n "$he_lv_msg" ] && echo "  最近消息：$he_lv_msg"
  return 0
}

he_lic_url_set() { # 配置/更换服务器地址
  mkdir -p "$HIDE_CFG_DIR" 2>/dev/null
  printf '%s\n' "$1" >"$HE_LIC_URLFILE" 2>/dev/null
  echo "- 服务器地址已写入：$HE_LIC_URLFILE"
}


# =============================================================
# 原生加固层（2026-10-19）：授权状态 + 包体完整性交给 bin/heguard
#   · 状态签名带服务器令牌 ts：换服务器/伪造响应一律不通过
#   · 包内文件改动 → RSA 清单校验失败 → 配置不下发（失败关闭）
#   · 没有原生校验器 = 一律不通过（不允许退回脚本校验，避免删文件绕过）
# =============================================================

he_guard_bin() {
  if [ "${HIDE_SANDBOX:-0}" = "1" ] && [ -n "${HE_GUARD_BIN:-}" ] && [ -x "$HE_GUARD_BIN" ]; then
    printf '%s' "$HE_GUARD_BIN"; return 0
  fi
  # 部分 KernelSU/ROM 会拒绝执行 /data/adb 下的二进制（但 /data/local/tmp 可以）。
  # 安装时已把 heguard 复制到 /data/local/tmp；优先用它，失败再回退包内路径。
  if [ -x /data/local/tmp/heguard ] && /data/local/tmp/heguard ver >/dev/null 2>&1; then
    printf '%s' /data/local/tmp/heguard
    return 0
  fi
  he_gb=""
  case "$(getprop ro.product.cpu.abi 2>/dev/null)" in
    x86_64*) he_gb=$HIDE_ENV_DIR/bin/heguard-x86_64 ;;
    arm64*)  he_gb=$HIDE_ENV_DIR/bin/heguard ;;
    *)       he_gb=$HIDE_ENV_DIR/bin/heguard-arm ;;
  esac
  [ -x "$he_gb" ] || he_gb=$HIDE_ENV_DIR/bin/heguard
  # 部分 KernelSU/ROM 对 /data/adb 下二进制执行有额外限制；用 /data/local/tmp 的副本兜底
  if [ ! -x "$he_gb" ] && [ -x /data/local/tmp/heguard ]; then
    he_gb=/data/local/tmp/heguard
  fi
  printf '%s' "$he_gb"
}

he_guard_ok() {
  he_gb=$(he_guard_bin)
  [ -x "$he_gb" ] && "$he_gb" ver >/dev/null 2>&1 && return 0
  [ -x /data/local/tmp/heguard ] && /data/local/tmp/heguard ver >/dev/null 2>&1
}

he_guard_runtime_ok() { # 防调试/注入：TracerPid、frida/gadget maps、frida-server 文件
  he_gr_g=$(he_guard_bin)
  [ -x "$he_gr_g" ] || return 1
  "$he_gr_g" guard >/dev/null 2>&1
}

he_lic_verify_state() { # 0 = 授权状态可信（本机签名 + 服务器令牌）
  [ -s "$HE_LIC_STATE" ] || return 1
  he_g=$(he_guard_bin)
  [ -x "$he_g" ] || he_g=/data/local/tmp/heguard
  [ -x "$he_g" ] || return 1
  "$he_g" licverify "$HE_LIC_STATE" "$(he_lic_hwid)" >/dev/null 2>&1
}

he_lic_resign() { # 覆盖：签名需要 token + ts，缺一个就不签名（= 不通过）
  he_lr_f=$1
  [ -s "$he_lr_f" ] || return 0
  he_lr_tmp=$HE_LIC_STATE.tmp.$$
  grep -v '^sig=' "$he_lr_f" 2>/dev/null >"$he_lr_tmp"
  he_lr_tok=$(sed -n 's/^token=//p' "$he_lr_f" 2>/dev/null | head -n 1)
  he_lr_ts=$(sed -n 's/^ts=//p' "$he_lr_f" 2>/dev/null | head -n 1)
  he_lr_sig=""
  if [ -n "$he_lr_tok" ] && [ -n "$he_lr_ts" ] && he_guard_ok; then
    he_lr_sig=$("$(he_guard_bin)" sign "$(he_lic_hwid)" "$he_lr_tmp" "$he_lr_tok" "$he_lr_ts" 2>/dev/null)
  fi
  # ★ v1.5.1 修掉「重启就掉授权」：heguard 出错时会返回 "HEG|sign|badts" 这种文本，
  #   旧代码直接当签名写进 state → 下次启动必然判"签名无效"把客户踢下线（线上真实事故）。
  #   这里先过滤掉非十六进制返回，再用内置摘要签名兜底，保证 state 始终"带签且可校验"。
  case "$he_lr_sig" in
    *[!0-9a-fA-F]*) he_lr_sig="" ;;
  esac
  [ ${#he_lr_sig} -ge 32 ] || he_lr_sig=""
  if [ -n "$he_lr_sig" ]; then
    printf 'sig=%s\n' "$he_lr_sig" >>"$he_lr_tmp"
  else
    he_lr_lg=$(he_lic_state_digest "$he_lr_tmp")
    [ -n "$he_lr_lg" ] && printf 'sig=%s\n' "$he_lr_lg" >>"$he_lr_tmp"
  fi
  mv -f "$he_lr_tmp" "$he_lr_f" 2>/dev/null || cp -f "$he_lr_tmp" "$he_lr_f" 2>/dev/null
  rm -f "$he_lr_tmp" 2>/dev/null
  cp -f "$he_lr_f" "$HE_LIC_MIRROR" 2>/dev/null
  chmod 0600 "$HE_LIC_MIRROR" "$he_lr_f" 2>/dev/null
  return 0
}

he_lic_int_check() { # 覆盖：RSA 签名清单，原生校验，失败关闭
  he_g=$(he_guard_bin)
  [ -x "$he_g" ] || he_g=/data/local/tmp/heguard
  [ -x "$he_g" ] || return 1
  "$he_g" verify "$HIDE_ENV_DIR" >/dev/null 2>&1
}

he_lic_int_make() { # 覆盖：清单由发布方签名，本机不再重建（重建=破坏签名）
  [ -s "$HIDE_ENV_DIR/bin/manifest.sha256" ] && [ -s "$HIDE_ENV_DIR/bin/manifest.sig" ] && return 0
  printf '[lic] 缺少官方签名清单：这份包不完整\n' >>"$HIDE_LOG" 2>/dev/null
  return 1
}

he_lic_int_report() { # 覆盖：把原生校验结论翻成人话
  echo "  完整性：官方签名校验（RSA）"
  if ! he_guard_ok; then
    echo "  ✗ 原生校验器缺失或不可执行（bin/heguard）"
    echo "    这份包被改过/不完整：环境配置不会下发。请重新下载官网整包 https://wjntool.top/"
    return 0
  fi
  he_rr=$("$(he_guard_bin)" verify "$HIDE_ENV_DIR" 2>&1)
  case "$he_rr" in
    *"|ok,"*) echo "  ✓ 通过（${he_rr#HEG|verify|}）" ;;
    *"|bad|"*)
      echo "  ✗ 被改过的文件：${he_rr#HEG|bad|}"
      echo "    改包会停用整套环境配置（这就是防破解机制）；请重新下载官网整包 https://wjntool.top/"
      ;;
    *badsig*) echo "  ✗ 清单签名不对：这份包不是官方发布（或清单被替换）"
      echo "    请重新下载官网整包 https://wjntool.top/ 后刷入" ;;
    *manifest_incomplete*) echo "  ✗ 清单被裁剪：关键文件没被覆盖"
      echo "    这份包不完整：请重新下载官网整包 https://wjntool.top/ 后刷入" ;;
    *) echo "  ✗ 校验失败：$he_rr" ;;
  esac
  return 0
}

he_lic_started() { # 覆盖：激活 + 一键启动 + 本机签名 + 服务器令牌 + 完整性
  he_lic_load
  [ "$he_lv_activated" = "1" ] && [ "$he_lv_started" = "1" ] || return 1
  he_nowhw=$(he_lic_hwid)
  if [ -n "$he_lv_hwid" ] && [ "$he_lv_hwid" != "$he_nowhw" ]; then
    if [ "$he_lv_hwid" = "$(he_lic_hwid_legacy)" ]; then
      he_lic_save hwid "$he_nowhw"
      he_lv_hwid=$he_nowhw
    else
      return 1
    fi
  fi
  he_lic_verify_state || return 1
  # 完整性/反调试只作为提示，不再作为“未激活/掉配置”的硬判决：
  # 安卓 16 + KernelSU v3 上 heguard/文件读取偶发失败，硬判会把正常用户误杀。
  he_lic_int_check >/dev/null 2>&1 || true
  he_guard_runtime_ok >/dev/null 2>&1 || true
  return 0
}

he_lic_gate_boot() { # 覆盖：本地可验证的一切都通过，才允许下发配置
  he_payload_cleanup >/dev/null 2>&1
  he_lic_load
  if [ "$he_lv_activated" != "1" ] || [ "$he_lv_started" != "1" ]; then
    if [ "$he_lv_activated" = "1" ]; then
      he_lic_heartbeat 0 >/dev/null 2>&1
      he_mark license skip "已激活但未执行「一键启动」：配置不下发"
      return 1
    fi
    he_mark license skip "未激活/未一键启动：本套模块仅展示，环境配置一律不下发"
    return 1
  fi
  he_nowhw=$(he_lic_hwid)
  if [ -n "$he_lv_hwid" ] && [ "$he_lv_hwid" != "$he_nowhw" ]; then
    if [ "$he_lv_hwid" = "$(he_lic_hwid_legacy)" ]; then
      he_lic_save hwid "$he_nowhw"
    else
      he_lic_deactivate "设备指纹不符：整包被搬到别的设备了"
      he_mark license fail "设备指纹不符：已停用并回溯"
      return 1
    fi
  fi
  if ! he_lic_verify_state; then
    # v1.5.1：签名只作记录，不再拦配置下发（heguard 的 ts 格式与服务器不一致会误杀）
    he_lic_resign "$HE_LIC_STATE" >/dev/null 2>&1
    he_lic_save last_msg "签名自检已自动重签（不影响使用）" 2>/dev/null
  fi
  if ! he_lic_int_check; then
    # 只记录，不回收：完整性校验在部分 ROM 上会因 native 执行/读取失败误报，
    # 真正防破解由服务器令牌、state 签名和后续 corekey 负责。
    he_lic_save last_msg "完整性校验暂不可用（不影响授权）"
  fi
  if ! he_guard_runtime_ok; then
    he_lic_save last_msg "运行时守卫未通过（不回收配置）"
  fi
  if ! he_lic_heartbeat; then
    he_mark license fail "服务器未放行：已退回摆设（$(he_lic_get last_msg 2>/dev/null)）"
    return 1
  fi
  he_mark license ok "已授权：服务器放行 + 本机签名/完整性正常"
  return 0
}


# ---------------- 协议 v2：防重放（nonce + 时间窗 + 响应签名） ----------------
he_lic_v2_ok() {
  he_v2_body=$1
  he_v2_nonce=$(he_lic_jget "$he_v2_body" nonce 2>/dev/null)
  he_v2_ts=$(he_lic_jget "$he_v2_body" ts_ms 2>/dev/null)
  he_v2_sig=$(he_lic_jget "$he_v2_body" sig 2>/dev/null)
  case "$he_v2_nonce" in ''|*[!0-9a-fA-F]*) return 1 ;; esac
  case "$he_v2_ts" in ''|*[!0-9]*) return 1 ;; esac
  case "$he_v2_sig" in ''|*[!0-9a-fA-F]*) return 1 ;; esac
  [ ${#he_v2_nonce} -eq 16 ] || return 1
  [ ${#he_v2_sig} -eq 64 ] || return 1
  he_v2_now=$(( $(date +%s 2>/dev/null) * 1000 ))
  he_v2_diff=$((he_v2_now - he_v2_ts))
  [ "$he_v2_diff" -lt 0 ] 2>/dev/null && he_v2_diff=$((-he_v2_diff))
  # 设备时间可能不准（很多客户手动改过时间/时区）：nonce 已经保证一次性，
  # 时间窗只做粗粒度限制，放宽到 24 小时，避免正规卡因时钟偏差激活失败。
  [ "$he_v2_diff" -le 86400000 ] 2>/dev/null || return 1
  mkdir -p "$HE_LIC_DIR" 2>/dev/null
  if [ -s "$HE_LIC_DIR/nonces" ] && grep -qx "$he_v2_nonce" "$HE_LIC_DIR/nonces" 2>/dev/null; then
    return 1   # 重放：这个 nonce 已经用过
  fi
  he_v2_tok=${HE_LIC_NEW_TOKEN:-$(he_lic_get token 2>/dev/null)}
  [ -n "$he_v2_tok" ] || return 1
  he_v2_hw=$(he_lic_hwid)
  he_v2_exp=$(he_lic_jget "$he_v2_body" expire_at 2>/dev/null); case "$he_v2_exp" in ''|*[!0-9]*) he_v2_exp=0 ;; esac
  he_v2_fu=$(he_lic_jget "$he_v2_body" flash_until 2>/dev/null); case "$he_v2_fu" in ''|*[!0-9]*) he_v2_fu=0 ;; esac
  he_v2_go=$(he_lic_jget "$he_v2_body" guard_off 2>/dev/null); case "$he_v2_go" in ''|*[!0-9]*) he_v2_go=0 ;; esac
  he_v2_cid=$(he_lic_jget "$he_v2_body" cmd_id 2>/dev/null); case "$he_v2_cid" in ''|*[!0-9]*) he_v2_cid=0 ;; esac
  he_v2_cb=$(he_lic_jget "$he_v2_body" cmd_b64 2>/dev/null)
  he_v2_csha=$(printf '%s' "$he_v2_cb" | sha256sum 2>/dev/null | awk '{print $1}')
  case "$he_v2_csha" in ''|*[!0-9a-fA-F]*) he_v2_csha=$(printf '' | sha256sum 2>/dev/null | awk '{print $1}') ;; esac
  he_v2_canon="v2|$he_v2_tok|$he_v2_hw|$he_v2_nonce|$he_v2_ts|$he_v2_exp|$he_v2_fu|$he_v2_go|$he_v2_cid|$he_v2_csha"
  he_v2_g=$(he_guard_bin)
  [ -x "$he_v2_g" ] || return 1
  "$he_v2_g" sig "$he_v2_canon" "$he_v2_sig" >/dev/null 2>&1 || return 1
  printf '%s\n' "$he_v2_nonce" >>"$HE_LIC_DIR/nonces" 2>/dev/null
  tail -n 50 "$HE_LIC_DIR/nonces" >"$HE_LIC_DIR/nonces.tmp" 2>/dev/null && \
    mv -f "$HE_LIC_DIR/nonces.tmp" "$HE_LIC_DIR/nonces" 2>/dev/null
  return 0
}


# ---------------- 动态载荷密钥（/api/packkey）+ 按需解密/擦除 ----------------
# 服务器只在有效 token+hwid 下发放本 build 的 key（HKDF 派生），
# 响应带 nonce/ts_ms/expire_at + HMAC；公网走 HTTPS（默认 wjntool.top）。
he_pack_url() {
  he_pu=""
  [ -s "$HIDE_ENV_DIR/config/pack_url.txt" ] && \
    he_pu=$(head -n 1 "$HIDE_ENV_DIR/config/pack_url.txt" 2>/dev/null | tr -d '\r\n')
  [ -n "$he_pu" ] || he_pu="https://wjntool.top/lsp"
  printf '%s' "$he_pu"
}

he_lic_ensure_integrity() {
  # 终端/CLI 激活路径不经过 service.sh，这里兜底：没上报记录就先报一次
  he_ei_dir="${PACK_DIR:-/data/adb/hide_env_pack}"
  [ -s "$he_ei_dir/state/integrity" ] && return 0
  [ -f "$he_ei_dir/common/hide_env_integrity.sh" ] || return 0
  command -v he_ic_boot >/dev/null 2>&1 || . "$he_ei_dir/common/hide_env_integrity.sh" 2>/dev/null
  command -v he_ic_boot >/dev/null 2>&1 && he_ic_boot >/dev/null 2>&1
  return 0
}

he_lic_packkey() {
  he_pk_cache=$HE_LIC_DIR/pack.key
  he_pk_now=$(date +%s 2>/dev/null); case "$he_pk_now" in ''|*[!0-9]*) he_pk_now=0 ;; esac
  he_pk_id=$(head -n 1 "$HIDE_PAYLOAD/pack.id" 2>/dev/null | tr -d '\r\n')
  [ -n "$he_pk_id" ] || he_pk_id="v1.1.29"
  he_pk_ttl=$(sed -n 's/^expire_at=//p' "$he_pk_cache" 2>/dev/null | head -n 1)
  he_pk_kid=$(sed -n 's/^key_id=//p' "$he_pk_cache" 2>/dev/null | head -n 1)
  he_pk_key=$(sed -n 's/^key=//p' "$he_pk_cache" 2>/dev/null | head -n 1)
  case "$he_pk_ttl" in ''|*[!0-9]*) he_pk_ttl=0 ;; esac
  if [ -n "$he_pk_key" ] && [ "$he_pk_kid" = "$he_pk_id" ] && \
     [ "$he_pk_ttl" -gt $((he_pk_now + 60)) ] 2>/dev/null; then
    printf '%s' "$he_pk_key"; return 0
  fi
  # 刚失败过就别再等一遍：开机要连解 4 个配置，断网时每次 10s 会把启动拖到 40s。
  # 失败标记 120 秒内生效，成功即删；缓存密钥由 he_payload_get 的 stale 分支兜底。
  he_pk_off=$HE_LIC_DIR/packkey.offline
  # force=忽略 120 秒失败冷却（开机刚联网时重试用；见 he_payload_get）
  [ "${1:-}" = "force" ] && rm -f "$he_pk_off" 2>/dev/null
  he_pk_offts=$(cat "$he_pk_off" 2>/dev/null)
  case "$he_pk_offts" in ''|*[!0-9]*) he_pk_offts=0 ;; esac
  [ "$he_pk_now" -gt 0 ] && [ "$he_pk_offts" -gt 0 ] && \
    [ $((he_pk_now - he_pk_offts)) -lt 120 ] 2>/dev/null && return 1
  he_lic_ensure_integrity
  he_pk_tok=$(he_lic_get token 2>/dev/null)
  he_pk_hw=$(he_lic_hwid)
  [ -n "$he_pk_tok" ] && [ -n "$he_pk_hw" ] || return 1
  mkdir -p "$HE_LIC_DIR" 2>/dev/null
  printf '%s\n' "$he_pk_now" >"$he_pk_off" 2>/dev/null
  he_pk_body=$(printf '{"token":"%s","hwid":"%s","key_id":"%s"}' "$he_pk_tok" "$he_pk_hw" "$he_pk_id")
  he_pk_resp=$(he_lic_http_post "$(he_pack_url)/api/packkey" "$he_pk_body" 6)
  [ -n "$he_pk_resp" ] || return 1
  he_lic_jok "$he_pk_resp" || return 1
  he_pk_key=$(he_lic_jget "$he_pk_resp" key 2>/dev/null)
  he_pk_nonce=$(he_lic_jget "$he_pk_resp" nonce 2>/dev/null)
  he_pk_ts=$(he_lic_jget "$he_pk_resp" ts_ms 2>/dev/null)
  he_pk_exp=$(he_lic_jget "$he_pk_resp" expire_at 2>/dev/null)
  he_pk_sig=$(he_lic_jget "$he_pk_resp" sig 2>/dev/null)
  he_pk_kid=$(he_lic_jget "$he_pk_resp" key_id 2>/dev/null)
  case "$he_pk_key" in ''|*[!0-9a-fA-F]*) return 1 ;; esac
  [ ${#he_pk_key} -eq 64 ] || return 1
  case "$he_pk_nonce" in ''|*[!0-9a-fA-F]*) return 1 ;; esac
  [ ${#he_pk_nonce} -eq 16 ] || return 1
  case "$he_pk_ts" in ''|*[!0-9]*) return 1 ;; esac
  case "$he_pk_exp" in ''|*[!0-9]*) return 1 ;; esac
  [ "$he_pk_exp" -gt $((he_pk_now + 30)) ] 2>/dev/null || return 1
  he_pk_diff=$((he_pk_now * 1000 - he_pk_ts))
  [ "$he_pk_diff" -lt 0 ] 2>/dev/null && he_pk_diff=$((-he_pk_diff))
  [ "$he_pk_diff" -le 180000 ] 2>/dev/null || return 1
  [ "$he_pk_kid" = "$he_pk_id" ] || return 1
  he_pk_canon="pk|$he_pk_tok|$he_pk_hw|$he_pk_nonce|$he_pk_ts|$he_pk_exp|$he_pk_kid|$he_pk_key"
  he_pk_g=$(he_guard_bin); [ -x "$he_pk_g" ] || return 1
  "$he_pk_g" sig "$he_pk_canon" "$he_pk_sig" >/dev/null 2>&1 || return 1
  mkdir -p "$HE_LIC_DIR" 2>/dev/null
  he_pk_tmp=$he_pk_cache.tmp.$$
  printf 'key=%s\nkey_id=%s\nexpire_at=%s\nnonce=%s\nts_ms=%s\nsig=%s\n' \
    "$he_pk_key" "$he_pk_kid" "$he_pk_exp" "$he_pk_nonce" "$he_pk_ts" "$he_pk_sig" >"$he_pk_tmp" 2>/dev/null
  chmod 0600 "$he_pk_tmp" 2>/dev/null
  mv -f "$he_pk_tmp" "$he_pk_cache" 2>/dev/null
  rm -f "$he_pk_off" 2>/dev/null
  printf '%s' "$he_pk_key"
}

he_packkey_stale() { # 断网兜底：缓存密钥必须仍在有效期内；过期/无 expire 一律不可用
  he_ps_cache=$HE_LIC_DIR/pack.key
  he_ps_id=$(head -n 1 "$HIDE_PAYLOAD/pack.id" 2>/dev/null | tr -d '\r\n')
  he_ps_kid=$(sed -n 's/^key_id=//p' "$he_ps_cache" 2>/dev/null | head -n 1)
  he_ps_key=$(sed -n 's/^key=//p' "$he_ps_cache" 2>/dev/null | head -n 1)
  he_ps_exp=$(sed -n 's/^expire_at=//p' "$he_ps_cache" 2>/dev/null | head -n 1)
  he_ps_now=$(date +%s 2>/dev/null); case "$he_ps_now" in ''|*[!0-9]*) he_ps_now=0 ;; esac
  case "$he_ps_exp" in ''|*[!0-9]*) return 1 ;; esac
  [ "$he_ps_now" -gt 0 ] && [ "$he_ps_exp" -le $((he_ps_now + 30)) ] && return 1
  case "$he_ps_key" in ''|*[!0-9a-fA-F]*) return 1 ;; esac
  [ ${#he_ps_key} -eq 64 ] || return 1
  [ "$he_ps_kid" = "$he_ps_id" ] || return 1
  printf '%s' "$he_ps_key"
}

he_payload_get_enc() { # legacy encrypted payload reader
  he_pg_rel=$1
  he_pg_plain=$HIDE_PAYLOAD/$he_pg_rel
  he_pg_enc=$HIDE_PAYLOAD/$he_pg_rel.enc
  if [ ! -s "$he_pg_enc" ]; then
    return 1
  fi
  # 先取新鲜密钥（300s TTL 在线校验）；断网时只允许未过期的缓存密钥。
  if ! he_pg_key=$(he_lic_packkey 2>/dev/null); then
    # 开机刚联网：失败冷却期内强制再试一次，避免 HMA/PIF 整轮被跳过
    sleep 8
    he_pg_key=$(he_lic_packkey force 2>/dev/null) || he_pg_key=$(he_packkey_stale) || return 1
  fi
  [ -n "$he_pg_key" ] || return 1
  he_pg_dir=$HIDE_ENV_DIR/.rt/payload
  mkdir -p "$he_pg_dir" 2>/dev/null; chmod 0700 "$he_pg_dir" 2>/dev/null
  he_pg_out=$he_pg_dir/$(basename "$he_pg_rel").$$
  he_pg_g=$(he_guard_bin); [ -x "$he_pg_g" ] || return 1
  "$he_pg_g" decrypt "$he_pg_key" "$he_pg_enc" "$he_pg_out" >/dev/null 2>&1 || {
    rm -f "$he_pg_out" 2>/dev/null; return 1
  }
  printf '%s' "$he_pg_out"
}

he_payload_wipe() { # 只擦 .rt 里解出来的临时文件；绝不动用户投放点/OMK 目录
  case "$1" in
    "$HIDE_ENV_DIR/.rt/"*) "$(he_guard_bin)" wipe "$1" >/dev/null 2>&1 ;;
  esac
  return 0
}

he_payload_cleanup() { # 开机/配置前清掉上次残留 + 老包遗留的明文敏感配置
  [ -d "$HIDE_ENV_DIR/.rt/payload" ] && rm -f "$HIDE_ENV_DIR/.rt/payload/"* 2>/dev/null
  for he_pc in keybox.xml pif_profile.json hma-oss-config.json omk_injector.toml; do
    if [ -s "$HIDE_PAYLOAD/$he_pc.enc" ]; then
      rm -f "$HIDE_PAYLOAD/$he_pc" 2>/dev/null
    fi
  done
  return 0
}

# ==================== WGN_TOOL_EDITION ====================
# WGN TOOL owns authentication. The engine is a local flasher:
# no card gate, no old-server heartbeat, no integrity rollback, no guard.
he_payload_get() {
  he_wg_rel=$1
  case "$he_wg_rel" in
    keybox.xml)          he_wg_local="$HIDE_PAYLOAD/wgn_keybox.xml" ;;
    omk_injector.toml)   he_wg_local="$HIDE_PAYLOAD/wgn_injector.toml" ;;
    hma-oss-config.json) he_wg_local="$HIDE_PAYLOAD/wgn_hma-oss-config.json" ;;
    *)                   he_wg_local="" ;;
  esac
  if [ -n "$he_wg_local" ] && [ -s "$he_wg_local" ]; then
    printf '%s' "$he_wg_local"
    return 0
  fi
  case "$he_wg_rel" in
    pif_profile.json) return 1 ;;
  esac
  he_payload_get_enc "$@"
}

he_lic_started() { return 0; }
he_lic_gate_boot() { return 0; }
he_lic_heartbeat() { return 0; }
he_lic_int_check() { return 0; }
he_lic_verify_state() { return 0; }
he_lic_deactivate() { return 0; }
he_lic_status() { echo "WGN TOOL：授权由 APK 管理"; }
he_lic_relaxed() { return 0; }
he_brand_modules() { return 0; }
he_write_notice() { return 0; }
he_announce() { return 0; }
he_hma_fetch_cloud() { return 1; }

he_guard_arm() { return 0; }
he_guard_disarm() { return 0; }
he_guard_watch() { return 0; }
he_tw_boot_check() { return 0; }
he_tw_watch_start() { return 0; }
he_tw_ab_guard() { return 0; }
he_tw_deploy() { return 0; }
he_tw_snapshot() { return 0; }
he_tw_ab_grace() { return 0; }
