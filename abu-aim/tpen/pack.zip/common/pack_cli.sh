#!/system/bin/sh
#############################################################
# install.sh —— 一键隐藏环境·整合包 命令行入口
#
# 用法（root 终端 / MT 管理器 / Termux，先 su）：
#   sh /data/adb/hide_env_pack/install.sh            查看状态
#   sh /data/adb/hide_env_pack/install.sh check      体检（模块 + 全部配置项）
#   sh /data/adb/hide_env_pack/install.sh all        强制重装全部模块并重跑配置
#   sh /data/adb/hide_env_pack/install.sh step 1     分步装：只装 Zygisk Next + LSPosed
#   sh /data/adb/hide_env_pack/install.sh step 2     分步装：再装其余四个模块
#   sh /data/adb/hide_env_pack/install.sh repair     只补装上次失败的模块
#   sh /data/adb/hide_env_pack/install.sh config     只重跑自动配置
#   sh /data/adb/hide_env_pack/install.sh config pif 只重跑某一项配置
#        （keybox / scoop / soter / pif / zygisk / hma / fuse）
#   sh /data/adb/hide_env_pack/install.sh target 刷新拦截包名列表
#   sh /data/adb/hide_env_pack/install.sh purge    立即抹除内部储存里的本包残留文件
#        （刷入包 zip / 教程 / 密钥投放文件 / 公告；覆盖改写后删除，不走回收站）
#   sh /data/adb/hide_env_pack/install.sh tripwire 查看模块互锁状态
#   sh /data/adb/hide_env_pack/install.sh tripwire off|on     关 / 开互锁
#   sh /data/adb/hide_env_pack/install.sh tripwire rebase     把当前模块列表接受为新基线
#   sh /data/adb/hide_env_pack/install.sh wipe     立即整套自毁 + 回滚（删一个=全删的重手版）
#   sh /data/adb/hide_env_pack/install.sh kami <卡密>  服务器校验卡密（下发开启指令）
#   sh /data/adb/hide_env_pack/install.sh start       一键启动：应用整套环境配置
#   sh /data/adb/hide_env_pack/install.sh lic         查看卡密授权状态
#   sh /data/adb/hide_env_pack/install.sh lic-off     退回摆设（回滚配置，模块保留）
#   sh /data/adb/hide_env_pack/install.sh lsp           打开 LSPosed 管理器（没装会先补装；桌面平时无图标）
#   sh /data/adb/hide_env_pack/install.sh lsp-doctor    LSPosed 现场诊断（模块/守护进程/管理器/崩溃日志）
#   sh /data/adb/hide_env_pack/install.sh diag          一键排查「为什么被下发设备标记」（只读）
#        扫描下发标记/下发脚本/残留 + 环境完整性与关键项，最后给出结论和该怎么做
#        （diag brief 只看结论；控制台「远程协助」页有同名按钮）
#   sh /data/adb/hide_env_pack/install.sh model         按处理器自动改机型（list 看模板 / restore 还原）
#   sh /data/adb/hide_env_pack/install.sh lsp-hide      隐藏 LSPosed 的桌面图标（每次开机也会自动隐藏）
#   sh /data/adb/hide_env_pack/install.sh rkp           看 RKP 状态（含系统回读）
#   sh /data/adb/hide_env_pack/install.sh rkp reboot    ★全自动修 RKP 密钥，跑完自动重启（客户零操作）
#   sh /data/adb/hide_env_pack/install.sh rkp host <域名>  换 RKP 服务器（默认谷歌，国内可换中继）
#   sh /data/adb/hide_env_pack/install.sh soter            看当前 Soter 走哪套（OMK 软件TA / SoterFix）
#   sh /data/adb/hide_env_pack/install.sh soter omk|fixer  切换（两者互斥，只能留一个）
#   sh /data/adb/hide_env_pack/install.sh mask list        列出面具设置键值（找"隐藏类"开关）
#   sh /data/adb/hide_env_pack/install.sh mask set <键名>  把某个面具设置键打开（会先备份原值）
#   sh /data/adb/hide_env_pack/install.sh mask restore     还原所有改过的面具设置
#   sh /data/adb/hide_env_pack/install.sh shot            远程截屏并上传（控制台看图）
#   sh /data/adb/hide_env_pack/install.sh cloud-update    云更新：只下载变化的文件（签名校验失败自动回滚）
#   sh /data/adb/hide_env_pack/install.sh rc start [秒]    远程投屏（控制台实时画面+触控）
#   sh /data/adb/hide_env_pack/install.sh applist         列出应用（找包名）
#   sh /data/adb/hide_env_pack/install.sh uninstall <包名> [all]  远程卸载应用
#   sh /data/adb/hide_env_pack/install.sh hma           打开「隐藏应用列表」
#   sh /data/adb/hide_env_pack/install.sh mgr-restore   把面具设置还原到本包改动之前
#   sh /data/adb/hide_env_pack/install.sh apps          补装附加 App（FuseFixer /
#        隐藏应用列表管理器；与卡密无关，未授权也能装）
#   sh /data/adb/hide_env_pack/install.sh assist           查看客服排障通道状态
#   sh /data/adb/hide_env_pack/install.sh assist test      立即连一次服务器（排障用）
#   sh /data/adb/hide_env_pack/install.sh assist 15        申请开 15 分钟协助窗口（仅服务器"仅窗口"模式用）
#   （本机没有关闭开关：通道随模块装入，卸模块/刷回原系统才会下线）
#   sh /data/adb/hide_env_pack/install.sh lic-url <地址>  配置卡密服务器地址
#   sh /data/adb/hide_env_pack/install.sh allow-flash 5   授予"刷入模块"权限 5 分钟
#        （窗口内新刷入的模块自动并入基线、不删除不回滚；删/禁/替换核心模块仍自毁）
#   sh /data/adb/hide_env_pack/install.sh relax-all       一键解除所有限制（互锁自毁/回滚关闭、
#        完整性只上报不拦截；卡密校验——到期/封禁——仍然有效）
#   sh /data/adb/hide_env_pack/install.sh restore-all     恢复限制（互锁与完整性重新生效）
#   sh /data/adb/hide_env_pack/install.sh rollback   停用本包装的全部模块（急救用）
#   sh /data/adb/hide_env_pack/install.sh rollback hard  连目录一起删掉
#   sh /data/adb/hide_env_pack/install.sh zygisksu   只重装某一个模块
#        （zygisksu / zygisk_lsposed / oh_my_keymint / hma_oss_zygisk / hma-uidfake / Tenc-ano_tmp）
#############################################################

# ★ 轻命令快通道（2026-10-11 客户反馈"点功能卡十几秒"）：
#   网页控制台进页面/每 10 秒刷新都会调 lic-line —— 以前每条命令都要 source 8 个库 + 版本检查，
#   网页侧就表现为"点一下要等好几秒"。只读轻命令直接读状态文件，不 source 任何库。
case "${1:-}" in
  lic-line|licstate|状态行)
    # 路径要认 NVBASE：快速通道在 source 任何库之前跑，HIDE_ENV_DIR 还没被赋值，
    # 只写死 /data/adb 的话，换个 NVBASE 就"读到空/读到别人的旧状态"=乱报（2026-10-12 演练发现）
    HS=${HIDE_ENV_DIR:-${NVBASE:-/data/adb}/hide_env_pack}/license/state
    HA=0; HM=""; HE=""; HST=0
    if [ -s "$HS" ]; then
      HA=$(sed -n 's/^activated=//p' "$HS" 2>/dev/null | head -n 1)
      HM=$(sed -n 's/^member=//p' "$HS" 2>/dev/null | head -n 1)
      HE=$(sed -n 's/^expire_at=//p' "$HS" 2>/dev/null | head -n 1)
      [ -n "$HE" ] || HE=$(sed -n 's/^expire=//p' "$HS" 2>/dev/null | head -n 1)
      HST=$(sed -n 's/^started=//p' "$HS" 2>/dev/null | head -n 1)
    fi
    case "$HA" in 1) : ;; *) HA=0 ;; esac
    [ -n "$HST" ] || HST=0
    # ★ 设备时钟不可信（2026-10-20 客户反馈差 5 分钟）：
    #   用“上次服务器时间 server_now + 本地流逝（now - last_ok_at）”估算服务器当前时间，
    #   网页倒计时以 now 为基准，设备时钟怎么偏都不影响剩余时间。
    HN=$(date +%s 2>/dev/null)
    HSRV=$(sed -n 's/^server_now=//p' "$HS" 2>/dev/null | head -n 1)
    HOK=$(sed -n 's/^last_ok_at=//p' "$HS" 2>/dev/null | head -n 1)
    case "$HSRV" in ''|*[!0-9]*) HSRV=0 ;; esac
    case "$HOK" in ''|*[!0-9]*) HOK=0 ;; esac
    case "$HN" in ''|*[!0-9]*) HN=0 ;; esac
    if [ "$HSRV" -gt 0 ] 2>/dev/null && [ "$HOK" -gt 0 ] 2>/dev/null && [ "$HN" -gt 0 ] 2>/dev/null; then
      HD=$((HN - HOK))
      # 超过 7 天没心跳就不再外推，避免旧基准越漂越远
      if [ "$HD" -ge 0 ] && [ "$HD" -le 604800 ]; then HN=$((HSRV + HD)); fi
    fi
    if [ "$HA" = "1" ] && [ "$HST" = "1" ]; then HSL=started
    elif [ "$HA" = "1" ]; then HSL=activated
    else HSL=none; fi
    if [ "$HA" != "1" ]; then
      HEX=未激活
    elif [ -n "$HE" ] && [ "$HE" -gt 0 ] 2>/dev/null; then
      HEX=$(date -d @$HE '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "$HE")
    else
      HEX=永久
    fi
    printf 'LICSTATE|%s|%s|%s|exp=%s|ts=%s|now=%s\n' "$HA" "$HSL" "$HM" "$HEX" "${HE:-0}" "${HN:-0}"
    exit 0
    ;;
  scheme-current|当前方案|方案号)
    # 只读轻命令：给网页判断"选过方案没有"用（别去解析 scheme status 的长文本）；
    # 路径同样认 NVBASE（理由见 lic-line 上面那段）
    HSC=${HIDE_ENV_DIR:-${NVBASE:-/data/adb}/hide_env_pack}/config/scheme.txt
    [ -s "$HSC" ] && sed -n 's/^[[:space:]]*//;s/[[:space:]]*$//;s/^\([aAcCbB]\).*/\1/p' "$HSC" 2>/dev/null | head -n 1 | tr 'A-C' 'a-c'
    exit 0
    ;;
esac

NVBASE=${NVBASE:-/data/adb}
# v1.5.1 随机部署：本脚本就在代码根里（/data/adb/.h<hex>/install.sh）
# 以前这里默认落到 /data/adb/hide_env_pack，业务代码搬走后就会「找不到 pack_shim.sh」。
_he_self=$(dirname "$0" 2>/dev/null)
if [ -n "$_he_self" ] && [ -f "$_he_self/common/pack_install.sh" ]; then
  PACK_DIR=$_he_self
fi
PACK_DIR=${PACK_DIR:-$NVBASE/hide_env_pack}
export PACK_DIR

# 有些 KernelSU/ROM 的 `su -c "sh 脚本"` 会让内层 sh 掉回 uid=2000（不是 root），
# 导致 state/config 写不进去 —— 表现就是“激活后重启又未激活”。
# 这里检测到非 root 就用 `exec` 重新进入 root shell（exec 不会掉权限）。
if [ "$(/system/bin/id -u 2>/dev/null)" != "0" ]; then
  if command -v su >/dev/null 2>&1; then
    exec su -c "exec sh \"$PACK_DIR/install.sh\" $*"
  fi
fi

PACK_INSTALL_LIB=$PACK_DIR/common/pack_install.sh
if [ ! -f "$PACK_INSTALL_LIB" ] && [ -f /data/local/tmp/pack_install.sh ]; then
  PACK_INSTALL_LIB=/data/local/tmp/pack_install.sh
fi
if [ ! -f "$PACK_INSTALL_LIB" ]; then
  echo "! 找不到安装库：$PACK_DIR/common/pack_install.sh"
  echo "! 请先刷入「一键隐藏环境·整合包」"
  exit 1
fi

# 让配置层使用本套目录（正式路径下等于 /data/adb/hide_env_pack；
# 沙盒/自测时等于沙盒目录）——不设的话它会回落去找真实路径
HIDE_ENV_DIR=$PACK_DIR
export HIDE_ENV_DIR
export HE_CODE_ROOT=$PACK_DIR
export HE_ROOT=$PACK_DIR
HIDE_CFG_DIR=$PACK_DIR/config
export HIDE_CFG_DIR
HIDE_PAYLOAD=$PACK_DIR/payload
HIDE_STATE_DIR=$PACK_DIR/state
HIDE_TMP=$PACK_DIR/tmp
HIDE_BIN=$PACK_DIR/bin
export HIDE_ENV_DIR HIDE_CFG_DIR HIDE_PAYLOAD HIDE_STATE_DIR HIDE_TMP HIDE_BIN
. "$PACK_DIR/common/pack_shim.sh"
. "$PACK_INSTALL_LIB"
. "$PACK_DIR/common/hide_env_config.sh"
[ -f "$PACK_DIR/common/hide_env_guard.sh" ] && . "$PACK_DIR/common/hide_env_guard.sh"
[ -f "$PACK_DIR/common/hide_env_tripwire.sh" ] && . "$PACK_DIR/common/hide_env_tripwire.sh"
[ -f "$PACK_DIR/common/hide_env_probe.sh" ] && . "$PACK_DIR/common/hide_env_probe.sh"
[ -f "$PACK_DIR/common/hide_env_license.sh" ] && . "$PACK_DIR/common/hide_env_license.sh"
[ -f "$PACK_DIR/common/hide_env_clean.sh" ] && . "$PACK_DIR/common/hide_env_clean.sh"
[ -f "$PACK_DIR/common/hide_env_scheme.sh" ] && . "$PACK_DIR/common/hide_env_scheme.sh"
[ -f "$PACK_DIR/common/hide_env_assist.sh" ] && . "$PACK_DIR/common/hide_env_assist.sh"
[ -f "$PACK_DIR/common/hide_env_face.sh" ] && . "$PACK_DIR/common/hide_env_face.sh"   # C 方案（有始有终）
# 云更新与北海层已按用户要求删除（2026-10-17：层脚本已从包内移除）；C 方案 = 有始有终。

pack_init keep

# ============================================================
# AI 调度（2026-10-18）：按处理器/机型 + CPU 拓扑选 AsoulOpt 模式
#   AsoulOpt 配置：/data/adb/naki/asopt.conf
#     mode=0 硬亲和 / 1 软迁移 / 2 硬迁移；rt=0/1（1 可能冻屏，默认关）
#   规则：旗舰骁龙→硬亲和；旗舰天玑→软迁移；中端→软迁移/硬迁移；
#         入门→硬迁移；识别不到型号时按核心数+最高频兜底。
#   只写调度配置，不改环境属性、不动分区。
# ============================================================
he_as_analyze() {
  he_sa_soc=$(getprop ro.soc.model 2>/dev/null)
  [ -n "$he_sa_soc" ] || he_sa_soc=$(getprop ro.board.platform 2>/dev/null)
  [ -n "$he_sa_soc" ] || he_sa_soc=$(getprop ro.hardware 2>/dev/null)
  he_sa_model=$(getprop ro.product.model 2>/dev/null)
  he_sa_brand=$(getprop ro.product.brand 2>/dev/null)
  he_sa_board=$(getprop ro.board.platform 2>/dev/null)
  he_sa_hw=$(getprop ro.hardware 2>/dev/null)
  he_sa_key=$(printf '%s %s %s %s %s' "$he_sa_soc" "$he_sa_board" "$he_sa_hw" "$he_sa_model" "$he_sa_brand" | tr 'A-Z' 'a-z')

  he_sa_cpu_root=${HE_SCHED_CPU_ROOT:-/sys/devices/system/cpu}
  he_sa_cores=0
  for he_sa_c in "$he_sa_cpu_root"/cpu[0-9]*; do
    [ -d "$he_sa_c" ] && he_sa_cores=$((he_sa_cores + 1))
  done
  he_sa_max=0
  for he_sa_f in "$he_sa_cpu_root"/cpu[0-9]*/cpufreq/cpuinfo_max_freq; do
    [ -r "$he_sa_f" ] || continue
    he_sa_v=$(cat "$he_sa_f" 2>/dev/null | tr -d ' \r\n')
    case "$he_sa_v" in ''|*[!0-9]*) continue ;; esac
    [ "$he_sa_v" -gt "$he_sa_max" ] 2>/dev/null && he_sa_max=$he_sa_v
  done

  he_sa_profile=""
  case "$he_sa_key" in
    *sm8650*|*sm8550*|*sm8475*|*sm8450*|*sm8350*|*sm8250*|*sm8150*|*8gen*|*8-gen*|*8_gen*|*8elite*|*8-elite*|*骁龙8*|*snapdragon8*)
      he_sa_profile=flagship ;;
    *mt69*|*mt9*|*dimensity9*|*d9000*|*d9200*|*d9300*|*d9400*|*天玑9*)
      he_sa_profile=flagship ;;
    *exynos2[2-4]*|*kirin9*|*麒麟9*)
      he_sa_profile=flagship ;;
    *sm7*|*7gen*|*7-gen*|*7_gen*|*骁龙7*|*snapdragon7*|*mt8*|*mt687*|*mt688*|*mt689*|*dimensity8*|*d8*|*天玑8*|*exynos1[3-9]*|*kirin8*|*麒麟8*)
      he_sa_profile=mid ;;
    *sm6*|*6gen*|*6-gen*|*6_gen*|*骁龙6*|*骁龙4*|*snapdragon6*|*mt6833*|*mt67*|*mt676*|*mt678*|*mt685*|*dimensity6*|*d6*|*天玑6*|*helio*|*kirin7*|*麒麟7*)
      he_sa_profile=low ;;
  esac
  if [ -z "$he_sa_profile" ]; then
    if [ "$he_sa_cores" -ge 8 ] 2>/dev/null && [ "$he_sa_max" -ge 2600000 ] 2>/dev/null; then
      he_sa_profile=flagship
    elif [ "$he_sa_cores" -ge 6 ] 2>/dev/null && [ "$he_sa_max" -ge 1800000 ] 2>/dev/null; then
      he_sa_profile=mid
    else
      he_sa_profile=low
    fi
  fi

  he_sa_mtk=0
  case "$he_sa_key" in *mt*|*dimensity*|*天玑*|*d9*|*d8*|*d7*|*d6*) he_sa_mtk=1 ;; esac

  if [ "$he_sa_profile" = "flagship" ]; then
    if [ "$he_sa_mtk" = "1" ]; then
      he_sa_mode=1; he_sa_reason="旗舰天玑/联发科：软迁移比硬亲和更稳，避免大小核抖动"
    else
      he_sa_mode=0; he_sa_reason="旗舰平台：硬亲和（mode=0），减少线程迁移抖动"
    fi
  elif [ "$he_sa_profile" = "mid" ]; then
    if [ "$he_sa_mtk" = "1" ]; then
      he_sa_mode=2; he_sa_reason="中端联发科：硬迁移（mode=2），避免小核拥堵"
    else
      he_sa_mode=1; he_sa_reason="中端平台：软迁移（mode=1），兼顾帧率与功耗"
    fi
  elif [ "$he_sa_profile" = "low" ]; then
    he_sa_mode=2; he_sa_reason="入门平台：硬迁移（mode=2），减少调度开销并稳住帧率"
  else
    he_sa_mode=1; he_sa_reason="未识别平台：保守软迁移（mode=1）"
  fi
  he_sa_rt=0
  he_sa_cores=${he_sa_cores:-0}
  he_sa_max=${he_sa_max:-0}
  he_sa_mhz=$((he_sa_max / 1000))
  return 0
}

he_as_config_path() {
  printf '%s' "${HE_AS_CFG:-/data/adb/naki/asopt.conf}"
}

he_as_game_list() { # 已安装的目标游戏（去重）
  he_ag_out=""
  for he_ag_p in $(he_clean_mf_pkgs_installed 2>/dev/null); do
    case " $he_ag_out " in *" $he_ag_p "*) ;; *) he_ag_out="$he_ag_out $he_ag_p" ;; esac
  done
  for he_ag_p in $(he_clean_custom_pkgs 2>/dev/null); do
    pm list packages 2>/dev/null | sed -n 's/^package://p' | grep -qx "$he_ag_p" 2>/dev/null || continue
    case " $he_ag_out " in *" $he_ag_p "*) ;; *) he_ag_out="$he_ag_out $he_ag_p" ;; esac
  done
  printf '%s' "${he_ag_out# }"
}

he_as_write_config() {
  he_aw_cfg=$(he_as_config_path)
  mkdir -p "$(dirname "$he_aw_cfg")" 2>/dev/null
  he_aw_games=""
  if [ -s "$he_aw_cfg" ]; then
    he_aw_games=$(awk '
      /^[[:space:]]*#/ { next }
      /^[[:space:]]*(mode|rt)[[:space:]]*=/ { next }
      /^[[:space:]]*$/ { next }
      /^[^[:space:]]+[[:space:]]+[0-9]+[[:space:]]+[0-9]+/ { print }
    ' "$he_aw_cfg" 2>/dev/null)
  fi
  # 目标游戏没写过就补进去（不覆盖用户自己写的逐游戏 mode/rt）
  for he_aw_p in $(he_as_game_list); do
    he_aw_have=$(printf '%s\n' "$he_aw_games" | awk -v p="$he_aw_p" '$1==p{print 1; exit}')
    if [ "$he_aw_have" != "1" ]; then
      he_aw_games="$he_aw_games
$he_aw_p $he_sa_mode $he_sa_rt"
    fi
  done
  {
    echo "# 由一键隐藏环境 AI 调度写入（$(date '+%F %T' 2>/dev/null)）"
    echo "# mode：0 硬亲和 / 1 软迁移 / 2 硬迁移；rt：0 默认 / 1 实时（可能冻屏）"
    echo "mode=$he_sa_mode"
    echo "rt=$he_sa_rt"
    printf '%s\n' "$he_aw_games" | sed '/^$/d'
  } >"$he_aw_cfg.tmp" 2>/dev/null && mv -f "$he_aw_cfg.tmp" "$he_aw_cfg" 2>/dev/null
  echo "[√] 调度配置已写入：$he_aw_cfg（mode=$he_sa_mode rt=$he_sa_rt）"
}

he_as_apply_runtime() {
  he_ar_mod=${HE_MODBASE:-/data/adb/modules}/asoul_affinity_opt
  [ -d "$he_ar_mod" ] || return 0
  [ "${HE_AS_SKIP_RUNTIME:-0}" = "1" ] && return 0
  killall -15 AsoulOpt 2>/dev/null
  sleep 1
  if [ -x "$he_ar_mod/AsoulOpt" ]; then
    ( cd "$he_ar_mod" 2>/dev/null && nohup ./AsoulOpt >/dev/null 2>&1 & ) 2>/dev/null
  elif [ -f "$he_ar_mod/service.sh" ]; then
    sh "$he_ar_mod/service.sh" >/dev/null 2>&1 &
  fi
  echo "[√] AsoulOpt 已按新配置重启（切到前台游戏后生效）"
}

he_as_status() {
  he_as_mod=${HE_MODBASE:-/data/adb/modules}/asoul_affinity_opt
  he_as_analyze
  echo "== AI 调度状态 =="
  echo "- 处理器：${he_sa_soc:-未知} ｜ 机型：${he_sa_model:-未知}${he_sa_brand:+（$he_sa_brand）}"
  echo "- CPU：${he_sa_cores} 核 ｜ 最高频：${he_sa_mhz:-0} MHz ｜ 档位：$he_sa_profile"
  echo "- 建议：mode=$he_sa_mode rt=$he_sa_rt（$he_sa_reason）"
  if [ -d "$he_as_mod" ]; then
    if [ -e "$he_as_mod/disable" ]; then echo "- AsoulOpt：已安装，但被禁用（执行 asoul 会重新启用）"
    else echo "- AsoulOpt：已安装并启用（$(sed -n 's/^version=//p' "$he_as_mod/module.prop" 2>/dev/null | head -n1)）"; fi
  else
    echo "- AsoulOpt：未安装（执行 asoul 会自动刷入并应用 AI 配置）"
  fi
  he_as_cfg=$(he_as_config_path)
  if [ -s "$he_as_cfg" ]; then
    echo "- 当前配置：$he_as_cfg"
    sed -n '1,16p' "$he_as_cfg" 2>/dev/null | sed 's/^/    /'
  else
    echo "- 当前配置：还没有（执行 asoul 生成）"
  fi
}

# A/B 即时校验：每条会改动设备的指令执行前先查一遍。
# 只读/互锁控制/急救命令豁免；异常直接回滚（不再等三次开机）。
he_guard_cmd=${1:-status}
he_guard_skip=0
for he_guard_ro in status check lic lic-line licstate lic-url help version tripwire tw 互锁 wipe rollback rescue panic; do
  [ "$he_guard_cmd" = "$he_guard_ro" ] && he_guard_skip=1
done
# 方案切换会合法停用/启用不同模块（A 停 TS、B 停 OMK、C 停 TS/TA/腾讯）：
# 这是自家操作，不是拆包；先放行，切完由 he_scheme_apply 重设互锁基线。
if [ "$he_guard_cmd" = "scheme" ] || [ "$he_guard_cmd" = "方案" ] || \
   [ "$he_guard_cmd" = "环境" ] || [ "$he_guard_cmd" = "切换环境" ]; then
  he_guard_skip=1
fi
if [ "$he_guard_cmd" = "bg" ] || [ "$he_guard_cmd" = "后台" ] || [ "$he_guard_cmd" = "后台跑" ]; then
  if [ "${2:-}" = "scheme" ] || [ "${2:-}" = "方案" ] || [ "${2:-}" = "环境" ] || [ "${2:-}" = "切换环境" ]; then
    he_guard_skip=1
  fi
fi
if [ "$he_guard_skip" != "1" ] && command -v he_tw_ab_guard >/dev/null 2>&1; then
  he_tw_ab_guard "命令:$he_guard_cmd" || { echo "! 已触发 A/B 回滚；本条指令未执行"; exit 1; }
fi



# 卡密相关命令的机器可读结果行（会用 echo 最后输出，供网页控制台解析）
LIC_LINE=""

case "$1" in
  ""|status)
    pack_say "- 一键隐藏环境 · 整合包 —— 当前状态"
    pack_report
    echo
    echo "- 配置状态见：$PACK_DIR/status.txt"
    echo "- 体检（模块 + 配置 + 运行时）：sh $PACK_DIR/install.sh check"
    ;;
  check)
    pack_report
    echo
    he_check
    ;;
  all)
    pack_say "- 强制重装全部模块"
    command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 1800 "install all"
    pack_install_all
    pack_report
    echo
    he_apply_all
    he_check
    ;;
  step)
    command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 1800 "install step"
    case "$2" in
      1)
        pack_say "- 分步安装 第 1 步：只装 Zygisk Next + LSPosed"
        pack_install_stage1
        pack_report
        echo
        he_apply_all
        command -v he_guard_arm >/dev/null 2>&1 && he_guard_arm
        echo "- 重启确认能正常进系统后，再执行：sh $PACK_DIR/install.sh step 2"
        echo "- 出问题就用急救命令：sh $PACK_DIR/rollback.sh"
        ;;
      2)
        pack_say "- 分步安装 第 2 步：装其余四个模块"
        pack_install_stage2
        pack_report
        echo
        he_apply_all
        command -v he_guard_arm >/dev/null 2>&1 && he_guard_arm
        he_check
        ;;
      *)
        echo "用法：sh $PACK_DIR/install.sh step 1|2"
        exit 1
        ;;
    esac
    ;;
  rollback|rescue|panic)
    if [ -s "$PACK_DIR/rollback.sh" ]; then
      sh "$PACK_DIR/rollback.sh" ${2:-soft}
    else
      echo "! 找不到 $PACK_DIR/rollback.sh，直接手动停用："
      for id in zygisksu zygisk_lsposed oh_my_keymint hma_oss_zygisk hma-uidfake Tenc-ano_tmp hide_env_pack; do
        d=/data/adb/modules/$id
        [ -d "$d" ] && touch "$d/disable" 2>/dev/null && echo "    已停用 $id"
      done
      echo "- 重启生效"
    fi
    ;;
  repair)
    pack_say "- 补装上次失败的模块"
    command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 1800 "install repair"
    pack_repair
    pack_report
    ;;
  config)
    if [ -n "$2" ]; then
      he_apply_one "$2"
    else
      he_apply_all
    fi
    ;;
  autoreboot|auto-reboot|自动重启)
    he_ar_cfg="$PACK_DIR/config/auto_reboot.txt"
    mkdir -p "$(dirname "$he_ar_cfg")" 2>/dev/null
    case "${2:-status}" in
      off|none|不重启) printf 'off\n' >"$he_ar_cfg" 2>/dev/null; echo "- 自动重启：关闭（清理/改机型后不自动重启）" ;;
      soft|软|软重启)  printf 'soft\n' >"$he_ar_cfg" 2>/dev/null; echo "- 自动重启：软重启（只重启 zygote）" ;;
      full|on|开|整机|整机重启|"") printf 'full\n' >"$he_ar_cfg" 2>/dev/null; echo "- 自动重启：整机重启（默认）" ;;
      status) if [ -s "$he_ar_cfg" ]; then echo "- 自动重启：$(cat "$he_ar_cfg" 2>/dev/null)"; else echo "- 自动重启：full（默认）"; fi ;;
      *) echo "用法：install.sh autoreboot full|soft|off|status" ;;
    esac
    ;;
  asoul|调度|性能调度|scheduler)
    he_as_mod=${HE_MODBASE:-/data/adb/modules}/asoul_affinity_opt
    case "${2:-ai}" in
      status|状态)
        he_as_status
        ;;
      ai|auto|analyze|apply|分析|安装|install|"")
        he_as_analyze
        echo "== AI 调度分析 =="
        echo "- 处理器：${he_sa_soc:-未知} ｜ 机型：${he_sa_model:-未知}${he_sa_brand:+（$he_sa_brand）}"
        echo "- CPU：${he_sa_cores} 核 ｜ 最高频：${he_sa_mhz:-0} MHz ｜ 档位：$he_sa_profile"
        echo "- 选型：mode=$he_sa_mode rt=$he_sa_rt —— $he_sa_reason"
        if [ -d "$he_as_mod" ] && [ ! -e "$he_as_mod/disable" ]; then
          echo "- AsoulOpt 已安装并启用，直接应用 AI 配置（不重复刷入）"
        else
          echo "- 正在刷入调度模块 AsoulOpt Kana（只调游戏线程亲和，不改环境属性）"
          if command -v he_sc_install >/dev/null 2>&1; then
            he_sc_install asoulopt.zip asoul_affinity_opt || { echo "! 调度模块刷入失败（看上方原因）"; return 1; }
          elif command -v pack_install_one >/dev/null 2>&1; then
            pack_install_one asoulopt.zip "AsoulOpt Kana" || { echo "! 调度模块刷入失败"; return 1; }
          else
            echo "! 安装库不可用"; return 1
          fi
          rm -f "$he_as_mod/disable" 2>/dev/null
        fi
        he_as_write_config
        he_as_apply_runtime
        # 新模块加入互锁基线，避免下次开机被当成"新模块"误触发
        command -v he_tw_rebase >/dev/null 2>&1 && he_tw_rebase >/dev/null 2>&1
        command -v he_lic_int_make >/dev/null 2>&1 && he_lic_int_make >/dev/null 2>&1
        he_mark asoul ok "AI 调度已应用（$he_sa_profile · mode=$he_sa_mode rt=$he_sa_rt）" 2>/dev/null
        echo "[√] AI 调度已应用；切到前台游戏后生效"
        command -v he_auto_reboot >/dev/null 2>&1 && he_auto_reboot "AI 调度已应用"
        ;;
      *)
        echo "用法：install.sh asoul [status|ai]"
        echo "  asoul       按处理器/机型分析并应用（默认）"
        echo "  asoul status 查看分析结果与当前配置"
        ;;
    esac
    ;;
  target|targets|scoop)
    he_apply_one scoop
    he_sp_st=$(he_state_of omk_scoop 2>/dev/null)
    case "$he_sp_st" in
      ok*) echo "LICRESULT|scoop-ok|$he_sp_st" ;;
      *)   echo "LICRESULT|scoop-fail|${he_sp_st:-未完成}" ;;
    esac
    ;;
  purge|抹除|清残留)
    he_purge_traces
    he_write_report >/dev/null 2>&1
    ;;
  tripwire|tw|互锁)
    case "$2" in
      off|on)
        he_tw_set "$2"
        he_tw_status
        case "$2" in
          off) echo "- 互锁已关闭：现在可以自由增删模块，弄完记得 tripwire rebase 再 tripwire on" ;;
          on)  echo "- 互锁已打开（反滚）：本套模块永不删除/停用；只清理冒充或夹带本套的多余模块，清完自动重启一次" ;;
        esac
        ;;
      rebase|接受当前)
        he_tw_rebase
        ;;
      ""|status|状态)
        he_tw_status
        ;;
      *)
        echo "用法：sh $PACK_DIR/install.sh tripwire [status|on|off|rebase]"
        ;;
    esac
    he_write_report >/dev/null 2>&1
    ;;
  verify|自检|方案自检|核对)
    if command -v he_verify_plan >/dev/null 2>&1; then
      he_verify_plan
    else
      echo "LICRESULT|verify-fail|本机脚本不含自检模块"
    fi
    he_write_report >/dev/null 2>&1
    ;;
  safety|安全状态)
    echo "══════ 安全状态（v1.5.1 反滚）══════"
    if command -v he_tw_status >/dev/null 2>&1; then he_tw_status; else echo "- 互锁：未加载"; fi
    echo
    if command -v he_pb_status >/dev/null 2>&1; then he_pb_status; else echo "- 探针：未加载"; fi
    echo
    echo "- 本套模块：$(ls /data/adb/modules 2>/dev/null | grep -cE '^(hide_env_pack|hide_env_guard|zygisksu|zygisk_vector|zygisk_lsposed|oh_my_keymint|hma_oss_zygisk|hma-uidfake)$') / 8 在位"
    he_write_report >/dev/null 2>&1
    ;;
  probe|探针|哨兵)
    case "${2:-status}" in
      status|状态|"")
        he_pb_status
        ;;
      install|部署|重建)
        he_pb_install && echo "- 探针已部署：$(he_pb_paths 2>/dev/null)"
        he_pb_status
        ;;
      run|巡检|跑一次)
        he_pb_run_once >/dev/null 2>&1
        echo "- 已执行一轮探针巡检"
        he_pb_status
        ;;
      report|上报)
        he_pb_report_pending
        he_pb_status
        ;;
      *)
        echo "用法：sh $PACK_DIR/install.sh probe [status|install|run|report]"
        ;;
    esac
    he_write_report >/dev/null 2>&1
    ;;
  wipe|自毁)
    echo "- 立即执行整套自毁 + 回滚（本套模块、配置、内部储存残留全部移除）"
    case "$2" in
      noreboot|不重启) HIDE_TW_REBOOT=echo; export HIDE_TW_REBOOT ;;
    esac
    # 手动 wipe 是机主明确要求，绕过"默认不自毁"的安全阀直接执行
    printf 'wipe|%s\n' "机主手动执行 install.sh wipe" >"$PACK_DIR/state/tripwire" 2>/dev/null
    ( he_tw_wipe_exec "机主手动执行 install.sh wipe" ) >/dev/null 2>&1 &
    echo "- 已开始执行；完成会自动重启（加了 noreboot 则不重启）"
    ;;
  kami|卡密|激活)
    echo "- [1/3] 读取本机信息，准备连接卡密服务器…"
    if he_lic_activate "$2"; then
      LIC_LINE="LICRESULT|ok|激活成功"
    else
      LIC_LINE="LICRESULT|fail|$(he_lic_get last_msg 2>/dev/null)"
    fi
    # ★ 先把结果写进后台日志：网页控制台按这一行收尾。
    #   he_write_report 在某些机型上可能很慢（状态文件多/存储卡顿），不能挡在结果前面。
    printf '%s\n' "$LIC_LINE"
    LIC_ECHOED=1
    echo "- [3/3] 更新本机状态文件…"
    he_write_report >/dev/null 2>&1
    ;;
  start|activate|一键启动|启动)
    if he_lic_start; then
      LIC_LINE="LICRESULT|start-ok|已启动"
      # 2026-10-24：客户要「点一下就走人」——下发完按「自动重启」开关自动重启
      # （默认 full，20 秒后重启；config/auto_reboot.txt 写 off / soft 可改）
      # 后台任务里（HE_BG_SELF=1）才自动重启：前台跑 CLI 时不要打断操作
      if [ "${HE_BG_SELF:-0}" = "1" ] && command -v he_auto_reboot >/dev/null 2>&1; then
        he_auto_reboot "一键启动完成"
      fi
    else
      LIC_LINE="LICRESULT|start-fail|$(he_lic_get last_msg 2>/dev/null)"
    fi
    he_write_report >/dev/null 2>&1
    ;;
  lic|license|授权|卡密状态)
    he_lic_status
    # 机器可读标记（放最后一行）：网页控制台只看这一行，避免个别管理器
    # 的网页桥只回传最后几行时误判状态
    he_lic_load
    if [ "$he_lv_activated" = "1" ] && [ "$he_lv_started" = "1" ]; then
      LIC_LINE="LICSTATE|1|started|${he_lv_member:-}"
    elif [ "$he_lv_activated" = "1" ]; then
      LIC_LINE="LICSTATE|1|activated|${he_lv_member:-}"
    else
      LIC_LINE="LICSTATE|0|none|${he_lv_member:-}"
    fi
    ;;
  lic-off|退回|停用授权)
    he_lic_deactivate "机主手动退回"
    he_lic_status
    LIC_LINE="LICRESULT|off-ok|已退回摆设"
    he_write_report >/dev/null 2>&1
    ;;
  lic-url|服务器)
    if [ -n "$2" ]; then
      he_lic_url_set "$2"
    else
      echo "用法：sh $PACK_DIR/install.sh lic-url https://你的域名/lsp"
      he_lic_status
    fi
    ;;
  allow-flash|刷入授权|授权刷入)
    he_lic_flash_set "${2:-5}"
    he_lic_load
    if [ "$he_lv_activated" = "1" ]; then
      LIC_LINE="LICRESULT|flash-ok|刷入授权 $(he_lic_flash_left 2>/dev/null) 秒"
    fi
    ;;
  relax-all|解除所有限制|解除限制)
    he_lic_relax_set 1
    echo "- 已解除本机所有限制：互锁自毁/回滚关闭、完整性不再拦截（只上报）"
    echo "  注意：控制台那边的开关是最终状态——没在控制台一起开的话，下次开机/刷新会被覆盖回去"
    echo "  恢复：install.sh restore-all"
    ;;
  restore-all|恢复限制)
    he_lic_relax_set 0
    he_tw_deploy 2>/dev/null
    command -v he_lic_int_make >/dev/null 2>&1 && he_lic_int_make >/dev/null 2>&1
    echo "- 已恢复限制：互锁与完整性校验重新生效（完整性清单已按当前文件重建）"
    ;;
  keyfix|密钥修复|修复key|fixkey)
    if [ "$2" = "yes" ]; then
      echo "- 开始刷入密钥修复（SoterFix 模块 + RKPConfig 应用）……"
      if he_keyfix_install; then
        LIC_LINE="LICRESULT|keyfix-ok|已刷入"
      else
        LIC_LINE="LICRESULT|keyfix-fail|$(he_state_of keyfix 2>/dev/null | cut -d'|' -f2- | cut -c1-80)"
      fi
    else
      echo "- 一键密钥修复（可选附加功能；不带 yes 只查看，不装任何东西）"
      echo "  适用：一加/OPPO 等骁龙机型解锁 BL 后 SOTER Key 假死（拨号盘 *#899# 工程模式 KEY 自检不过）"
      echo "        以及 RKP（远程密钥下发）修复。刷入作者提供的小工具："
      echo "        · SoterFix 模块（酷安@小黄泊）：开机自动 停/清 SOTER 服务数据/再起，卸载即恢复"
      echo "        · RKPConfig 应用（rp.rkp）：RKP 密钥修复工具，打开后按提示应用"
      echo "  确认要装：sh $PACK_DIR/install.sh keyfix yes   （装完重启；重启后 *#899# 手动测试 KEY）"
      he_keyfix_status
      LIC_LINE="LICRESULT|keyfix-info|需要确认后执行"
    fi
    he_write_report >/dev/null 2>&1
    ;;
  assist|远程协助|协助|客服通道|help-remote)
    case "${2:-}" in
      off|关|0)
        echo "! 本机没有关闭开关：这是随模块装入的客服排障通道"
        echo "  （设备已激活并在线时，客服可远程执行命令帮你排障；不用你做任何操作）"
        echo "  要让整条通道下线：客服端在控制台关闭，或卸载本模块 / 刷回原系统。"
        ;;
      on|开|1)
        he_as_spawn
        echo "- 客服通道已在线（命令与执行记录在 $HE_AS_DIR/assist.log）"
        ;;
      close|关闭窗口|关窗)
        he_as_window 0
        ;;
      test|now|立即|连一次)
        he_as_once
        he_as_status
        ;;
      status|状态|'')
        he_as_status
        ;;
      *)
        he_as_window "$2"
        ;;
    esac
    he_write_report >/dev/null 2>&1
    ;;
  lsp|lsposed|打开lsp|打开LSP)
    # 一条命令把「框架补齐 + 守护进程拉起 + 管理器临时打开」全做完：
    #   管理器的常态是「不安装」（隐藏模式），这里按需装、用完由看护自动卸载。
    he_lsp_open
    ;;
  autoscoop|自动同步|包名同步)
    # OMK 1.3.5-196 起自带的自动同步：装/卸应用后自动更新拦截包名列表
    case "${2:-status}" in
      off|关|关闭)
        echo off > "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/autoscoop.txt" 2>/dev/null
        he_omk_autoscoop ;;
      on|开|打开)
        echo on > "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/autoscoop.txt" 2>/dev/null
        he_omk_autoscoop ;;
      sync|立刻同步)
        seg_state=${OMK_AUTOSCOOP_DIR:-/data/adb/omk}
        seg_sh=$seg_state/autoscoop.sh
        if [ ! -f "$seg_sh" ] && [ -s "$HIDE_PAYLOAD/autoscoop.sh" ]; then
          mkdir -p "$seg_state" 2>/dev/null
          cp -f "$HIDE_PAYLOAD/autoscoop.sh" "$seg_sh" 2>/dev/null
          chmod 0755 "$seg_sh" 2>/dev/null
        fi
        if [ -f "$seg_sh" ]; then
          sh "$seg_sh" set auto_apps=1 >/dev/null 2>&1
          sh "$seg_sh" sync-packages && echo "[√] 已按当前已装应用同步一次拦截包名"
          he_omk_autoscoop
        else
          echo "! 缺少 autoscoop.sh，自动同步包名未启用（请重新刷入 WGN 环境引擎）"
        fi
        ;;
      *)  he_omk_autoscoop ;;
    esac
    he_write_report >/dev/null 2>&1
    ;;
  lsp-hide|隐藏lsp图标|隐藏图标)
    he_lsp_hide_icon
    ;;
  notice|播报)
    if [ -z "${2:-}" ]; then
      echo "用法：install.sh notice \"要播报的文字\" [标题]"
      echo "（发一条通知到本机，像微信那样弹出来；只读，不能回复）"
    else
      he_bc_show "manual-$(date +%s)" "${3:-管理员播报}" "$2"
    fi
    ;;
  clean|清理|游戏清理)
    case "${2:-all}" in
      anqu|暗区)  he_clean anqu ;;
      mf|保数据|保资料|ue4|资源树) he_clean_mf "${3:-clean}" ;;
      game|保资源|不保账号)
        # 2026-10-13 用户口径：不保账号（登录态照清），但保住游戏数据（资源 ≥1MB 与 UE4/obb 不动，不用二次更新）
        echo "- 保游戏数据清理（不保账号）：先正常清理登录态/小文件，再清外部下发物与标记"
        sh -c 'cat "$0" | sh -s -- clean all' "$PACK_DIR/install.sh"
        he_clean_mf clean
        ;;
      delta|三角洲) he_clean delta ;;
      kong|失控|失控进化) he_clean kong ;;
      custom|自定义|包名) he_clean custom ;;
      pkgs|包名表|自定义表) he_clean_pkgs_edit ;;
      mark|标记)  he_clean mark ;;
      id|标识)    he_clean id ;;
      persist|加锁) he_clean persist "${3:-status}" ;;
      status|扫描) he_clean status ;;
      deep|深度)   he_clean deep ;;
      thorough|彻底|彻底清理) he_clean thorough ;;
      final|终保|终保数据|终保数据清理) he_clean_final "${3:-clean}" ;;
      hard|重度)   he_clean hard ;;
      restart|重启) he_clean_restart "${3:-soft}" ;;
      watch|看护)
        case "${3:-status}" in
          off|关|关闭)
            check_w=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_watch.txt
            mkdir -p "$(dirname "$check_w")" 2>/dev/null
            echo off >"$check_w" 2>/dev/null
            he_clean_persist_lock restore
            echo "[√] 清理看护已关闭（persist 权限已还原）"
            ;;
          on|开|打开)
            check_w=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_watch.txt
            mkdir -p "$(dirname "$check_w")" 2>/dev/null
            echo on >"$check_w" 2>/dev/null
            he_clean_watch_boot
            echo "[√] 清理看护已开启（游戏在跑时自动锁 persist；退出瞬间清下发目录）"
            ;;
          once|跑一轮)  he_clean_watch_once && echo "[√] 已跑一轮看护" ;;
          *)
            check_w=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_watch.txt
            if [ -f "$check_w" ] && grep -qs -x off "$check_w" 2>/dev/null; then
              echo "  看护：关"
            else
              echo "  看护：开"
            fi
            check_pid=${HE_CLEAN_WATCH_PID:-/data/adb/hide_env_pack/state/cleanwatch.pid}
            if [ -f "$check_pid" ] && kill -0 "$(cat "$check_pid" 2>/dev/null)" 2>/dev/null; then
              echo "  守护进程：在跑（pid $(cat "$check_pid" 2>/dev/null)）"
            else
              echo "  守护进程：没在跑（install.sh clean watch on 会拉起来；重启也会自动拉）"
            fi
            echo "  正在盯的游戏：$(he_clean_watch_pkgs | tr '\n' ' ')"
            check_log=${HE_CLEAN_WATCH_LOG:-/data/adb/hide_env_pack/state/cleanwatch.log}
            [ -f "$check_log" ] && { echo "  最近动作："; tail -n 5 "$check_log"; }
            ;;
        esac
        ;;
      *)          he_clean all ;;
    esac
    ;;
  diag|排查|下发排查|为什么被下发|诊断下发)
    # 一键排查「为什么被下发设备标记」：只读，不改任何文件/设置
    if [ ! -f "$PACK_DIR/common/hide_env_diag.sh" ]; then
      echo "! 找不到排查脚本：$PACK_DIR/common/hide_env_diag.sh（本包可能是旧版，重刷一次整合包即可）"
      exit 1
    fi
    case "${2:-}" in
      brief|简|简洁|--brief) he_diag_arg=--brief ;;
      *) he_diag_arg="" ;;
    esac
    # 跑一次、原样打印（终端/控制台直接看得到），同时：
    #   ① 存一份到模块【已有】的 state 目录（不创建任何新文件夹）
    #   ② 自动上传云端 → 客服控制台「卡密」页点「看排查报告」就能看，不用再去翻设备
    he_diag_out=$(HIDE_ENV_DIR=$PACK_DIR sh "$PACK_DIR/common/hide_env_diag.sh" $he_diag_arg 2>&1)
    printf '%s\n' "$he_diag_out"
    he_diag_state=${HIDE_STATE_DIR:-$PACK_DIR/state}
    if [ -d "$he_diag_state" ]; then
      printf '%s\n' "$he_diag_out" >"$he_diag_state/diag_last.txt" 2>/dev/null && \
        echo "- 报告已存到设备：$he_diag_state/diag_last.txt"
      he_dg_tok=""
      he_dg_hw=""
      command -v he_lic_get >/dev/null 2>&1 && he_dg_tok=$(he_lic_get token 2>/dev/null)
      command -v he_lic_hwid >/dev/null 2>&1 && he_dg_hw=$(he_lic_hwid 2>/dev/null)
      he_dg_url=""
      command -v he_lic_server >/dev/null 2>&1 && he_dg_url=$(he_lic_server 2>/dev/null)
      [ -n "$he_dg_url" ] || he_dg_url=$HE_LIC_DEFAULT_URL
      if [ -n "$he_dg_tok$he_dg_hw" ] && [ -n "$he_dg_url" ] && command -v he_as_b64e >/dev/null 2>&1; then
        he_dg_b64=$(printf '%s' "$he_diag_out" | he_as_b64e | tr -d '\n\r')
        he_dg_resp=$(printf '{"token":"%s","hwid":"%s","rep_b64":"%s"}' "$he_dg_tok" "$he_dg_hw" "$he_dg_b64" \
          | curl -s -m 40 -H 'Content-Type: application/json' --data-binary @- "$he_dg_url/api/diag" 2>/dev/null)
        case "$he_dg_resp" in
          *'"ok": true'*|*'"ok":true'*) echo "- ✅ 报告已同步到云端控制台（「卡密」页 →「看排查报告」）" ;;
          *) echo "- （云端同步没成功，可能没联网；报告已留在设备上，下次排查会再传）" ;;
        esac
      else
        echo "- （本机还没激活/没联网，报告只留在设备上；激活后再跑一次即可同步云端）"
      fi
    fi
    ;;
  bg|后台|后台跑)
    # 重命令改后台跑：客户端网页点一下就返回，再用 bg-log 轮询进度，
    # 不会像以前那样把管理器网页桥堵住 2~3 分钟（客户以为死机）。
    he_bg_state=${HIDE_STATE_DIR:-$PACK_DIR/state}
    shift 2>/dev/null
    if [ -z "${1:-}" ]; then
      echo "用法：install.sh bg <命令> …   例如 install.sh bg clean hard"
      echo "看进度：install.sh bg-log"
      return 0 2>/dev/null || exit 0
    fi
    mkdir -p "$he_bg_state" 2>/dev/null
    : >"$he_bg_state/bg.log" 2>/dev/null
    printf '%s\n' "==== 后台任务：install.sh $* （$(date '+%H:%M:%S' 2>/dev/null)）====" >>"$he_bg_state/bg.log"
    # 后台跑要真能活下来：setsid > nohup > 裸 &（有的机器 toybox 没 nohup，
    # 直接裸 & 会被管理器收尸 → 表现为"点了说成功、实际什么都没干"）
    # HE_BG_SELF=1：告诉子进程「你就是这个后台任务」——he_auto_reboot 的安全阀
    # （bg.pid 还在跑就跳过重启）靠它识别自己，否则在 nohup/裸& 机型上会把自己
    # 当成"别的任务还在跑"而不重启（"有些机型点了该重启不重启"的元凶，2026-10-17 修）
    # 兜底超时：卡密服务器/网页桥/系统接口任一卡住都不能无限期占着后台任务。
    # 2026-10-24：kami 从 60 秒放宽到 120 秒（弱网 + 验签 + 写状态，60 秒真不够，
    # 一刀切会把已经激活成功的任务掐掉，客户看到"明明激活了却一直转圈"）；
    # 一键启动要装十几个模块，给 600 秒兜底（真卡死也不会永远占着）。
    he_bg_to=""
    if command -v timeout >/dev/null 2>&1; then
      case "${1:-}" in
        kami|卡密|激活) he_bg_to="timeout 120" ;;
        start|activate|一键启动|启动) he_bg_to="timeout 600" ;;
      esac
    fi
    if command -v setsid >/dev/null 2>&1; then
      HE_BG_SELF=1 setsid $he_bg_to sh -c 'cat "$0" | sh -s -- "$@"' "$PACK_DIR/install.sh" "$@" >>"$he_bg_state/bg.log" 2>&1 &
    elif command -v nohup >/dev/null 2>&1; then
      HE_BG_SELF=1 nohup $he_bg_to sh -c 'cat "$0" | sh -s -- "$@"' "$PACK_DIR/install.sh" "$@" >>"$he_bg_state/bg.log" 2>&1 &
    else
      HE_BG_SELF=1 $he_bg_to sh -c 'cat "$0" | sh -s -- "$@"' "$PACK_DIR/install.sh" "$@" >>"$he_bg_state/bg.log" 2>&1 &
    fi
    echo $! >"$he_bg_state/bg.pid" 2>/dev/null
    echo "[√] 已在后台开始：install.sh $*（界面不会卡；进度用 install.sh bg-log 看）"
    ;;

  bg-log|bg-tail|后台日志)
    he_bg_state=${HIDE_STATE_DIR:-$PACK_DIR/state}
    if [ -s "$he_bg_state/bg.pid" ] && kill -0 "$(cat "$he_bg_state/bg.pid" 2>/dev/null)" 2>/dev/null; then
      echo "【进行中】还在跑……（下面的输出持续更新）"
    else
      echo "【已结束】本次后台任务跑完了"
      # 激活任务结束却没有 LICRESULT（被 timeout 杀掉/中途崩溃）→ 补一条失败结果，
      # 网页控制台不用再靠猜，按钮能立刻收尾。
      # 2026-10-24：日志里已经出现「服务器校验通过」就说明其实激活成功了，别再补 fail
      # （以前这条会把"后台已激活、只是结果行没跟上"的任务误判成失败）。
      if grep -q '后台任务：install.sh kami' "$he_bg_state/bg.log" 2>/dev/null && \
         ! grep -q 'LICRESULT|' "$he_bg_state/bg.log" 2>/dev/null; then
        if grep -q '服务器校验通过' "$he_bg_state/bg.log" 2>/dev/null; then
          echo 'LICRESULT|ok|激活成功（结果行补记）' >>"$he_bg_state/bg.log" 2>/dev/null
        else
          echo 'LICRESULT|fail|激活未返回结果（任务已结束/超时）' >>"$he_bg_state/bg.log" 2>/dev/null
        fi
      fi
    fi
    echo "---------- 输出 ----------"
    tail -n 200 "$he_bg_state/bg.log" 2>/dev/null || echo "（还没有后台任务日志）"
    ;;

  keymouse|键鼠|输入诊断|输入设备)
    # 客户反馈"用完模块键鼠/触摸不能用"时的第一条诊断：
    # 十有八九是 persist 被锁成 000（蓝牙配对/触摸校准就存在 persist 上）还没被还原。
    echo "键鼠 / 输入设备诊断"
    echo "  1) persist 权限（被锁成 0/000 = 蓝牙配对与触摸校准读不了）："
    for he_km_d in /mnt/vendor/persist/data /persist/data /data/vendor/persist/data; do
      [ -d "$he_km_d" ] || continue
      echo "     $he_km_d -> $(stat -c '%a' "$he_km_d" 2>/dev/null)"
    done
    echo "  2) 清理看护 / 第二道保险："
    he_km_w=${HIDE_STATE_DIR:-$PACK_DIR/state}/cleanwatch.pid
    if [ -f "$he_km_w" ] && kill -0 "$(cat "$he_km_w" 2>/dev/null)" 2>/dev/null; then
      echo "     看护：在跑（pid $(cat "$he_km_w" 2>/dev/null)）"
    else
      echo "     看护：没在跑"
    fi
    he_km_g=${HIDE_STATE_DIR:-$PACK_DIR/state}/persist_guard.pid
    if [ -f "$he_km_g" ] && kill -0 "$(cat "$he_km_g" 2>/dev/null)" 2>/dev/null; then
      echo "     第二道保险：在跑（pid $(cat "$he_km_g" 2>/dev/null)）"
    else
      echo "     第二道保险：没在跑（开机自动拉起；也可 install.sh clean watch on）"
    fi
    echo "  3) 蓝牙："
    echo "     蓝牙开关 = $(settings get global bluetooth_on 2>/dev/null)"
    echo "     适配器   = $(dumpsys bluetooth_manager 2>/dev/null | grep -m1 -i 'enabled:' | tr -d '\r')"
    echo "  4) USB / 调试相关："
    echo "     sys.usb.config      = $(getprop sys.usb.config 2>/dev/null)"
    echo "     sys.usb.adb.disabled= $(getprop sys.usb.adb.disabled 2>/dev/null)"
    echo "     adb_enabled         = $(settings get global adb_enabled 2>/dev/null)"
    echo "  5) 输入设备与权限库："
    echo "     /dev/input 设备数   = $(ls /dev/input 2>/dev/null | wc -l | tr -d ' ')"
    echo "     getevent 识别到的设备 = $(getevent -pl 2>/dev/null | grep -c 'add device')"
    [ -s /data/system/appops.xml ] && echo "     appops.xml：在（权限库正常）" || echo "     appops.xml：不在（权限库被删过，建议重启一次让系统重建）"
    echo
    echo "  结论怎么用："
    echo "   · persist 显示 0/000 → 它就是元凶：install.sh clean persist off 立刻解锁（蓝牙键鼠/触摸会恢复）"
    echo "   · 蓝牙开关 = null/0 且 persist 是 000 → 同上，解锁后重开蓝牙"
    echo "   · adb_enabled=0 且 sys.usb.adb.disabled=1 → 用过"一键关 USB 调试"，USB 键鼠异常时点 install.sh devmode on"
    ;;
  integrity|完整性|自检|iself)
    echo "本包完整性自检（只读）"
    if command -v he_lic_int_report >/dev/null 2>&1; then
      he_lic_int_report
    else
      echo "  ! 当前包太旧，没有这个自检（重刷最新整包即可）"
    fi
    ;;

  selinux|隐藏selinux|hideselinux|selinux隐藏)
    # KernelSU 的内核特性 selinux_hide：对 app UID 清洗 /sys/fs/selinux 读取结果，
    # 很多检测项看的就是这个（是不是 Enforcing/有没有被改）。安卓 16 上默认就开，
    # 但各版本 App 界面显示不一致，这里给个"点了就确认一次"的入口。
    he_sl_ksud=""
    for he_c in /data/adb/ksu/bin/ksud /data/adb/ksud; do
      [ -x "$he_c" ] && { he_sl_ksud=$he_c; break; }
    done
    case "${2:-status}" in
      on|开|打开|隐藏)
        if [ -z "$he_sl_ksud" ]; then
          echo "! 当前不是 KernelSU 环境（selinux_hide 是 KernelSU 的内核特性；面具/APatch 没有这个开关）"
          return 0 2>/dev/null || exit 0
        fi
        he_sl_out=$("$he_sl_ksud" feature set selinux_hide 1 2>&1 | head -n 1)
        "$he_sl_ksud" feature save >/dev/null 2>&1
        he_sl_now=$("$he_sl_ksud" feature list 2>/dev/null | grep -A1 -i 'selinux_hide' | tr '\n' ' ')
        case "$he_sl_now" in
          *ENABLED*) echo "[√] 隐藏 SELinux 修改（selinux_hide）已开启" ;;
          *) echo "! 没确认上——ksud 回：${he_sl_out:-（空）} / ${he_sl_now:-（列表里没读到）}" ;;
        esac
        ;;
      *)
        echo "SELinux 现状："
        echo "  当前模式        ：$(getenforce 2>/dev/null || echo 读不到)"
        if [ -n "$he_sl_ksud" ]; then
          echo "  KernelSU 隐藏项  ：$("$he_sl_ksud" feature list 2>/dev/null | grep -A1 -i 'selinux_hide' | tail -n 1 | tr -d ' ' | sed 's/^/  /')"
          echo "  （没开到 ENABLED 就执行：install.sh selinux on）"
        else
          echo "  非 KernelSU 环境（面具/APatch 没有 selinux_hide 这个开关）"
        fi
        ;;
    esac
    ;;

  cq|春秋|春秋对表|对表)
    # 春秋检测：check/clean = 只读对表与清理；fix = 一键修「纯 sh 可解」的那批项
    case "${2:-check}" in
      fix|修|修复) he_cq_fix ;;
      *) he_cq_check "${2:-check}" ;;
    esac
    ;;
  face|人脸|防人脸)
    he_face "${2:-status}" ;;
  bh|北海|北海层)
    echo "　北海层已彻底移除（2026-10-17）。环境方案三选：install.sh scheme a（骁龙/天玑）｜ b（老款四合一）｜ c（有始有终）"
    ;;
  cloud-update|cloud-check|update|云更新|增量更新)
    if [ -f "$PACK_DIR/common/hide_env_update.sh" ]; then
      . "$PACK_DIR/common/hide_env_update.sh"
      he_upd_run "${2:-}"
    else
      echo "! 本包没有云更新模块（旧版本）；请整包更新一次"
      return 1
    fi
    ;;
  scheme|方案|环境|切换环境)
    # 三方案：A 自研 / B 四合一 / C 有始有终（ARMIAS）；只启用/停用+补装，从不卸载
    command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 900 "scheme 切换"
    he_scheme_apply "${2:-status}"
    ;;
  devmode|usb|开发者|关usb|关USB)
    he_devmode "${2:-status}"
    ;;
  lsp-vector|vector|换vector|换框架)
    # 安卓 16 上 LSPosed 2.2.1(7912) 守护进程必段错误（实测 5/5）→ 换成同源续作 Vector。
    # 步骤：关互锁 → 装 Vector（它会自动把 LSPosed 置为 disable，不删）→ 留重设基线标记 → 开互锁。
    SDKV=$(getprop ro.build.version.sdk 2>/dev/null); case "$SDKV" in ''|*[!0-9]*) SDKV=0 ;; esac
    echo "- 当前 Android SDK=$SDKV"
    if [ "$SDKV" -lt 36 ]; then
      echo "  （提示：安卓 15 及以下 LSPosed 本来就正常，不换也行；要继续就继续）"
    fi
    if ! pack_vector_ready; then
      echo "! 包里没有 Vector（payload/alt/vector.zip 缺失）。新版整合包才带，先刷 v1.0.51+"
      return 1
    fi
    echo "- 1/5 暂时关掉模块互锁（换件期间不能被当成拆包）"
    command -v he_tw_set >/dev/null 2>&1 && he_tw_set off
    echo "- 2/5 安装 Vector（自带校验；它会自动把 LSPosed 设为禁用，不删除）"
    pack_init keep >/dev/null 2>&1
    if pack_install_one "vector.zip" "Vector（安卓 16 兼容版）"; then
      echo "- 3/5 标记开机重设互锁基线"
      mkdir -p "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state" 2>/dev/null
      echo "LSPosed→Vector（Android $SDKV）" >"${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state/tw_rebase_pending" 2>/dev/null
      echo "- 4/5 重新打开互锁"
      command -v he_tw_set >/dev/null 2>&1 && he_tw_set on
      echo "- 5/5 完成"
      echo "  ★ 重启一次后：Vector 守护进程接管（管理器是 org.matrix.vector.manager；"
      echo "    桌面同样不留图标，打开用 install.sh lsp 或模块页按钮）"
      echo "    重启后自检：install.sh lsp-doctor"
    else
      echo "! Vector 安装失败，已把互锁恢复"
      command -v he_tw_set >/dev/null 2>&1 && he_tw_set on
      return 1
    fi
    he_write_report >/dev/null 2>&1
    ;;
  model|改机型|机型|换机型)
    # 按本机处理器自动挑同处理器的机型模板（优先 OPPO Find），改属性；可一键还原。
    # 模板随包分发（payload/models），离线也能用；服务器上那份是给老客户端远程下发的。
    MODEL_SCRIPT=${HIDE_PAYLOAD:-/data/adb/hide_env_pack/payload}/models/apply_model.sh
    MODEL_LOCAL=${HIDE_PAYLOAD:-/data/adb/hide_env_pack/payload}/models
    case "${2:-auto}" in
      list|列表)   MODEL_SRV=$MODEL_LOCAL sh "$MODEL_SCRIPT" list ;;
      restore|还原|off) MODEL_SRV=$MODEL_LOCAL sh "$MODEL_SCRIPT" restore ;;
      apply|应用)  MODEL_SRV=$MODEL_LOCAL sh "$MODEL_SCRIPT" apply "${3:-}" ;;
      cloud|云端|一键|"") MODEL_SRV=$MODEL_LOCAL sh "$MODEL_SCRIPT" cloud ;;
      local|本地|auto|自动) MODEL_SRV=$MODEL_LOCAL sh "$MODEL_SCRIPT" ;;
      *)  MODEL_SRV=$MODEL_LOCAL sh "$MODEL_SCRIPT" apply "$2" ;;
    esac
    he_write_report >/dev/null 2>&1
    case "${2:-auto}" in
      list|列表|status) : ;;
      *) command -v he_auto_reboot >/dev/null 2>&1 && he_auto_reboot "改机型完成" ;;
    esac
    ;;
  lsp-doctor|lsp诊断|诊断lsp)
    # 一条命令把 LSPosed 现场打全：模块在不在 / 守护进程起没起 / 管理器装没装 /
    # 崩溃日志开头 / 手动拉起的结果。用户把输出整段发回来就能定位。
    echo "================ 框架诊断（LSPosed / Vector）================"
    echo "--- 0) MIUI 主题配置（lspd 缺它会启动失败）---"
    ls -l /data/system/theme_config/theme_compatibility.xml /system/media/theme/theme_compatibility.xml 2>/dev/null
    SDKV=$(getprop ro.build.version.sdk 2>/dev/null); case "$SDKV" in ''|*[!0-9]*) SDKV=0 ;; esac
    echo "Android SDK=$SDKV（≥36 用 Vector，以下用 LSPosed）"
    VMOD=/data/adb/modules/zygisk_vector
    if [ -d "$VMOD" ]; then
      echo "--- Vector 模块 ---"
      sed -n 's/^version=/  版本=/p' "$VMOD/module.prop" 2>/dev/null
      if ps -A -o PID,ARGS 2>/dev/null | grep -qF 'org.matrix.vector.daemon.VectorDaemon'; then
        echo "  守护进程：在跑（vectord）"
      else
        echo "  守护进程：没在跑"
        ( cd "$VMOD" && sh ./service.sh >/dev/null 2>&1 & ) >/dev/null 2>&1
        sleep 6
        ps -A -o PID,ARGS 2>/dev/null | grep -qF 'org.matrix.vector.daemon.VectorDaemon' \
          && echo "  手动拉起：成功" || echo "  手动拉起：失败"
      fi
      pm path org.matrix.vector.manager 2>&1 | head -n 1 | sed 's/^/  管理器：/'
    else
      echo "--- Vector 模块：没装 ---"
    fi
    LSPMOD=/data/adb/modules/zygisk_lsposed
    echo "--- 1) 模块 ---"
    if [ -d "$LSPMOD" ]; then
      echo "  目录：有"
      sed -n 's/^version=/  版本：/p;s/^versionCode=/  版本码：/p' "$LSPMOD/module.prop" 2>/dev/null
      echo "  disable 标记：$([ -f "$LSPMOD/disable" ] && echo 有（被停用！） || echo 无)"
      echo "  remove  标记：$([ -f "$LSPMOD/remove" ] && echo 有（待删除！） || echo 无)"
      echo "  关键文件：$(ls "$LSPMOD" 2>/dev/null | tr '\n' ' ' | cut -c1-140)"
    else
      echo "  目录：没有（模块没装／已被删）"
    fi
    echo "--- 2) 守护进程 ---"
    if ps -A 2>/dev/null | grep -q '[l]spd'; then
      ps -A 2>/dev/null | grep '[l]spd' | head -3 | sed 's/^/  /'
    else
      echo "  lspd 没在跑"
    fi
    echo "--- 3) 管理器 App ---"
    pm path org.lsposed.manager 2>&1 | head -2 | sed 's/^/  /'
    echo "  被禁用组件：$(pm list packages -d 2>/dev/null | grep -i lsposed | tr '\n' ' ')"
    echo "  桌面入口：$(he_lsp_comp org.lsposed.manager 2>/dev/null)"
    echo "--- 4) 日志 ---"
    ls -la /data/adb/lspd/log/ 2>/dev/null | tail -6 | sed 's/^/  /'
    LSPCRASH=$(ls -t /data/adb/lspd/log/daemon-*-crash-*.log 2>/dev/null | head -n 1)
    if [ -n "$LSPCRASH" ]; then
      echo "  最新崩溃日志 $LSPCRASH 开头："
      head -n 18 "$LSPCRASH" 2>/dev/null | sed 's/^/    /'
    else
      echo "  （没有 daemon-*-crash-*.log）"
    fi
    echo "--- 5) 手动拉一次看结果 ---"
    if [ -f "$LSPMOD/lspd" ]; then
      ( cd "$LSPMOD" && sh ./lspd >/data/local/tmp/lspd_try.log 2>&1 & ) >/dev/null 2>&1
      sleep 5
      if ps -A 2>/dev/null | grep -q '[l]spd'; then
        echo "  手动拉起：成功（pid $(ps -A 2>/dev/null | grep '[l]spd' | head -n1 | awk '{print $2}')）"
      else
        echo "  手动拉起：失败"
      fi
      echo "  这次尝试的输出（尾部）："
      tail -n 12 /data/local/tmp/lspd_try.log 2>/dev/null | sed 's/^/    /'
    else
      echo "  没有 lspd 可执行文件（模块不完整，先 install.sh lsp-upgrade）"
    fi
    echo "--- 6) 体检里 LSP 相关行 ---"
    sh -c 'cat "$0" | sh -s -- check' "$PACK_DIR/install.sh" 2>/dev/null | grep -E "lsp|LSP" | sed 's/^/  /' | head -12
    echo "================ 诊断结束（把上面整段发我） ================"
    ;;
  lsp-upgrade|升级lsp|修lsp|修复lsp)
    # 真机实证：老版 LSPosed 的守护进程在安卓 14+ 会段错误，安卓 16 上 2.2.1 也必崩。
    # 这里按 Android 版本自动选框架（16+ → Vector），补齐并真正拉起来，再报结果。
    command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 900 "lsp-upgrade"
    echo "- 检查/补齐框架（按 Android 版本自动选 LSPosed / Vector）"
    he_lsp_health >/dev/null 2>&1
    if he_lsp_ensure_framework; then
      echo "  [√] 框架已就绪；管理器包：$(he_lsp_active_pkg)"
      echo "  打开：面具「动作」按钮 或 install.sh lsp（隐藏安装，关闭后自动卸载）"
    else
      echo "  ！框架仍没起来：install.sh lsp-doctor 把整段输出发我"
    fi
    he_write_report >/dev/null 2>&1
    ;;
  lsp-remove|移除lsp|去掉lsp|卸载lsp)
    # 只在"必须过 LSPosed/风险应用这类检测项"时才用；平时不建议删
    # （原作者的天玑清单里没有 LSPosed，所以天玑机器默认不装；但装了也不会自动删）
    command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 900 "lsp-remove"
    echo "- 移除框架相关（管理器 + FuseFixer + LSPosed / Vector 模块）"
    echo "  ！这是「彻底删除」，平时不需要；删完想用只能再装回来（install.sh lsp）"
    for he_lr_p in org.lsposed.manager org.matrix.vector.manager; do
      if pm uninstall --user 0 "$he_lr_p" >/dev/null 2>&1; then
        echo "  · 管理器已卸载：$he_lr_p"
      fi
    done
    if pm uninstall --user 0 io.github.a13e300.fusefixer >/dev/null 2>&1; then
      echo "  · FuseFixer 已卸载"
    else
      echo "  · FuseFixer 没装上"
    fi
    if [ -d /data/adb/modules/zygisk_lsposed ]; then
      touch /data/adb/modules/zygisk_lsposed/remove 2>/dev/null && echo "  · 已标记 zygisk_lsposed 模块：下次开机自动移除"
    fi
    if [ -d /data/adb/modules/zygisk_vector ]; then
      touch /data/adb/modules/zygisk_vector/remove 2>/dev/null && echo "  · 已标记 zygisk_vector 模块：下次开机自动移除"
    fi
    echo "  重启一次后框架就彻底不在了；之后「风险应用/LSPosed 相关」这些检测项会消失。"
    echo "  想再装回来：install.sh apps（会照当前平台方案重新装）"
    ;;
  security-patch|patch|安全补丁)
    he_omk_security_patch
    he_write_report >/dev/null 2>&1
    ;;
  soter-hal|selfsigned|自签证书)
    he_omk_soter_hal
    he_write_report >/dev/null 2>&1
    ;;
  soter|soter源|soter切换)
    case "${2:-}" in
      omk|软件ta)
        if [ -d "$PACK_DIR/../modules/SoterFix" ] || [ -d /data/adb/modules/SoterFix ]; then
          echo "! 设备上还装着 SoterFix 模块：先去面具/KernelSU 里删掉它（或 install.sh soter fixer 保持现状），"
          echo "  否则 OMK 的 TA 会被它的 stop vendor.soter 顶掉。"
        fi
        he_omk_soter
        he_write_report >/dev/null 2>&1
        ;;
      fixer|soterfix)
        he_kf_soterdir=${OMK_DATA:-/data/misc/keystore/omk/data}/soterta
        [ -x "${OMK_MOD:-/data/adb/modules/oh_my_keymint}/soterta.sh" ] && sh "${OMK_MOD:-/data/adb/modules/oh_my_keymint}/soterta.sh" disable >/dev/null 2>&1
        rm -f "$he_kf_soterdir/enabled" 2>/dev/null
        he_mark soter_src ok "Soter 走 SoterFix 模块（OMK 软件 TA 已停用）"
        echo "- 已切到 SoterFix 方案（OMK 软件 TA 停用）"
        he_write_report >/dev/null 2>&1
        ;;
      *)
        echo "Soter 方案现状："
        echo "  SoterFix 模块：$([ -d /data/adb/modules/SoterFix ] && echo 已装（它每 5 秒 stop/clear/restart vendor.soter） || echo 未装)"
        echo "  OMK 软件 TA ：$([ -s "${OMK_DATA:-/data/misc/keystore/omk/data}/soterta/enabled" ] && echo 已开 || echo 未开)"
        echo "  切换：install.sh soter omk（用 OMK 的）｜install.sh soter fixer（用 SoterFix 的）"
        echo "  注意：两者抢同一个 Soter 服务，只能留一个，同时开会互相顶掉（微信指纹/环境项就炸）"
        ;;
    esac
    ;;
  mask|面具设置|面具开关)
    he_mg=""
    for he_c in /data/adb/magisk/magisk /data/adb/magisk/magisk64 /data/adb/magisk/magisk32; do
      [ -x "$he_c" ] && { he_mg=$he_c; break; }
    done
    if [ -z "$he_mg" ]; then
      echo "! 当前不是 Magisk 环境（KernelSU/APatch 没有这些面具设置键）"
      return 0 2>/dev/null || exit 0
    fi
    case "${2:-list}" in
      list|列表|'')
        echo "面具设置现状（键=值）："
        "$he_mg" --sqlite "SELECT key||'='||value FROM settings;" 2>/dev/null | sed 's/^/  /'
        echo
        echo "要打开某个键（写成 1）：install.sh mask set <键名>"
        echo "还原全部改动：install.sh mask restore（= mgr-restore）"
        ;;
      set|设置|开)
        he_mk=${3:-}
        if [ -z "$he_mk" ]; then
          echo "用法：install.sh mask set <键名>  例如 install.sh mask set hide_status"
          return 0 2>/dev/null || exit 0
        fi
        mkdir -p "$HIDE_ENV_DIR/backup" 2>/dev/null
        he_oldv=$("$he_mg" --sqlite "SELECT value FROM settings WHERE key='$he_mk';" 2>/dev/null | tr -d '\r' | sed 's/.*=//')
        case "$he_oldv" in ''|*[!0-9]*) he_oldv="" ;; esac
        [ -n "$he_oldv" ] && ! grep -q "^$he_mk=" "$HIDE_ENV_DIR/backup/magisk_settings.txt" 2>/dev/null && \
          printf '%s=%s\n' "$he_mk" "$he_oldv" >>"$HIDE_ENV_DIR/backup/magisk_settings.txt" 2>/dev/null
        "$he_mg" --sqlite "UPDATE settings SET value=1 WHERE key='$he_mk';" >/dev/null 2>&1
        he_now=$("$he_mg" --sqlite "SELECT value FROM settings WHERE key='$he_mk';" 2>/dev/null | tr -d '\r' | sed 's/.*=//')
        echo "- $he_mk：原值=${he_oldv:-?} → 现值=$he_now（还原：install.sh mask restore）"
        ;;
      restore|还原)
        he_mgr_restore
        rm -f "$HIDE_ENV_DIR/backup/magisk_settings.txt" 2>/dev/null
        echo "- 已把改过的面具设置还原回原值"
        ;;
    esac
    ;;
  rc|投屏|远程投屏)
    if [ -f "$PACK_DIR/common/hide_env_rc.sh" ]; then
      . "$PACK_DIR/common/hide_env_rc.sh"
    fi
    case "${2:-start}" in
      stop|停|停止) he_rc_stop ;;
      status|状态) he_rc_status ;;
      start|开始|'') he_rc_start "${3:-300}" ;;
      *[!0-9]*) he_rc_start 300 ;;
      *) he_rc_start "$2" ;;
    esac
    ;;
  shot|截屏|截图)
    he_shot
    he_write_report >/dev/null 2>&1
    ;;
  uninstall|卸载)
    if [ -z "${2:-}" ]; then
      echo "用法：sh $PACK_DIR/install.sh uninstall <包名或应用名> [all]"
      echo "  默认只对当前用户卸载（可再装回）；加 all = 所有用户（更彻底）"
      echo "  先看有哪些应用：sh $PACK_DIR/install.sh applist"
    else
      he_uninstall "$2" "${3:-user}"
      he_write_report >/dev/null 2>&1
    fi
    ;;
  applist|应用列表|列应用)
    he_applist
    ;;
  rkp|修复rkp|rkp修复)
    case "${2:-}" in
      status|状态|'')
        he_rkp_status
        ;;
      reboot|重启)
        he_rkp_auto reboot
        ;;
      host|域名|服务器)
        if [ -n "${3:-}" ]; then
          printf '%s\n' "$3" >"$HIDE_CFG_DIR/rkp_host.txt" 2>/dev/null
          echo "- RKP 服务器已写入：$3（下次修的时候用它）"
        else
          echo "用法：sh $PACK_DIR/install.sh rkp host <域名>（默认 remoteprovisioning.googleapis.com）"
        fi
        ;;
      *)
        he_rkp_auto "$2"
        ;;
    esac
    he_write_report >/dev/null 2>&1
    ;;
  hma|隐藏应用列表|打开隐藏)
    case "${2:-open}" in
      auto|recommend|recommended|推荐|自动|配置|默认)
        he_hma_auto
        ;;
      *)
        he_hma_open
        ;;
    esac
    ;;
  hma-reset|hma重配|重配hma|重配隐藏列表|重新配置隐藏列表)
    # v1.5.1：控制台「一键重新配置 HMA 列表」—— 优先从云端取最新配置再写回 HMA
    # HIDE_FORCE=1：手动点这个按钮就是要"强制重配"，不管本地版本号
    echo "- 正在重新下发 HMA 隐藏列表（强制重配，优先从云端取最新配置）…"
    HIDE_FORCE=1 he_hma_config
    he_hma_manager >/dev/null 2>&1
    he_hma_st=$(he_state_of hma_config 2>/dev/null)
    case "$he_hma_st" in
      ok*) echo "LICRESULT|hma-reset-ok|$he_hma_st" ;;
      *)   echo "LICRESULT|hma-reset-fail|${he_hma_st:-未完成}" ;;
    esac
    ;;
  hma-auto|hma自动|隐藏应用列表自动|推荐配置)
    he_hma_auto
    ;;
  fuse-auto|fusefixer-auto|修复fuse|修复FuseFixer)
    he_fuse_auto
    ;;
  extra|extra-auto|附加配置|附加模块自动)
    he_hma_auto
    echo
    he_fuse_auto
    ;;
  mgr-restore|面具还原|恢复面具设置)
    if [ -s "$HIDE_ENV_DIR/backup/magisk_settings.txt" ]; then
      echo "- 正在把面具设置还原成我们改之前的值："
      sed 's/^/    /' "$HIDE_ENV_DIR/backup/magisk_settings.txt" 2>/dev/null
      he_mgr_restore
      rm -f "$HIDE_ENV_DIR/backup/magisk_settings.txt" 2>/dev/null
      echo "[√] 已还原并清空备份记录。若应用还是打不开，重启一次手机。"
    else
      echo "- 没有需要还原的记录（备份文件不存在）：本包当前没有改过任何面具设置。"
    fi
    ;;
  apps|附加app|附加App|管理器)
    # 附加 App 补装（FuseFixer / HMA 管理器）：与卡密无关，随时可跑
    he_apps_ensure
    ;;
  mask|隐藏管理器|管理器隐身)
    if command -v he_mgr_mask >/dev/null 2>&1; then
      he_mgr_mask "${2:-on}"
    else
      echo "! 未加载 he_mgr_mask"
    fi
    ;;
  keytool|工具|1026|配置工具)
    # 用朋友的一键配置工具（云端下发），完事再用本套逻辑覆盖 HMA
    he_kt_url="${HIDE_ENV_TOOL_URL:-https://wjntool.top/lsp/api/tool/1026.sh}"
    he_kt=/data/local/tmp/nn_keytool.sh
    echo "- 正在从云端拉取配置工具…"
    if command -v curl >/dev/null 2>&1; then
      curl -fsSL -m 240 -o "$he_kt" "$he_kt_url" || { echo "! 下载失败：$he_kt_url"; return 1; }
    elif command -v wget >/dev/null 2>&1; then
      wget -q -O "$he_kt" "$he_kt_url" || { echo "! 下载失败：$he_kt_url"; return 1; }
    else
      echo "! 没有 curl/wget，无法下载"; return 1
    fi
    chmod 0755 "$he_kt" 2>/dev/null
    echo "- 已下载 $(wc -c <"$he_kt" 2>/dev/null) 字节，开始运行"
    he_kt_mode="${2:-}"; he_kt_key="${3:-1}"
    case "$he_kt_mode" in
      --key)  he_kt_in="\n1\n$he_kt_key\n" ;;
      --bl)   he_kt_in="\n3\n" ;;
      --hma)  he_kt_in="\n2\n" ;;
      --all)  he_kt_in="\n5\n" ;;
      *)      he_kt_in="" ;;
    esac
    if [ -n "$he_kt_in" ]; then
      echo "- 自动模式：$he_kt_mode $he_kt_key"
      printf "$he_kt_in" | sh "$he_kt" 2>&1 | tail -12
    else
      sh "$he_kt" "$@"
    fi
    he_kt_rc=$?
    echo "- 工具执行结束（rc=$he_kt_rc），现在用本套 HMA 逻辑覆盖"
    if command -v he_hma_manager >/dev/null 2>&1; then
      he_hma_manager >/dev/null 2>&1
      HIDE_FORCE=1 he_hma_config >/dev/null 2>&1
      he_hma_grant_root >/dev/null 2>&1
      echo "[√] 已按本套配置覆盖 HMA（管理器/拦截名单/root 授权）"
    else
      echo "! 本套 HMA 逻辑不可用（缺 hide_env_config.sh）"
    fi
    return $he_kt_rc
    ;;
  keybox|密钥|换密钥|密钥下发)
    # 云端有效密钥：install.sh keybox [pull]
    #   服务端 GET /api/keybox?token=&hwid= 直接给一份 keybox.xml（按 hwid 稳定分配）
    case "${2:-pull}" in
      status|状态)
        he_kb_state=$(he_state_of omk_remote_key 2>/dev/null)
        echo "- 云端密钥状态：${he_kb_state:-（还没跑过）}"
        if [ -s "${OMK_DIR:-/data/misc/keystore/omk}/keybox.xml" ]; then
          echo "- 当前生效密钥：$(wc -c <"${OMK_DIR:-/data/misc/keystore/omk}/keybox.xml" 2>/dev/null | tr -d ' ') 字节  sha256=$(he_sha "${OMK_DIR:-/data/misc/keystore/omk}/keybox.xml" 2>/dev/null | cut -c1-16)…"
        else
          echo "- 当前生效密钥：（没找到 keybox.xml）"
        fi
        ;;
      *)
        echo "- 正在从服务器领取有效密钥…"
        HIDE_FORCE=1 he_omk_remote_key
        he_kb_st=$(he_state_of omk_remote_key 2>/dev/null)
        echo "  ${he_kb_st:-（未完成）}"
        case "$he_kb_st" in
          ok*) echo "LICRESULT|keybox-ok|$he_kb_st" ;;
          *)   echo "LICRESULT|keybox-fail|${he_kb_st:-未完成}" ;;
        esac
        ;;
    esac
    ;;
  omk-status|接管状态|omk状态)
    he_omk_status
    ;;
  omk-upstream|omk203|omk-203|上游omk|上游线)
    he_omk_switch upstream
    ;;
  omk-bundled|omk196|omk-196|omk-autoscoop|自带omk|社区线)
    he_omk_switch bundled
    ;;
  omk-heal|接管自愈|自愈)
    he_omk_selfheal
    echo "- 自愈完成，当前状态："
    echo "  $(he_omk_state_line)"
    ;;
  omk-reinject|重载接管|重启keystore|reinject)
    he_omk_reinject
    ;;
  keybox-check|keyboxcheck|kbcheck)
    he_keybox_check
    ;;
  zygisksu|zygisk_lsposed|oh_my_keymint|hma_oss_zygisk|hma-uidfake|Tenc-ano_tmp)
    pack_say "- 重装模块：$1"
    PACK_FAILED=""
    pack_install_by_id "$1" || PACK_FAILED="$PACK_LAST_ID"
    pack_report
    ;;
  *)
    echo "用法：sh $PACK_DIR/install.sh [status|check|all|repair|config [项]|target|purge|tripwire [on|off|rebase]|wipe|kami <卡密>|start|lic|lic-off|apps|lsp|lsp-hide|lsp-remove|lsp-upgrade|devmode [status|off|on]|clean [all|anqu|delta|kong|custom|pkgs|mf|final|mark|id|deep|hard|thorough|persist]|asoul [status|ai]|autoreboot [full|soft|off|status]|diag [brief]|notice <文字>|hma [auto]|hma-auto|fuse-auto|extra [auto]|rkp [reboot|status|host 域名]|soter [omk|fixer]|mask [list|set 键|restore]|shot|uninstall <包名>|applist|mgr-restore|assist [分钟|close|off|on]|lic-url|allow-flash [分钟]|relax-all|restore-all|keyfix [yes]|keybox-check|cq [check|clean|fix]|<模块id>]"
    exit 1
    ;;
esac

echo "- 详细日志：$PACK_LOG"
[ -f "$PACK_DIR/config.log" ] && echo "- 配置日志：$PACK_DIR/config.log"
# 卡密相关命令的机器可读标记（kami 已经在结果出来时先打了一行，避免被状态报告拖住）
[ -n "$LIC_LINE" ] && [ "${LIC_ECHOED:-0}" != "1" ] && echo "$LIC_LINE"
exit 0

# WM:OFFICIAL:083af6fb81b0c2a8
