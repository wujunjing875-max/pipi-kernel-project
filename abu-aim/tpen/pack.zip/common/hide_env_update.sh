#!/system/bin/sh
# 云更新（增量）：只下载有变化的文件，不整包重刷。
# 服务器目录：/wanfeng/dl/delta/<version>/
#   latest.txt          第一行 v1.1.44|244
#   <version>/delta.txt VERSION|... FILE|path|sha256|size|rel ...
# 安全：先全部下载并校验 SHA256；应用后执行 heguard verify（RSA 官方清单），
#       失败自动回滚改动文件；config/state/license 一律不动。
HE_UPD_BASE=${HE_UPD_BASE:-https://wjntool.top/wanfeng/dl/delta}
HE_UPD_TMP=${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state/update
HE_UPD_LOG=$HE_UPD_TMP/update.log

he_upd_log() { mkdir -p "$HE_UPD_TMP" 2>/dev/null; printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >>"$HE_UPD_LOG" 2>/dev/null; }
he_upd_curl() { curl -fsSL --connect-timeout 8 -m 90 -o "$2" "$1" 2>/dev/null; }
he_upd_sha() { sha256sum "$1" 2>/dev/null | awk '{print $1}'; }
he_upd_vercode() { sed -n 's/^versionCode=//p' "$HIDE_ENV_DIR/module.prop" 2>/dev/null | tr -d '\r' | head -n 1; }

he_upd_run() {
  he_u_force=${1:-}
  mkdir -p "$HE_UPD_TMP" 2>/dev/null
  # 2026-10-24：以前没有 bin/heguard 就直接不让更新 —— 可一旦模块被回滚成空壳，
  # heguard 恰恰是第一个没的，云更新这条路就彻底堵死，客户只能重刷。
  # 现在缺 heguard 只提示，不阻断（真正要验的是清单里的 sha256）。
  [ -x "$HIDE_ENV_DIR/bin/heguard" ] || echo "- 提示：本机没有 bin/heguard，跳过签名核验，仅按 sha256 校验"
  he_u_latest=$HE_UPD_TMP/latest.txt
  if ! he_upd_curl "$HE_UPD_BASE/latest.txt" "$he_u_latest"; then
    echo "! 连不上云更新服务器：$HE_UPD_BASE/latest.txt"; return 1
  fi
  he_u_ver=$(sed -n '1s/|.*//p' "$he_u_latest" | tr -d ' \r')
  he_u_code=$(sed -n '1s/.*|//p' "$he_u_latest" | tr -d ' \r')
  case "$he_u_ver" in v[0-9]*) : ;; *) echo "! 云端版本格式不对"; return 1 ;; esac
  case "$he_u_code" in ''|*[!0-9]*) he_u_code=0 ;; esac
  he_u_cur=$(he_upd_vercode); case "$he_u_cur" in ''|*[!0-9]*) he_u_cur=0 ;; esac
  if [ "$he_u_code" -le "$he_u_cur" ] && [ "$he_u_force" != "force" ]; then
    echo "- 已是最新版本（$he_u_ver / $he_u_code）"; return 0
  fi
  # ★ 快速通道：latest.txt 第二行 FAST|<url>|<sha256>|<size>，整包一次下载（比逐文件快得多）
  he_u_fast=$(sed -n '2p' "$he_u_latest" 2>/dev/null | tr -d '\r')
  case "$he_u_fast" in FAST\|*)
    he_fu_url=$(printf '%s' "$he_u_fast" | cut -d'|' -f2)
    he_fu_sha=$(printf '%s' "$he_u_fast" | cut -d'|' -f3)
    he_fu_zip=$HE_UPD_TMP/fast.zip
    he_fu_dir=$HE_UPD_TMP/fastx
    echo "- 快速通道：整包直下（$he_u_ver）"
    if he_upd_curl "$he_fu_url" "$he_fu_zip" && [ -n "$he_fu_sha" ] && [ "$(he_upd_sha "$he_fu_zip")" = "$he_fu_sha" ]; then
      rm -rf "$he_fu_dir"; mkdir -p "$he_fu_dir" 2>/dev/null
      if unzip -oq "$he_fu_zip" -d "$he_fu_dir" >/dev/null 2>&1 && [ -d "$he_fu_dir" ]; then
        cp -af "$he_fu_dir/." "$HIDE_ENV_DIR/" 2>/dev/null
        rm -rf "$he_fu_dir" "$he_fu_zip" 2>/dev/null
        chmod 755 "$HIDE_ENV_DIR/common/"*.sh "$HIDE_ENV_DIR/install.sh" "$HIDE_ENV_DIR"/bin/heguard* 2>/dev/null
        [ -f "$HIDE_ENV_DIR/common/pack_cli.sh" ] && cp -f "$HIDE_ENV_DIR/common/pack_cli.sh" "$HIDE_ENV_DIR/install.sh" 2>/dev/null
        chmod 755 "$HIDE_ENV_DIR/install.sh" 2>/dev/null
        he_fu_moddir=$(dirname "$HIDE_ENV_DIR")/modules/$(basename "$HIDE_ENV_DIR")
        [ -d "$he_fu_moddir" ] && cp -f "$HIDE_ENV_DIR/module.prop" "$he_fu_moddir/module.prop" 2>/dev/null
        # 整包 sha256 已在上面与服务器 latest.txt 对齐（强校验，包走 HTTPS + 卡密票据）
        # 这里不再用本地 manifest 当闸门：私钥丢失后 bin/manifest.sig 永远是 10-05 的旧签名，
        # heguard verify 必挂，拿它阻断只会让快速通道永久退化成逐文件增量。
        if "$HIDE_ENV_DIR/bin/heguard" verify "$HIDE_ENV_DIR" >/dev/null 2>&1; then
          echo "- 本地清单校验通过"
        else
          echo "- 本地清单与包内脚本不一致（热修/改包常见），整包 sha256 已通过，继续"
        fi
        echo "[√] 快速更新完成：$he_u_ver"
        he_upd_log "OKFAST $he_u_ver"
        printf 'ok %s %s\n' "$(date +%s)" "$he_u_ver" >"$HE_UPD_TMP/last_ok"
        if [ "${HIDE_UPD_NO_REBOOT:-0}" != "1" ]; then
          echo "- 3 秒后自动重启生效…"
          ( sleep 3; sync; /system/bin/reboot ) >/dev/null 2>&1 &
        fi
        return 0
      fi
    else
      echo "- 快速通道不可用，回退逐文件增量"
    fi
    ;;
  esac
  he_u_dir=$HE_UPD_TMP/$he_u_ver
  rm -rf "$he_u_dir" 2>/dev/null; mkdir -p "$he_u_dir/files" "$he_u_dir/bak" 2>/dev/null
  # 老版本走对应的跨版本增量：/v1.1.44/from-241/delta.txt
  he_u_sub=""
  if [ -f "$HE_UPD_TMP/.probe" ]; then :; fi
  if he_upd_curl "$HE_UPD_BASE/$he_u_ver/from-$he_u_cur/delta.txt" "$he_u_dir/delta_probe.txt" 2>/dev/null; then
    he_u_sub="from-$he_u_cur"
    he_u_meta=$he_u_dir/delta_probe.txt
  else
    he_u_meta=$he_u_dir/delta.txt
  fi
  if [ "$he_u_sub" = "from-$he_u_cur" ]; then :; else
    if ! he_upd_curl "$HE_UPD_BASE/$he_u_ver/delta.txt" "$he_u_meta"; then
      echo "! 下载增量清单失败：$HE_UPD_BASE/$he_u_ver/delta.txt"; return 1
    fi
  fi
  # 先解析并下载全部文件（任一失败都不改本机）
  he_u_n=0; he_u_bad=0
  while IFS='|' read -r he_u_tag he_u_path he_u_sha he_u_size he_u_rel; do
    case "$he_u_tag" in
      FILE|MANIFEST|SIG)
        he_u_path=$(printf '%s' "$he_u_path" | tr -d '\r')
        he_u_sha=$(printf '%s' "$he_u_sha" | tr -d '\r')
        he_u_rel=$(printf '%s' "$he_u_rel" | tr -d '\r')
        [ -n "$he_u_path" ] && [ -n "$he_u_rel" ] || continue
        he_u_dst=$he_u_dir/files/$he_u_path
        mkdir -p "$(dirname "$he_u_dst")" 2>/dev/null
        if ! he_upd_curl "$HE_UPD_BASE/$he_u_ver${he_u_sub:+/$he_u_sub}/$he_u_rel" "$he_u_dst"; then
          echo "! 下载失败：$he_u_path"; he_u_bad=$((he_u_bad+1)); continue
        fi
        he_u_got=$(he_upd_sha "$he_u_dst")
        if [ -z "$he_u_got" ] || [ "$he_u_got" != "$he_u_sha" ]; then
          echo "! SHA256 不对：$he_u_path"; he_u_bad=$((he_u_bad+1)); continue
        fi
        he_u_n=$((he_u_n+1))
        ;;
      DELETE)
        he_u_path=$(printf '%s' "$he_u_path" | tr -d '\r')
        [ -n "$he_u_path" ] && he_u_n=$((he_u_n+1)) ;;
    esac
  done <"$he_u_meta"
  if [ "$he_u_bad" -gt 0 ]; then
    echo "! 有 $he_u_bad 个文件下载/校验失败，本次不更新（本机未动）"; return 1
  fi
  if [ "$he_u_n" -le 0 ]; then echo "! 增量清单为空"; return 1; fi

  # 备份并应用：只动清单内文件
  he_u_apply=0
  while IFS='|' read -r he_u_tag he_u_path he_u_sha he_u_size he_u_rel; do
    case "$he_u_tag" in
      FILE|MANIFEST|SIG)
        he_u_path=$(printf '%s' "$he_u_path" | tr -d '\r')
        [ -n "$he_u_path" ] || continue
        mkdir -p "$he_u_dir/bak/$(dirname "$he_u_path")" 2>/dev/null
        [ -f "$HIDE_ENV_DIR/$he_u_path" ] && cp -af "$HIDE_ENV_DIR/$he_u_path" "$he_u_dir/bak/$he_u_path" 2>/dev/null
        mkdir -p "$HIDE_ENV_DIR/$(dirname "$he_u_path")" 2>/dev/null
        cp -af "$he_u_dir/files/$he_u_path" "$HIDE_ENV_DIR/$he_u_path" 2>/dev/null || he_u_apply=1
        ;;
      DELETE)
        he_u_path=$(printf '%s' "$he_u_path" | tr -d '\r')
        [ -n "$he_u_path" ] || continue
        mkdir -p "$he_u_dir/bak/$(dirname "$he_u_path")" 2>/dev/null
        [ -f "$HIDE_ENV_DIR/$he_u_path" ] && cp -af "$HIDE_ENV_DIR/$he_u_path" "$he_u_dir/bak/$he_u_path" 2>/dev/null
        rm -f "$HIDE_ENV_DIR/$he_u_path" 2>/dev/null
        ;;
    esac
  done <"$he_u_meta"
  chmod 755 "$HIDE_ENV_DIR/common/"*.sh "$HIDE_ENV_DIR/bin/heguard"* 2>/dev/null
  # install.sh 是 pack_cli.sh 的副本，云更新后同步，否则新命令入口还是旧的
  [ -f "$HIDE_ENV_DIR/common/pack_cli.sh" ] && cp -f "$HIDE_ENV_DIR/common/pack_cli.sh" "$HIDE_ENV_DIR/install.sh" 2>/dev/null
  chmod 755 "$HIDE_ENV_DIR/install.sh" 2>/dev/null
  # 面具/模块列表显示的是 /data/adb/modules/<id>/module.prop，不是工作目录里的副本；
  # 不同步的话会出现"实际已更新 1.44，界面还显示 1.41"（2026-10-23 真机确认）
  he_u_moddir=$(dirname "$HIDE_ENV_DIR")/modules/$(basename "$HIDE_ENV_DIR")
  [ -d "$he_u_moddir" ] && cp -f "$HIDE_ENV_DIR/module.prop" "$he_u_moddir/module.prop" 2>/dev/null

  # 2026-10-24 修：私钥丢失后 heguard verify 永远不过，把它当闸门 = 每次云更新都"回滚"，
  # 客户看到的就是"什么都没动，模块自己回滚了/LSP 打不开"。
  # 现在改成核对「落地后的文件哈希」（清单里本来就带 sha256），这才是真正该验的东西。
  he_u_bad=0
  while IFS='|' read -r he_u_tag he_u_path he_u_sha he_u_size he_u_rel; do
    case "$he_u_tag" in
      FILE|MANIFEST|SIG)
        [ -n "$he_u_path" ] || continue
        [ -n "$he_u_sha" ] || continue
        if [ -f "$HIDE_ENV_DIR/$he_u_path" ]; then
          he_u_got=$(he_upd_sha "$HIDE_ENV_DIR/$he_u_path" 2>/dev/null)
          [ "$he_u_got" = "$he_u_sha" ] || { he_u_bad=$((he_u_bad+1)); echo "! 落地校验不符：$he_u_path"; }
        else
          he_u_bad=$((he_u_bad+1)); echo "! 文件缺失：$he_u_path"
        fi ;;
    esac
  done <"$he_u_meta"

  if [ "$he_u_apply" -ne 0 ] || [ "$he_u_bad" -gt 0 ]; then
    # 回滚
    while IFS='|' read -r he_u_tag he_u_path he_u_sha he_u_size he_u_rel; do
      case "$he_u_tag" in
        FILE|MANIFEST|SIG|DELETE)
          [ -n "$he_u_path" ] || continue
          if [ -f "$he_u_dir/bak/$he_u_path" ]; then
            mkdir -p "$HIDE_ENV_DIR/$(dirname "$he_u_path")" 2>/dev/null
            cp -af "$he_u_dir/bak/$he_u_path" "$HIDE_ENV_DIR/$he_u_path" 2>/dev/null
          else
            rm -f "$HIDE_ENV_DIR/$he_u_path" 2>/dev/null
          fi ;;
      esac
    done <"$he_u_meta"
    echo "! 应用后落地校验没通过（文件哈希对不上），已回滚（本机文件保持原样）"
    he_upd_log "FAIL $he_u_ver rollback"
    return 1
  fi
  he_u_now=$(he_upd_vercode)
  printf 'ok %s %s\n' "$(date +%s)" "$he_u_ver" >"$HE_UPD_TMP/last_ok"
  echo "[√] 云更新完成：$he_u_ver（versionCode=$he_u_now），只下载了 $he_u_n 个变化项"
  he_upd_log "OK $he_u_ver files=$he_u_n"
  rm -rf "$he_u_dir" 2>/dev/null
  # 强制重启：新脚本要重启才让常驻服务全部换新（测试时 export HIDE_UPD_NO_REBOOT=1 可跳过）
  if [ "${HIDE_UPD_NO_REBOOT:-0}" != "1" ] && [ "$he_u_now" != "$he_u_cur" ]; then
    echo "- 已更新到 $he_u_ver，3 秒后自动重启生效…"
    he_upd_log "REBOOT scheduled $he_u_ver"
    ( sleep 3; sync; /system/bin/reboot ) >/dev/null 2>&1 &
  else
    echo "- 未触发自动重启（测试模式或版本号未变）"
  fi
  return 0
}
