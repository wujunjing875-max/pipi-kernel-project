#!/system/bin/sh
#############################################################
# hide_env_guard.sh —— 开机看门狗（防无限重启）
#
# 问题：这套包里有三个是「系统级」组件（Zygisk Next / LSPosed / UID Fake 内核模块），
#       在个别设备上和已有的 Zygisk 框架、内核版本冲突时会把 zygote/system_server
#       搞崩，表现就是刷完无限重启，用户再也进不了系统。
#
# 做法：安装（或 install.sh all/config）后写一份 guard 标记。
#       之后每次开机，本模块的 service.sh 会在后台盯着 sys.boot_completed：
#         * 走到了      → 开机成功，撤掉标记（保险解除，之后不再管）
#         * 软窗口(480s)过了还在"有进展"（动画在跑/dev.bootcomplete）→ 继续等到硬上限(900s)
#         * 确实没进展  → 先只记一笔（不动模块、不重启）；**下次开机仍失败**才自动把这套装的
#                         全部模块停用（disable 标记）并重启一次，让设备一定能回到系统里
#       最多连做 3 次，避免自己把设备拖进死循环。
#       ★ 为什么要"两次才动手"：现场事故 —— 慢机器首次开机超过 240 秒被误判成失败，
#         全体模块被打上 disable 并重启，客户看到的就是"随机重启 + 重启后掉模块"。
#
# 注意：如果是内核级崩溃（例如 UID Fake 的 ko 让内核 panic），init 可能根本走不到
#       执行模块脚本这一步，这种情况下看门狗也起不来 —— 那种情况请用
#       root 管理器的安全模式（开机按住音量下）或 recovery 里执行 rollback.sh。
#############################################################

HIDE_ENV_DIR=${HIDE_ENV_DIR:-/data/adb/hide_env_pack}
HE_GUARD_FILE=$HIDE_ENV_DIR/guard
HE_GUARD_FAIL=$HIDE_ENV_DIR/guard_fail
HE_GUARD_LOG=$HIDE_ENV_DIR/guard.log
# 软窗口：超过它开始看"还有没有进展"；硬上限：有进展最多等到这里（慢机器/首次开机）
#   现场教训：原来固定 240 秒，慢机器明明能开机也被判失败 → 停用全部模块 + 重启，
#   这就是客户说的"随机重启、重启后掉模块"。
HE_GUARD_WAIT=${HE_GUARD_WAIT:-480}
HE_GUARD_HARD=${HE_GUARD_HARD:-900}
HE_GUARD_MAX=3
# 下面两个只为了自测时能指向沙盒；正常运行时用默认值
HE_MODBASE=${HE_MODBASE:-/data/adb/modules}

he_guard_arm() { # 安装/重装后调用：装上保险
  mkdir -p "$HIDE_ENV_DIR" 2>/dev/null
  printf '%s\n' "$HE_GUARD_MAX" >"$HE_GUARD_FILE" 2>/dev/null
  printf '[guard] 已装保险：接下来 %s 次开机若 240 秒内起不来，会自动停用本包模块\n' "$HE_GUARD_MAX" >>"$HE_GUARD_LOG" 2>/dev/null
  return 0
}

he_guard_disarm() {
  rm -f "$HE_GUARD_FILE" 2>/dev/null
  printf '[guard] 开机成功，保险解除（%s）\n' "$(date '+%Y-%m-%d %H:%M:%S')" >>"$HE_GUARD_LOG" 2>/dev/null
  return 0
}

he_guard_left() {
  [ -f "$HE_GUARD_FILE" ] || return 0
  v=$(tr -dc '0-9' <"$HE_GUARD_FILE" 2>/dev/null)
  [ -n "$v" ] || v=0
  printf '%s' "$v"
}

# 后台看门狗：service.sh 里以 & 启动
he_guard_watch() {
  left=$(he_guard_left)
  [ -n "$left" ] || return 0
  [ "$left" -gt 0 ] || return 0

  printf '[guard] 本次开机盯着（剩余机会 %s）\n' "$left" >>"$HE_GUARD_LOG" 2>/dev/null

  waited=0
  he_g_ok=0
  while [ "$waited" -lt "$HE_GUARD_HARD" ]; do
    if [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; then
      he_g_ok=1
      break
    fi
    if [ "$waited" -ge "$HE_GUARD_WAIT" ]; then
      # 过了软窗口：只要系统还在"有进展"（开机动画在跑 / dev.bootcomplete 已置位），
      # 就继续等（慢机器、首次开机、dex2oat 都可能超过 4 分钟）。
      he_g_bn=$(getprop init.svc.bootanim 2>/dev/null)
      he_g_dc=$(getprop dev.bootcomplete 2>/dev/null)
      if [ "$he_g_bn" != "running" ] && [ "$he_g_dc" != "1" ]; then
        break
      fi
    fi
    sleep 10
    waited=$((waited + 10))
  done

  if [ "$he_g_ok" = "1" ]; then
    rm -f "$HE_GUARD_FAIL" 2>/dev/null
    he_guard_disarm
    return 0
  fi

  # 判定"开机失败"：**要连续两次开机都失败才动手** —— 第一次只记一笔，
  # 不动模块、不重启（宁可多给一次机会，也不要再出现"能开机却被停用全部模块"）。
  if [ ! -f "$HE_GUARD_FAIL" ]; then
    printf 'boot_fail %s waited=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$waited" >"$HE_GUARD_FAIL" 2>/dev/null
    printf '[guard] 本次开机 %s 秒未完成且看不到进展：先记一笔，不动模块也不重启（下次开机仍失败才回滚）\n' "$waited" >>"$HE_GUARD_LOG" 2>/dev/null
    return 0
  fi

  # 超时：开机没起来 —— 停用本包全部模块，然后重启一次
  rm -f "$HE_GUARD_FAIL" 2>/dev/null
  left=$((left - 1))
  printf '%s\n' "$left" >"$HE_GUARD_FILE" 2>/dev/null
  printf '[guard] 警告：%s 秒内没有开机完成，判定为开机失败（剩余机会 %s），开始自动回滚\n' "$HE_GUARD_WAIT" "$left" >>"$HE_GUARD_LOG" 2>/dev/null

  # 急救回滚前先关互锁：不然"停用模块"本身就是互锁的触发条件，会连锁自毁
  if [ -d "$HIDE_ENV_DIR/config" ]; then
    printf 'off\n' >"$HIDE_ENV_DIR/config/tripwire.txt" 2>/dev/null
    printf '[guard] 已关闭模块互锁（避免急救回滚触发自毁）\n' >>"$HE_GUARD_LOG" 2>/dev/null
  fi

  for id in zygisksu zygisk_lsposed oh_my_keymint hma_oss_zygisk hma-uidfake Tenc-ano_tmp hide_env_pack hide_env_guard; do
    d=$HE_MODBASE/$id
    [ -d "$d" ] || continue
    touch "$d/disable" 2>/dev/null
    printf '[guard] 已停用 %s\n' "$id" >>"$HE_GUARD_LOG" 2>/dev/null
  done

  # 先把数据分区刷盘，再重启
  sync
  if [ "$HE_GUARD_NO_REBOOT" = "1" ]; then
    printf '[guard] （自测模式：不重启）\n' >>"$HE_GUARD_LOG" 2>/dev/null
    return 0
  fi
  if command -v svc >/dev/null 2>&1; then
    svc power reboot 2>/dev/null
  elif command -v reboot >/dev/null 2>&1; then
    reboot 2>/dev/null
  fi
  return 0
}
