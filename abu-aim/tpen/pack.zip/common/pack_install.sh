#!/system/bin/sh
#############################################################
# pack_install.sh —— 一键隐藏环境·整合包 的安装核心（三种场景共用）
#   1) 刷入时：被模块的 customize.sh source
#   2) 开机补装：被 service.sh 调用（只补上次失败的模块）
#   3) 手动重装：sh /data/adb/hide_env_pack/install.sh [status|all|repair|<模块id>]
#
# 设计要点（对应「不要刷一半断开」）：
#   * 每个模块先解到 staging 目录，执行它自己的 customize.sh，
#     校验产物关键文件后再「同分区 rename」原子提交到 /data/adb/modules/<id>。
#     校验不过就整体回滚，绝不会在 /data/adb/modules 里留下半个模块。
#   * 单个模块失败不影响其它模块：内层脚本跑在独立进程，abort 只杀掉它自己。
#   * 失败的模块 id 写进 pending，开机后 service.sh 自动补装（最多 3 次）。
#   * 六个模块装完后，紧接着跑 hide_env_config.sh 自动配置（密钥/包名/策略/HMA/FuseFixer）。
#
# 变量命名刻意避开管理器占用的 MODPATH / TMPDIR / ZIPFILE / MODID / API / ARCH，
# 因为 customize.sh 是被管理器 source 执行的，覆盖它们会破坏管理器后续流程。
#############################################################

PACK_ID=hide_env_pack
NVBASE=${NVBASE:-/data/adb}
PACK_DIR=${PACK_DIR:-$NVBASE/$PACK_ID}
PACK_PAYLOAD=$PACK_DIR/payload
PACK_STAGE=$PACK_DIR/staging
PACK_TMP=$PACK_DIR/tmp
PACK_BIN=$PACK_DIR/bin
PACK_LOG=$PACK_DIR/install.log
PACK_MODULES_DIR=$NVBASE/modules
PACK_SH=/system/bin/sh
[ -x "$PACK_SH" ] || PACK_SH=sh

PACK_MAX_REPAIR=3
# 当前 payload 顶层 14 个 zip（v1.1.21 起）；少于此数才判“包没解全”。
# 注意：这个值只用于最小数量闸门，新增/减少组件时同步改这里与 sizes.txt。
PACK_PAYLOAD_COUNT=14

PACK_FAILED=""
PACK_LAST_ID=""
PACK_CUR_ID=pack

# ---------------- 日志 ----------------
pack_say() {
  # 刷入期安静模式：不逐条打印“跳过 …”，结尾统一汇总
  if [ "${HIDE_FLASH_QUIET:-0}" = "1" ]; then
    case "$1" in
      *"跳过"*) return 0 ;;
    esac
  fi
  printf '%s\n' "$1"
  [ -n "$PACK_LOG" ] && printf '[pack] %s\n' "$1" >>"$PACK_LOG" 2>/dev/null
  return 0
}

pack_warn() {
  printf '! %s\n' "$1"
  [ -n "$PACK_LOG" ] && printf '[pack][WARN] %s\n' "$1" >>"$PACK_LOG" 2>/dev/null
  return 0
}

pack_logline() {
  [ -n "$PACK_LOG" ] && printf '[pack] %s\n' "$1" >>"$PACK_LOG" 2>/dev/null
  return 0
}

# ---------------- 初始化 ----------------
# pack_init <flash|keep>
pack_init() {
  pack_mode="$1"
  mkdir -p "$PACK_DIR" "$PACK_PAYLOAD" "$PACK_STAGE" "$PACK_TMP" "$PACK_BIN" 2>/dev/null
  if [ "$pack_mode" = "flash" ]; then
    : >"$PACK_LOG" 2>/dev/null
  else
    printf '\n===== %s =====\n' "$(date '+%Y-%m-%d %H:%M:%S')" >>"$PACK_LOG" 2>/dev/null
  fi
  pack_setup_tools
  pack_detect_manager
  api_level_arch_detect
  pack_logline "mode=${pack_mode:-keep} uid=$(id -u 2>/dev/null) sdk=$(getprop ro.build.version.sdk 2>/dev/null)"
  pack_logline "ARCH=${ARCH:-?} ABI=${ABI:-?} API=${API:-?} busybox=${BB:-none} KSU=${KSU:-} KSUN=${KSU_NEXT:-} KSudVer=${KSU_VER_CODE:-} KVer=${KSU_KERNEL_VER_CODE:-} MagiskVer=${MAGISK_VER_CODE:-} APatch=${APATCH:-}"
  return 0
}

# 建立工具链：优先用管理器自带 busybox（含 unzip/sha256sum/base64），
# 找不到就向 ksud 要一个（ksud extract-binary busybox）。
pack_setup_tools() {
  BB=""
  for pack_c in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox /system/bin/busybox "$PACK_BIN/busybox"; do
    if [ -x "$pack_c" ]; then
      BB="$pack_c"
      break
    fi
  done
  if [ -z "$BB" ] && [ -x /data/adb/ksud ]; then
    /data/adb/ksud extract-binary busybox "$PACK_BIN/busybox" >/dev/null 2>&1
    [ -x "$PACK_BIN/busybox" ] && BB="$PACK_BIN/busybox"
  fi
  if [ -z "$BB" ] && [ -x /data/adb/apd ]; then
    /data/adb/apd --help >/dev/null 2>&1
  fi

  if [ -n "$BB" ]; then
    APPLETS=$("$BB" --list 2>/dev/null | tr '\n' ' ')
    [ -z "$APPLETS" ] && APPLETS="unzip sha256sum sed awk grep find stat xargs sort head tail wc cut tr cat cp mv rm rmdir mkdir ln chmod chown touch date sleep id readlink dirname basename dos2unix xxd base64 tee dd cmp diff"
    for pack_a in unzip sha256sum sed awk grep egrep fgrep find stat xargs sort head tail wc cut tr cat cp mv rm rmdir mkdir ln chmod chown touch date sleep id readlink dirname basename dos2unix xxd base64 tee dd cmp diff printf seq; do
      case " $APPLETS " in
        *" $pack_a "*) ln -sf "$BB" "$PACK_BIN/$pack_a" 2>/dev/null ;;
      esac
    done
  fi

  PATH="$PACK_BIN:/system/bin:/system/xbin:/system/sbin:/data/adb/ksu/bin:/data/adb/magisk:/data/adb/ap/bin:$PATH"
  export PATH BB APPLETS

  # sha256sum 兼容：Zygisk Next / LSPosed / OMK / HMA-OSS 的 verify.sh 用
  # `sha256sum -c -s -`（busybox 风格）。GNU coreutils 不认 `-s`，直接透传会让
  # 内层校验误判成「包损坏」；这里统一生成一个兼容层：
  #   1) 解析真实 sha256sum（若是 busybox/toybox 本体，补 applet 名）
  #   2) `-c -s -` 改写成 `-c -`（状态保留，输出丢弃）
  #   3) 兼容层自身永远覆盖，避免上次留下的 symlink/旧包装反复生效
  pack_sha_shebang=/bin/sh
  case "$PACK_SH" in
    /*) [ -x "$PACK_SH" ] && pack_sha_shebang=$PACK_SH ;;
  esac
  pack_real_sha=""
  if [ -L "$PACK_BIN/sha256sum" ]; then
    pack_real_sha=$(readlink -f "$PACK_BIN/sha256sum" 2>/dev/null || readlink "$PACK_BIN/sha256sum" 2>/dev/null)
  fi
  if [ -z "$pack_real_sha" ]; then
    pack_real_sha=$(PATH=/system/bin:/system/xbin:/system/sbin:/data/adb/ksu/bin:/data/adb/magisk:/data/adb/ap/bin:/usr/bin:/bin command -v sha256sum 2>/dev/null)
  fi
  if [ -n "$pack_real_sha" ]; then
    # 多合一入口（busybox / toybox 本体）必须先给 applet 名，否则调用必失败
    case "$pack_real_sha" in
      *busybox|*toybox) pack_sha_prefix="sha256sum" ;;
      *) pack_sha_prefix="" ;;
    esac
    # 目标可能是 busybox symlink；先删链接再写，绝不能顺着链接覆盖 busybox 本体
    rm -f "$PACK_BIN/sha256sum" 2>/dev/null
    {
      printf '#!%s\n' "$pack_sha_shebang"
      printf 'REAL_SHA=%s\n' "$pack_real_sha"
      printf 'PREFIX=%s\n' "$pack_sha_prefix"
      printf '%s\n' 'case "$*" in'
      printf '%s\n' '  "-c -s -"|"-s -c -"|"-cs -"|"-sc -")'
      printf '%s\n' '     "$REAL_SHA" ${PREFIX:+$PREFIX } -c - >/dev/null 2>&1'
      printf '%s\n' '     exit $? ;;'
      printf '%s\n' 'esac'
      printf '%s\n' 'exec "$REAL_SHA" ${PREFIX:+$PREFIX } "$@"'
    } >"$PACK_BIN/sha256sum" 2>/dev/null
    chmod 0755 "$PACK_BIN/sha256sum" 2>/dev/null
    pack_logline "已在 $PACK_BIN 生成 sha256sum 兼容层（real=$pack_real_sha prefix=${pack_sha_prefix:-无}）"
  fi
  return 0
}

# 识别 root 管理器：刷入时环境里本来就有 KSU / APATCH 等变量，直接沿用；
# 手动运行时（Termux / MT 管理器）才需要自己补。
pack_detect_manager() {
  if [ -z "${BOOTMODE:-}" ]; then
    BOOTMODE=true
  fi
  export BOOTMODE

  if [ -x /data/adb/ksud ]; then
    [ -z "${KSU:-}" ] && KSU=true
    if [ -z "${KSU_VER:-}" ]; then
      KSU_VER=$(/data/adb/ksud --version 2>/dev/null | head -n 1)
      [ -z "$KSU_VER" ] && KSU_VER=$(/data/adb/ksud -V 2>/dev/null | head -n 1)
      [ -z "$KSU_VER" ] && KSU_VER=$(/data/adb/ksud version 2>/dev/null | head -n 1)
    fi
    [ -z "${KSU_VER_CODE:-}" ] && KSU_VER_CODE=$(printf '%s' "${KSU_VER:-}" | grep -o '[0-9]\+' | tail -n 1)
    [ -z "${KSU_KERNEL_VER_CODE:-}" ] && KSU_KERNEL_VER_CODE=$(printf '%s' "${KSU_VER:-}" | grep -o '[0-9]\+' | head -n 1)
    if [ -z "${KSU_VER_CODE:-}" ] || [ -z "${KSU_KERNEL_VER_CODE:-}" ]; then
      pack_warn "未从运行环境读到 KSU 版本号，用内层模块要求的最低版本兜底（只影响版本门槛判断）"
      [ -z "${KSU_KERNEL_VER_CODE:-}" ] && KSU_KERNEL_VER_CODE=10940
      [ -z "${KSU_VER_CODE:-}" ] && KSU_VER_CODE=11575
    fi
    if [ -z "${KSU_NEXT:-}" ] && printf '%s' "${KSU_VER:-}" | grep -qi 'next'; then
      KSU_NEXT=true
    fi
  fi
  if [ -f /data/adb/ap/version ] || [ -x /data/adb/apd ]; then
    [ -z "${APATCH:-}" ] && APATCH=true
    if [ -z "${APATCH_VER_CODE:-}" ]; then
      APATCH_VER_CODE=$(cat /data/adb/ap/version 2>/dev/null | tr -dc '0-9')
    fi
    [ -z "${APATCH_VER_CODE:-}" ] && APATCH_VER_CODE=$(/data/adb/apd -V 2>/dev/null | grep -o '[0-9]\+' | tail -n 1)
    [ -n "${APATCH_VER_CODE:-}" ] && APATCH_VER="$APATCH_VER_CODE"
  fi
  if [ -x /data/adb/magisk/magisk ] || [ -x /data/adb/magisk/magisk64 ]; then
    if [ -z "${MAGISK_VER_CODE:-}" ]; then
      MAGISK_VER_CODE=$(/data/adb/magisk/magisk -V 2>/dev/null | grep -o '[0-9]\+' | head -n 1)
    fi
    [ -n "${MAGISK_VER_CODE:-}" ] && MAGISK_VER="$MAGISK_VER_CODE"
  fi
  pack_logline "root 环境：KSU=${KSU:-}(${KSU_VER_CODE:-}) APATCH=${APATCH:-}(${APATCH_VER_CODE:-}) MAGISK=${MAGISK_VER_CODE:-}"
  export KSU KSU_VER KSU_VER_CODE KSU_KERNEL_VER_CODE KSU_NEXT APATCH APATCH_VER APATCH_VER_CODE MAGISK_VER MAGISK_VER_CODE
  return 0
}

# 一键检查六个安装包是否都完整（避免刷到一半才发现某个包坏了）
pack_check_payloads() {
  pack_bad=""
  pack_n=0
  pack_nounzip=0
  for pack_z in "$PACK_PAYLOAD"/*.zip; do
    [ -f "$pack_z" ] || continue
    pack_n=$((pack_n + 1))
    pack_ok=0
    # ① 能列目录就直接看里面有没有 module.prop（unzip / busybox unzip 都行）
    if command -v unzip >/dev/null 2>&1 && unzip -l "$pack_z" 2>/dev/null | grep -q 'module.prop'; then
      pack_ok=1
    fi
    if [ "$pack_ok" = "0" ] && [ -n "$BB" ] && "$BB" unzip -l "$pack_z" 2>/dev/null | grep -q 'module.prop'; then
      pack_ok=1
    fi
    if [ "$pack_ok" = "0" ]; then
      for pack_c in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox /system/bin/busybox; do
        [ -x "$pack_c" ] || continue
        if "$pack_c" unzip -l "$pack_z" 2>/dev/null | grep -q 'module.prop'; then
          pack_ok=1
          break
        fi
      done
    fi
    # ② 没有任何解包工具时，用 sizes.txt 的字节数核对（这一步不需要 unzip）
    if [ "$pack_ok" = "0" ]; then
      pack_nounzip=1
      pack_name=$(basename "$pack_z")
      pack_need=$(awk -v n="$pack_name" '$1==n {print $2}' "$PACK_PAYLOAD/sizes.txt" 2>/dev/null | head -n 1)
      pack_have=$(wc -c <"$pack_z" 2>/dev/null | tr -d ' ')
      if [ -n "$pack_need" ] && [ "$pack_need" = "$pack_have" ]; then
        pack_ok=1
      fi
    fi
    [ "$pack_ok" = "1" ] || pack_bad="$pack_bad $(basename "$pack_z")"
  done
  if [ "$pack_n" -lt "$PACK_PAYLOAD_COUNT" ]; then
    pack_warn "payload 里只有 $pack_n 个安装包（应为 $PACK_PAYLOAD_COUNT 个）—— 包没解全，请重新下载整包"
    return 1
  fi
  if [ -n "$pack_bad" ]; then
    if [ "$pack_nounzip" = "1" ]; then
      pack_warn "这些安装包和清单里的大小对不上：$pack_bad"
      pack_warn "→ 判断为【下载不完整】：重新下载整包（官网 https://wjntool.top/ 有大小/MD5），别接着用旧的半截文件"
    else
      pack_warn "以下安装包不完整/损坏：$pack_bad"
      pack_warn "→ 重新下载整包再刷（官网 https://wjntool.top/ 上有大小和 MD5 可核对）"
    fi
    return 1
  fi
  if [ "$pack_nounzip" = "1" ]; then
    pack_logline "[check] 环境里没有 unzip，已用 payload/sizes.txt 的字节数完成完整性核对"
  fi
  return 0
}

# ---------------- 权限归一 ----------------
pack_fix_perms() {
  pack_d="$1"
  find "$pack_d" -type d -exec chmod 0755 {} + 2>/dev/null
  find "$pack_d" -type f -name '*.sh' -exec chmod 0755 {} + 2>/dev/null
  if [ -d "$pack_d/bin" ]; then
    find "$pack_d/bin" -type f -exec chmod 0755 {} + 2>/dev/null
  fi
  for pack_f in daemon daemon-injector machikado mazoku zygiskd cleanup.sh sync-tool; do
    [ -f "$pack_d/$pack_f" ] && chmod 0755 "$pack_d/$pack_f" 2>/dev/null
  done
  return 0
}

# 按模块 id 校验关键产物（安装成功与否以产物为准，而不是内层脚本的退出码）
pack_check_key_files() {
  pack_id_ck="$1"
  pack_p="$2"
  case "$pack_id_ck" in
    zygisksu)
      [ -f "$pack_p/module.prop" ] || return 1
      [ -f "$pack_p/bin/zygiskd" ] || return 1
      [ -f "$pack_p/machikado" ] || return 1
      if [ ! -f "$pack_p/lib64/libzygisk.so" ] && [ ! -f "$pack_p/lib/libzygisk.so" ]; then
        return 1
      fi
      ;;
    zygisk_lsposed)
      [ -f "$pack_p/module.prop" ] || return 1
      [ -f "$pack_p/daemon" ] || return 1
      [ -f "$pack_p/lspd" ] || return 1
      [ -f "$pack_p/framework.dex" ] || return 1
      [ -f "$pack_p/manager.apk" ] || return 1
      if [ ! -f "$pack_p/zygisk/arm64-v8a.so" ] && [ ! -f "$pack_p/zygisk/armeabi-v7a.so" ]; then
        return 1
      fi
      ;;
    zygisk_vector)
      [ -f "$pack_p/module.prop" ] || return 1
      [ -f "$pack_p/daemon" ] || return 1
      [ -f "$pack_p/cli" ] || return 1
      [ -f "$pack_p/daemon.apk" ] || return 1
      if [ ! -f "$pack_p/zygisk/arm64-v8a.so" ] && [ ! -f "$pack_p/zygisk/armeabi-v7a.so" ]; then
        return 1
      fi
      ;;
    oh_my_keymint)
      [ -f "$pack_p/module.prop" ] || return 1
      [ -f "$pack_p/daemon" ] || return 1
      [ -f "$pack_p/daemon-injector" ] || return 1
      [ -f "$pack_p/webroot/index.html" ] || return 1
      if [ ! -f "$pack_p/libs/arm64-v8a/keymint" ] && [ ! -f "$pack_p/libs/x86_64/keymint" ]; then
        return 1
      fi
      ;;
    hma_oss_zygisk)
      [ -f "$pack_p/module.prop" ] || return 1
      [ -f "$pack_p/classes.dex" ] || return 1
      [ -f "$pack_p/manager.apk" ] || return 1
      if [ ! -f "$pack_p/zygisk/arm64-v8a.so" ] && [ ! -f "$pack_p/zygisk/armeabi-v7a.so" ]; then
        return 1
      fi
      ;;
    hma-uidfake)
      [ -f "$pack_p/module.prop" ] || return 1
      [ -f "$pack_p/ko/hma_uidfake.ko" ] || return 1
      [ -f "$pack_p/sync-tool" ] || return 1
      ;;
    Tenc-ano_tmp)
      [ -f "$pack_p/module.prop" ] || return 1
      [ -f "$pack_p/service.sh" ] || return 1
      [ -d "$pack_p/Whitelist520" ] || return 1
      ;;
    *)
      [ -f "$pack_p/module.prop" ] || return 1
      ;;
  esac
  return 0
}

# zip 文件名 → 模块 id（写 pending 用；即使 payload 损坏也能记住该补装谁）
pack_id_of_zip() {
  case "$1" in
    zygisk-next.zip)   echo zygisksu ;;
    lsposed.zip)       echo zygisk_lsposed ;;
    vector.zip)        echo zygisk_vector ;;
    omk.zip)           echo oh_my_keymint ;;
    omk_196.zip)       echo oh_my_keymint ;;
    hma-oss.zip)       echo hma_oss_zygisk ;;
    hma-uidfake.zip)   echo hma-uidfake ;;
    aling-tenc.zip)    echo Tenc-ano_tmp ;;
    *) echo "${1%.zip}" ;;
  esac
}

# ---------------- 单个模块安装 ----------------
# pack_install_one <payload 里的 zip 文件名> <显示名>
pack_install_one() {
  pack_zipname="$1"
  pack_label="$2"
  pack_zip="$PACK_PAYLOAD/$pack_zipname"
  pack_tag=${pack_zipname%.zip}
  # 先按映射表记下模块 id：这样即使安装包损坏、读不到 module.prop，
  # pending 里也能记准确，开机补装才有目标
  PACK_CUR_ID=$(pack_id_of_zip "$pack_zipname")
  PACK_LAST_ID=$PACK_CUR_ID

  pack_say "- [$pack_label] 开始安装"
  if [ ! -f "$pack_zip" ]; then
    pack_warn "[$pack_label] 缺少安装包 $pack_zipname，跳过"
    return 1
  fi

  pack_mytmp="$PACK_TMP/$pack_tag"
  rm -rf "$pack_mytmp"
  mkdir -p "$pack_mytmp" 2>/dev/null

  unzip -o "$pack_zip" module.prop -d "$pack_mytmp" >>"$PACK_LOG" 2>&1
  if [ ! -f "$pack_mytmp/module.prop" ]; then
    pack_warn "[$pack_label] 读不到 module.prop（安装包损坏？），已跳过"
    rm -rf "$pack_mytmp"
    return 1
  fi
  pack_mid=$(grep_prop id "$pack_mytmp/module.prop")
  if [ -z "$pack_mid" ]; then
    pack_warn "[$pack_label] module.prop 里没有 id，已跳过"
    rm -rf "$pack_mytmp"
    return 1
  fi
  PACK_CUR_ID=$pack_mid
  PACK_LAST_ID=$pack_mid
  pack_logline "[$pack_label] id=$pack_mid zip=$pack_zipname"

  pack_stage="$PACK_STAGE/$pack_mid"
  rm -rf "$pack_stage"
  mkdir -p "$pack_stage" 2>/dev/null
  unzip -o "$pack_zip" customize.sh -d "$pack_stage" >>"$PACK_LOG" 2>&1

  pack_skip=0
  if [ -f "$pack_stage/customize.sh" ] && grep -q '^SKIPUNZIP=1$' "$pack_stage/customize.sh" 2>/dev/null; then
    pack_skip=1
  fi
  pack_logline "[$pack_label] SKIPUNZIP=$pack_skip"

  if [ "$pack_skip" -eq 0 ]; then
    unzip -o "$pack_zip" -x 'META-INF/*' -d "$pack_stage" >>"$PACK_LOG" 2>&1
    # 不同 unzip 实现（Info-ZIP / busybox / toybox）对 -x 的支持不一致，
    # 这里再显式清一次，保证模块目录里不会残留刷机用的 META-INF
    rm -rf "$pack_stage/META-INF" 2>/dev/null
    set_perm_recursive "$pack_stage" 0 0 0755 0644
  fi

  # 阿灵游戏助手的 customize.sh 会自己打开 Telegram 频道：
  # 一键安装时用空操作 am 挡掉（见 run_module.sh），不打扰用户
  pack_shim_path=0
  case "$pack_zipname" in
    aling-tenc.zip) pack_shim_path=1 ;;
  esac

  # LSPosed v2.2.1(7912) 的内层脚本会先向发布方的机器人联网申领 license.pb，
  # 拿不到就 abort —— 离线刷机、机器人服务不可用时，LSPosed 就装不上，
  # 表现就是「LSP 打不开/未激活」。实测：daemon/manager/framework 运行期
  # 都不读 license.pb（二进制里搜不到这个字符串），所以这里直接跳过联网申领。
  if [ "$pack_zipname" = "lsposed.zip" ]; then
    he_lspd_dir=${HE_LSPD_DIR:-/data/adb/lspd}
    mkdir -p "$he_lspd_dir" 2>/dev/null
    : >"$he_lspd_dir/skip_online_request" 2>/dev/null
    pack_logline "[LSPosed] 已置 skip_online_request（跳过联网申领授权）"
  fi

  # 架构名归一：OMK 1.3.5-196 起把 SUPPORTED_ABIS 从 "arm64 arm64-v8a" 收窄成
  # 精确匹配 "arm64 x64" —— 管理器若报 arm64-v8a（而不是 arm64），内层脚本会
  # 直接 abort「Unsupported platform」。这里统一成主流拼法再传进去。
  case "${ARCH:-}" in
    arm64-v8a|aarch64) ARCH=arm64 ;;
    armeabi-v7a|armeabi|armv7) ARCH=arm ;;
    x86_64|amd64)      ARCH=x64 ;;
    i386|i686)         ARCH=x86 ;;
  esac
  ABI=${ABI:-} ABI32=${ABI32:-} IS64BIT=${IS64BIT:-}

  pack_rc=0
  if [ -f "$pack_stage/customize.sh" ]; then
    pack_logline "[$pack_label] 执行内层 customize.sh"
    TMPDIR="$pack_mytmp" \
    MODPATH="$pack_stage" \
    ZIPFILE="$pack_zip" \
    PACK_DIR="$PACK_DIR" PACK_LOG="$PACK_LOG" PACK_CUR_ID="$pack_mid" \
    PACK_SHIM_PATH="$pack_shim_path" \
    ARCH="$ARCH" ABI="$ABI" ABI32="$ABI32" IS64BIT="$IS64BIT" API="${API:-}" \
    BOOTMODE="${BOOTMODE:-true}" ASH_STANDALONE=1 \
    KSU="${KSU:-}" KSU_VER="${KSU_VER:-}" KSU_VER_CODE="${KSU_VER_CODE:-}" \
    KSU_KERNEL_VER_CODE="${KSU_KERNEL_VER_CODE:-}" KSU_NEXT="${KSU_NEXT:-}" \
    MAGISK_VER="${MAGISK_VER:-}" MAGISK_VER_CODE="${MAGISK_VER_CODE:-}" \
    APATCH="${APATCH:-}" APATCH_VER="${APATCH_VER:-}" APATCH_VER_CODE="${APATCH_VER_CODE:-}" \
    "$PACK_SH" "$PACK_DIR/common/run_module.sh" "$pack_stage/customize.sh" >>"$PACK_LOG" 2>&1
    pack_rc=$?
    pack_logline "[$pack_label] 内层脚本退出码=$pack_rc"
    # 127 = 连执行器都没跑起来（run_module.sh / sh 不在），这种情况不能按产物判定成功
    if [ "$pack_rc" -eq 127 ]; then
      pack_warn "[$pack_label] 内层执行器不可用（退出码 127），判定安装失败，已整体回滚"
      rm -rf "$pack_stage" "$pack_mytmp"
      return 1
    fi
    [ "$pack_rc" -ne 0 ] && pack_warn "[$pack_label] 内层脚本退出码 $pack_rc，改按产物校验结果判定"
  fi

  if [ ! -f "$pack_stage/module.prop" ]; then
    pack_warn "[$pack_label] 安装未完成（staging 里没有 module.prop），已整体回滚"
    rm -rf "$pack_stage" "$pack_mytmp"
    return 1
  fi
  if ! pack_check_key_files "$pack_mid" "$pack_stage"; then
    pack_warn "[$pack_label] 关键文件缺失，判定安装失败，已整体回滚"
    rm -rf "$pack_stage" "$pack_mytmp"
    return 1
  fi

  pack_fix_perms "$pack_stage"

  # 阿灵游戏助手的 customize.sh 特意把自己的数据目录设成 0777，
  # 别被上面的通用权限归一改回 0755（它的游戏分身读写依赖这个权限）
  if [ "$pack_mid" = "Tenc-ano_tmp" ]; then
    chmod -R 0777 "$pack_stage/Whitelist520" 2>/dev/null
  fi

  # 与管理器行为对齐：安装完成后模块目录里不留 customize.sh
  rm -f "$pack_stage/customize.sh" 2>/dev/null

  # 原子提交：staging 与 /data/adb/modules 同一分区，rename 瞬间生效
  rm -rf "$PACK_MODULES_DIR/$pack_mid"
  if ! mv "$pack_stage" "$PACK_MODULES_DIR/$pack_mid" 2>/dev/null; then
    mkdir -p "$PACK_MODULES_DIR/$pack_mid" 2>/dev/null
    cp -af "$pack_stage/." "$PACK_MODULES_DIR/$pack_mid/" 2>/dev/null
    rm -rf "$pack_stage"
  fi
  rm -rf "$pack_mytmp"

  if [ ! -f "$PACK_MODULES_DIR/$pack_mid/module.prop" ]; then
    pack_warn "[$pack_label] 提交失败（$PACK_MODULES_DIR 不可写？）"
    return 1
  fi

  pack_fcnt=$(find "$PACK_MODULES_DIR/$pack_mid" -type f 2>/dev/null | wc -l | tr -d ' ')
    # 装完立刻统一显示名（改过名就重设互锁基线，避免重启后回退/误判）
  if ! command -v he_mods_pretty >/dev/null 2>&1 && [ -f "$PACK_DIR/common/hide_env_mods.sh" ]; then
    . "$PACK_DIR/common/hide_env_mods.sh"
  fi
  if command -v he_mods_pretty >/dev/null 2>&1; then
    he_mods_pretty
    if [ "$?" = "2" ]; then
      command -v he_tw_rebase >/dev/null 2>&1 && he_tw_rebase >/dev/null 2>&1
    fi
  fi
pack_say "- [$pack_label] 安装完成 → $PACK_MODULES_DIR/$pack_mid（$pack_fcnt 个文件）"
  [ "$pack_mid" = "zygisk_vector" ] && command -v pack_patch_vector_service >/dev/null 2>&1 && pack_patch_vector_service
  return 0
}

# ---------------- 状态报告 ----------------
pack_report() {
  pack_say "- 模块状态："
  # 分隔符用 : 而不是 | —— Android 的 mksh 会把 ${var%%|*} 里的 | 当作“或”，解析会错位
  for pack_spec in "zygisksu:系统框架服务" "zygisk_lsposed:系统框架服务" "oh_my_keymint:系统密钥服务" \
                   "hma_oss_zygisk:应用兼容服务" "hma-uidfake:应用隔离服务" "Tenc-ano_tmp:游戏兼容服务"; do
    pack_mid_r=${pack_spec%%:*}
    pack_label_r=${pack_spec#*:}
    pack_d="$PACK_MODULES_DIR/$pack_mid_r"
    # 天玑方案会刻意跳过 UID Fake：那不算"没装上"，单独说明
    if [ "$pack_mid_r" = "hma-uidfake" ] && [ ! -f "$pack_d/module.prop" ] && pack_soc_is_mtk; then
      pack_say "    [-] $pack_label_r — 天玑方案已跳过（它会开不了机，非故障）"
      continue
    fi
    if [ -f "$pack_d/module.prop" ]; then
      pack_fcnt=$(find "$pack_d" -type f 2>/dev/null | wc -l | tr -d ' ')
      pack_st="已安装"
      [ -f "$pack_d/remove" ] && pack_st="待卸载"
      [ -f "$pack_d/disable" ] && pack_st="已安装（被禁用）"
      pack_say "    [√] $pack_label_r — $pack_st，$pack_fcnt 个文件"
    else
      pack_say "    [×] $pack_label_r — 未安装"
    fi
  done
  return 0
}

# ---------------- 批量安装 ----------------
# ---------------- 安装前预检（对症：刷完无限重启） ----------------
# 这套包里最容易把设备搞进重启循环的两件事：
#   1) 设备上已经有 Zygisk 框架（Magisk 内置 Zygisk、OnyxZygisk、ReZygisk、
#      另一个 Zygisk Next…），再装一个 Zygisk Next → 两套 Zygisk 抢 zygote → 崩
#      → 无限重启。HMA 的安装脚本能发现「模块形态」的冲突，但发现不了
#      Magisk 内置 Zygisk，所以这里补上，并且直接跳过 ZN（不是硬闯）。
#   2) HMA UID Fake 只支持 KernelSU（靠 ksud insmod）。非 KernelSU 上装了也只是白装，
#      而且它的 ko 加载是最可能触发内核 panic 的一环，干脆跳过。
pack_precheck() {
  PACK_SKIP_ZN=0
  PACK_SKIP_UIDFAKE=0
  PACK_SKIP_LSPOSED=0
  PACK_SKIP_FUSE=0
  PACK_SKIP_SOTER=0
  PACK_ZYGISK_FOUND=""
  PACK_MAGISK_ZYGISK=0

  # 调用方可以强制跳过 UID Fake：它要 insmod 内核模块，在部分定制内核上风险高
  if [ "${HIDE_SKIP_UIDFAKE:-}" = "1" ]; then
    PACK_SKIP_UIDFAKE=1
  fi

  # 调用方可以强制跳过 OMK（OhMyKeymint）：
  # 用户实测——联发科(天玑)机型装 OMK 会开不了机（OMK 替换 keystore/KeyMint 服务，
  # 而 MTK 的 KeyMint 是厂商深度定制的，接管后 keystore 起不来 → 系统起不来 →
  # MTK bootloader 连续失败后停在 fastboot，只能清数据恢复）
  PACK_SKIP_OMK=${PACK_SKIP_OMK:-0}
  if [ "${HIDE_SKIP_OMK:-}" = "1" ]; then
    PACK_SKIP_OMK=1
  fi

  # 平台方案（天玑）——必须在重置完 SKIP_* 之后再判定
  [ -n "${PACK_MTK:-}" ] || { if pack_soc_is_mtk; then PACK_MTK=1; else PACK_MTK=0; fi; }

  # 1) 已有的其它 Zygisk 框架模块（排除本包自己的 zygisksu）
  #    注意：必须看真实的 /data/adb/modules —— 那才是开机时真正会加载的模块，
  #    PACK_MODULES_DIR 在沙盒/自测时可能指向别处
  for pack_d in /data/adb/modules/*/ "$PACK_MODULES_DIR"/*/; do
    [ -d "$pack_d" ] || continue
    pack_id=$(basename "$pack_d")
    case "$pack_id" in
      zygisksu|hide_env_pack) continue ;;
    esac
    [ -f "$pack_d/disable" ] && continue
    [ -f "$pack_d/remove" ] && continue
    if [ -f "$pack_d/bin/zygiskd" ] || [ -f "$pack_d/bin/zygiskd64" ] || [ -d "$pack_d/zygisk" ]; then
      PACK_ZYGISK_FOUND="$PACK_ZYGISK_FOUND $pack_id"
    fi
  done

  # 2) Magisk 内置 Zygisk
  for pack_m in /data/adb/magisk/magisk /data/adb/magisk/magisk64; do
    [ -x "$pack_m" ] || continue
    pack_z=$("$pack_m" --sqlite "SELECT value FROM settings WHERE key = 'zygisk'" 2>/dev/null | cut -d= -f2)
    [ "$pack_z" = "1" ] && PACK_MAGISK_ZYGISK=1
    break
  done

  if [ -n "$PACK_ZYGISK_FOUND" ] || [ "$PACK_MAGISK_ZYGISK" = "1" ]; then
    PACK_SKIP_ZN=1
    pack_say "! 检测到设备上已经有 Zygisk 框架："
    [ -n "$PACK_ZYGISK_FOUND" ] && pack_say "    · 已有同类框架组件"
    [ "$PACK_MAGISK_ZYGISK" = "1" ] && pack_say "    · Magisk 内置 Zygisk：已开启"
    pack_say "! 因此跳过安装系统框架服务 —— 两套 Zygisk 同时存在会把 zygote 搞崩，"
    pack_say "! 这正是「刷完无限重启」最常见的成因。LSPosed 会直接用已有的 Zygisk。"
    pack_say "! 如果你确实想改用系统框架服务：先在管理器里停用/卸载上面那些框架，再执行"
    pack_say "!   su -c 'sh $PACK_DIR/install.sh zygisksu'"
  fi

  if [ ! -x /data/adb/ksud ]; then
    PACK_SKIP_UIDFAKE=1
    pack_say "- 当前不是 KernelSU 环境，跳过 HMA UID Fake（它靠 ksud 加载内核模块，装上也不会生效）"
  fi

  # 天玑专属方案：跳过 HMA UID Fake（附加模块，实测会让 MTK 开不了机；HMA 本体不受影响）
  if [ "${PACK_MTK:-0}" = "1" ] && [ "$PACK_SKIP_UIDFAKE" != "1" ]; then
    if [ "${HIDE_FORCE_UIDFAKE:-}" = "1" ] || grep -qs -x 'on' "$PACK_DIR/config/uidfake.txt" 2>/dev/null; then
      pack_say "- 天玑机型：配置要求照装 HMA UID Fake（风险自负，出问题删掉 hma-uidfake 模块）"
    else
      PACK_SKIP_UIDFAKE=1
      pack_say "- 天玑机型：跳过 HMA UID Fake（附加模块实测会让天玑开不了机；HMA 本体照常安装）"
    fi
  fi

  # 天玑专属方案（按原作者给的天玑清单）：天玑只需要
  #   omk / zygisk next / 阿灵游戏助手 / HMA-OSS（改机型可选）
  # —— 没有 LSPosed、没有 FuseFixer 防扫盘、没有微信指纹修复（Soter）。
  # 少装一个就少一处可被检测的特征，所以这里按方案跳过（可用配置强制照装）。
  if [ "${PACK_MTK:-0}" = "1" ]; then
    if [ "${HIDE_FORCE_LSPOSED:-}" = "1" ] || grep -qs -x 'on' "$PACK_DIR/config/lsposed.txt" 2>/dev/null; then
      pack_say "- 天玑机型：配置要求照装 LSPosed（config/lsposed.txt=on）"
    else
      PACK_SKIP_LSPOSED=1
      pack_say "- 天玑方案：跳过 LSPosed（原方案天玑清单里没有它；也就不用装 FuseFixer）"
    fi
    if [ "${HIDE_FORCE_FUSE:-}" = "1" ] || grep -qs -x 'on' "$PACK_DIR/config/fusefixer.txt" 2>/dev/null; then
      pack_say "- 天玑机型：配置要求照装 FuseFixer（config/fusefixer.txt=on）"
    else
      PACK_SKIP_FUSE=1
      pack_say "- 天玑方案：跳过 FuseFixer 防扫盘（它依赖 LSPosed；原方案天玑清单里没有）"
    fi
    # 用户明确要求：微信指纹修复（Soter TA）天玑也照开 —— 默认不再跳过。
    # 想关掉：刷前设 HIDE_SKIP_SOTER=1，或 config/soter.txt 里写 off
    if [ "${HIDE_SKIP_SOTER:-}" = "1" ] || grep -qs -x 'off' "$PACK_DIR/config/soter.txt" 2>/dev/null; then
      PACK_SKIP_SOTER=1
      pack_say "- 天玑机型：按配置跳过微信指纹修复（config/soter.txt=off 或 HIDE_SKIP_SOTER=1）"
    else
      pack_say "- 天玑机型：照常开启微信指纹修复（Soter TA）"
    fi
  fi

  pack_logline "precheck: skip_zn=$PACK_SKIP_ZN(已有:$PACK_ZYGISK_FOUND magisk_zygisk=$PACK_MAGISK_ZYGISK) skip_uidfake=$PACK_SKIP_UIDFAKE skip_lsp=$PACK_SKIP_LSPOSED skip_fuse=$PACK_SKIP_FUSE skip_soter=$PACK_SKIP_SOTER mtk=${PACK_MTK:-0}"
  export PACK_SKIP_ZN PACK_SKIP_UIDFAKE PACK_SKIP_OMK PACK_SKIP_LSPOSED PACK_SKIP_FUSE PACK_SKIP_SOTER PACK_ZYGISK_FOUND PACK_MAGISK_ZYGISK PACK_MTK
  return 0
}

# 统一的批次收尾：记失败清单 / 清临时目录
pack_finish_batch() {
  PACK_FAILED=$(printf '%s\n' $PACK_FAILED | sort -u | tr '\n' ' ')
  if [ -n "$(printf '%s' "$PACK_FAILED" | tr -d ' ')" ]; then
    printf '%s\n' $PACK_FAILED | tr ' ' '\n' | grep -v '^$' >"$PACK_DIR/pending" 2>/dev/null
  else
    rm -f "$PACK_DIR/pending" "$PACK_DIR/attempts" 2>/dev/null
  fi
  rm -rf "$PACK_STAGE" "$PACK_TMP" 2>/dev/null
  # 本包自己刚装/补装了模块 —— 这是合法变更，把结果接受为新基线，
  # 免得下次开机互锁把"补装成功"误判成"出现新模块"
  if command -v he_tw_snapshot >/dev/null 2>&1 && { ! command -v he_tw_on >/dev/null 2>&1 || he_tw_on; }; then
    he_tw_snapshot
  fi
  return 0
}

# ---------------- 处理器方案：骁龙（完整） / 天玑（跳过 HMA UID Fake） ----------------
# 历史：早期实测"天玑刷本套会开不了机（卡 fastboot、只能清数据）"，所以一度直接拒绝刷入。
# 2026-10-05 用户朋友给出更准的结论：**是 HMA UID Fake 这个附加模块**在天玑上导致开不了机
#   （它靠 ksud insmod 内核模块，那个 ko 只认部分高通内核），删掉它、HMA 本体留着就正常。
# 于是改成"天玑专属方案"：不再拒绝天玑设备，自动跳过 HMA UID Fake，其余照装。
#   · 想强行装 UID Fake 试：HIDE_FORCE_UIDFAKE=1（或 config/uidfake.txt 写 on）
#   · OhMyKeymint 按用户朋友的实机结果保留（他删掉 UID Fake 后系统正常）；
#     若某台天玑仍开不了机：在面具里删掉 oh_my_keymint 模块即可恢复，或再刷时设 HIDE_SKIP_OMK=1
pack_soc_is_mtk() {
  # 自测钩子：HIDE_FORCE_MTK=1 时按天玑处理（只用于验证拦截逻辑，正常使用不要设）
  if [ "${HIDE_FORCE_MTK:-}" = "1" ]; then
    return 0
  fi
  pack_soc="$(getprop ro.mediatek.platform 2>/dev/null)$(getprop ro.hardware 2>/dev/null)$(getprop ro.board.platform 2>/dev/null)$(getprop ro.product.board 2>/dev/null)$(getprop ro.soc.manufacturer 2>/dev/null)$(getprop ro.vendor.mediatek.platform 2>/dev/null)"
  case "$(printf '%s' "$pack_soc" | tr 'A-Z' 'a-z')" in
    *mediatek*|*dimen*|*mt6*|*mt8*|*mt9*) return 0 ;;
  esac
  return 1
}

pack_soc_profile() {
  PACK_MTK=0
  if pack_soc_is_mtk; then
    PACK_MTK=1
    pack_say "- 检测到联发科（天玑 / MTK）机型 → 使用【天玑专属方案】"
    pack_say "    · 将跳过 HMA UID Fake（这个附加模块实测在天玑上会开不了机；HMA 本体照装）"
    pack_say "    · 天玑清单里没有 LSPosed 与 FuseFixer 防扫盘 → 不装（少一个被检测的点）"
    pack_say "    · 微信指纹修复（Soter TA）天玑也照开（你要的）；不想要就 config/soter.txt 写 off"
    pack_say "    · 按方案安装的组件"
    if [ "${HIDE_FORCE_UIDFAKE:-}" = "1" ] || grep -qs -x 'on' "$PACK_DIR/config/uidfake.txt" 2>/dev/null; then
      pack_say "    · 但配置里要求照装 UID Fake（config/uidfake.txt=on 或 HIDE_FORCE_UIDFAKE=1）：风险自负"
    fi
    if [ "${HIDE_FORCE_LSPOSED:-}" = "1" ] || grep -qs -x 'on' "$PACK_DIR/config/lsposed.txt" 2>/dev/null; then
      pack_say "    · 但配置里要求照装 LSPosed（config/lsposed.txt=on 或 HIDE_FORCE_LSPOSED=1）"
    fi
    if [ "${HIDE_FORCE_FUSE:-}" = "1" ] || grep -qs -x 'on' "$PACK_DIR/config/fusefixer.txt" 2>/dev/null; then
      pack_say "    · 但配置里要求照装 FuseFixer（config/fusefixer.txt=on 或 HIDE_FORCE_FUSE=1）"
    fi
    pack_say "    · 设备：$(getprop ro.product.brand 2>/dev/null) $(getprop ro.product.model 2>/dev/null)  平台：$(getprop ro.board.platform 2>/dev/null) $(getprop ro.hardware 2>/dev/null)"
    pack_say "    · 万一这版还是开不了机：在面具/KernelSU 里删掉 oh_my_keymint 模块即可恢复；"
    pack_say "      想跳过 OMK 再刷：刷之前设 HIDE_SKIP_OMK=1（教程「天玑机型」一节有说明）"
    pack_logline "处理器方案：天玑（跳过 HMA UID Fake）"
    return 0
  fi
  pack_say "- 处理器校验通过（骁龙/高通）：$(getprop ro.board.platform 2>/dev/null) / $(getprop ro.hardware 2>/dev/null)"
  pack_logline "处理器方案：骁龙（完整）"
  return 0
}

# 兼容旧调用名：现在不拒绝任何机型，只做"按平台设策略"
pack_require_snapdragon() { pack_soc_profile; }

# ★ 安卓 16（SDK 36）上 LSPosed 2.2.1(7912) 的守护进程必段错误（2026-10-07 实测 5/5 台）
#   —— 表现为"管理器一直未激活/打不开"。同源续作 Vector v2.2（支持安卓 8.1~17）正常。
#   所以 SDK≥36 直接用 Vector；sd 上仍用 LSPosed（客户界面没变化）。
pack_vector_ready() {   # 把 payload/alt/vector.zip 备到顶层，返回 0 = 可用
  [ -s "$PACK_PAYLOAD/vector.zip" ] && return 0
  [ -s "$PACK_PAYLOAD/alt/vector.zip" ] || return 1
  cp -f "$PACK_PAYLOAD/alt/vector.zip" "$PACK_PAYLOAD/vector.zip" 2>/dev/null
  [ -s "$PACK_PAYLOAD/vector.zip" ]
}

pack_fw_zip() {   # 打印应当安装的框架 zip 名
  pack_fw_sdk=$(getprop ro.build.version.sdk 2>/dev/null)
  case "$pack_fw_sdk" in ''|*[!0-9]*) pack_fw_sdk=0 ;; esac
  if [ "$pack_fw_sdk" -ge 36 ] && pack_vector_ready; then
    printf '%s' vector.zip
  else
    printf '%s' lsposed.zip
  fi
}

pack_fw_label() {
  case "$(pack_fw_zip)" in vector.zip) printf '%s' "Vector（安卓 16 兼容版）" ;; *) printf '%s' "系统框架服务" ;; esac
}

# pack_install_batch "<zip 文件名> <显示名>" ...
# ★ Vector 的 service.sh 原版是 `unshare --propagation slave -m "$MODDIR/daemon" ...`。
#   实测（2026-10-08，Android 16 / ColorOS）：部分机器上 PATH 里的 unshare 是 toybox 的，
#   不认 --propagation → 守护进程一行都没跑起来，管理器也装不上。
#   这里按可用性改写它的 service.sh：busybox unshare(--propagation) → unshare -m → 直接跑。
pack_patch_vector_service() {
  pack_vs_m="$PACK_MODULES_DIR/zygisk_vector"
  [ -f "$pack_vs_m/daemon" ] || return 0
  cat >"$pack_vs_m/service.sh" <<'EOFVS'
#!/system/bin/sh
# 修改版（一键隐藏环境整合包）：原版 unshare --propagation 在个别 Android 16 上不被支持，
# 会造成守护进程起不来。这里按可用性依次退让（busybox → unshare -m → 直接跑）。
MODDIR=${0%/*}
cd "$MODDIR" || exit 1
BB=""
for c in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox; do
  [ -x "$c" ] && { BB="$c"; break; }
done
if [ -n "$BB" ] && "$BB" unshare --propagation slave -m true >/dev/null 2>&1; then
  "$BB" unshare --propagation slave -m "$MODDIR/daemon" --system-server-max-retry=3 "$@" &
elif unshare -m true >/dev/null 2>&1; then
  unshare -m "$MODDIR/daemon" --system-server-max-retry=3 "$@" &
else
  "$MODDIR/daemon" --system-server-max-retry=3 "$@" &
fi
exit 0
EOFVS
  chmod 0755 "$pack_vs_m/service.sh" 2>/dev/null
  pack_logline "[Vector] 已改写 service.sh（unshare 参数兼容版）"
  return 0
}

pack_install_batch() {
  PACK_FAILED=""
  pack_require_snapdragon || { rm -f "$PACK_DIR/pending" 2>/dev/null; return 1; }
  while [ $# -ge 2 ]; do
    pack_install_one "$1" "$2" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
    shift 2
  done
  pack_finish_batch
  return 0
}

# 升级时保持用户已选的 OMK 线：
#   1) 优先读 config/omk_line.txt（he_omk_switch 写入，跨升级保留）
#   2) 没配置就按已装 oh_my_keymint/module.prop 的 version/description 判定
#   3) 只有对应的 omk_196.zip 真缺失，才回落默认 omk.zip（203）
# 返回要安装的 zip 文件名，不打印其它内容。
pack_omk_zip() {
  pack_ol=""
  for pack_olf in "$PACK_DIR/config/omk_line.txt" "${HIDE_CFG_DIR:-}/omk_line.txt"; do
    [ -n "$pack_olf" ] && [ -s "$pack_olf" ] || continue
    pack_ol=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$pack_olf" 2>/dev/null | grep -v '^$' | head -n 1)
    [ -n "$pack_ol" ] && break
  done
  if [ -z "$pack_ol" ]; then
    pack_omp="$PACK_MODULES_DIR/oh_my_keymint/module.prop"
    if [ -s "$pack_omp" ] && grep -Eqi '196|autoscoop' "$pack_omp" 2>/dev/null; then
      pack_ol="bundled"
    else
      pack_ol="upstream"
    fi
  fi
  case "$pack_ol" in
    bundled|196|autoscoop)
      if [ -s "$PACK_PAYLOAD/omk_196.zip" ]; then
        printf '%s' "omk_196.zip"
      else
        pack_say "- 已选 196-autoscoop，但包内 payload/omk_196.zip 缺失：本次回落默认 203 线"
        printf '%s' "omk.zip"
      fi
      ;;
    *) printf '%s' "omk.zip" ;;
  esac
}

pack_install_all() {
  pack_require_snapdragon || { rm -f "$PACK_DIR/pending" 2>/dev/null; return 1; }
  pack_precheck
  PACK_FAILED=""
  if [ "$PACK_SKIP_ZN" = "1" ]; then
    pack_say "- 跳过系统框架服务（设备已有 Zygisk 框架）"
  else
    pack_install_one "zygisk-next.zip" "系统框架服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  fi
  if [ "${PACK_SKIP_LSPOSED:-0}" = "1" ]; then
    pack_say "- 跳过 LSPosed（天玑方案：原方案的天玑清单里没有它）"
  else
    pack_fw_sdk_now=$(getprop ro.build.version.sdk 2>/dev/null)
    case "$pack_fw_sdk_now" in ''|*[!0-9]*) pack_fw_sdk_now=0 ;; esac
    if [ "$pack_fw_sdk_now" -ge 36 ]; then
      # 安卓 16+：LSPosed 守护进程必段错误（实测 5/5 台）→ 不装，避免被检测到
      # （"发现 RSP 应用"就是靠 org.lsposed.manager 包 + zygisk_lsposed 模块识别的）
      pack_say "- 跳过 LSPosed：安卓 16 上它的守护进程会崩（实测段错误），装了只会被检测到"
      pack_say "    想试同源续作 Vector：install.sh lsp-vector（不保证每台 ROM 都能起）"
    else
      pack_install_one "lsposed.zip" "系统框架服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
    fi
  fi
  if [ "$PACK_SKIP_OMK" = "1" ]; then
    pack_say "- 跳过系统密钥服务（MTK/天玑兼容模式：装了会开不了机）"
  else
    pack_omk_sel=$(pack_omk_zip)
    [ "$pack_omk_sel" = "omk_196.zip" ] && pack_say "- 系统密钥服务：保持 196-autoscoop 线（不覆盖用户选择）"
    pack_install_one "$pack_omk_sel" "系统密钥服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  fi
  pack_install_one "hma-oss.zip" "应用兼容服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  if [ "$PACK_SKIP_UIDFAKE" = "1" ]; then
    if [ "${PACK_MTK:-0}" = "1" ]; then
      pack_say "- 跳过 HMA UID Fake（天玑专属方案：这个附加模块在 MTK 上会开不了机；HMA 本体正常装）"
    else
      pack_say "- 跳过 HMA UID Fake（非 KernelSU 环境，装上也不会生效）"
    fi
  else
    pack_install_one "hma-uidfake.zip" "应用隔离服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  fi
  pack_install_one "aling-tenc.zip" "游戏兼容服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  pack_finish_batch
}

# 分步安装第 1 步：只装两个框架级组件，确认能开机再装剩下的。
# 个别设备和已有 Zygisk 框架 / 内核冲突时，出问题的几乎总是系统级那几个，
# 分步能把风险切小、把范围缩小。
pack_install_stage1() {
  pack_require_snapdragon || { rm -f "$PACK_DIR/pending" 2>/dev/null; return 1; }
  pack_precheck
  PACK_FAILED=""
  if [ "$PACK_SKIP_ZN" = "1" ]; then
    pack_say "- 跳过系统框架服务（设备已有 Zygisk 框架）"
  else
    pack_install_one "zygisk-next.zip" "系统框架服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  fi
  if [ "${PACK_SKIP_LSPOSED:-0}" = "1" ]; then
    pack_say "- 跳过 LSPosed（天玑方案）"
  else
    pack_install_one "$(pack_fw_zip)" "$(pack_fw_label)" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  fi
  pack_finish_batch
}

# 分步安装第 2 步：装其余四个模块
pack_install_stage2() {
  pack_require_snapdragon || { rm -f "$PACK_DIR/pending" 2>/dev/null; return 1; }
  pack_precheck
  PACK_FAILED=""
  if [ "$PACK_SKIP_OMK" = "1" ]; then
    pack_say "- 跳过系统密钥服务（MTK/天玑兼容模式：装了会开不了机）"
  else
    pack_omk_sel=$(pack_omk_zip)
    [ "$pack_omk_sel" = "omk_196.zip" ] && pack_say "- 系统密钥服务：保持 196-autoscoop 线（不覆盖用户选择）"
    pack_install_one "$pack_omk_sel" "系统密钥服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  fi
  pack_install_one "hma-oss.zip" "应用兼容服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  if [ "$PACK_SKIP_UIDFAKE" = "1" ]; then
    if [ "${PACK_MTK:-0}" = "1" ]; then
      pack_say "- 跳过 HMA UID Fake（天玑专属方案：这个附加模块在 MTK 上会开不了机；HMA 本体正常装）"
    else
      pack_say "- 跳过 HMA UID Fake（非 KernelSU 环境，装上也不会生效）"
    fi
  else
    pack_install_one "hma-uidfake.zip" "应用隔离服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  fi
  pack_install_one "aling-tenc.zip" "游戏兼容服务" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  pack_finish_batch
}

# 只装某一个模块（手动重装 / 补装用）
pack_install_by_id() {
  pack_require_snapdragon || return 1
  case "$1" in
    zygisksu)         pack_install_one "zygisk-next.zip" "系统框架服务" ;;
    zygisk_lsposed)   pack_install_one "lsposed.zip" "系统框架服务" ;;
    oh_my_keymint)    pack_install_one "$(pack_omk_zip)" "系统密钥服务" ;;
    hma_oss_zygisk)   pack_install_one "hma-oss.zip" "应用兼容服务" ;;
    hma-uidfake)      pack_install_one "hma-uidfake.zip" "应用隔离服务" ;;
    Tenc-ano_tmp)     pack_install_one "aling-tenc.zip" "游戏兼容服务" ;;
    *)
      pack_warn "未知模块 id：$1（可用：zygisksu / zygisk_lsposed / oh_my_keymint / hma_oss_zygisk / hma-uidfake / Tenc-ano_tmp）"
      return 1
      ;;
  esac
}

# 开机补装：只处理 pending 里的模块，最多尝试 PACK_MAX_REPAIR 次
pack_repair() {
  if [ ! -f "$PACK_DIR/pending" ]; then
    pack_logline "没有待补装的模块"
    return 0
  fi
  pack_attempts=0
  [ -f "$PACK_DIR/attempts" ] && pack_attempts=$(cat "$PACK_DIR/attempts" 2>/dev/null)
  pack_attempts=$((pack_attempts + 1))
  printf '%s\n' "$pack_attempts" >"$PACK_DIR/attempts" 2>/dev/null

  if [ "$pack_attempts" -gt "$PACK_MAX_REPAIR" ]; then
    pack_warn "补装已尝试 $pack_attempts 次仍未成功，停止自动重试；请手动执行：sh $PACK_DIR/install.sh all"
    return 1
  fi

  pack_ids=$(cat "$PACK_DIR/pending" 2>/dev/null)
  pack_logline "补装第 $pack_attempts 次，待处理：$(printf '%s' "$pack_ids" | tr '\n' ' ')"
  PACK_FAILED=""
  for pack_one in $pack_ids; do
    pack_install_by_id "$pack_one" || PACK_FAILED="$PACK_FAILED $PACK_LAST_ID"
  done

  PACK_FAILED=$(printf '%s\n' $PACK_FAILED | sort -u | tr '\n' ' ')
  if [ -n "$(printf '%s' "$PACK_FAILED" | tr -d ' ')" ]; then
    printf '%s\n' $PACK_FAILED | tr ' ' '\n' | grep -v '^$' >"$PACK_DIR/pending" 2>/dev/null
  else
    rm -f "$PACK_DIR/pending" "$PACK_DIR/attempts" 2>/dev/null
  fi
  rm -rf "$PACK_STAGE" "$PACK_TMP" 2>/dev/null
  # 补装也是合法变更：把补装后的结果接受为新基线（与 pack_finish_batch 同理）
  if command -v he_tw_snapshot >/dev/null 2>&1 && { ! command -v he_tw_on >/dev/null 2>&1 || he_tw_on; }; then
    he_tw_snapshot
  fi
  return 0
}
