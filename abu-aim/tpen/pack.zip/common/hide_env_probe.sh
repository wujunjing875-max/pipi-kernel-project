#!/system/bin/sh
#############################################################
# hide_env_probe.sh —— v1.5.1「C4 探针」（分散式哨兵）
#
# 目的：判断「设备已经脱离服务器、却还在正常用本套环境」（= 被破解/被转卖）。
# 动作：只记录 + 上报后台，由机主处置。不改系统、不锁机、不动任何配置。
#
# 形态：往设备里 5 个不同目录各放一个【自包含】小探针（不依赖主代码，
#       主代码被删了它们照样能跑、照样能上报）。每个探针自带：
#         - 身份号、同伴清单（互相点名，少一个就报「探针被拆」）
#         - 授权状态读取（token / hwid / 是否已激活、已启动）
#         - 服务器真伪校验（/api/ping 必须带约定标记，否则判「服务器被替换」）
#         - 脱管判定（连续 3 次连不上 + 已激活 + 环境在跑 → 判「脱机使用」）
#         - 断网时先记账（pending），一旦能上网立刻补报
#
# 放哪里：/data/adb、/data/local/tmp、/cache、/data/misc、/data/local
#         —— 全在 data 分区，只写普通文件；不碰 /system、不改 SELinux、
#            不加开机服务、不常驻进程（由主程序每 20 分钟轮询一个探针）
#
# 开关：config/probe.txt       写 off 关闭巡检
#       config/probe_report.txt 写 off 只记录不上报（自测用）
#############################################################

HE_PB_STATE=${HE_PB_STATE:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state}
HE_PB_LIST=$HE_PB_STATE/probe.list
HE_PB_LOG=$HE_PB_STATE/probe.log
HE_PB_QUEUE=$HE_PB_STATE/probe_pending
HE_PB_MARK="wjn-probe-2026"

he_pb_on() {
  [ -f "${HIDE_CFG_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/config}/probe.txt" ] || return 0
  case "$(tr -d ' \n\r\t' <"${HIDE_CFG_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/config}/probe.txt" 2>/dev/null | tr 'A-Z' 'a-z')" in
    off|0|no|关|关闭) return 1 ;;
  esac
  return 0
}

he_pb_report_on() {
  [ -f "${HIDE_CFG_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/config}/probe_report.txt" ] || return 0
  case "$(tr -d ' \n\r\t' <"${HIDE_CFG_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/config}/probe_report.txt" 2>/dev/null | tr 'A-Z' 'a-z')" in
    off|0|no|关|关闭) return 1 ;;
  esac
  return 0
}

he_pb_log() {
  mkdir -p "$HE_PB_STATE" 2>/dev/null
  printf '%s %s\n' "$(date '+%F %T' 2>/dev/null)" "$1" >>"$HE_PB_LOG" 2>/dev/null
}

he_pb_api_base() { # 上报基址：与授权同源（<base>/api/probe）
  he_pb_u=""
  if command -v he_lic_server >/dev/null 2>&1; then he_pb_u=$(he_lic_server 2>/dev/null); fi
  if [ -z "$he_pb_u" ]; then
    he_pb_cfg="${HIDE_CFG_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/config}/license_url.txt"
    [ -s "$he_pb_cfg" ] && he_pb_u=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$he_pb_cfg" 2>/dev/null | head -n 1)
  fi
  [ -n "$he_pb_u" ] || he_pb_u="https://wjntool.top/lsp"
  printf '%s' "${he_pb_u%/}"
}

he_pb_dirs() { # 5 个落点（存在才用；全都按 data 分区，安全）
  for d in /data/adb /data/local/tmp /cache /data/misc /data/local; do
    [ -d "$d" ] && [ -w "$d" ] && printf '%s\n' "$d"
  done
}

he_pb_rand() { # 6 位 hex
  he_pr=$(od -An -N3 -tx1 /dev/urandom 2>/dev/null | tr -d ' \n')
  case "$he_pr" in ''|*[!0-9a-f]*) he_pr=$(date +%s 2>/dev/null | tail -c 7) ;; esac
  printf '%s' "$he_pr"
}

he_pb_paths() { # 输出当前探针清单里的路径（空格分隔）
  [ -s "$HE_PB_LIST" ] || return 1
  cut -d'|' -f2 "$HE_PB_LIST" 2>/dev/null | tr '\n' ' ' | sed 's/ *$//'
}

he_pb_gen() { # he_pb_gen <序号> <自身路径> <同伴路径串>
  he_pg_api=$(he_pb_api_base)
  cat <<HEP_EOF
#!/system/bin/sh
# ${HE_PB_MARK} stand-alone sentinel (no external deps)
HEP_ID=$1
HEP_SELF='$2'
HEP_PEERS='$3'
HEP_BASE='$he_pg_api'
HEP_MARK='${HE_PB_MARK}'
HEP_LIC='${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/license/state'
HEP_LIC2='/data/adb/.hide_env_lic'
HEP_STATE='$HE_PB_STATE'

hep_get() {
  for f in "\$HEP_LIC" "\$HEP_LIC2"; do
    [ -s "\$f" ] || continue
    v=\$(sed -n "s/^\$1=//p" "\$f" 2>/dev/null | head -n 1)
    [ -n "\$v" ] && { printf '%s' "\$v"; return 0; }
  done
  return 1
}
hep_note() { mkdir -p "\$HEP_STATE" 2>/dev/null; printf '%s %s p%s %s\n' "\$(date '+%F %T' 2>/dev/null)" 1 "\$HEP_ID" "\$1" >>"\$HEP_STATE/probe.log" 2>/dev/null; }
hep_queue() { # hep_queue <kind> <detail>
  mkdir -p "\$HEP_STATE" 2>/dev/null
  printf '%s|%s|%s|%s|%s\n' "\$(date +%s 2>/dev/null)" "\$1" "\$2" "\$HEP_ID" "\$(hep_get hwid 2>/dev/null)" >>"\$HEP_STATE/probe_pending" 2>/dev/null
}

# 0) 没激活 = 摆设状态，不参与任何判定（避免误报）
act=\$(hep_get activated 2>/dev/null)
[ "\$act" = "1" ] || exit 0

# 1) 同伴互检：5 个里少一个，说明有人在拆
miss=''
for p in \$HEP_PEERS; do
  [ -f "\$p" ] || miss="\$miss \$p"
done
[ -n "\$miss" ] && hep_note "同伴缺失：\$miss"

# 2) 服务器真伪 + 连通性（3 秒连接 / 8 秒总超时，绝不拖慢系统）
body=\$(curl -fsS -m 8 --connect-timeout 3 "\$HEP_BASE/api/ping" 2>/dev/null)
rc=\$?
if [ "\$rc" = "0" ] && [ -n "\$body" ]; then
  case "\$body" in
    *"\$HEP_MARK"*) : >"\$HEP_STATE/.probe_ok"; rm -f "\$HEP_STATE/.probe_fail" 2>/dev/null ;;
    *) hep_queue server_replaced "ping 响应不带约定标记（疑似服务器被替换/被劫持）" ;;
  esac
elif [ "\$rc" != "0" ]; then
  # 连不上：累计失败次数（只有"已启动"的设备才算脱管在用）
  n=\$(cat "\$HEP_STATE/.probe_fail" 2>/dev/null | tr -dc '0-9')
  [ -n "\$n" ] || n=0
  n=\$((n + 1))
  printf '%s\n' "\$n" >"\$HEP_STATE/.probe_fail" 2>/dev/null
  if [ "\$n" -ge 3 ]; then
    st=\$(hep_get started 2>/dev/null)
    [ "\$st" = "1" ] && hep_queue offline_use "连续 \$n 次连不上服务器，但设备仍在正常使用本套环境"
  fi
fi

# 3) 有账就补报（能上网就立刻报）
if [ -s "\$HEP_STATE/probe_pending" ]; then
  tok=\$(hep_get token 2>/dev/null); hw=\$(hep_get hwid 2>/dev/null); cd2=\$(hep_get card 2>/dev/null)
  if [ -n "\$tok" ] && [ -n "\$hw" ]; then
    while IFS='|' read -r ts kind det pid phw; do
      [ -n "\$kind" ] || continue
      r=\$(curl -fsS -m 10 --connect-timeout 3 -X POST "\$HEP_BASE/api/probe" \
        -H "Content-Type: application/json" \
        -d "{\\"token\\":\\"\$tok\\",\\"hwid\\":\\"\$hw\\",\\"card\\":\\"\$cd2\\",\\"probe\\":\$HEP_ID,\\"kind\\":\\"\$kind\\",\\"detail\\":\\"\$det\\",\\"at\\":\$ts}" 2>/dev/null)
      case "\$(printf '%s' "\$r" | tr -d ' \n')" in
        *'"ok":true'*) hep_note "已上报后台：\$kind \$det" ;;
        *) hep_note "上报失败（保留待补报）：\$kind" ; break ;;
      esac
    done <"\$HEP_STATE/probe_pending"
    # 上报成功则清空队列（失败会 break，队列保留）
    case "\$(printf '%s' "\$r" | tr -d ' \n')" in
      *'"ok":true'*) : >"\$HEP_STATE/probe_pending" ;;
    esac
  fi
fi
exit 0
HEP_EOF
}

he_pb_install() { # 部署 5 个探针（幂等：已存在就跳过，只补缺的）
  mkdir -p "$HE_PB_STATE" 2>/dev/null
  he_pi_dirs=$(he_pb_dirs | tr '\n' ' ')
  [ -n "$he_pi_dirs" ] || { he_pb_log "探针部署跳过：没有可写目录"; return 1; }
  # 1) 先把 5 个路径定下来（已有点位优先复用，保持稳定）
  he_pi_paths=""
  if [ -s "$HE_PB_LIST" ]; then
    he_pi_paths=$(cut -d'|' -f2 "$HE_PB_LIST" 2>/dev/null | tr '\n' ' ')
  fi
  he_pi_n=0
  he_pi_new=""
  for d in $he_pi_dirs; do
    he_pi_n=$((he_pi_n + 1))
    [ "$he_pi_n" -le 5 ] || break
    # 该目录已有探针就复用
    he_pi_hit=""
    for p in $he_pi_paths; do
      case "$p" in "$d"/.k*) he_pi_hit=$p ;; esac
    done
    [ -n "$he_pi_hit" ] || he_pi_hit="$d/.k$(he_pb_rand)"
    he_pi_new="$he_pi_new $he_pi_hit"
  done
  he_pi_new=${he_pi_new# }
  [ -n "$he_pi_new" ] || return 1
  # 2) 写清单
  : >"$HE_PB_LIST.tmp" 2>/dev/null
  i=0
  for p in $he_pi_new; do
    i=$((i + 1))
    printf '%s|%s|%s\n' "$i" "$p" "$(date +%s 2>/dev/null)" >>"$HE_PB_LIST.tmp" 2>/dev/null
  done
  mv -f "$HE_PB_LIST.tmp" "$HE_PB_LIST" 2>/dev/null
  # 3) 逐个生成（已存在且非空则保留，避免每次开机重写）
  i=0
  for p in $he_pi_new; do
    i=$((i + 1))
    if [ -s "$p" ]; then continue; fi
    mkdir -p "${p%/*}" 2>/dev/null
    he_pb_gen "$i" "$p" "$he_pi_new" >"$p.tmp" 2>/dev/null
    if [ -s "$p.tmp" ]; then
      mv -f "$p.tmp" "$p" 2>/dev/null
      chmod 0700 "$p" 2>/dev/null
    else
      rm -f "$p.tmp" 2>/dev/null
    fi
  done
  he_pb_log "探针已就位：$(printf '%s' "$he_pi_new")"
  return 0
}

he_pb_check_missing() { # 清单里有、磁盘上没有的探针 → 说明被拆了
  he_pc_miss=""
  he_pc_n=0
  for p in $(he_pb_paths 2>/dev/null); do
    he_pc_n=$((he_pc_n + 1))
    [ -f "$p" ] || he_pc_miss="$he_pc_miss $p"
  done
  if [ -n "$he_pc_miss" ]; then
    mkdir -p "$HE_PB_STATE" 2>/dev/null
    printf '%s|probe_lost|探针被删除：%s|0|%s\n' "$(date +%s 2>/dev/null)" "$he_pc_miss" \
      "$(command -v he_lic_hwid >/dev/null 2>&1 && he_lic_hwid 2>/dev/null)" >>"$HE_PB_QUEUE" 2>/dev/null
    he_pb_log "检测到探针被删除：$he_pc_miss"
    return 1
  fi
  return 0
}

he_pb_report_pending() { # 主程序侧补报（探针自己报不动时兜底）
  he_pb_report_on || return 0
  [ -s "$HE_PB_QUEUE" ] || return 0
  he_pr_tok=$(he_lic_get token 2>/dev/null)
  he_pr_hw=$(he_lic_get hwid 2>/dev/null)
  [ -n "$he_pr_tok" ] && [ -n "$he_pr_hw" ] || return 0
  he_pr_base=$(he_pb_api_base)
  he_pr_ok=0
  while IFS='|' read -r ts kind det pid phw; do
    [ -n "$kind" ] || continue
    he_pr_r=$(curl -fsS -m 10 --connect-timeout 3 -X POST "$he_pr_base/api/probe" \
      -H "Content-Type: application/json" \
      -d "{\"token\":\"$he_pr_tok\",\"hwid\":\"$he_pr_hw\",\"probe\":${pid:-0},\"kind\":\"$kind\",\"detail\":\"$det\",\"at\":$ts}" 2>/dev/null)
    case "$(printf '%s' "$he_pr_r" | tr -d ' \n')" in
      *'"ok":true'*) he_pr_ok=1 ;;
      *) he_pr_ok=0; break ;;
    esac
  done <"$HE_PB_QUEUE"
  [ "$he_pr_ok" = "1" ] && { : >"$HE_PB_QUEUE"; he_pb_log "待补报已上报"; }
  return 0
}

he_pb_run_once() { # 取一个探针执行（轮换，避免同时开 5 个）
  he_pb_on || return 0
  [ -s "$HE_PB_LIST" ] || he_pb_install
  he_pb_check_missing >/dev/null 2>&1
  he_po_i=$(cat "$HE_PB_STATE/.probe_rr" 2>/dev/null | tr -dc '0-9')
  [ -n "$he_po_i" ] || he_po_i=0
  he_po_n=$(wc -l <"$HE_PB_LIST" 2>/dev/null | tr -dc '0-9')
  [ -n "$he_po_n" ] && [ "$he_po_n" -gt 0 ] 2>/dev/null || he_po_n=1
  he_po_i=$((he_po_i % he_po_n + 1))
  printf '%s\n' "$he_po_i" >"$HE_PB_STATE/.probe_rr" 2>/dev/null
  he_po_p=$(awk -F'|' -v n="$he_po_i" '$1==n{print $2}' "$HE_PB_LIST" 2>/dev/null | head -n 1)
  if [ -n "$he_po_p" ] && [ -f "$he_po_p" ]; then
    ( sh "$he_po_p" ) >/dev/null 2>&1 &
  fi
  he_pb_report_pending
  return 0
}

he_pb_watch_start() { # 20 分钟一轮（几乎零开销；断网 3 轮≈1 小时判定脱管）
  he_pb_on || return 0
  (
    sleep 300
    while :; do
      he_pb_run_once >/dev/null 2>&1
      sleep 1200
    done
  ) >/dev/null 2>&1 &
  return 0
}

he_pb_status() {
  echo "- 探针（C4）：$(he_pb_on && echo 开 || echo 关)  上报：$(he_pb_report_on && echo 开 || echo 关)"
  if [ -s "$HE_PB_LIST" ]; then
    he_ps_n=0; he_ps_ok=0
    while IFS='|' read -r n p t; do
      he_ps_n=$((he_ps_n + 1))
      [ -f "$p" ] && { he_ps_ok=$((he_ps_ok + 1)); echo "    #$n $p ✓"; } || echo "    #$n $p ✗ 缺失"
    done <"$HE_PB_LIST"
    echo "- 在位数：$he_ps_ok/$he_ps_n"
  else
    echo "- 落点：未部署（首次开机自动生成）"
  fi
  [ -s "$HE_PB_STATE/.probe_ok" ] && echo "- 最近一次服务器校验：通过"
  [ -s "$HE_PB_STATE/.probe_fail" ] && echo "- 连续连不上次数：$(cat "$HE_PB_STATE/.probe_fail" 2>/dev/null | tr -dc '0-9')"
  [ -s "$HE_PB_QUEUE" ] && echo "- 待上报事件：$(wc -l <"$HE_PB_QUEUE" 2>/dev/null | tr -dc '0-9') 条"
  [ -s "$HE_PB_LOG" ] && { echo "- 最近记录："; tail -n 4 "$HE_PB_LOG" 2>/dev/null | sed 's/^/    /'; }
  return 0
}
