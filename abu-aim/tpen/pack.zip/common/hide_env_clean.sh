#!/system/bin/sh
#############################################################
# hide_env_clean.sh —— 游戏环境清理（三合一）
#
# 原理来自三个社区脚本（已逆向还原，见 D:\re_qingli）：
#   ① 暗区清理  / ② 三角洲常规清理  —— 文件级清理，核心一样，只是包名不同
#   ③ 解决设备连续标记         —— persist 分区加锁 + 设备标识重置
#
# 本文件把三件事合成一条命令：install.sh clean [all|anqu|delta|mark|id|persist|status|mf|final|thorough]
#
#   A. 文件清理（对已安装的那几个游戏，一个不多动）
#        · shared_prefs：退掉游戏登录态
#        · cache / code_cache / no_backup / 外置 Android/data|obb 的 cache
#        · ★ files/ano_tmp 系列"下发缓存"：ACE 临时下发的标记就落在这里
#        · databases / files 里 <1MB 的小文件（标记文件都是小文件；游戏资源是大文件，不动）
#        · dalvik-cache / package_cache 里与该包相关的缓存
#   B. 标记文件（mrpcs* 系列，这是反作弊下发的"设备标记"）
#        · 扫描位置：游戏数据目录的 ano_tmp 系列 + /mnt/vendor/persist/data 等 persist 目录
#        · 按文件名分级：A_v 环境 / A_cd 行为 / A_h 数据 / A_s 强标(传染) / A_r 处罚 / VM / 云下发
#        · 删之前先备份到 /data/local/tmp/hide_env_clean_backup/（可回查，不直接抹掉）
#   C. 设备标识重置：android_id 换新 + SSAID 缓存清除 + gms/gsf 广告 ID 清空
#   D. 标记防护（可选，默认关）：把 /mnt/vendor/persist/data 权限设 000
#        —— 社区"简易解设备标记"的手法（挡标记写入/读取）。重启会失效，
#           所以打开后每次开机自动重放。有风险（个别机型 persist 里的东西读不到），
#           默认不开，要开：install.sh clean persist on
#
# 安全约定：只碰上面列出的东西；游戏没装就跳过；删文件前先备份；不动用户自己的其它数据。
#############################################################

# 数据根目录（沙盒自测时可重定向到临时目录，真机上就是 /data/user 与 /data/user_de）
HE_CLEAN_ROOT=${HE_CLEAN_ROOT:-/data/user}
HE_CLEAN_ROOT_DE=${HE_CLEAN_ROOT_DE:-/data/user_de}
HE_CLEAN_BACKUP=${HE_CLEAN_BACKUP:-/data/local/tmp/hide_env_clean_backup}
HE_CLEAN_LOG_DIR=${HE_CLEAN_LOG_DIR:-/sdcard/hide_env_清理日志}
HE_PERSIST_DIRS=${HE_PERSIST_DIRS:-"/mnt/vendor/persist/data /persist/data /data/vendor/persist/data"}

# 要清理的游戏（包名匹配规则 + 显示名）—— 来自逆向还原的脚本
he_clean_targets() {
  cat <<'EOF'
tmgp.dfm|三角洲行动(国服)
com.tencent.mf.uam|暗区突围(国服)
com.proximabeta.mf.uamo|暗区突围/三角洲(国际服)
garena.game.df|三角洲行动(台服)
com.proxima.dfm|三角洲行动(国际服)
com.tencent.rmcn|失控进化
EOF
}

he_clean_custom_file() {   # 自定义要清理/盯防的包名清单（一行一个，# 注释）
  printf '%s' "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_pkgs.txt"
}

he_clean_custom_pkgs() {   # 打印自定义包名（去注释/去空/去重；兼容老的 clean_watch_pkgs.txt）
  he_cc_f=$(he_clean_custom_file)
  [ -s "$he_cc_f" ] && sed -e 's/#.*//' -e 's/[[:space:]]//g' "$he_cc_f" 2>/dev/null | grep -v '^$' | sort -u
  he_cc_f2=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_watch_pkgs.txt
  [ -s "$he_cc_f2" ] && sed -e 's/#.*//' -e 's/[[:space:]]//g' "$he_cc_f2" 2>/dev/null | grep -v '^$' | sort -u
  return 0
}

he_clean_targets_ext() {   # $1=act；custom 时把自定义包名并进来（标签=自定义）
  he_clean_targets
  if [ "${1:-}" = "custom" ]; then
    for he_ce_p in $(he_clean_custom_pkgs); do
      printf '%s|自定义\n' "$he_ce_p"
    done
  fi
  return 0
}

he_clean_pkgs_edit() {   # 看/建 自定义包名表（install.sh clean pkgs）
  he_cp_f=$(he_clean_custom_file)
  if [ ! -f "$he_cp_f" ]; then
    mkdir -p "$(dirname "$he_cp_f")" 2>/dev/null
    cat >"$he_cp_f" <<'EOF'
# 自定义要清的游戏包名（一行一个；# 开头是注释）
# 清一次：install.sh clean custom ｜ 看护：这些包也会被盯（在跑锁 persist，退出瞬间清下发目录）
# 常用参考（要用就删掉前面的 #）：
# com.tencent.rmcn            失控进化（已在默认清理表里，无需再加）
# com.tencent.tmgp.sgame      王者荣耀
# com.tencent.tmgp.pubgmhd    和平精英
# com.tencent.tmgp.codev      无畏契约手游
# com.tencent.tmgp.cf         穿越火线手游
# com.tencent.lolm            英雄联盟手游
EOF
    echo "[√] 已创建自定义包名表：$he_cp_f"
  fi
  echo "== 自定义包名表：$he_cp_f =="
  head -40 "$he_cp_f" 2>/dev/null
  echo
  echo "- 当前生效：$(he_clean_custom_pkgs | tr '\n' ' ')"
  echo "- 编辑方式：MT 管理器打开该文件 / 模块网页终端 / 控制台协助页下发命令"
  echo "- 清一次：install.sh clean custom"
}

he_clean_users() {
  he_u=$(pm list users 2>/dev/null | sed -n 's/.*UserInfo{\([0-9]*\):.*/\1/p' | sort -un | tr '\n' ' ')
  [ -n "$he_u" ] || he_u="0"
  for he_d in /data/user/*; do
    [ -d "$he_d" ] || continue
    he_n=$(basename "$he_d")
    case "$he_n" in ''|*[!0-9]*) continue ;; esac
    case " $he_u " in *" $he_n "*) ;; *) he_u="$he_u $he_n" ;; esac
  done
  printf '%s' "$he_u"
}

he_clean_game_pkgs() { # he_clean_game_pkgs <匹配规则> ；输出实际装在设备上的包名（可多个）
  he_cp="$1"
  pm list packages 2>/dev/null | sed -n 's/^package://p' | grep -iE "$he_cp" 2>/dev/null
}

he_clean_marker_level() { # 按文件名分级（逆向还原的对照表）
  case "$1" in
    mrpcs_a_v.data)   printf '中|A_v 环境监测标记（系统环境异常：解锁/Magisk/模块/改机型）' ;;
    mrpcs_a_cd.data)  printf '中|A_cd 行为监测标记（内存读取/透视等行为异常）' ;;
    mrpcs_a_h*.data)  printf '低|A_h 数据异常标记（多由辅助模块触发）' ;;
    mrpcs_a_s.data)   printf '极高|A_s 强标设备/账号标记（有传染性：新号也会被连坐）' ;;
    mrpcs_a_r.data)   printf '极高|A_r 处罚下发标记（反作弊已判定）' ;;
    mrpcs_vm_*.data)  printf '高|VM 虚拟机/容器检测标记' ;;
    mrpcs_m.data|mrpcs-android*.data|mrpcs_iarm*.data|mrpcs-*.data) printf '高|云下发可疑设备标记（后续账号会连带被下发）' ;;
    mrpcs.data|mrpcs_c.data|mrpcs_[0-9A-Za-z]+.data) printf '高|反作弊下发标记（真机实测 暗区 退出时落这个：mrpcs.data / mrpcs_c.data / mrpcs_<随机>）' ;;
    *)                printf '中|未知 mrpcs 系列标记（反作弊下发，建议清理）' ;;
  esac
}

# 扫一个目录里的 mrpcs*（最多两层，和原脚本一致）
he_clean_scan_dir() {
  he_sd_dir="$1"
  he_sd_out="$2"
  [ -d "$he_sd_dir" ] || return 0
  find "$he_sd_dir" -maxdepth 2 -type f -name "mrpcs*" 2>/dev/null >>"$he_sd_out"
  return 0
}

# A+B：对某个包做文件清理 + 标记扫描（wipe=1 时删除标记文件，0 时只报告）
he_clean_pkg() {
  he_pkg="$1"; he_uid="$2"; he_name="$3"; he_wipe="$4"
  he_found=0; he_hit=0
  he_tmp="${HIDE_TMP:-/data/local/tmp}"

  # ★ 顺序很重要：先把标记扫出来（并备份/删除），再去清缓存 ——
  #   反过来的话 ano_tmp 先被清空，标记文件就永远扫不到了（这就是老脚本的坑）。
  he_list="$he_tmp/clean_scan.$$"
  mkdir -p "$he_tmp" 2>/dev/null   # 兜底：tmp 被清过时自己建（否则重定向失败 → 整段清理静默跳过）
  : >"$he_list"
  for he_base in "$HE_CLEAN_ROOT/$he_uid/$he_pkg" "$HE_CLEAN_ROOT_DE/$he_uid/$he_pkg"; do
    [ -d "$he_base" ] || continue
    for he_ano in "files/ano_tmp/custom_cache" "files/ano_tmp" "files/cache/ano_tmp" "files/.ano_cache" "files/ano_cache"; do
      he_clean_scan_dir "$he_base/$he_ano" "$he_list"
    done
  done
  for he_pp in $HE_PERSIST_DIRS; do he_clean_scan_dir "$he_pp" "$he_list"; done
  sort -u "$he_list" 2>/dev/null >"$he_list.u" && mv -f "$he_list.u" "$he_list" 2>/dev/null

  while read -r he_mf; do
    [ -n "$he_mf" ] || continue
    [ -f "$he_mf" ] || continue
    he_lv=$(he_clean_marker_level "$(basename "$he_mf")" | cut -d'|' -f1)
    he_desc=$(he_clean_marker_level "$(basename "$he_mf")" | cut -d'|' -f2)
    echo "   ✖ [$he_lv] $(basename "$he_mf") —— $he_desc"
    echo "      路径：$he_mf"
    he_found=$((he_found+1))
    if [ "$he_wipe" = "1" ]; then
      mkdir -p "$HE_CLEAN_BACKUP" 2>/dev/null
      cp -f "$he_mf" "$HE_CLEAN_BACKUP/$(basename "$he_mf").$(date +%s)" 2>/dev/null
      if rm -f "$he_mf" 2>/dev/null; then
        he_hit=$((he_hit+1)); echo "      → 已删除（已备份）"
      else
        echo "      → 删除失败（该目录只读？可试 install.sh clean persist on 把 persist 锁上）"
      fi
    fi
  done <"$he_list"
  rm -f "$he_list" "$he_list.u" 2>/dev/null

  # status 模式（he_wipe=0）：只报告，一个文件都不动 —— 上面扫完就返回
  if [ "$he_wipe" != "1" ]; then
    he_mark clean ok "$he_name：发现标记 $he_found 个（只扫描，未改动任何文件）"
    return 0
  fi

  # ---- 下面是"清理"，只在 he_wipe=1 时做 ----
  for he_base in "$HE_CLEAN_ROOT/$he_uid/$he_pkg" "$HE_CLEAN_ROOT_DE/$he_uid/$he_pkg"; do
    [ -d "$he_base" ] || continue
    [ -d "$he_base/shared_prefs" ] && rm -rf "$he_base/shared_prefs" 2>/dev/null && he_hit=$((he_hit+1)) && echo "   · 已清登录态（shared_prefs）"
    [ -d "$he_base/cache" ] && rm -rf "$he_base/cache"/* 2>/dev/null
    [ -d "$he_base/code_cache" ] && rm -rf "$he_base/code_cache"/* 2>/dev/null
    [ -d "$he_base/no_backup" ] && rm -rf "$he_base/no_backup"/* 2>/dev/null
    for he_ano in "files/ano_tmp/custom_cache" "files/ano_tmp" "files/cache/ano_tmp" "files/.ano_cache" "files/ano_cache"; do
      if [ -d "$he_base/$he_ano" ]; then
        rm -rf "$he_base/$he_ano"/* 2>/dev/null && he_hit=$((he_hit+1)) && echo "   · 已抹除下发缓存 $he_ano"
      fi
    done
    for he_sub in databases files; do
      [ -d "$he_base/$he_sub" ] || continue
      he_l2="$he_tmp/clean_small.$$"
      find "$he_base/$he_sub" -type f -size -1048576c 2>/dev/null >"$he_l2"
      if [ -s "$he_l2" ]; then
        he_n=$(wc -l <"$he_l2" 2>/dev/null | tr -d ' ')
        while read -r he_f; do [ -n "$he_f" ] && rm -f "$he_f" 2>/dev/null; done <"$he_l2"
        echo "   · 已清 $he_sub 小文件 ${he_n:-若干} 个"
        he_hit=$((he_hit+1))
      fi
      rm -f "$he_l2" 2>/dev/null
    done
  done

  if [ "$he_uid" = "0" ]; then he_exts="/sdcard /storage/emulated/0"; else he_exts="/storage/emulated/$he_uid /data/media/$he_uid /sdcard/$he_uid"; fi
  for he_b in $he_exts; do
    for he_sub in data obb; do
      he_ed="$he_b/Android/$he_sub/$he_pkg"
      [ -d "$he_ed" ] || continue
      [ -d "$he_ed/cache" ] && rm -rf "$he_ed/cache"/* 2>/dev/null
      he_l3="$he_tmp/clean_ext.$$"
      find "$he_ed" -type f -size -1048576c 2>/dev/null >"$he_l3"
      if [ -s "$he_l3" ]; then
        while read -r he_f; do [ -n "$he_f" ] && rm -f "$he_f" 2>/dev/null; done <"$he_l3"
        he_hit=$((he_hit+1))
      fi
      rm -f "$he_l3" 2>/dev/null
    done
  done

  rm -f /data/dalvik-cache/*"$he_pkg"* /data/system/package_cache/*"$he_pkg"* 2>/dev/null
  he_mark clean ok "$he_name：清了 $he_hit 处，标记 $he_found 个（已删并备份）"
  return 0
}


# C：设备标识重置（"解决连续标记"里最有效的一步）
he_clean_id_reset() {
  he_new=$(od -An -tx1 -N8 /dev/urandom 2>/dev/null | tr -d ' \n')
  [ -n "$he_new" ] || he_new=$(date +%s | md5sum 2>/dev/null | cut -c1-16)
  if settings put secure android_id "$he_new" >/dev/null 2>&1; then
    echo "   · Android ID 已重置为 $he_new"
  else
    echo "   ! Android ID 重置失败（settings 不可用？）"
  fi
  pm clear com.google.android.gms >/dev/null 2>&1 && echo "   · GMS 数据已清（广告 ID 重置）"
  pm clear com.google.android.gsf >/dev/null 2>&1 && echo "   · GSF 数据已清"
  for he_u in $(he_clean_users); do
    rm -f "/data/system/users/$he_u/settings_ssaid.xml" 2>/dev/null
  done
  echo "   · SSAID 缓存已清除"
  he_mark clean_id ok "设备标识已重置（Android ID / SSAID / 广告 ID）"
  return 0
}

# D：persist 目录加锁（可选，默认关；开了每次开机重放）
he_clean_persist() {
  he_pm_act=${1:-status}
  case "$he_pm_act" in
    on|lock)
      he_clean_persist_lock on
      if [ "$HE_CLEAN_PL_OK" = "1" ]; then
        mkdir -p "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}" 2>/dev/null
        echo "on" >"${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_persist.txt" 2>/dev/null
        he_mark clean_persist ok "persist 目录已加锁（挡标记写入；原权限已备份，clean persist off 可还原）"
      else
        he_mark clean_persist fail "加锁失败（没有可写的 persist 目录？）"
      fi
      ;;
    off|restore|unlock)
      he_clean_persist_lock restore
      rm -f "${HIDE_CFG_DIR:-/data/adb/hide_env_pack}/config/clean_persist.txt" 2>/dev/null
      rm -f "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_persist.txt" 2>/dev/null
      he_mark clean_persist ok "persist 目录已按备份还原权限（恢复原状）"
      ;;
    *)
      for he_pp in $HE_PERSIST_DIRS; do
        [ -d "$he_pp" ] || continue
        he_ls=$(ls -ld "$he_pp" 2>/dev/null | cut -c1-10)
        echo "   $he_pp  权限=$he_ls"
      done
      echo "   （开关：install.sh clean persist on|off；常态由「看护」自动加锁/还原）"
      ;;
  esac
  return 0
}

# ---------------------------------------------------------------
# persist 目录加锁 / 还原（★ 社区那套模块的关键手法）
#   游戏运行中把 /mnt/vendor/persist/data 设 000 → 反作弊的标记写不进去；
#   游戏一退出立刻把【原权限】还回去（所以必须先把原权限备份下来）。
#   备份：state/persist_perms.txt（一行：权限 属主:属组 路径）
# ---------------------------------------------------------------
he_clean_persist_lock() {   # he_clean_persist_lock on|restore
  HE_CLEAN_PL_OK=0
  he_pl_bak=${HE_CLEAN_PERM_BAK:-/data/adb/hide_env_pack/state/persist_perms.txt}
  case "$1" in
    on|lock)
      if [ ! -s "$he_pl_bak" ]; then
        mkdir -p "$(dirname "$he_pl_bak")" 2>/dev/null
        : >"$he_pl_bak" 2>/dev/null
        for he_pp in $HE_PERSIST_DIRS; do
          [ -d "$he_pp" ] || continue
          find "$he_pp" -exec stat -c "%a %U:%G %n" {} \; >>"$he_pl_bak" 2>/dev/null
        done
        [ -s "$he_pl_bak" ] || printf '%s\n' "755 root:root" >"$he_pl_bak"
      fi
      for he_pp in $HE_PERSIST_DIRS; do
        [ -d "$he_pp" ] || continue
        chmod 000 "$he_pp" 2>/dev/null && HE_CLEAN_PL_OK=1
      done
      ;;
    restore|off|unlock)
      he_pl_n=0
      if [ -s "$he_pl_bak" ]; then
        while read -r he_perm he_own he_path; do
          [ -n "$he_path" ] || continue
          [ -e "$he_path" ] || continue
          chmod "$he_perm" "$he_path" 2>/dev/null && he_pl_n=$((he_pl_n+1))
          [ -n "$he_own" ] && chown "$he_own" "$he_path" 2>/dev/null
        done <"$he_pl_bak"
      fi
      if [ "$he_pl_n" = "0" ]; then
        for he_pp in $HE_PERSIST_DIRS; do
          [ -d "$he_pp" ] || continue
          chmod 755 "$he_pp" 2>/dev/null && he_pl_n=$((he_pl_n+1))
        done
      fi
      [ "$he_pl_n" != "0" ] && HE_CLEAN_PL_OK=1
      ;;
  esac
  return 0
}

# ---------------------------------------------------------------
# 行为日志清理（★ 社区模块"游戏退出瞬间"那套）
#   light：dropbox / usagestats / anr / tombstones（看护每次游戏退出都做）
#   full ：再加 appops.xml / ifw / ndebugsocket / logd / update_engine（手动清理才做）
# ---------------------------------------------------------------
he_clean_behaviour_logs() {   # he_clean_behaviour_logs light|full
  he_bl_mode=${1:-light}
  rm -rf /data/system/dropbox/* /data/system/usagestats/* /data/anr/* /data/tombstones/* 2>/dev/null
  if [ "$he_bl_mode" = "full" ]; then
        # ★ v1.0.78：不再整文件删 /data/system/appops.xml —— 那是【全系统的权限/授权数据】，
    #   删掉会把 USB 设备授权、输入相关授权一起重置（客户反馈“用完模块键鼠不能用”）。
    #   改为只对游戏做 appops reset（精准清掉它的行为记录，不动别的授权）。
    for he_bl_p in $(he_clean_game_pkgs '*' 2>/dev/null); do
      appops reset "$he_bl_p" >/dev/null 2>&1
    done
    rm -rf /data/system/ifw/* /data/system/ndebugsocket/* 2>/dev/null
    rm -rf /data/misc/logd/* /data/misc/update_engine/log/* 2>/dev/null
  fi
  echo 16384 > /proc/sys/fs/inotify/max_queued_events 2>/dev/null
  echo 128   > /proc/sys/fs/inotify/max_user_instances 2>/dev/null
  echo 8192  > /proc/sys/fs/inotify/max_user_watches 2>/dev/null
  return 0
}

# ---------------------------------------------------------------
# 看护（★ 社区方案真正的"关键点"，一次性清理永远追不上它）
#   游戏在跑   → persist 加锁（标记写不进去）
#   游戏刚退出 → 清 ano_tmp + 缓存 + 行为日志（刚下发的标记立刻抹掉）
#   没有游戏跑 → persist 权限还原（不影响系统里别的东西）
#   开关：config/clean_watch.txt 写 off 关闭（默认开）
# ---------------------------------------------------------------
he_clean_watch_pkgs() {   # 输出要盯的包名（游戏没装就没有；含自定义表）
  for he_wp_pat in $(he_clean_targets | cut -d'|' -f1); do
    he_clean_game_pkgs "$he_wp_pat"
  done | sort -u
  he_clean_custom_pkgs
  return 0
}

he_clean_on_game_exit() {   # he_clean_on_game_exit <包名>
  he_ge_pkg="$1"
  he_ge_n=0
  for he_u in $(he_clean_users); do
    for he_base in "$HE_CLEAN_ROOT/$he_u/$he_ge_pkg" "$HE_CLEAN_ROOT_DE/$he_u/$he_ge_pkg"; do
      [ -d "$he_base" ] || continue
      for he_ano in "files/ano_tmp/custom_cache" "files/ano_tmp" "files/cache/ano_tmp" "files/.ano_cache" "files/ano_cache"; do
        if [ -d "$he_base/$he_ano" ]; then
          rm -rf "$he_base/$he_ano"/* 2>/dev/null && he_ge_n=$((he_ge_n+1))
        fi
      done
      rm -rf "$he_base/cache"/* "$he_base/code_cache"/* 2>/dev/null
    done
  done
  # 外部资源树（Android/data/<包>/files，UE4Game 那棵）里的下发目录与标记也一起清
  #   —— 「有始有终」的保数据清理思路：账号/登录态在内部 /data/data，这里只删下发物
  if command -v he_clean_mf_ext_files >/dev/null 2>&1; then
    for he_u in $(he_clean_users); do
      for he_ef in $(he_clean_mf_ext_files "$he_ge_pkg" "$he_u" 2>/dev/null); do
        [ -f "$he_ef" ] || continue
        rm -f "$he_ef" 2>/dev/null && he_ge_n=$((he_ge_n+1))
      done
    done
  fi
  he_clean_behaviour_logs light
  he_ge_log=${HE_CLEAN_WATCH_LOG:-/data/adb/hide_env_pack/state/cleanwatch.log}
  [ -d "$(dirname "$he_ge_log")" ] && echo "$(date '+%m-%d %H:%M:%S') 退出清理 $he_ge_pkg：清了 $he_ge_n 处下发目录" >>"$he_ge_log" 2>/dev/null
  return 0
}

he_clean_watch_once() {   # 看护循环的"一轮"（沙盒测试直接调这个）
  he_wo_state=${HE_CLEAN_WATCH_DIR:-/data/adb/hide_env_pack/state/cleanwatch}
  mkdir -p "$he_wo_state" 2>/dev/null
  he_wo_running=0
  for he_wp in $(he_clean_watch_pkgs); do
    [ -n "$he_wp" ] || continue
    if pidof "$he_wp" >/dev/null 2>&1; then
      he_wo_running=$((he_wo_running+1))
      : >"$he_wo_state/run.$he_wp" 2>/dev/null
    else
      if [ -f "$he_wo_state/run.$he_wp" ]; then
        rm -f "$he_wo_state/run.$he_wp" 2>/dev/null
        he_clean_on_game_exit "$he_wp"
      fi
    fi
  done
  if [ "$he_wo_running" != "0" ]; then
    if [ ! -f "$he_wo_state/locked" ]; then
      he_clean_persist_lock on
      [ "$HE_CLEAN_PL_OK" = "1" ] && : >"$he_wo_state/locked" 2>/dev/null
    fi
  else
    if [ -f "$he_wo_state/locked" ]; then
      he_clean_persist_lock restore
      rm -f "$he_wo_state/locked" 2>/dev/null
    fi
  fi
  return 0
}

# ★ v1.0.78 第二道保险：只干一件事——绝不让 persist 停在 000。
#   背景：主看护一旦死掉（被杀/异常断电），锁着的 persist 就没人还原，
#   而蓝牙配对、触摸/传感器校准都可能存在 persist 上 → 客户表现为"键鼠/触摸失灵"。
#   这道保险独立于主看护：锁文件超过 N 分钟且没有游戏在跑，就直接还原权限。
HE_PERSIST_GUARD_SEC=${HE_PERSIST_GUARD_SEC:-600}

he_clean_persist_guard() {
  he_pg_pid=${HE_CLEAN_PERSIST_GUARD_PID:-/data/adb/hide_env_pack/state/persist_guard.pid}
  mkdir -p "$(dirname "$he_pg_pid")" 2>/dev/null
  echo $$ >"$he_pg_pid" 2>/dev/null
  while true; do
    he_pg_state=${HE_CLEAN_WATCH_DIR:-/data/adb/hide_env_pack/state/cleanwatch}
    if [ -f "$he_pg_state/locked" ]; then
      he_pg_age=$(($(date +%s 2>/dev/null || echo 0) - $(stat -c %Y "$he_pg_state/locked" 2>/dev/null || echo 0)))
      he_pg_game=0
      for he_pg_p in $(he_clean_watch_pkgs); do
        [ -n "$he_pg_p" ] || continue
        pidof "$he_pg_p" >/dev/null 2>&1 && { he_pg_game=1; break; }
      done
      if [ "$he_pg_game" = "0" ] && [ "$he_pg_age" -gt "$HE_PERSIST_GUARD_SEC" ] 2>/dev/null; then
        he_clean_persist_lock restore
        rm -f "$he_pg_state/locked" 2>/dev/null
        printf '%s 第二道保险：锁超过 %s 秒且没有游戏在跑 → 已自动还原 persist 权限\n' \
          "$(date '+%m-%d %H:%M:%S' 2>/dev/null)" "$HE_PERSIST_GUARD_SEC" \
          >>"${HE_CLEAN_WATCH_LOG:-/data/adb/hide_env_pack/state/cleanwatch.log}" 2>/dev/null
      fi
    fi
    sleep 20
  done
}

he_clean_watch_daemon() {
  he_wd_pid=${HE_CLEAN_WATCH_PID:-/data/adb/hide_env_pack/state/cleanwatch.pid}
  mkdir -p "$(dirname "$he_wd_pid")" 2>/dev/null
  echo $$ >"$he_wd_pid" 2>/dev/null
  while true; do
    he_clean_watch_once
    sleep 1
  done
}

he_clean_watch_boot() {   # 开机：先 panic 还原，再按配置拉看护
  he_wb_cfg=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_watch.txt
  if [ -f "$he_wb_cfg" ] && grep -qs -x 'off' "$he_wb_cfg" 2>/dev/null; then
    he_clean_persist_lock restore
    return 0
  fi
  he_clean_persist_lock restore      # 上次异常关机可能留着 000
  mkdir -p "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}" 2>/dev/null
  [ -f "$he_wb_cfg" ] || echo "on" >"$he_wb_cfg" 2>/dev/null
  he_wb_pid=${HE_CLEAN_WATCH_PID:-/data/adb/hide_env_pack/state/cleanwatch.pid}
  if [ -f "$he_wb_pid" ]; then
    he_wb_p=$(cat "$he_wb_pid" 2>/dev/null)
    [ -n "$he_wb_p" ] && kill -0 "$he_wb_p" 2>/dev/null && return 0
  fi
  ( he_clean_watch_daemon ) >/dev/null 2>&1 &
  # 第二道保险（只负责"绝不把 persist 停在 000"），与主看护互相独立
  he_pg_pidf=${HE_CLEAN_PERSIST_GUARD_PID:-/data/adb/hide_env_pack/state/persist_guard.pid}
  he_pg_alive=0
  if [ -f "$he_pg_pidf" ]; then
    he_pg_p=$(cat "$he_pg_pidf" 2>/dev/null)
    [ -n "$he_pg_p" ] && kill -0 "$he_pg_p" 2>/dev/null && he_pg_alive=1
  fi
  [ "$he_pg_alive" = "1" ] || ( he_clean_persist_guard ) >/dev/null 2>&1 &
  return 0
}


# ---------------------------------------------------------------
# 深度 / 重度：社区清理器真正的两档（2026-10-07 用户反馈补上）
#   深度 = 停掉游戏 + `pm clear`（整个应用数据清空 → 等于"退出登录 + 重新授权"）
#          ＋ 外置目录 + 下发目录 + persist 标记
#          —— 只删文件那套（light）漏掉的东西（大文件里/游戏自己数据里的标记）也一并没了
#   重度 = 深度 + `pm uninstall`（把游戏卸掉 → 用户重装）＝ 社区说的"非永久强标"
#          —— 卸载会连同 /data/data 与部分外置目录一起清掉，最彻底
# ---------------------------------------------------------------
he_clean_game_deep() {   # he_clean_game_deep <包名> <显示名> <deep|hard>
  he_dp_pkg="$1"; he_dp_name="$2"; he_dp_mode="$3"
  he_dp_users=$(he_clean_users)

  echo "   - 停掉进程"
  am force-stop "$he_dp_pkg" >/dev/null 2>&1
  for he_u in $he_dp_users; do
    am force-stop --user "$he_u" "$he_dp_pkg" >/dev/null 2>&1
  done

  if [ "$he_dp_mode" = "hard" ]; then
    echo "   - 卸载游戏（重度：用户重装即可，标记随之消失）"
    for he_u in $he_dp_users; do
      pm uninstall --user "$he_u" "$he_dp_pkg" >/dev/null 2>&1 && echo "     · 已卸载（用户 $he_u）"
    done
  else
    echo "   - pm clear（深度：数据全清 = 退出登录 + 重新授权）"
    for he_u in $he_dp_users; do
      pm clear --user "$he_u" "$he_dp_pkg" >/dev/null 2>&1 && echo "     · 已清空数据（用户 $he_u）"
    done
  fi

  # 外置目录（卸载/clear 不一定带走）
  if [ "$he_dp_users" = "0" ] || [ -z "${he_dp_users##* }" ]; then :; fi
  for he_u in $he_dp_users; do
    if [ "$he_u" = "0" ]; then
      he_ex="/sdcard /storage/emulated/0"
    else
      he_ex="/storage/emulated/$he_u /data/media/$he_u /sdcard/$he_u"
    fi
    for he_b in $he_ex; do
      for he_sub in data obb; do
        he_ed="$he_b/Android/$he_sub/$he_dp_pkg"
        if [ -d "$he_ed" ]; then
          # 深度先删缓存与小文件；重度直接整目录删掉
          if [ "$he_dp_mode" = "hard" ]; then
            rm -rf "$he_ed" 2>/dev/null && echo "     · 已删外置目录 $he_ed"
          else
            [ -d "$he_ed/cache" ] && rm -rf "$he_ed/cache"/* 2>/dev/null
            he_ce="${HIDE_TMP:-/data/local/tmp}/ce.$$"
            mkdir -p "$(dirname "$he_ce")" 2>/dev/null
            find "$he_ed" -type f -size -1048576c 2>/dev/null >"$he_ce"
            while read -r he_f; do [ -n "$he_f" ] && rm -f "$he_f" 2>/dev/null; done <"$he_ce"
            rm -f "$he_ce" 2>/dev/null
          fi
        fi
      done
    done
  done

  # 遗留的内部数据目录（卸载后偶尔残留）+ 编译缓存
  for he_u in $he_dp_users; do
    [ "$he_u" = "0" ] && { rm -rf "/data/data/$he_dp_pkg" 2>/dev/null; } || rm -rf "/data/user/$he_u/$he_dp_pkg" 2>/dev/null
    rm -rf "/data/user_de/$he_u/$he_dp_pkg" 2>/dev/null
  done
  rm -f /data/dalvik-cache/*"$he_dp_pkg"* /data/system/package_cache/*"$he_dp_pkg"* 2>/dev/null

  # 下发目录 + persist 标记（两档都做）
  for he_pp in $HE_PERSIST_DIRS; do
    [ -d "$he_pp" ] || continue
    he_pf="${HIDE_TMP:-/data/local/tmp}/pp.$$"
    mkdir -p "$(dirname "$he_pf")" 2>/dev/null
    he_clean_scan_dir "$he_pp" "$he_pf"
    if [ -s "$he_pf" ]; then
      while read -r he_mf; do
        [ -f "$he_mf" ] || continue
        mkdir -p "$HE_CLEAN_BACKUP" 2>/dev/null
        cp -f "$he_mf" "$HE_CLEAN_BACKUP/$(basename "$he_mf").$(date +%s)" 2>/dev/null
        rm -f "$he_mf" 2>/dev/null && echo "     · 已删标记 $(basename "$he_mf")（$he_pp）"
      done <"$he_pf"
    fi
    rm -f "$he_pf" 2>/dev/null
  done

  he_mark clean ok "$he_dp_name：$([ "$he_dp_mode" = "hard" ] && echo 重度清理（已卸载，重装即可） || echo 深度清理（数据全清，需重新登录）)"
  return 0
}

# ---------------------------------------------------------------
# ★ 彻底清理（2026-10-17 新增）：解决"连续下发"的完整清扫（不需要恢复出厂）
#   一条命令做完：全量清理(all 的全部动作) → 深扫游戏内部/资源树/persist(≤6层)
#   → 重置设备标识 → 清理看护常开（游戏在跑才锁 persist、退出即还原、开机自动拉起）
#   → 20 秒后自动重启。旧的 all/deep/hard/… 一个不动，这是**新增**的一条。
#   比社区「解设备标记」的永久锁 000 更稳：死锁会连带蓝牙配对/触摸校准读不了；
#   看护是"只在游戏运行中锁、退出立刻还原"，效果等价且不伤系统。
# ---------------------------------------------------------------
he_clean_all_pkgs() {
  { while IFS='|' read -r he_ap_pat he_ap_label; do
      [ -n "$he_ap_pat" ] && he_clean_game_pkgs "$he_ap_pat"
    done <<EOF
$(he_clean_targets_ext thorough)
EOF
    he_clean_custom_pkgs
  } 2>/dev/null | sort -u
}

he_clean_thorough_sweep() {
  he_th_tmp="${HIDE_TMP:-/data/local/tmp}"
  mkdir -p "$he_th_tmp" 2>/dev/null
  he_th_list="$he_th_tmp/thorough_scan.$$"
  : >"$he_th_list"
  he_th_users=$(he_clean_users)
  he_th_ext="${HE_CLEAN_EXT_ROOT:-}"
  for he_tp in $(he_clean_all_pkgs); do
    for he_tu in $he_th_users; do
      for he_tb in "$HE_CLEAN_ROOT/$he_tu/$he_tp" "$HE_CLEAN_ROOT_DE/$he_tu/$he_tp"; do
        [ -d "$he_tb" ] && find "$he_tb" -maxdepth 6 -type f -name 'mrpcs*' >>"$he_th_list" 2>/dev/null
      done
      if [ -n "$he_th_ext" ]; then
        [ -d "$he_th_ext/Android/data/$he_tp" ] && find "$he_th_ext/Android/data/$he_tp" -maxdepth 6 -type f -name 'mrpcs*' >>"$he_th_list" 2>/dev/null
      else
        for he_tb in "/sdcard/Android/data/$he_tp" "/storage/emulated/$he_tu/Android/data/$he_tp" "/data/media/$he_tu/Android/data/$he_tp"; do
          [ -d "$he_tb" ] && find "$he_tb" -maxdepth 6 -type f -name 'mrpcs*' >>"$he_th_list" 2>/dev/null
        done
      fi
    done
  done
  for he_pp in $HE_PERSIST_DIRS; do
    [ -d "$he_pp" ] && find "$he_pp" -maxdepth 3 -type f -name 'mrpcs*' >>"$he_th_list" 2>/dev/null
  done
  sort -u "$he_th_list" 2>/dev/null >"$he_th_list.u" && mv -f "$he_th_list.u" "$he_th_list" 2>/dev/null
  he_th_n=0
  while read -r he_mf; do
    [ -n "$he_mf" ] || continue
    [ -f "$he_mf" ] || continue
    mkdir -p "$HE_CLEAN_BACKUP" 2>/dev/null
    cp -f "$he_mf" "$HE_CLEAN_BACKUP/$(basename "$he_mf").$(date +%s)" 2>/dev/null
    rm -f "$he_mf" 2>/dev/null && he_th_n=$((he_th_n + 1))
  done <"$he_th_list"
  rm -f "$he_th_list" "$he_th_list.u" 2>/dev/null
  echo "   · 深扫补刀（游戏内部/资源树/persist，≤6 层）：再删残留标记 $he_th_n 个（删前已备份）"
}

# ============================================================
# E2. 终保数据清理（2026-10-18）
#     比「保数据清理 mf」更深，比「彻底清理」更保数据：
#       · 先整树备份 APK + UE4Game（可 restore），再深扫内部/资源树/persist
#       · 只删 ano_tmp 下发缓存与 mrpcs* 标记（删前逐个备份，可 final revert）
#       · 账号/登录态（shared_prefs）、databases、游戏资源一律不动
#       · 重置 Android ID/SSAID/广告 ID、清行为日志、开清理看护、按开关自动重启
#     这是新增模式，原有 clean all / mf / thorough / deep / hard 全部保留。
# ============================================================
HE_CLEAN_FINAL_BACKUP=${HE_CLEAN_FINAL_BACKUP:-$HE_CLEAN_BACKUP/final}
HE_CLEAN_FINAL_FULL_BACKUP=${HE_CLEAN_FINAL_FULL_BACKUP:-1}

he_clean_final_pkgs() {
  he_clean_all_pkgs
  return 0
}

he_clean_final_scan() { # 输出待删的“下发缓存 + mrpcs”文件；不碰 shared_prefs/databases/资源
  he_ff_tmp="${HIDE_TMP:-/data/local/tmp}/final_scan.$$"
  mkdir -p "$he_ff_tmp" 2>/dev/null
  : >"$he_ff_tmp/list"
  he_ff_users=$(he_clean_users)
  for he_ff_p in $(he_clean_final_pkgs); do
    for he_ff_u in $he_ff_users; do
      for he_ff_b in "$HE_CLEAN_ROOT/$he_ff_u/$he_ff_p" "$HE_CLEAN_ROOT_DE/$he_ff_u/$he_ff_p"; do
        [ -d "$he_ff_b" ] || continue
        for he_ff_a in "files/ano_tmp/custom_cache" "files/ano_tmp" "files/cache/ano_tmp" "files/.ano_cache" "files/ano_cache"; do
          [ -d "$he_ff_b/$he_ff_a" ] && find "$he_ff_b/$he_ff_a" -type f >>"$he_ff_tmp/list" 2>/dev/null
        done
        # 游戏内部深藏的 mrpcs（≤6 层）；只认这个家族，资源/账号文件不碰
        find "$he_ff_b" -maxdepth 6 -type f -name 'mrpcs*' >>"$he_ff_tmp/list" 2>/dev/null
      done
      # 外部资源树：ano_tmp 系列 + 埋在 UE4Game 里的 mrpcs*（≤6 层）
      if command -v he_clean_mf_ext_files >/dev/null 2>&1; then
        he_clean_mf_ext_files "$he_ff_p" "$he_ff_u" >>"$he_ff_tmp/list" 2>/dev/null
      fi
    done
  done
  for he_ff_pp in $HE_PERSIST_DIRS; do
    [ -d "$he_ff_pp" ] && find "$he_ff_pp" -maxdepth 3 -type f -name 'mrpcs*' >>"$he_ff_tmp/list" 2>/dev/null
  done
  sort -u "$he_ff_tmp/list" 2>/dev/null >"$he_ff_tmp/list.u" && mv -f "$he_ff_tmp/list.u" "$he_ff_tmp/list" 2>/dev/null
  cat "$he_ff_tmp/list" 2>/dev/null
  rm -f "$he_ff_tmp/list" "$he_ff_tmp/list.u" 2>/dev/null
  rmdir "$he_ff_tmp" 2>/dev/null
  return 0
}

he_clean_final_clean() {
  he_fc_stamp=$(date +%m%d-%H%M%S 2>/dev/null)
  he_fc_bak="$HE_CLEAN_FINAL_BACKUP/removed_$he_fc_stamp"
  mkdir -p "$he_fc_bak" 2>/dev/null
  he_fc_n=0; he_fc_del=0; he_fc_mark=0
  he_ff_list="${HIDE_TMP:-/data/local/tmp}/final_scan.$$.txt"
  he_clean_final_scan >"$he_ff_list"
  while read -r he_ff_f; do
    [ -n "$he_ff_f" ] || continue
    [ -f "$he_ff_f" ] || continue
    he_fc_n=$((he_fc_n + 1))
    he_ff_rel=${he_ff_f#/}
    he_ff_dst="$he_fc_bak/$he_ff_rel"
    mkdir -p "$(dirname "$he_ff_dst")" 2>/dev/null
    cp -f "$he_ff_f" "$he_ff_dst" 2>/dev/null
    case "${he_ff_f##*/}" in
      mrpcs*)
        he_fc_mark=$((he_fc_mark + 1))
        he_ff_lv=$(he_clean_marker_level "${he_ff_f##*/}")
        echo "    ✖ [${he_ff_lv%%|*}] ${he_ff_f##*/} —— ${he_ff_lv#*|}"
        echo "       路径：$he_ff_f"
        ;;
    esac
    rm -f "$he_ff_f" 2>/dev/null && he_fc_del=$((he_fc_del + 1))
  done <"$he_ff_list"
  rm -f "$he_ff_list" 2>/dev/null
  if [ "$he_fc_del" -gt 0 ]; then
    mkdir -p "$HE_CLEAN_FINAL_BACKUP" 2>/dev/null
    printf '%s' "$he_fc_bak" >"$HE_CLEAN_FINAL_BACKUP/LAST" 2>/dev/null
  fi
  echo "    · 终保清理：扫到 $he_fc_n 项，删掉 $he_fc_del 项（mrpcs 标记 $he_fc_mark 个）"
  echo "    · 账号/登录态/资源文件没动；删除前已备份：$he_fc_bak"
}

he_clean_final_revert() {
  he_fr_last=$(cat "$HE_CLEAN_FINAL_BACKUP/LAST" 2>/dev/null)
  if [ -z "$he_fr_last" ] || [ ! -d "$he_fr_last" ]; then
    echo "    ! 没有可还原的终保删除记录（clean final 跑过一次之后才有）"
    return 1
  fi
  he_fr_n=0
  for he_fr_f in $(find "$he_fr_last" -type f 2>/dev/null); do
    he_fr_rel=${he_fr_f#$he_fr_last/}
    he_fr_to="/$he_fr_rel"
    mkdir -p "$(dirname "$he_fr_to")" 2>/dev/null
    cp -f "$he_fr_f" "$he_fr_to" 2>/dev/null && he_fr_n=$((he_fr_n + 1))
  done
  echo "    · 已还原上次终保清理删掉的 $he_fr_n 个文件（从 $he_fr_last）"
}

he_clean_final() {
  he_fin_act="${1:-clean}"
  case "$he_fin_act" in
    revert|还原)
      he_clean_final_revert
      return $?
      ;;
    status|扫描)
      echo "=============================================="
      echo " 终保数据清理 · 状态"
      echo "=============================================="
      he_fin_n=$(he_clean_final_scan | wc -l | tr -d ' ')
      echo "- 待清下发缓存/标记：$he_fin_n 项"
      echo "- 已装目标：$(he_clean_final_pkgs | tr '\n' ' ')"
      echo "- 整树备份目录：$HE_CLEAN_MF_BACKUP/2"
      echo "- 删除物备份：$HE_CLEAN_FINAL_BACKUP"
      [ -s "$HE_CLEAN_FINAL_BACKUP/LAST" ] && echo "- 上次删除备份：$(cat "$HE_CLEAN_FINAL_BACKUP/LAST" 2>/dev/null)"
      return 0
      ;;
  esac

  echo "=============================================="
  echo " 终保数据清理（保账号 · 保资源 · 深清下发）"
  echo "   先备份 → 深扫内部/资源树/persist → 只删下发缓存与 mrpcs → 重置标识 → 看护 → 自动重启"
  echo "   保留：账号/登录态(shared_prefs)、databases、游戏资源(UE4Game/obb)"
  echo "=============================================="

  # ① 强停目标游戏，防止边删边写；也保证整树备份是静态数据
  echo
  echo "- ① 强停游戏"
  for he_fin_p in $(he_clean_final_pkgs); do
    am force-stop "$he_fin_p" >/dev/null 2>&1
    for he_fin_u in $(he_clean_users); do
      am force-stop --user "$he_fin_u" "$he_fin_p" >/dev/null 2>&1
    done
    echo "   · 已强停 $he_fin_p"
  done

  # ② 整树备份（可 restore）：先停游戏再备份，避免备份到一半的状态
  if [ "${HE_CLEAN_FINAL_FULL_BACKUP:-1}" = "1" ]; then
    echo
    echo "- ② 整树备份（APK + UE4Game；资源大的机器会久一点）"
    he_clean_mf backup
  else
    echo "- ② 跳过整树备份（HE_CLEAN_FINAL_FULL_BACKUP=0）"
  fi

  # ③ 深扫删除（只删下发缓存 + mrpcs；账号/资源不动）
  echo
  echo "- ③ 深扫下发缓存与 mrpcs 标记"
  he_clean_final_clean

  # ④ 重置设备标识（账号数据保留，标识换新才会让旧标记失效）
  echo
  echo "- ④ 重置设备标识"
  he_wipe=1 he_clean_id_reset

  # ⑤ 行为日志 + 看护
  echo
  echo "- ⑤ 清行为日志 / 开启清理看护"
  he_clean_behaviour_logs full
  mkdir -p "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}" 2>/dev/null
  echo on >"${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_watch.txt" 2>/dev/null
  command -v he_clean_watch_boot >/dev/null 2>&1 && he_clean_watch_boot
  echo "   · 看护已开启（游戏在跑锁 persist，退出即清下发目录；开机自动拉起）"

  # ⑥ 按开关自动重启（config/auto_reboot.txt：full/soft/off）
  echo
  he_auto_reboot "终保数据清理完成"
  he_mark clean ok "终保数据清理完成（保账号/资源，只清下发与标记）" 2>/dev/null
  return 0
}

he_clean_thorough() {
  echo "=============================================="
  echo " 彻底清理（解决连续下发 · 不需要恢复出厂）"
  echo "   全量清理 → 深扫游戏内部/资源树/persist → 重置标识 → 看护常开 → 自动重启"
  echo "=============================================="
  # ① 全量清理（标记/登录态/下发缓存 + persist 标记 + 行为日志 + 标识重置）——不触发它自己的重启
  HE_CLEAN_NO_AUTOREBOOT=1 he_clean all
  # ② 深扫补刀：all 的扫描是浅层(≤2 层)，这里把游戏内部数据与资源树(≤6 层)再扫一遍
  echo
  echo "- 深扫补刀"
  he_clean_thorough_sweep
  # ③ 清理看护常开（安全版 persist 防护：游戏在跑才锁、退出即还原）
  echo
  echo "- 清理看护"
  mkdir -p "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}" 2>/dev/null
  echo on >"${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_watch.txt" 2>/dev/null
  command -v he_clean_watch_boot >/dev/null 2>&1 && he_clean_watch_boot
  echo "   · 看护已开启（游戏运行中自动锁 persist；一退出立刻清下发目录；开机自动拉起）"
  echo "   · 说明：这里用「看护」而不是把 persist 永久锁 000 —— 死锁会连带蓝牙配对/触摸校准读不了"
  # ④ 自动重启（20 秒；config/auto_reboot.txt 写 off 可关）
  if [ "${HE_CLEAN_NO_AUTOREBOOT:-}" = "1" ]; then
    echo "（测试/嵌套模式：不单独触发自动重启）"
  else
    he_auto_reboot "彻底清理完成"
  fi
  return 0
}

# 主入口
he_clean() {
  he_act=${1:-all}
  case "$he_act" in
    persist) he_clean_persist "${2:-status}"; return 0 ;;
    thorough|彻底|彻底清理) he_clean_thorough; return 0 ;;
    final|终保|终保数据|终保数据清理|mf-final) he_clean_final "${2:-clean}"; return 0 ;;
  esac

  he_wipe=1
  [ "$he_act" = "status" ] && he_wipe=0
  case "$he_act" in
    deep|hard) he_wipe=1 ;;
  esac

  echo "=============================================="
  echo " 游戏环境清理（暗区/三角洲 + 设备标记）"
  [ "$he_wipe" = "1" ] && echo " 模式：清理（删前先备份到 $HE_CLEAN_BACKUP）" || echo " 模式：只扫描不删（status）"
  echo "=============================================="

  he_users=$(he_clean_users)
  echo "- 用户空间：$he_users"
  he_any=0

  while IFS='|' read -r he_pat he_label; do
    [ -n "$he_pat" ] || continue
    # 按需过滤：anqu 只做暗区、delta 只做三角洲、mark 只扫标记
    case "$he_act" in
      anqu)  case "$he_label" in *暗区*) ;; *) continue ;; esac ;;
      delta) case "$he_label" in *三角洲*) ;; *) continue ;; esac ;;
      kong|失控) case "$he_label" in *失控*) ;; *) continue ;; esac ;;
      custom|自定义) case "$he_label" in *自定义*) ;; *) continue ;; esac ;;
      mark|id|all|status|deep|hard) ;;
      *) ;;
    esac
    he_pkgs=$(he_clean_game_pkgs "$he_pat")
    [ -n "$he_pkgs" ] || continue
    for he_p in $he_pkgs; do
      # ★ 先停进程再动文件：游戏/反作弊还在跑的时候删标记，它转头就写回来
      #   （社区脚本都是先停再清；这一步漏了，用户看到的就是"清了个寂寞"）
      if [ "$he_wipe" = "1" ]; then
        am force-stop "$he_p" >/dev/null 2>&1
        for he_u in $he_users; do
          am force-stop --user "$he_u" "$he_p" >/dev/null 2>&1
        done
        echo "  · 已强停 $he_p"
      fi
      for he_u in $he_users; do
        he_any=1
        echo
        echo "- 【$he_label】$he_p"
        case "$he_act" in
          deep|hard)
            he_clean_game_deep "$he_p" "$he_label" "$he_act" ;;
          *)
            echo "  （用户 $he_u）"
            he_clean_pkg "$he_p" "$he_u" "$he_label" "$he_wipe" ;;
        esac
      done
    done
  done <<EOF
$(he_clean_targets_ext "$he_act")
EOF

  if [ "$he_any" = "0" ]; then
    echo
    echo "- 没检测到这些游戏（包名：tmgp.dfm / com.tencent.mf.uam / com.tencent.rmcn …）"
    echo "  装了再跑即可；不影响下面这些通用步骤。"
    if [ "$he_act" = "custom" ] || [ "$he_act" = "all" ]; then
      echo "  · 要给别的游戏也用：编辑 $(he_clean_custom_file)（一行一个包名），或 install.sh clean pkgs 看说明"
    fi
  fi

  # mark / all：persist 里也扫一遍（有些标记只在 persist）
  if [ "$he_act" = "mark" ] || [ "$he_act" = "all" ] || [ "$he_act" = "status" ]; then
    echo
    echo "- persist 分区标记扫描"
    he_pl="${HIDE_TMP:-/data/local/tmp}/clean_persist_scan.$$"
    : >"$he_pl"
    for he_pp in $HE_PERSIST_DIRS; do he_clean_scan_dir "$he_pp" "$he_pl"; done
    if [ -s "$he_pl" ]; then
      while read -r he_mf; do
        [ -f "$he_mf" ] || continue
        he_lv=$(he_clean_marker_level "$(basename "$he_mf")" | cut -d'|' -f1)
        he_desc=$(he_clean_marker_level "$(basename "$he_mf")" | cut -d'|' -f2)
        echo "   ✖ [$he_lv] $(basename "$he_mf") —— $he_desc"
        echo "      路径：$he_mf"
        if [ "$he_wipe" = "1" ]; then
          mkdir -p "$HE_CLEAN_BACKUP" 2>/dev/null
          cp -f "$he_mf" "$HE_CLEAN_BACKUP/$(basename "$he_mf").$(date +%s)" 2>/dev/null
          rm -f "$he_mf" 2>/dev/null && echo "      → 已删除" || echo "      → 删除失败（可试 install.sh clean persist on 锁上这个目录）"
        fi
      done <"$he_pl"
    else
      echo "   （persist 里没发现 mrpcs* 标记文件）"
    fi
    rm -f "$he_pl" 2>/dev/null
  fi

  # id / all
  if [ "$he_act" = "id" ] || [ "$he_act" = "all" ] || [ "$he_act" = "deep" ] || [ "$he_act" = "hard" ]; then
    echo
    echo "- 设备标识重置"
    he_wipe=1 he_clean_id_reset
  fi

  # 行为日志（★ 社区模块那套：反作弊能读到的"行为痕迹"）
  if [ "$he_act" = "all" ] || [ "$he_act" = "deep" ] || [ "$he_act" = "hard" ]; then
    echo
    echo "- 行为日志"
    he_clean_behaviour_logs full
    echo "   · dropbox / usagestats / appops.xml / ifw / ndebugsocket / anr / tombstones / logd / update_engine 已清"
  fi

  echo
  echo "=============================================="
  echo " 完成。清理前删掉的标记文件都备份在："
  echo "   $HE_CLEAN_BACKUP"
  echo " 看护（游戏在跑时锁 persist / 一退出就清下发目录）："
  echo "   install.sh clean watch status   看状态"
  echo "   install.sh clean watch off      关掉"
  echo "=============================================="

  # ★ 重启这一步：设备标识（Android ID/SSAID/广告 ID）要重启才真正生效，
  #   社区脚本清完都会问一句"完全重启 / 软重启 / 不重启"。这里按配置自动做：
  #   config/clean_restart.txt = soft(默认) | full | none
  he_rs_want=${2:-}
  if [ -z "$he_rs_want" ]; then
    he_rs_cfg=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/clean_restart.txt
    # ★ v1.0.78：默认【不再自动重启】。原来 all/deep/hard 清完会自动软重启 zygote，
    #   装上 LSPosed/Vector 这类注入 system_server 的框架后，这一刻极易让整机卡住
    #   2~3 分钟甚至起不来（客户反馈"点完清理就死机"）。标识重置本来也不需要立刻重启，
    #   客户方便时自己重启一次即可。想恢复"清完自动软重启"：config/clean_restart.txt 写 soft。
    he_rs_want=none
    case "$he_act" in
      anqu|delta) he_rs_want=none ;;
    esac
    if [ -s "$he_rs_cfg" ]; then
      he_rs_in=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$he_rs_cfg" 2>/dev/null | grep -v '^$' | head -n 1)
      case "$he_rs_in" in
        full|完全) he_rs_want=full ;;
        none|不重启|off) he_rs_want=none ;;
        soft|软|on) he_rs_want=soft ;;
      esac
    fi
  fi
  if [ "${HE_CLEAN_NO_AUTOREBOOT:-}" = "1" ]; then
    # 嵌套调用（如「彻底清理」内部先跑 all）：中途不各自排重启，由最外层统一排
    :
  elif [ -n "${2:-}" ] || [ -s "$he_rs_cfg" ]; then
    he_clean_restart "$he_rs_want"
  else
    case "$he_act" in
      mark|pkgs|status|列表) he_clean_restart none ;;
      *) he_auto_reboot "清理完成（模式=$he_act）" ;;
    esac
  fi

  he_mark clean ok "游戏环境清理完成（模式=$he_act）"
  return 0
}

# ============================================================
# F. 保数据清理（外部资源树）—— 思路来自「有始有终」
#    标记/下发物有一部分落在 /storage/emulated/<用户>/Android/data/<包>/files
#    这棵**外部资源树**（UE4 游戏的 UE4Game 就在里面，双开还有 999 空间）；
#    账号与登录态在内部 /data/data，这里一律不碰 —— 所以"清下发物但保数据"。
#    备份布局与他的脚本一致：/sdcard/back/1（APK）、/sdcard/back/2/UE4Game_<用户>（资源树整树）
#    另加：clean 删掉的每一个文件都会先备份到 back/2/removed_<时间>/…，可 revert 一键还
# ============================================================
HE_CLEAN_SD=${HE_CLEAN_SD:-/sdcard}
HE_CLEAN_MF_EXT_ROOT=${HE_CLEAN_MF_EXT_ROOT:-/storage/emulated}
HE_CLEAN_MF_BACKUP=${HE_CLEAN_MF_BACKUP:-$HE_CLEAN_SD/back}
HE_CLEAN_MF_PKGS="com.tencent.mf.uam com.proximabeta.mf.uamo com.tencent.tmgp.dfm com.proxima.dfm garena.game.df"

he_clean_mf_pkgs_installed() { # 只输出真装了的目标包
  for he_mp in $HE_CLEAN_MF_PKGS; do
    pm list packages 2>/dev/null | sed -n 's/^package://p' | grep -x "$he_mp" 2>/dev/null
  done
}

he_clean_mf_ext_files() { # he_clean_mf_ext_files <包> <用户>：输出外部树里该清的文件（下发目录 + mrpcs 标记）
  he_me_pkg="$1"; he_me_u="$2"
  he_me_dir="$HE_CLEAN_MF_EXT_ROOT/$he_me_u/Android/data/$he_me_pkg"
  [ -d "$he_me_dir" ] || return 0
  for he_me_ano in "files/ano_tmp/custom_cache" "files/ano_tmp" "files/cache/ano_tmp" "files/.ano_cache" "files/ano_cache"; do
    [ -d "$he_me_dir/$he_me_ano" ] && find "$he_me_dir/$he_me_ano" -type f 2>/dev/null
  done
  # 标记可能埋在 UE4 资源树里（深度放宽），但只认 mrpcs* 这一个家族，绝不碰资源文件
  find "$he_me_dir" -maxdepth 6 -type f -name "mrpcs*" 2>/dev/null
  return 0
}

he_clean_mf_running() { # 游戏在不在跑（在跑就跳过整树备份/还原，避免备份到一半的状态）
  command -v pidof >/dev/null 2>&1 || return 1
  for he_mr in $HE_CLEAN_MF_PKGS; do
    pidof "$he_mr" >/dev/null 2>&1 && return 0
  done
  return 1
}

he_clean_mf() { # he_clean_mf clean|backup|restore|revert|status
  he_mf_act="${1:-clean}"
  he_mf_tmp="${HIDE_TMP:-/data/local/tmp}"
  mkdir -p "$he_mf_tmp" "$HE_CLEAN_MF_BACKUP" 2>/dev/null

  case "$he_mf_act" in
    status)
      echo "  保数据清理（外部资源树，思路：有始有终）"
      he_mf_any=0
      for he_mp in $(he_clean_mf_pkgs_installed); do
        he_mf_any=1
        for he_mu in $(he_clean_users); do
          he_mn=$(he_clean_mf_ext_files "$he_mp" "$he_mu" | wc -l | tr -d ' ')
          if [ -d "$HE_CLEAN_MF_BACKUP/2/UE4Game_$he_mu" ]; then he_mb=有; else he_mb=无; fi
          echo "    · $he_mp ｜ 用户 $he_mu：待清 $he_mn 项 ｜ 整树备份：$he_mb"
        done
      done
      [ "$he_mf_any" = "1" ] || echo "    （没装目标游戏）"
      if [ -s "$HE_CLEAN_MF_BACKUP/2/LAST" ]; then
        echo "    上次删除物的备份：$(cat "$HE_CLEAN_MF_BACKUP/2/LAST" 2>/dev/null)（clean mf revert 可还原）"
      fi
      ;;

    backup)
      # 整树备份（有始有终原法）：装了游戏的用户空间各一份 UE4Game_<用户> + APK
      for he_mp in $(he_clean_mf_pkgs_installed); do
        he_apk=$(pm path "$he_mp" 2>/dev/null | sed -n 's/^package://p' | head -n 1)
        if [ -n "$he_apk" ] && [ -f "$he_apk" ]; then
          mkdir -p "$HE_CLEAN_MF_BACKUP/1" 2>/dev/null
          cp -f "$he_apk" "$HE_CLEAN_MF_BACKUP/1/$he_mp.apk" 2>/dev/null && \
            echo "    · 已备份 APK：$he_mp.apk"
        fi
        for he_mu in $(he_clean_users); do
          he_src="$HE_CLEAN_MF_EXT_ROOT/$he_mu/Android/data/$he_mp/files/UE4Game"
          [ -d "$he_src" ] || he_src="$HE_CLEAN_MF_EXT_ROOT/$he_mu/Android/data/$he_mp/files"
          [ -d "$he_src" ] || continue
          if he_clean_mf_running; then
            echo "    ! $he_mp 正在运行：整树备份先跳过（退游戏后再跑，避免备份到一半的状态）"
            continue
          fi
          he_dst="$HE_CLEAN_MF_BACKUP/2/UE4Game_$he_mu"
          rm -rf "$he_dst" 2>/dev/null
          mkdir -p "$he_dst" 2>/dev/null
          cp -a "$he_src/." "$he_dst/" 2>/dev/null
          he_sz=$(du -sh "$he_src" 2>/dev/null | cut -f1)
          echo "    · 已备份资源树：用户 $he_mu → $he_dst（$he_sz）"
        done
      done
      ;;

    restore)
      for he_mp in $(he_clean_mf_pkgs_installed); do
        if he_clean_mf_running; then
          echo "    ! $he_mp 正在运行：先退游戏再还原"
          continue
        fi
        for he_mu in $(he_clean_users); do
          he_dst="$HE_CLEAN_MF_BACKUP/2/UE4Game_$he_mu"
          [ -d "$he_dst" ] || continue
          he_base="$HE_CLEAN_MF_EXT_ROOT/$he_mu/Android/data/$he_mp/files"
          # 兼容两种备份布局：带 UE4Game/ 层的（别家脚本留的）放到 files/；纯内容的放到 files/UE4Game
          if [ -d "$he_dst/UE4Game" ]; then he_src="$he_base"; else he_src="$he_base/UE4Game"; fi
          mkdir -p "$he_src" 2>/dev/null
          cp -a "$he_dst/." "$he_src/" 2>/dev/null && echo "    · 已还原资源树：用户 $he_mu ← $he_dst"
        done
      done
      ;;

    revert)
      # 只把「上次 clean 删掉的那些」放回去（不动整树，最快恢复）
      he_last=$(cat "$HE_CLEAN_MF_BACKUP/2/LAST" 2>/dev/null)
      if [ -z "$he_last" ] || [ ! -d "$he_last" ]; then
        echo "    ! 没有可还原的删除记录（clean mf 跑过一次之后才有）"
        return 1
      fi
      he_n=0
      for he_f in $(find "$he_last" -type f 2>/dev/null); do
        he_rel=${he_f#$he_last/}
        he_to="$HE_CLEAN_MF_EXT_ROOT/$he_rel"
        mkdir -p "$(dirname "$he_to")" 2>/dev/null
        cp -f "$he_f" "$he_to" 2>/dev/null && he_n=$((he_n + 1))
      done
      echo "    · 已还原上次删掉的 $he_n 个文件（从 $he_last）"
      ;;

    *)
      # clean（默认）：只清「下发目录 + mrpcs 标记」，账号/登录态/资源文件一律不动
      he_list="$he_mf_tmp/mf_scan.$$"
      : >"$he_list"
      for he_mp in $(he_clean_mf_pkgs_installed); do
        for he_mu in $(he_clean_users); do
          he_clean_mf_ext_files "$he_mp" "$he_mu" >>"$he_list"
        done
      done
      sort -u "$he_list" 2>/dev/null >"$he_list.u" && mv -f "$he_list.u" "$he_list" 2>/dev/null
      he_stamp=$(date +%m%d-%H%M%S)
      he_bdir="$HE_CLEAN_MF_BACKUP/2/removed_$he_stamp"
      he_n=0; he_del=0; he_mark_hit=0
      while read -r he_f; do
        [ -n "$he_f" ] || continue
        [ -f "$he_f" ] || continue
        he_n=$((he_n + 1))
        # 备份（保留"用户空间/相对路径"结构 → revert 能原样还回原位）
        he_rel=${he_f#$HE_CLEAN_MF_EXT_ROOT/}
        case "$he_rel" in *"/Android/data/"*) : ;; *) he_rel="0/$he_rel" ;; esac
        he_b="$he_bdir/$(dirname "$he_rel")"
        mkdir -p "$he_b" 2>/dev/null
        cp -f "$he_f" "$he_b/" 2>/dev/null
        case "${he_f##*/}" in
          mrpcs*)
            he_lv=$(he_clean_marker_level "${he_f##*/}")
            he_mark_hit=$((he_mark_hit + 1))
            echo "    ✖ [${he_lv%%|*}] ${he_f##*/} —— ${he_lv#*|}"
            echo "       路径：$he_f"
            ;;
        esac
        rm -f "$he_f" 2>/dev/null && he_del=$((he_del + 1))
      done <"$he_list"
      rm -f "$he_list" 2>/dev/null
      if [ "$he_del" -gt 0 ]; then
        mkdir -p "$HE_CLEAN_MF_BACKUP/2" 2>/dev/null
        printf '%s' "$he_bdir" >"$HE_CLEAN_MF_BACKUP/2/LAST" 2>/dev/null
      fi
      echo "    · 保数据清理完成：扫到 $he_n 项，清掉 $he_del 项（标记 $he_mark_hit 个）；账号/登录态/资源文件没动"
      [ "$he_del" -gt 0 ] && echo "    · 删除前已备份：$he_bdir（install.sh clean mf revert 一键还原）"
      ;;
  esac
  return 0
}

# ★ 自动重启（统一入口，2026-10-13 用户要求「非常需要」）：
#   config/auto_reboot.txt = full(默认，整机重启) | soft(只重启 zygote) | off(关闭)
#   12 秒后执行，够设备端把输出回传给控制台；先 sync 落盘，防丢数据。
he_auto_reboot() {
  he_ar_cfg=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/auto_reboot.txt
  he_ar_mode=full
  if [ -s "$he_ar_cfg" ]; then
    he_ar_in=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$he_ar_cfg" 2>/dev/null | grep -v '^$' | head -n 1)
    case "$he_ar_in" in
      off|none|不重启) he_ar_mode=off ;;
      soft|软|软重启) he_ar_mode=soft ;;
      *) he_ar_mode=full ;;
    esac
  fi
  # 安全阀：还有模块没装完（pending）或【别的】后台任务在跑 → 这次不重启（重启会把安装截断）
  # ★ 2026-10-17 修「有些机型点了该重启不重启」：经 bg 通道进来的命令（HE_BG_SELF=1）
  #   就是 bg.pid 记的那个人——在 nohup / 裸& 的机型上 kill -0 会命中自己，
  #   旧逻辑会误判"另一个后台任务还在跑"而跳过重启。自己是 bg 任务时跳过 bg.pid 检查。
  he_ar_pend=${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/pending
  if [ -s "$he_ar_pend" ]; then
    echo "- 检测到还有模块没装完（pending 非空）→ 本次跳过自动重启；装完再点一次或手动重启即可"
    return 0
  fi
  if [ "${HE_BG_SELF:-}" != "1" ]; then
    he_ar_bg=${HIDE_STATE_DIR:-/data/adb/hide_env_pack/state}/bg.pid
    if [ -s "$he_ar_bg" ] && kill -0 "$(cat "$he_ar_bg" 2>/dev/null)" 2>/dev/null; then
      echo "- 另一个后台任务还在跑 → 本次跳过自动重启（等它跑完再点一次）"
      return 0
    fi
  fi
  if [ "$he_ar_mode" = "off" ]; then
    echo "- 自动重启已关闭（想开：删掉 config/auto_reboot.txt 或写 full）"
    return 0
  fi
  echo ""
  echo "═══════════════════════════"
  echo "  ${1:-操作完成} → 20 秒后自动重启（$he_ar_mode）"
  echo "  想取消：config/auto_reboot.txt 写 off"
  echo "═══════════════════════════"
  he_ar_state=${HIDE_STATE_DIR:-/data/adb/hide_env_pack/state}
  mkdir -p "$he_ar_state" 2>/dev/null
  if [ "$he_ar_mode" = "soft" ]; then
    (
      sleep 20; sync
      echo "[$(date '+%F %T' 2>/dev/null)] soft reboot begin (pid $$)"
      he_ar_z1=$(pidof zygote64 zygote 2>/dev/null | tr ' ' '\n' | sort | head -n 1)
      setprop ctl.restart zygote 2>/dev/null
      sleep 4
      he_ar_z2=$(pidof zygote64 zygote 2>/dev/null | tr ' ' '\n' | sort | head -n 1)
      if [ -z "$he_ar_z2" ] || [ "$he_ar_z1" = "$he_ar_z2" ]; then
        echo "[soft] ctl.restart 未生效（z1=$he_ar_z1 z2=$he_ar_z2）→ 强杀 zygote 让 init 拉起"
        killall zygote64 2>/dev/null; killall zygote 2>/dev/null
        sleep 2
        pidof zygote64 zygote >/dev/null 2>&1 || { stop 2>/dev/null; sleep 2; start 2>/dev/null; }
      fi
    ) >>"$he_ar_state/auto_reboot.log" 2>&1 &
  else
    (
      sleep 20; sync
      echo "[$(date '+%F %T' 2>/dev/null)] full reboot begin (pid $$)"
      setprop sys.powerctl reboot 2>/dev/null
      sleep 3
      echo "[full] setprop 未能重启 → 走 reboot 二进制"
      reboot 2>/dev/null
      sleep 3
      /system/bin/reboot 2>/dev/null
      sleep 3
      svc power reboot 2>/dev/null
      sleep 3
      busybox reboot -f 2>/dev/null
      echo "[full] 所有重启路径都没生效（这台机型受限，请手动重启）"
    ) >>"$he_ar_state/auto_reboot.log" 2>&1 &
  fi
  return 0
}

# 重启执行器：soft=软重启（重启 zygote，保留 root，几秒后执行，命令能先回传结果）
#             full=完全重启   none=不重启
# 2026-10-17：full/soft 都加了多路回退（setprop 被 SELinux 挡、reboot 二进制缺的机型也能重启）
he_clean_restart() {
  case "${1:-none}" in
    full|完全重启)
      echo "- 完全重启：3 秒后 reboot"
      ( sleep 3; sync
        setprop sys.powerctl reboot 2>/dev/null
        sleep 3; reboot 2>/dev/null
        sleep 3; svc power reboot 2>/dev/null ) >/dev/null 2>&1 &
      ;;
    soft|软重启|"")
      echo "- 软重启：6 秒后重启 zygote（保留 root；标识重置立刻生效）"
      ( sleep 6
        he_cr_z1=$(pidof zygote64 zygote 2>/dev/null | tr ' ' '\n' | sort | head -n 1)
        setprop ctl.restart zygote 2>/dev/null
        sleep 4
        he_cr_z2=$(pidof zygote64 zygote 2>/dev/null | tr ' ' '\n' | sort | head -n 1)
        if [ -z "$he_cr_z2" ] || [ "$he_cr_z1" = "$he_cr_z2" ]; then
          killall zygote64 2>/dev/null; killall zygote 2>/dev/null
          sleep 2
          pidof zygote64 zygote >/dev/null 2>&1 || { stop 2>/dev/null; sleep 2; start 2>/dev/null; }
        fi ) >/dev/null 2>&1 &
      ;;
    *)
      echo "- 未重启：设备标识要重启一次才完全生效（可随时 install.sh clean restart soft）"
      ;;
  esac
  return 0
}

# 开机重放：persist 加锁（开了才做）
he_clean_boot() {   # 开机入口（service.sh 调）：拉起看护 + 把残留的 persist 锁还原
  he_clean_watch_boot
  return 0
}
