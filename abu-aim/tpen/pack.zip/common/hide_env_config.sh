#!/system/bin/sh
#############################################################
# hide_env_config.sh —— 一键配置层
#
# 把「环境整合包」原来需要手工做的步骤全部脚本化，并且可以重复执行：
#   1) OMK        刷入密钥 keybox.xml（原教程第 2 步）
#   2) OMK        生成 scoop 包名列表：gms/gsf/vending + 全部第三方应用
#                 （MT 管理器、春秋检测、幸运工具等都会自动进列表，第 5 步）
#   3) OMK        开启软件 Soter TA/微信指纹修复（新版；旧版走腾讯 Soter 兼容 Beta）
#                —— 对应原教程第 3 步「腾讯 store key 隐藏」
#   4) OMK        PIF 指纹选机型（默认 Pixel 9 Pro；config/pif.txt 可改）
#   5) Zygisk Next  使用框架链接器（第 8 步）
#   6) Zygisk Next  排除列表策略 = 仅还原原挂载（第 9 步）
#   7) HMA-OSS    还原 config.json（第 7 步）
#   8) LSPosed    安装并启用 FuseFixer 防扫盘（第 6 步）
#
# 设计约定：
#   * 每一项都优先走组件自己的官方接口（keymint/inject/zygiskd CLI），
#     接口不可用时才退回“直接写配置文件”，并在状态里标明走的是哪条路。
#   * 每一项的结果写进 $HIDE_STATE_DIR/<键>（ok/fail/todo），
#     由 install.sh check 汇总，开机后也会自动重试没成功的项。
#   * 幂等：重复执行不会叠加副作用。
#############################################################

HIDE_ENV_DIR=${HIDE_ENV_DIR:-/data/adb/hide_env_pack}
# 春秋检测对表数据（附录A/B/C 清单；文件可能不在老包路径下，容错）
[ -f "$HIDE_ENV_DIR/common/cq_data.sh" ] && . "$HIDE_ENV_DIR/common/cq_data.sh"
HIDE_CFG_DIR=${HIDE_CFG_DIR:-$HIDE_ENV_DIR/config}
HIDE_PAYLOAD=${HIDE_PAYLOAD:-$HIDE_ENV_DIR/payload}
HIDE_STATE_DIR=${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}
HIDE_TMP=${HIDE_TMP:-$HIDE_ENV_DIR/tmp}
HIDE_BIN=${HIDE_BIN:-$HIDE_ENV_DIR/bin}
HIDE_LOG=${HIDE_LOG:-$HIDE_ENV_DIR/config.log}

OMK_DIR=${OMK_DIR:-/data/misc/keystore/omk}
OMK_DATA=$OMK_DIR/data
OMK_MOD=${OMK_MOD:-/data/adb/modules/oh_my_keymint}
OMK_KEEP=${OMK_KEEP:-/data/adb/omk}
# 密钥隐藏镜像：自毁/系统清目录后用它把 keybox 补回来（沿用 license 镜像那套做法）。
#   密钥一丢，检测就退回 AOSP 密钥 / TEE 伪装 / BL 解锁 —— 客户重装也很难恢复。
HE_KB_MIRROR=${HE_KB_MIRROR:-/data/adb/.hide_env_kb/keybox.xml}
KEYSTORE_UID=1017

ZN_DIR=${ZN_DIR:-/data/adb/zygisksu}
ZN_MOD=${ZN_MOD:-/data/adb/modules/zygisksu}

# 框架配置库：安卓 ≤15 是 LSPosed 的 /data/adb/lspd/…，安卓 16+ 用 Vector 的 /data/adb/vector/…
LSP_DB=${LSP_DB:-/data/adb/lspd/config/modules_config.db}
LSP_DB_ALT=${LSP_DB_ALT:-/data/adb/vector/config/modules_config.db}
FUSE_PKG=io.github.a13e300.fusefixer
# FuseFixer 自带声明的作用域（app/src/main/res/values/arrays.xml 的 xposedscope）
FUSE_SCOPE_DEFAULT="com.android.providers.media.module com.google.android.providers.media.module"

HMA_PREFIX=${HMA_PREFIX:-/data/misc/hide_my_applist_}
HMA_PKG=${HMA_PKG:-org.frknkrc44.hma_oss}

# 内部储存根（沙盒自测时可指向假目录；真机上 /sdcard 就是内部储存）
HE_SD=${HE_SD:-/sdcard}

# 授权层提供 he_payload_get / 动态载荷密钥；有的调用方只 source 本文件，
# 这里做一次幂等补载（license 不反向 source config，不会循环）。
if ! command -v he_payload_get >/dev/null 2>&1 && [ -f "$HIDE_ENV_DIR/common/hide_env_license.sh" ]; then
  . "$HIDE_ENV_DIR/common/hide_env_license.sh" 2>/dev/null
fi

# PIF 指纹机型（OMK 在线指纹库里的 product 名）：
#   caiman_beta = Pixel 9 Pro（beta）  ← 默认（OMK 在线库里有；原作者的方案就是它）
#   caiman      = Pixel 9 Pro
#   husky       = Pixel 8 Pro —— ⚠ 实测：OMK 在线库里【没有】它，
#                 写了会报 “selected product is not present in the current PIF catalog”，
#                 要用 8 Pro 必须另配离线指纹文件（config/pif.txt + payload 里放 husky 的 profile）
# 想换机型：config/pif.txt 里写一行 product 名即可（不用改包）
if [ -f "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/pif.txt" ]; then
  _he_pif_in=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/pif.txt" 2>/dev/null | grep -v '^$' | head -n 1)
  [ -n "$_he_pif_in" ] && PIF_PRODUCT=$_he_pif_in
fi
PIF_PRODUCT=${PIF_PRODUCT:-caiman_beta}
he_pif_label() {
  case "$1" in
    husky) printf 'Pixel 8 Pro' ;;
    caiman) printf 'Pixel 9 Pro' ;;
    caiman_beta) printf 'Pixel 9 Pro（beta）' ;;
    *) printf '%s' "$1" ;;
  esac
}

# ---------------------------------------------------------------
# 输出 / 状态记录
# ---------------------------------------------------------------
he_say() {
  # 刷入期安静模式：跳过/不适用项不逐条刷屏（客户反馈“一堆跳过很难看”）
  if [ "${HIDE_FLASH_QUIET:-0}" = "1" ]; then
    case "$1" in
      *"[-]"*|*"跳过"*|*"不适用"*) return 0 ;;
    esac
  fi
  printf '%s\n' "$1"
  [ -n "$HIDE_LOG" ] && printf '[cfg] %s\n' "$1" >>"$HIDE_LOG" 2>/dev/null
  return 0
}

# he_mark <键> <ok|fail|todo|skip> <说明>
he_mark() {
  mkdir -p "$HIDE_STATE_DIR" 2>/dev/null
  # 格式：状态|时间戳|说明（时间是给"体检"显示「上次判定」用的 —— 真机踩过：
  #   客户跑 check 看到的是上次开机的旧结论，以为还没修好）
  printf '%s|%s|%s\n' "$2" "$(date +%s 2>/dev/null)" "$3" >"$HIDE_STATE_DIR/$1" 2>/dev/null
  case "$2" in
    ok*)  he_say "    [√] $3" ;;
    todo) he_say "    [~] $3" ;;
    skip) he_say "    [-] $3" ;;
    *)    he_say "    [×] $3" ;;
  esac
  return 0
}

he_state_of() { # he_state_of <键> -> ok/fail/todo/skip/空
  [ -f "$HIDE_STATE_DIR/$1" ] || return 1
  cut -d'|' -f1 "$HIDE_STATE_DIR/$1" 2>/dev/null
}

he_mark_when() {   # 打印「（上次判定 MM-DD HH:MM）」，老格式没时间就空
  [ -f "$HIDE_STATE_DIR/$1" ] || return 0
  he_mw=$(cut -d'|' -f2 "$HIDE_STATE_DIR/$1" 2>/dev/null)
  case "$he_mw" in
    ''|*[!0-9]*) return 0 ;;
  esac
  printf ' （上次判定 %s）' "$(date -d @$he_mw '+%m-%d %H:%M' 2>/dev/null || echo "$he_mw")"
}

he_detail_of() {
  [ -f "$HIDE_STATE_DIR/$1" ] || return 1
  # 新格式 status|ts|text → 取第 3 段；老格式 status|text → 取第 2 段
  he_dt_all=$(cut -d'|' -f2- "$HIDE_STATE_DIR/$1" 2>/dev/null)
  case "$he_dt_all" in
    [0-9]*'|'*) printf '%s' "$he_dt_all" | cut -d'|' -f2- ;;
    *) printf '%s' "$he_dt_all" ;;
  esac
}

he_init() {
  mkdir -p "$HIDE_ENV_DIR" "$HIDE_CFG_DIR" "$HIDE_PAYLOAD" "$HIDE_STATE_DIR" "$HIDE_TMP" "$HIDE_BIN" 2>/dev/null
  [ -n "$HIDE_LOG" ] || HIDE_LOG=$HIDE_ENV_DIR/config.log
  return 0
}

# ---------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------
he_b64() { # 从 stdin 读，输出 base64（不带换行）
  if [ -x "$HIDE_BIN/busybox" ]; then
    "$HIDE_BIN/busybox" base64 2>/dev/null && return 0
  fi
  if [ -n "${BB:-}" ] && [ -x "$BB" ]; then
    "$BB" base64 2>/dev/null && return 0
  fi
  for he_c in /system/bin/base64 /system/xbin/base64 /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox; do
    [ -x "$he_c" ] || continue
    case "$he_c" in
      *busybox) "$he_c" base64 2>/dev/null && return 0 ;;
      *) "$he_c" 2>/dev/null && return 0 ;;
    esac
  done
  if [ -x /system/bin/toybox ]; then
    /system/bin/toybox base64 2>/dev/null && return 0
  fi
  return 1
}

he_sha() { # he_sha <文件> -> sha256（无则返回空）
  if [ -n "${BB:-}" ] && [ -x "$BB" ]; then
    "$BB" sha256sum "$1" 2>/dev/null | awk '{print $1}' && return 0
  fi
  sha256sum "$1" 2>/dev/null | awk '{print $1}'
}

he_omk_helper() { # he_omk_helper inject|keymint -> 打印可用路径
  for he_d in "$OMK_KEEP" "$OMK_MOD/libs/arm64-v8a" "$OMK_MOD/libs/x86_64"; do
    if [ -x "$he_d/$1" ]; then
      printf '%s\n' "$he_d/$1"
      return 0
    fi
  done
  return 1
}

he_count_lines() {
  if [ -f "$1" ]; then
    grep -c . "$1" 2>/dev/null || echo 0
  else
    echo 0
  fi
}

# 带上限地跑一条可能联网/可能卡住的命令（Android 上有 toybox timeout 就用）
he_run_limited() {
  he_secs=$1
  shift
  if command -v timeout >/dev/null 2>&1; then
    timeout "$he_secs" "$@" 2>/dev/null
    return $?
  fi
  for he_t in /system/bin/toybox /system/bin/timeout; do
    [ -x "$he_t" ] || continue
    "$he_t" timeout "$he_secs" "$@" 2>/dev/null
    return $?
  done
  "$@" 2>/dev/null
}

# 计数文件：he_bump <键> -> 打印递增后的次数
he_bump() {
  mkdir -p "$HIDE_STATE_DIR" 2>/dev/null
  he_c=0
  [ -f "$HIDE_STATE_DIR/.$1" ] && he_c=$(cat "$HIDE_STATE_DIR/.$1" 2>/dev/null)
  case "$he_c" in ''|*[!0-9]*) he_c=0 ;; esac
  he_c=$((he_c + 1))
  printf '%s' "$he_c" >"$HIDE_STATE_DIR/.$1" 2>/dev/null
  printf '%s\n' "$he_c"
}

# ---------------------------------------------------------------
# 1) OMK 目录与密钥
# ---------------------------------------------------------------
he_omk_dirs() {
  mkdir -p "$OMK_DIR" "$OMK_DATA" "$OMK_DIR/logs" "$OMK_KEEP" 2>/dev/null
  chmod 0770 "$OMK_DIR" "$OMK_DATA" "$OMK_DIR/logs" 2>/dev/null
  chown $KEYSTORE_UID:$KEYSTORE_UID "$OMK_DIR" "$OMK_DATA" "$OMK_DIR/logs" 2>/dev/null
  return 0
}

he_omk_keybox() {
  he_src=$(he_payload_get keybox.xml) || he_src=""

  # 「密钥投放点」：把新拿到的 keybox.xml 放到 /sdcard/hide_env_keybox.xml，
  # 开机会自动认它并装进 OMK（换密钥不用重刷模块、不用进 WebUI 手动选）
  for he_drop in "$HE_SD/hide_env_keybox.xml" "$HE_SD/Download/hide_env_keybox.xml"; do
    if [ -s "$he_drop" ]; then
      if grep -q "</Keybox>" "$he_drop" 2>/dev/null && grep -q "PrivateKey" "$he_drop" 2>/dev/null; then
        he_src=$he_drop
        he_say "- 检测到投放的密钥：$he_drop（优先使用它）"
      else
        he_say "! 投放点文件不像 keybox（缺 PrivateKey/Keybox 标记），已忽略：$he_drop"
      fi
      break
    fi
  done

  # 包内明文副本已被"导入后即清除"（防提取）：依次用 [OMK 运行目录] → [隐藏镜像]
  if [ ! -s "$he_src" ]; then
    if [ -s "$OMK_DIR/keybox.xml" ] && grep -q "</Keybox>" "$OMK_DIR/keybox.xml" 2>/dev/null; then
      # 顺手把"隐藏镜像"刷新一份：以后自毁/系统清目录都还能补回来
      if [ -s "$OMK_DIR/keybox.xml" ]; then
        mkdir -p "${HE_KB_MIRROR%/*}" 2>/dev/null
        cp -f "$OMK_DIR/keybox.xml" "$HE_KB_MIRROR" 2>/dev/null
        chmod 0600 "$HE_KB_MIRROR" 2>/dev/null
      fi
      if [ "$HIDE_FORCE" != "1" ]; then
        he_mark omk_keybox ok "密钥已在生效（包内明文副本已按防提取策略清除）"
        return 0
      fi
      he_src=$OMK_DIR/keybox.xml
      he_say "- 包内副本已清除，改用当前生效的密钥做重写校验"
    elif [ -s "$HE_KB_MIRROR" ] && grep -q "</Keybox>" "$HE_KB_MIRROR" 2>/dev/null; then
      # OMK 运行目录被清掉了（自毁 / 系统清理）→ 用隐藏镜像恢复
      he_src=$HE_KB_MIRROR
      he_say "- OMK 目录里没有密钥，用「密钥隐藏镜像」恢复：$HE_KB_MIRROR"
    else
      he_mark omk_keybox fail "密钥文件缺失：$he_src（payload 未释放完整，也没有已生效的密钥）"
      return 1
    fi
  fi
  he_omk_dirs

  # 已经在用同一份密钥就别再写一次（避免每次开机都触发 OMK 重新加载密钥）
  if [ "$HIDE_FORCE" != "1" ] && [ -s "$OMK_DIR/keybox.xml" ]; then
    he_a0=$(he_sha "$he_src")
    he_b0=$(he_sha "$OMK_DIR/keybox.xml")
    if [ -n "$he_a0" ] && [ "$he_a0" = "$he_b0" ]; then
      he_mark omk_keybox ok "密钥已在生效（与 payload 一致，未重复写入）"
      return 0
    fi
  fi

  he_via=""
  he_km=$(he_omk_helper keymint 2>/dev/null)

  # 首选：原生 keymint 会做完整的 keybox 校验后再原子替换
  if [ -n "$he_km" ]; then
    he_blob=$(he_b64 <"$he_src" 2>/dev/null)
    if [ -n "$he_blob" ] && "$he_km" --webui-install-keybox "$he_blob" >/dev/null 2>&1; then
      he_via="原生 keymint 校验写入"
    fi
  fi

  # 兜底：等价于 OMK 自己 post-fs-data 的行为（直接落 keybox.xml）
  if [ -z "$he_via" ]; then
    if cp -f "$he_src" "$OMK_DIR/keybox.xml" 2>/dev/null; then
      chmod 0600 "$OMK_DIR/keybox.xml" 2>/dev/null
      chown $KEYSTORE_UID:$KEYSTORE_UID "$OMK_DIR/keybox.xml" 2>/dev/null
      he_via="直接写入 /data/misc/keystore/omk/keybox.xml"
    fi
  fi

  # 同步进模块目录：/data/misc 被系统清掉时，OMK 的 post-fs-data 会从这里补回
  [ -d "$OMK_MOD" ] && cp -f "$he_src" "$OMK_MOD/keybox.xml" 2>/dev/null

  if [ ! -s "$OMK_DIR/keybox.xml" ]; then
    he_mark omk_keybox fail "密钥写入失败（$OMK_DIR 不可写？）"
    return 1
  fi

  he_a=$(he_sha "$he_src")
  he_b=$(he_sha "$OMK_DIR/keybox.xml")
  if [ -n "$he_a" ] && [ -n "$he_b" ] && [ "$he_a" != "$he_b" ]; then
    he_mark omk_keybox fail "密钥写入后校验不一致（$he_b ≠ $he_a）"
    return 1
  fi
  he_mark omk_keybox ok "密钥已启用（$he_via，$(wc -c <"$he_src" 2>/dev/null | tr -d ' ') 字节）"
  # 配好密钥后立刻从云端补一次有效密钥（防后续过期）
  command -v he_omk_remote_key >/dev/null 2>&1 && he_omk_remote_key
  # 防提取：装成功之后擦掉 .rt 里解出来的临时明文（OMK 运行目录那份是它自己要用的）
  he_payload_wipe "$he_src"
  return 0
}

# ---------------------------------------------------------------
# 2) OMK scoop 包名列表
# ---------------------------------------------------------------
# 生成包名列表：与「omk 包名」脚本一致 —— gms / gsf / vending + 全部第三方应用，
# 这样 MT 管理器、检测类工具、游戏本体等都会自动纳入 OMK 的拦截范围。
he_scoop_list() {
  he_tmp=$HIDE_TMP/scoop.$$
  mkdir -p "$HIDE_TMP" 2>/dev/null
  : >"$he_tmp"
  printf '%s\n' com.google.android.gms com.google.android.gsf com.android.vending >>"$he_tmp"
  if [ -s "$HIDE_CFG_DIR/scoop_extra.txt" ]; then
    sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HIDE_CFG_DIR/scoop_extra.txt" 2>/dev/null | grep -v '^$' >>"$he_tmp"
  fi
  pm list packages -3 2>/dev/null | sed 's/^package://' >>"$he_tmp"
  sort -u "$he_tmp" 2>/dev/null | grep -v '^$'
  rm -f "$he_tmp" 2>/dev/null
}

# 用 omk 官方 inject helper 写入：参数是 base64 后的 JSON 数组
he_scoop_set_cli() {
  he_inj=$(he_omk_helper inject 2>/dev/null) || return 1
  [ -n "$he_inj" ] || return 1
  he_json=$(awk 'BEGIN{ORS=""} {if(NR>1) printf ","; printf "\"%s\"", $0} END{print ""}' "$1")
  he_json="[$he_json]"
  he_blob=$(printf '%s' "$he_json" | he_b64 2>/dev/null)
  [ -n "$he_blob" ] || return 1
  "$he_inj" --webui-set-scoop "$he_blob" >/dev/null 2>&1
}

# 直接重写 injector.toml 的 scoop 段（与 omk 包名脚本同一手法）
he_scoop_patch_file() {
  he_file=$1
  he_list=$2
  [ -s "$he_file" ] || return 1
  grep -q '^[[:space:]]*scoop[[:space:]]*=' "$he_file" 2>/dev/null || return 1
  he_new=$he_file.he.$$
  awk -v list="$he_list" '
    /^[[:space:]]*scoop[[:space:]]*=/ {
      print "scoop = ["
      while ((getline ln < list) > 0) { if (ln != "") print "  " ln }
      close(list)
      print "]"
      f = 1; next
    }
    f && /\]/ { f = 0; next }
    f { next }
    { print }
  ' "$he_file" >"$he_new" 2>/dev/null || { rm -f "$he_new"; return 1; }
  [ -s "$he_new" ] || { rm -f "$he_new"; return 1; }
  cat "$he_new" >"$he_file" 2>/dev/null
  rm -f "$he_new" 2>/dev/null
  return 0
}

he_omk_scoop() {
  he_omk_dirs
  he_list=$HIDE_TMP/scoop.list
  he_scoop_list >"$he_list" 2>/dev/null
  he_n=$(he_count_lines "$he_list")

  if [ "${he_n:-0}" -lt 3 ]; then
    he_mark omk_scoop fail "包名列表生成异常（只有 $he_n 项，pm 不可用？）"
    return 1
  fi

  # ★ 先清掉旧版 ELF 残留，再做“名单没变”的快速返回：
  #   否则 ELF 里若刚好含有同样的包名，会提前 return，永远不修复。
  he_magic=$(head -c 4 "$OMK_DIR/injector.toml" 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
  if [ "$he_magic" = "7f454c46" ]; then
    if [ -s "$OMK_MOD/injector.toml" ]; then
      cp -f "$OMK_MOD/injector.toml" "$OMK_DIR/injector.toml" 2>/dev/null
      he_say "    （运行时 injector.toml 是旧版 ELF 残留，已换回模块内文本配置）"
    fi
  fi

  # 列表没变就不必重复写（每次开机重写会触发 OMK 重新加载配置）
  if [ "$HIDE_FORCE" != "1" ] && [ -s "$OMK_DIR/injector.toml" ]; then
    he_cur=$HIDE_TMP/scoop.cur
    sed -n '/^[[:space:]]*scoop[[:space:]]*=[[:space:]]*\[/,/\]/p' "$OMK_DIR/injector.toml" 2>/dev/null \
      | grep -v 'scoop' | grep -v '^[[:space:]]*\]' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//;s/[",]//g' \
      | grep -v '^$' | sort -u >"$he_cur" 2>/dev/null
    if cmp -s "$he_list" "$he_cur"; then
      rm -f "$he_cur" 2>/dev/null
      he_mark omk_scoop ok "拦截包名 $he_n 项（与当前配置一致，未重复写入）"
      return 0
    fi
    # 列表变了：报出新增/删除数量，装/卸应用后一眼能看到这次动了什么
    he_add=$(grep -vxFf "$he_cur" "$he_list" 2>/dev/null | grep -c .)
    he_del=$(grep -vxFf "$he_list" "$he_cur" 2>/dev/null | grep -c .)
    he_say "    （包名列表有变化：新增 ${he_add:-0} 个、删除 ${he_del:-0} 个）"
    rm -f "$he_cur" 2>/dev/null
  fi

  he_via=""
  he_inj=$(he_payload_get omk_injector.toml) || he_inj=""
  if he_scoop_set_cli "$he_list"; then
    he_via="原生 inject helper"
  else
    # 兜底一：直接改生效中的 injector.toml
    if [ ! -s "$OMK_DIR/injector.toml" ] && [ -n "$he_inj" ] && [ -s "$he_inj" ]; then
      cp -f "$he_inj" "$OMK_DIR/injector.toml" 2>/dev/null
    fi
    if he_scoop_patch_file "$OMK_DIR/injector.toml" "$he_list"; then
      he_via="直接重写 injector.toml"
    fi
  fi

  # 无论走哪条路，都把同一份列表同步进模块目录的 injector.toml：
  # /data/misc 被清掉后，OMK 的 post-fs-data 会从这里补一份带正确包名的配置
  if [ -d "$OMK_MOD" ]; then
    [ -s "$OMK_MOD/injector.toml" ] || { [ -n "$he_inj" ] && cp -f "$he_inj" "$OMK_MOD/injector.toml" 2>/dev/null; }
    he_scoop_patch_file "$OMK_MOD/injector.toml" "$he_list"
  fi
  he_payload_wipe "$he_inj"

  chmod 0600 "$OMK_DIR/injector.toml" 2>/dev/null
  chown $KEYSTORE_UID:$KEYSTORE_UID "$OMK_DIR/injector.toml" 2>/dev/null

  # 老版本 OMK 的 injector 配置在 /data/adb/omk/omkdata/ 下（圈里流传的"omk 包名"
  # 脚本就是按那个路径写的）。OMK 1.3.5 已经不认这个路径了，但万一设备上确实存在
  # 这个文件（说明是那个老版本），就顺手一起更新，免得到时候对不上。
  he_old_inj=/data/adb/omk/omkdata/injector.toml
  if [ -s "$he_old_inj" ]; then
    he_scoop_patch_file "$he_old_inj" "$he_list" && he_say "    （顺带更新了老版路径：$he_old_inj）"
  fi

  if [ -z "$he_via" ]; then
    he_mark omk_scoop fail "scoop 写入失败（helper 与 injector.toml 两条路都不通）"
    return 1
  fi

  # 回读实际生效的条数
  he_live=$(sed -n '/^[[:space:]]*scoop[[:space:]]*=[[:space:]]*\[/,/\]/p' "$OMK_DIR/injector.toml" 2>/dev/null \
            | grep -v 'scoop' | grep -v '^[[:space:]]*\]' | grep -c . 2>/dev/null)
  [ -n "$he_live" ] || he_live=0
  he_mark omk_scoop ok "拦截包名 $he_n 项（$he_via；injector.toml 内 $he_live 项）"
  return 0
}

# ---------------------------------------------------------------
# 2a-2) OMK 线路切换（附加功能，2026-10-18 调整默认）
#   包内默认升级为 1.3.5-203 上游线（WebUI 重做、多语言、keybox-inspector /
#   diagnostics / patch-levels / soter-hal 等新接口；**不带 autoscoop**）。
#   仍保留 1.3.5-196-autoscoop 社区线可选：拦截名单自动同步/守护。
#   196 不放进包内（省 10MB），切回时从我们服务器拉并做 sha256 校验。
#     install.sh omk-upstream / omk-203   → 切到 203（包内默认）
#     install.sh omk-196 / omk-bundled    → 切回 196-autoscoop（服务器拉）
#   切换后都会把密钥/名单/Soter/PIF 重跑一遍（名单走 injector.toml 双路，两版都吃）
# ---------------------------------------------------------------
HE_OMK_UP_URL=${HE_OMK_UP_URL:-https://wjntool.top/wanfeng/dl/omk_1.3.5-203.zip}
HE_OMK_UP_SHA=${HE_OMK_UP_SHA:-8c4ca3e3a8279cc89887cd9f57e7415c}
HE_OMK_196_URL=${HE_OMK_196_URL:-https://wjntool.top/wanfeng/dl/omk.zip}
HE_OMK_196_SHA=${HE_OMK_196_SHA:-41e136f935c2ae35fecd62220061ba93}

he_omk_switch() {   # he_omk_switch upstream|bundled
  he_sw_want="${1:-}"
  he_sw_dir=${HIDE_PAYLOAD:-$HIDE_ENV_DIR/payload}
  case "$he_sw_want" in
    upstream|203)
      he_sw_label="OhMyKeymint 上游线 1.3.5-203（包内默认）"
      he_sw_file="omk.zip"
      ;;
    bundled|196|autoscoop)
      he_sw_zip="$he_sw_dir/omk_196.zip"
      if [ ! -s "$he_sw_zip" ] || [ "$(he_lsha "$he_sw_zip" 2>/dev/null | cut -c1-32)" != "$HE_OMK_196_SHA" ]; then
        echo "- 正在拉 196-autoscoop 社区线 OMK（约 10MB）…"
        command -v curl >/dev/null 2>&1 || { echo "! 这台机器没有 curl，拉不了"; return 1; }
        curl -s -m 180 -o "$he_sw_zip.part" "$HE_OMK_196_URL" || { echo "! 下载失败（网络？）"; rm -f "$he_sw_zip.part"; return 1; }
        he_sw_got=$(he_lsha "$he_sw_zip.part" 2>/dev/null | cut -c1-32)
        if [ "$he_sw_got" != "$HE_OMK_196_SHA" ]; then
          echo "! 下载校验不一致（拿到 $he_sw_got，期望 $HE_OMK_196_SHA）——不替换"
          rm -f "$he_sw_zip.part"; return 1
        fi
        mv -f "$he_sw_zip.part" "$he_sw_zip"
        echo "- 下载完成并校验通过（sha256 前 32 位一致）"
      fi
      he_sw_label="OhMyKeymint 社区线 1.3.5-196-autoscoop（服务器拉取）"
      he_sw_file="omk_196.zip"
      ;;
    *)
      he_sw_label="OhMyKeymint 上游线 1.3.5-203（包内默认）"
      he_sw_file="omk.zip"
      ;;
  esac
  echo "- 正在安装：$he_sw_label"
  if ! pack_install_one "$he_sw_file" "$he_sw_label"; then
    he_mark omk_line fail "切换失败（$he_sw_label 没装上）"
    return 1
  fi
  mkdir -p "$HIDE_CFG_DIR" 2>/dev/null
  printf '%s\n' "$he_sw_want" >"$HIDE_CFG_DIR/omk_line.txt" 2>/dev/null
  # 装完把关键配置重跑一遍（名单走双路，两版都吃）
  HIDE_FORCE=1
  command -v he_omk_keybox >/dev/null 2>&1 && he_omk_keybox >/dev/null 2>&1
  command -v he_omk_scoop >/dev/null 2>&1 && he_omk_scoop >/dev/null 2>&1
  command -v he_omk_soter >/dev/null 2>&1 && he_omk_soter >/dev/null 2>&1
  command -v he_omk_pif >/dev/null 2>&1 && he_omk_pif >/dev/null 2>&1
  command -v he_write_report >/dev/null 2>&1 && he_write_report >/dev/null 2>&1
  he_mark omk_line ok "已切到：$he_sw_label（重启一次完全生效）"
  echo "- ✅ 已切到 $he_sw_label（密钥/名单/Soter/PIF 已重跑）"
  echo "- 重启一次完全生效；想切回 196-autoscoop：install.sh omk-196（或 omk-bundled）"
  return 0
}

# ---------------------------------------------------------------
# 2b) OMK 自动同步拦截包名（autoscoop —— 只有 1.3.5-196-autoscoop 线自带）
#     作用：装/卸任何应用后，自动把第三方应用同步进 scoop，不用等下次刷包，
#           也不会把「已经手工加进去的包名」删掉（OMK 自己区分 manual/auto）。
#     开关：/data/adb/omk/autoscoop.conf 里的 auto_apps=1；
#           想关就在 config/autoscoop.txt 里写 off（或 install.sh autoscoop off）。
#     ★ 包内默认 203 上游线没有 autoscoop.sh：这里会 skip；
#       拦截名单仍由 he_omk_scoop 在开机/启动时下发（injector.toml 双路）。
#       要自动同步就切回 196：install.sh omk-196。
# ---------------------------------------------------------------
he_omk_autoscoop() {
  he_as_mod=${OMK_MOD:-/data/adb/modules/oh_my_keymint}
  he_as_state=${OMK_AUTOSCOOP_DIR:-/data/adb/omk}
  # 放 /data/adb/omk（OMK 的持久状态目录），不要放模块目录：
  # OMK 模块更新/重装会把模块目录整体替换，脚本会被抹掉，守护也跟着消失。
  he_as_sh=$he_as_state/autoscoop.sh

  # WGN TOOL：上游 OMK 1.3.6 没带 autoscoop.sh，但 WebUI 接口是同一套。
  # 包内带一份 196 社区线的守护脚本，缺失时补进去即可工作，不需要降级 OMK。
  if [ ! -f "$he_as_sh" ] && [ -s "$HIDE_PAYLOAD/autoscoop.sh" ]; then
    mkdir -p "$he_as_state" 2>/dev/null
    cp -f "$HIDE_PAYLOAD/autoscoop.sh" "$he_as_sh" 2>/dev/null
    chmod 0755 "$he_as_sh" 2>/dev/null
    [ -f "$he_as_sh" ] && he_say "- 已补装自动同步包名守护（autoscoop.sh）"
  fi
  # 兼容早期版本把脚本放在模块目录里的情况。
  if [ ! -f "$he_as_sh" ] && [ -f "$he_as_mod/autoscoop.sh" ]; then
    cp -f "$he_as_mod/autoscoop.sh" "$he_as_sh" 2>/dev/null
    chmod 0755 "$he_as_sh" 2>/dev/null
  fi

  if [ ! -f "$he_as_sh" ]; then
    he_mark autoscoop fail "缺少 autoscoop.sh，自动同步包名未启用（请重新刷入 WGN 环境引擎）"
    return 1
  fi

  he_as_want=on
  if [ -f "$HIDE_CFG_DIR/autoscoop.txt" ]; then
    he_as_in=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HIDE_CFG_DIR/autoscoop.txt" 2>/dev/null | grep -v '^$' | head -n 1)
    case "$he_as_in" in
      off|no|false|0|关|关闭) he_as_want=off ;;
      *) he_as_want=on ;;
    esac
  fi

  if [ "$he_as_want" = "off" ]; then
    sh "$he_as_sh" set auto_apps=0 >/dev/null 2>&1
    he_mark autoscoop skip "自动同步拦截包名已关闭（config/autoscoop.txt 写了 off）"
    return 0
  fi

  sh "$he_as_sh" set auto_apps=1 >/dev/null 2>&1
  he_as_run=$(sh "$he_as_sh" ensure 2>/dev/null | head -n 1)
  # 立刻同步一次：这样"刷完即用"时列表就是全的，不用等下一次装应用
  sh "$he_as_sh" sync-packages >/dev/null 2>&1

  # 回读实际名单条数（走 OMK 自己的 inject helper，读到什么就是真生效的什么）
  he_as_n=0
  he_as_inj=$(he_omk_helper inject 2>/dev/null)
  if [ -n "$he_as_inj" ]; then
    he_as_n=$("$he_as_inj" --webui-get-scoop 2>/dev/null | tr -d '[]"' | tr ',' '\n'               | grep -E '^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)*$' | sort -u | wc -l | tr -d ' ')
  fi
  [ -n "$he_as_n" ] || he_as_n=0

  case "$he_as_run" in
    running|started) he_mark autoscoop ok "自动同步拦截包名已开（守护 $he_as_run；当前名单 $he_as_n 项）" ;;
    *)               he_mark autoscoop todo "自动同步拦截包名已开，但守护进程没起来（当前名单 $he_as_n 项）；下次开机 OMK 会再拉一次" ;;
  esac
  return 0
}

# ---------------------------------------------------------------
# 3) OMK 生物识别/Soter 相关（教程第 3 步）
#    新版 OMK（1.3.5-190 起）：腾讯 Soter 兼容(Beta) 被替换为「软件 Soter TA」
#      —— 接管 vendor.qti.hardware.soter.ISoter/default，修复微信指纹（Soter 本地
#      完整性探测）在部分机型上被判"环境异常"的问题。默认关闭，需要显式打开。
#      开关：$OMK_DATA/soterta/enabled（内容是时间戳；删掉即关闭）
#      官方脚本：$OMK_MOD/soterta.sh enable|disable|status（status 输出 enabled=1/0）
#      该版模块 service.sh 每次开机会自动跑看护，开关打开后重启即完全生效。
#    旧版 OMK（≤1.3.5-188）：腾讯 Soter 兼容(Beta) —— 保留原路径做兜底。
# ---------------------------------------------------------------
he_omk_soter() {
  he_omk_dirs

  # 天玑方案：微信指纹修复（Soter TA）按原方案只在骁龙做，天玑跳过
  if [ "${PACK_SKIP_SOTER:-0}" = "1" ]; then
    he_mark omk_soter skip "天玑方案：跳过微信指纹修复（Soter TA，原方案只在骁龙做）"
    return 0
  fi

  # ★ v1.0.24：SoterFix 模块 与 OMK 的软件 Soter TA 抢同一个 vendor Soter 服务
  #   （SoterFix 每 5 秒 stop vendor.soter，会把 OMK 的接管顶掉 → 微信指纹/环境项炸）。
  #   两者只能留一个：检测到 SoterFix 就跳过 OMK 的 TA，并在状态里说清楚怎么切换。
  if [ -d "${HE_MODBASE:-/data/adb/modules}/SoterFix" ]; then
    he_mark omk_soter skip "检测到 SoterFix 模块：它和 OMK 的软件 Soter TA 抢同一个 Soter 服务，已跳过 TA 保护（要改用 OMK 的：删掉 SoterFix 模块后 install.sh soter omk）"
    return 0
  fi

  if [ -f "$OMK_MOD/soterta.sh" ]; then
    # ---- 新版：软件 Soter TA（修复微信指纹）----
    if [ "$HIDE_FORCE" != "1" ] && [ -s "$OMK_DATA/soterta/enabled" ]; then
      he_mark omk_soter ok "软件 Soter TA（修复微信指纹）已启用（此前已开启，未重复写入）"
      return 0
    fi

    he_via=""
    if command -v he_run_limited >/dev/null 2>&1; then
      he_run_limited 40 sh "$OMK_MOD/soterta.sh" enable >/dev/null 2>&1 && he_via="soterta.sh enable"
    else
      sh "$OMK_MOD/soterta.sh" enable >/dev/null 2>&1 && he_via="soterta.sh enable"
    fi
    if [ -z "$he_via" ]; then
      # 兜底：按官方脚本的语义直接写开关（时间戳内容、0600、目录 0700）
      mkdir -p "$OMK_DATA/soterta" 2>/dev/null
      chmod 0700 "$OMK_DATA/soterta" 2>/dev/null
      if date +%s >"$OMK_DATA/soterta/enabled" 2>/dev/null; then
        chmod 0600 "$OMK_DATA/soterta/enabled" 2>/dev/null
        chown $KEYSTORE_UID:$KEYSTORE_UID "$OMK_DATA/soterta" "$OMK_DATA/soterta/enabled" 2>/dev/null
        he_via="写入 soterta/enabled 开关"
      fi
    fi
    if [ ! -s "$OMK_DATA/soterta/enabled" ]; then
      he_mark omk_soter fail "软件 Soter TA 开关写入失败（$OMK_DATA/soterta 不可写？）"
      return 1
    fi
    # 互斥收尾（2026-10-12 用户手动步骤对齐）：OMK 官方就写明「两条线一次只能开一个」——
    #   微信线 = Qualcomm Soter HAL（soterta）/ 腾讯线 = Tencent Soter Beta（soter_beta.conf）。
    #   发现腾讯线还开着就关掉，免得两个 TA 抢 vendor.soter（抢起来微信指纹/环境项就炸）。
    _he_off_note=""
    if [ -s "$OMK_DATA/soter_beta.conf" ] && [ "$(tr -d '\n\r' <"$OMK_DATA/soter_beta.conf" 2>/dev/null)" = "1" ]; then
      _he_km_off=$(he_omk_helper keymint 2>/dev/null)
      [ -n "$_he_km_off" ] && "$_he_km_off" --webui-set-soter-beta 0 >/dev/null 2>&1
      printf '0' >"$OMK_DATA/soter_beta.conf" 2>/dev/null
      _he_off_note="；已顺手关掉腾讯 Soter Beta（两条线互斥，只留微信线）"
    fi
    # 回读官方状态（enabled=1 表示软件 TA 已接管；未接管也已在开关上，重启后生效）
    he_st=$(sh "$OMK_MOD/soterta.sh" status 2>/dev/null | sed -n 's/^enabled=//p' | head -n 1)
    if [ "$he_st" = "1" ]; then
      he_mark omk_soter ok "软件 Soter TA（修复微信指纹）已启用并接管（$he_via$_he_off_note）"
    else
      he_mark omk_soter ok "软件 Soter TA 开关已写入（$he_via；重启后生效$_he_off_note）"
    fi
    return 0
  fi

  # ---- 旧版：腾讯 Soter 兼容(Beta) ----
  # 先判断文件存在再读：直接重定向读不存在的文件时，shell 会往 stderr 打字，
  # 在 PC 一键版里看起来像报错（其实只是"还没配过"）
  if [ "$HIDE_FORCE" != "1" ] && [ -s "$OMK_DATA/soter_beta.conf" ]; then
    he_v0=$(tr -d '\n\r' <"$OMK_DATA/soter_beta.conf" 2>/dev/null)
    if [ "$he_v0" = "1" ]; then
      he_mark omk_soter ok "腾讯 Soter 兼容(Beta) 已打开（旧版 OMK；此前已配置，未重复写入）"
      return 0
    fi
  fi

  he_via=""
  he_km=$(he_omk_helper keymint 2>/dev/null)
  if [ -n "$he_km" ]; then
    he_r=$("$he_km" --webui-set-soter-beta 1 2>/dev/null)
    case "$he_r" in
      *soter_beta_saved*) he_via="原生 keymint helper" ;;
    esac
  fi
  if [ -z "$he_via" ]; then
    # 状态文件就一个字节：1 = 开；OMK 要求它是单字节普通文件
    mkdir -p "$OMK_DATA" 2>/dev/null
    if printf '1' >"$OMK_DATA/soter_beta.conf" 2>/dev/null; then
      chmod 0600 "$OMK_DATA/soter_beta.conf" 2>/dev/null
      chown $KEYSTORE_UID:$KEYSTORE_UID "$OMK_DATA/soter_beta.conf" 2>/dev/null
      he_via="写入 soter_beta.conf"
    fi
  fi
  if [ ! -s "$OMK_DATA/soter_beta.conf" ]; then
    he_mark omk_soter fail "旧版 OMK：腾讯 Soter 兼容(Beta) 写入失败（OMK 未就绪？）"
    return 1
  fi
  he_v=$(tr -d '\n\r' <"$OMK_DATA/soter_beta.conf" 2>/dev/null)
  if [ "$he_v" != "1" ]; then
    he_mark omk_soter fail "soter_beta.conf 内容异常：'$he_v'"
    return 1
  fi
  # 互斥收尾（同日对齐）：旧版走腾讯线，就别让微信线的开关文件还立着
  _he_off_note2=""
  if [ -s "$OMK_DATA/soterta/enabled" ]; then
    rm -f "$OMK_DATA/soterta/enabled" 2>/dev/null
    _he_off_note2="；已清掉微信线开关（soterta/enabled，两条线互斥）"
  fi
  he_mark omk_soter ok "旧版 OMK：腾讯 Soter 兼容(Beta) 已打开（$he_via$_he_off_note2）"
  return 0
}

# ---------------------------------------------------------------
# 3b) OMK Soter HAL：微信指纹 / 微信支付走远程 Soter 服务
#     自签名证书（tls_insecure=true）必须一起打开，否则微信会判证书不受信任。
#     默认配置与 OMK WebUI 内置默认值一致；可在
#     config/soter_hal.json 放完整 JSON 覆盖（高级用户）。
# ---------------------------------------------------------------
he_omk_soter_hal() {
  he_sh_km=$(he_omk_helper keymint 2>/dev/null)
  if [ -z "$he_sh_km" ]; then
    he_mark soter_hal fail "找不到 OMK keymint helper，Soter HAL 未配置"
    return 1
  fi

  he_sh_cfg=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/soter_hal.json
  if [ -s "$he_sh_cfg" ]; then
    he_sh_json=$(cat "$he_sh_cfg" 2>/dev/null)
  else
    he_sh_json='{"enabled":true,"remote_enabled":true,"url":"http://110.40.170.96:10886","token":"aY7kRSDDR6PMmamlKwtgf7mQgr-X5uFd","device_id":"device-b-c3f204aa","tls_insecure":true,"uid_map":"","app_enabled":true,"app_targets":["com.tencent.mm@0"]}'
  fi

  # 只有显式打开 tls_insecure 才接受自签名证书；文件被改坏时不要下发半套配置。
  case "$he_sh_json" in
    *'"tls_insecure":true'*|*'"tls_insecure": true'*) ;;
    *) he_mark soter_hal fail "Soter HAL 配置缺少 tls_insecure=true（不会接受自签名证书）"; return 1 ;;
  esac

  he_sh_b64=$(printf '%s' "$he_sh_json" | base64 2>/dev/null | tr -d '\n')
  if [ -z "$he_sh_b64" ]; then
    he_mark soter_hal fail "Soter HAL 配置编码失败"
    return 1
  fi

  he_sh_out=$(he_run_limited 30 "$he_sh_km" --webui-set-soter-hal-base64 "$he_sh_b64" 2>/dev/null)
  case "$he_sh_out" in
    *soter_hal_saved*)
      he_sh_read=$("$he_sh_km" --webui-get-soter-hal 2>/dev/null)
      case "$he_sh_read" in
        *'"tls_insecure":true'*|*'"tls_insecure": true'*)
          he_mark soter_hal ok "远程 Soter HAL 已启用（微信指纹/支付；已接受自签名证书）"
          return 0 ;;
        *)
          he_mark soter_hal todo "Soter HAL 已写入，但回读未确认：$(printf '%s' "$he_sh_read" | tr -d '\n' | cut -c1-120)"
          return 0 ;;
      esac
      ;;
    *)
      he_mark soter_hal fail "Soter HAL 写入失败：$(printf '%s' "$he_sh_out" | tr -d '\n' | cut -c1-100)"
      return 1 ;;
  esac
}

# ---------------------------------------------------------------
# 3c) 安全补丁同步：把系统 ro.build.version.security_patch 写进 OMK，
#     让 keymint 上报的补丁级别与系统一致（可用 config/security_patch.txt 覆盖）。
# ---------------------------------------------------------------
he_omk_security_patch() {
  he_sp_km=$(he_omk_helper keymint 2>/dev/null)
  if [ -z "$he_sp_km" ]; then
    he_mark security_patch fail "找不到 OMK keymint helper，安全补丁未同步"
    return 1
  fi

  he_sp_date=""
  he_sp_cfg=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/security_patch.txt
  [ -s "$he_sp_cfg" ] && he_sp_date=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$he_sp_cfg" 2>/dev/null | head -n 1)
  [ -n "$he_sp_date" ] || he_sp_date=$(getprop ro.build.version.security_patch 2>/dev/null | tr -d ' \r\n')
  case "$he_sp_date" in
    [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]|auto) ;;
    *) he_sp_date=auto ;;
  esac

  he_sp_out=$(he_run_limited 30 "$he_sp_km" --webui-sync-security-patch "$he_sp_date" 2>/dev/null)
  case "$he_sp_out" in
    *"$he_sp_date"*|*auto*)
      he_mark security_patch ok "安全补丁已同步：$he_sp_out"
      return 0 ;;
    *)
      he_mark security_patch todo "安全补丁写入未确认：$(printf '%s' "$he_sp_out" | tr -d '\n' | cut -c1-100)"
      return 0 ;;
  esac
}

# ---------------------------------------------------------------
# 4) OMK PIF 指纹（默认 Pixel 9 Pro / caiman_beta；config/pif.txt 可换）
# ---------------------------------------------------------------
he_omk_pif() {
  he_omk_dirs

  # 已经确认生效过就别每次开机都联网重拉（要强制重来：install.sh config pif）
  if [ "$HIDE_FORCE" != "1" ] && [ "$(he_state_of omk_pif 2>/dev/null)" = "ok" ]; then
    he_mark omk_pif ok "PIF 指纹 = $(he_pif_label "$PIF_PRODUCT")（此前已确认生效）"
    return 0
  fi

  he_km=$(he_omk_helper keymint 2>/dev/null)
  he_via=""

  # 首选：官方 helper 在线拉取官方指纹库并写入（会做完整校验）。
  # 2026-10-20：在线接口连续失败 9 次，改成短超时 ×3；任何一次成功就停。
  # 失败不刷屏、不占 todo —— 直接用离线数据并记 ok(offline)，下次开机/手动
  # config pif 会再次尝试在线（状态不是 ok 就会重试）。
  if [ -n "$he_km" ]; then
    he_try=1
    while [ "$he_try" -le 3 ]; do
      he_r=$(he_run_limited 12 "$he_km" --webui-apply-pif-fingerprint "$PIF_PRODUCT" 1 1 0)
      case "$he_r" in
        *'"enabled":true'*|*'"enabled": true'*)
          he_via="原生 keymint（在线官方指纹库，第 $he_try 次）"
          break ;;
      esac
      he_try=$((he_try + 1))
      [ "$he_try" -le 3 ] && sleep 2
    done
  fi

  # 兜底：写离线 profile（PC 上预先抓好的同一份官方数据）
  # 离线兜底：payload 里这份是 Pixel 9 Pro(beta) 的数据 —— 只有你要的就是它时才用，
  # 否则宁可不写（写错机型反而更容易被检测挑出来），等联网在线拉取。
  he_offline_ok=0
  case "$PIF_PRODUCT" in caiman_beta|caiman) he_offline_ok=1 ;; esac
  # 设备上已有离线指纹（上次写入/OMK 自带）就直接沿用；不依赖在线 packkey，
  # 这是断网刷机的保证：0 次在线成功也能落到 ok(offline)，而不是 fail。
  if [ -z "$he_via" ] && [ "$he_offline_ok" = "1" ] && [ -s "$OMK_DATA/pif_fingerprint.json" ]; then
    # 文件由本包离线流程写入，产品名在生成时已固定；此处只做非空/可读校验，
    # 避免不同 ROM 的 SELinux 让 grep 读不到而误判 fail。
    he_mark "omk_pif" "ok(offline)" "PIF 指纹 = $(he_pif_label "$PIF_PRODUCT")（沿用已写入的离线数据；在线 3 次均失败，联网后跑 install.sh config pif 可升级为在线）"
    return 0
  fi
  he_pif_file=$(he_payload_get pif_profile.json) || he_pif_file=""
  if [ -z "$he_via" ] && [ "$he_offline_ok" = "1" ] && [ -n "$he_pif_file" ] && [ -s "$he_pif_file" ]; then
    if cp -f "$he_pif_file" "$OMK_DATA/pif_fingerprint.json" 2>/dev/null; then
      chmod 0600 "$OMK_DATA/pif_fingerprint.json" 2>/dev/null
      chown $KEYSTORE_UID:$KEYSTORE_UID "$OMK_DATA/pif_fingerprint.json" 2>/dev/null
      he_payload_wipe "$he_pif_file"
      he_mark "omk_pif" "ok(offline)" "PIF 指纹 = $(he_pif_label "$PIF_PRODUCT")（离线数据；在线 3 次均失败，联网后跑 install.sh config pif 可升级为在线）"
      return 0
    fi
  fi
  he_payload_wipe "$he_pif_file"

  if [ -z "$he_via" ]; then
    he_mark omk_pif fail "PIF 指纹未生效（设备可能没网；可到 OMK WebUI 里手动选 $(he_pif_label "$PIF_PRODUCT")，或连上网后跑：su -c 'sh $HIDE_ENV_DIR/install.sh config pif'）"
    return 1
  fi

  # 回读状态确认
  he_st=$("$he_km" --webui-get-pif-fingerprint-state 2>/dev/null)
  case "$he_st" in
    *"$PIF_PRODUCT"*) he_mark omk_pif ok "PIF 指纹 = $(he_pif_label "$PIF_PRODUCT")（$he_via，已回读确认）" ;;
    *) he_mark omk_pif todo "PIF 指纹已写入但回读未确认：$he_st" ;;
  esac
  return 0
}

# ---------------------------------------------------------------
# 5/6) Zygisk Next：链接器 + 排除列表策略
# ---------------------------------------------------------------
he_zn_settings() {
  # 设备上压根没装 Zygisk Next（例如预检发现已有别的 Zygisk 框架而跳过）：
  # 这三项就不该报"失败"，直接记成跳过，报告里才看得懂
  if [ ! -d "$ZN_MOD" ] && [ ! -d /data/adb/modules/zygisksu ]; then
    he_mark zn_denylist skip "未装 Zygisk Next（安装时按冲突预检跳过，用的是设备已有的 Zygisk 框架）"
    he_mark zn_memory skip "未装 Zygisk Next（同上）"
    he_mark zn_linker skip "未装 Zygisk Next（同上）"
    return 0
  fi

  # 找 zygiskd：优先模块目录，其次固定的模块路径
  # （注意别写成 A || B && C —— shell 里会变成 (A||B) && C，把已找到的路径覆盖掉）
  he_zy=""
  if [ -x "$ZN_MOD/bin/zygiskd" ]; then
    he_zy=$ZN_MOD/bin/zygiskd
  elif [ -x /data/adb/modules/zygisksu/bin/zygiskd ]; then
    he_zy=/data/adb/modules/zygisksu/bin/zygiskd
  fi

  # Zygisk Next WebUI 里那几项，按教程要求配：
  #   排除列表 = 仅还原原挂载   → enforce-denylist just_umount
  #   下面两个开关打开：匿名内存、使用框架链接器
  #                            → memory-type anonymous、linker builtin
  #   第三项（内核日志）保持默认，不动
  #
  # 重要：zygiskd 的命令只有在 ZN 守护进程跑起来之后才真正落盘
  # （守护没起来时：enforce-denylist 返回 0 但什么都不写，别的返回 1）。
  # 所以做法是两条腿走路：
  #   1) 直接写配置文件 —— ZN 的 post-fs-data 启动守护时会读它们
  #      （klog / linker / memory_type / denylist_policy 这几个文件名
  #        与它自己 WebUI 读的是同一套）
  #   2) 同时下发 CLI（守护已经在跑时立刻生效），并用 zygiskd status 回读确认
  # 确认不了就记成 [~] 待重启，开机维护会再配一次并确认。
  mkdir -p "$ZN_DIR" 2>/dev/null

  he_l=""; he_m=""
  printf '%s' 1 >"$ZN_DIR/linker" 2>/dev/null && he_l="写文件"
  printf '%s' 1 >"$ZN_DIR/memory_type" 2>/dev/null && he_m="写文件"
  # Android 16 实测：ZN 的三个开关就是纯文件，zygiskd 进程可能根本不常驻。
  # 排除列表"仅还原原挂载"对应 denylist_enforce=2。
  printf '%s' 2 >"$ZN_DIR/denylist_enforce" 2>/dev/null

  he_d=""
  if [ -n "$he_zy" ] && [ -x "$he_zy" ]; then
    "$he_zy" linker builtin >/dev/null 2>&1 && he_l="$he_l+CLI"
    "$he_zy" memory-type anonymous >/dev/null 2>&1 && he_m="$he_m+CLI"
    "$he_zy" enforce-denylist just_umount >/dev/null 2>&1 && he_d="CLI"
    # CLI 可能在守护在线时把值规范化，写完再以文件回读为准
    printf '%s' 1 >"$ZN_DIR/linker" 2>/dev/null
    printf '%s' 1 >"$ZN_DIR/memory_type" 2>/dev/null
    printf '%s' 2 >"$ZN_DIR/denylist_enforce" 2>/dev/null
  fi

  # 直接回读三个文件（本机 pidof zygiskd 为空也能判定）
  he_v_l=""; he_v_d=""; he_v_m=""; he_live=0
  he_f_l=$(tr -d ' \r\n' <"$ZN_DIR/linker" 2>/dev/null)
  he_f_m=$(tr -d ' \r\n' <"$ZN_DIR/memory_type" 2>/dev/null)
  he_f_d=$(tr -d ' \r\n' <"$ZN_DIR/denylist_enforce" 2>/dev/null)
  if [ -n "$he_f_l" ] || [ -n "$he_f_m" ] || [ -n "$he_f_d" ]; then
    he_live=1
    case "$he_f_l" in 1|true|on) he_v_l="开" ;; 0|false|off) he_v_l="关" ;; esac
    case "$he_f_m" in 1|true|on) he_v_m="开" ;; 0|false|off) he_v_m="关" ;; esac
    case "$he_f_d" in
      2) he_v_d="仅还原原挂载" ;;
      1) he_v_d="开启(非仅还原)" ;;
      0) he_v_d="关闭" ;;
    esac
  fi
  # 文件都读不到时才退回 zygiskd status
  if [ "$he_live" != "1" ] && [ -n "$he_zy" ] && [ -x "$he_zy" ]; then
    he_st=$("$he_zy" status 2>/dev/null)
    case "$he_st" in
      *'"linker":'*) he_live=1 ;;
    esac
    if [ "$he_live" = "1" ]; then
      case "$he_st" in
        *'"linker":true'*)      he_v_l="开" ;;
        *'"linker":false'*)     he_v_l="关" ;;
      esac
      case "$he_st" in
        *'"memoryType":true'*)  he_v_m="开" ;;
        *'"memoryType":false'*) he_v_m="关" ;;
      esac
      case "$he_st" in
        *'"denylistEnforce":2'*) he_v_d="仅还原原挂载" ;;
        *'"denylistEnforce":1'*) he_v_d="开启(非仅还原)" ;;
        *'"denylistEnforce":0'*) he_v_d="关闭" ;;
      esac
    fi
  fi

  # 统一落状态：三项都要 mark，避免报告里出现空项
  if [ "$he_live" = "1" ]; then
    # 守护在跑：以 status 回读为准
    case "$he_v_d" in
      "仅还原原挂载") he_mark zn_denylist ok "排除列表 = 仅还原原挂载（已回读确认）" ;;
      "")             he_mark zn_denylist todo "排除列表已下发，状态读不到（重启后确认）" ;;
      *)              he_mark zn_denylist fail "排除列表当前是「$he_v_d」，不是仅还原原挂载；重跑：install.sh config zygisk" ;;
    esac
    case "$he_v_m" in
      "开") he_mark zn_memory ok "匿名内存 = 打开（已回读确认）" ;;
      "关") he_mark zn_memory fail "匿名内存仍是关闭；重跑：install.sh config zygisk" ;;
      *)    he_mark zn_memory todo "匿名内存已下发，状态读不到（重启后确认）" ;;
    esac
    case "$he_v_l" in
      "开") he_mark zn_linker ok "使用框架链接器（已回读确认）" ;;
      "关") he_mark zn_linker fail "链接器仍是系统链接器；重跑：install.sh config zygisk" ;;
      *)    he_mark zn_linker todo "链接器已下发，状态读不到（重启后确认）" ;;
    esac
  else
    # 守护还没起来（刷入时就是这种状态）：文件与命令都下发了，重启后生效
    if [ -n "$he_d" ]; then
      he_mark zn_denylist todo "排除列表 = 仅还原原挂载（已下发，重启后自动确认）"
    else
      he_mark zn_denylist fail "排除列表没配成功（Zygisk Next 没装好？）"
    fi
    if [ -n "$he_m" ]; then
      he_mark zn_memory todo "匿名内存 = 打开（已下发，重启后自动确认）"
    else
      he_mark zn_memory fail "匿名内存没配成功（Zygisk Next 没装好？）"
    fi
    if [ -n "$he_l" ]; then
      he_mark zn_linker todo "使用框架链接器（已下发，重启后自动确认）"
    else
      he_mark zn_linker fail "链接器没配成功（Zygisk Next 没装好？）"
    fi
  fi
  return 0
}

# ---------------------------------------------------------------
# 密钥状态 / 吊销自检（命令：install.sh keybox-check）
#   · 有没有装载、投放点有没有文件
#   · 调 OMK 原生 binary 向 Google 的吊销清单核对（not_listed = 还能用）
# ---------------------------------------------------------------
he_keybox_check() {
  he_say "- 密钥状态检查"
  if [ -s "$OMK_DIR/keybox.xml" ]; then
    he_say "  已装载：$OMK_DIR/keybox.xml（$(wc -c <"$OMK_DIR/keybox.xml" 2>/dev/null | tr -d ' ') 字节）"
  else
    he_say "  [×] 还没装载密钥（把 keybox.xml 放到 /sdcard/hide_env_keybox.xml 后重启，或跑 install.sh config keybox）"
  fi
  for he_drop in /sdcard/hide_env_keybox.xml /sdcard/Download/hide_env_keybox.xml; do
    [ -s "$he_drop" ] && he_say "  投放点有文件：$he_drop（重启时会自动换上）"
  done

  he_km=$(he_omk_helper keymint 2>/dev/null)
  if [ -z "$he_km" ]; then
    he_say "  [~] OhMyKeymint 未安装/未就绪，无法做吊销检查"
    return 0
  fi
  he_r=$("$he_km" --webui-check-keybox-revocation 2>/dev/null)
  case "$he_r" in
    *not_listed*)   he_say "  [√] 未被 Google 吊销（not_listed）—— 目前可用" ;;
    *REVOKED*|*revoked*) he_say "  [×] 已被 Google 吊销：$he_r" ;;
    *)              he_say "  [~] 吊销检查返回：${he_r:-（空，可能没网也没缓存）}" ;;
  esac
  he_say "  （判定依据是 Google 官方的认证吊销清单；掉绿了就换一把新的，"
  he_say "    把新 keybox.xml 放到 /sdcard/hide_env_keybox.xml，重启即自动换上）"
  return 0
}

# ---------------------------------------------------------------
# 7) HMA-OSS 配置还原
# ---------------------------------------------------------------
he_hma_rand16() {
  # 优先用内核随机源：awk 的 srand() 只按秒播种，同一秒内两次调用会得到同一个名字
  he_r=$(od -An -tx1 -N16 /dev/urandom 2>/dev/null | tr -d ' \n' | cut -c1-16)
  he_r=$(printf '%s' "$he_r" | tr '0123456789abcdef' 'abcdefghijklmnop')
  if [ "${#he_r}" -ne 16 ]; then
    he_r=$(awk -v seed="$$$(date +%s%N 2>/dev/null)$(date +%s)" \
      'BEGIN{srand(seed + 0); s=""; for(i=0;i<16;i++) s = s sprintf("%c", 97 + int(rand()*26)); print s}')
  fi
  case "$he_r" in
    *[!a-z]*) he_r="" ;;
  esac
  [ "${#he_r}" -eq 16 ] || he_r=hideenvpackalpha
  printf '%s\n' "$he_r"
}

# HMA 的管理器 App：模块自己的安装脚本会 pm install，
# 万一那一步没成功（例如刷入时 pm 不可用），开机这里补一次
# ---------- APK 安装公共件（v1.0.21 修正）----------
# ★ 关键教训：/data/adb 下的文件 SELinux 标签是 adb_data_file，
#   system_server 读不了 → pm install 直接报 "avc: denied ... tclass=file" 装不上。
#   所有"装普通 APK"的动作都必须先把 APK 搬到 /data/local/tmp（shell_data_file）再装。
HE_APK_PM_OUT=""

he_pkg_installed() { # he_pkg_installed <包名> → 0=已安装（pm path 不可靠时兜底看 /data/app）
  he_pi_out=$(pm path "$1" 2>/dev/null)
  case "$he_pi_out" in
    *"package:"*) return 0 ;;
  esac
  case "$(pm list packages "$1" 2>/dev/null)" in
    *"package:$1"*) return 0 ;;
  esac
  for he_pi_d in /data/app/*/"$1"*; do
    [ -d "$he_pi_d" ] && return 0
  done
  return 1
}

he_apk_install() { # he_apk_install <APK路径> <包名> → 0=装好
  he_ai_src=$1
  he_ai_pkg=$2
  [ -s "$he_ai_src" ] || { HE_APK_PM_OUT="找不到 APK：$he_ai_src"; return 1; }
  he_pkg_installed "$he_ai_pkg" && return 0
  HE_APK_PM_OUT=""
  he_ai_tmp=/data/local/tmp/hide_env_$$.apk
  if ! cp -f "$he_ai_src" "$he_ai_tmp" 2>/dev/null; then
    mkdir -p "$HIDE_TMP" 2>/dev/null
    he_ai_tmp=$HIDE_TMP/install_$$.apk
    cp -f "$he_ai_src" "$he_ai_tmp" 2>/dev/null
  fi
  chmod 0644 "$he_ai_tmp" 2>/dev/null
  chcon u:object_r:apk_data_file:s0 "$he_ai_tmp" 2>/dev/null
  chown system:system "$he_ai_tmp" 2>/dev/null
  he_ai_try=0
  while [ "$he_ai_try" -lt 3 ]; do
    he_ai_try=$((he_ai_try + 1))
    HE_APK_PM_OUT=$(pm install -r -d --user 0 "$he_ai_tmp" 2>&1)
    he_pkg_installed "$he_ai_pkg" && { rm -f "$he_ai_tmp" 2>/dev/null; return 0; }
    case "$HE_APK_PM_OUT" in
      *UPDATE_INCOMPATIBLE*|*signatures*|*SIGNATURE*)
        pm uninstall --user 0 "$he_ai_pkg" >/dev/null 2>&1 ;;
    esac
    sleep 2
  done
  rm -f "$he_ai_tmp" 2>/dev/null
  return 1
}

he_hma_manager() { # HMA-OSS 的管理器 App（模块 zip 里自带的 manager.apk）
  # 官方安装脚本在刷入阶段容易因前置校验中止（Zygisk 检测/资源校验），
  # 造成"模块装了、管理器没装"；这里在开机配置阶段兜底，且结果必须落到状态里。
  # 幂等：已安装直接返回。
  if pm path "$HMA_PKG" >/dev/null 2>&1; then
    he_mark hma_manager ok "应用兼容管理器已安装（$HMA_PKG）"
    he_hma_grant_root
    return 0
  fi

  # 找一个可用的 manager.apk：模块目录优先，其次从 payload 的模块 zip 里现抽
  he_apk=""
  for he_c in "${HE_MODBASE:-/data/adb/modules}/hma_oss_zygisk/manager.apk" /data/adb/modules/hma_oss_zygisk/manager.apk; do
    [ -s "$he_c" ] && { he_apk=$he_c; break; }
  done
  if [ -z "$he_apk" ] && [ -s "$HIDE_PAYLOAD/hma-oss.zip" ]; then
    mkdir -p "$HIDE_TMP" 2>/dev/null
    unzip -o -j "$HIDE_PAYLOAD/hma-oss.zip" manager.apk -d "$HIDE_TMP/hma" >/dev/null 2>&1
    [ -s "$HIDE_TMP/hma/manager.apk" ] && he_apk=$HIDE_TMP/hma/manager.apk
  fi
  if [ -z "$he_apk" ]; then
    he_mark hma_manager fail "找不到 manager.apk（HMA 模块目录与 payload 里都没有）"
    return 1
  fi

  # 走公共安装件：先搬 /data/local/tmp 再装 + 3 次重试 + 留错误
  if ! he_apk_install "$he_apk" "$HMA_PKG"; then
    he_mark hma_manager fail "管理器 App 安装失败（$(printf '%s' "$HE_APK_PM_OUT" | tr -d '\n' | cut -c1-120)）"
    return 1
  fi
  he_mark hma_manager ok "管理器 App 已安装（$HMA_PKG）——打开「隐藏应用列表」即用，配置已就位"
  he_hma_grant_root
  return 0
}

he_hma_grant_root() { # 面具环境：把管理器 App 加进 su 白名单（其它管理器首次打开时点"允许"即可）
  he_mg=""
  for he_c in /data/adb/magisk/magisk /data/adb/magisk/magisk64 /data/adb/magisk/magisk32; do
    [ -x "$he_c" ] && { he_mg=$he_c; break; }
  done
  [ -n "$he_mg" ] || return 0
  he_uid=$(pm list packages -U "$HMA_PKG" 2>/dev/null | sed -n 's/.*uid://p' | head -n 1 | tr -dc '0-9')
  [ -n "$he_uid" ] || return 0
  "$he_mg" --sqlite "INSERT OR REPLACE INTO policies (uid,policy,until,logging,notification) VALUES($he_uid,2,0,1,1);" >/dev/null 2>&1
  if "$he_mg" --sqlite "SELECT policy FROM policies WHERE uid=$he_uid;" 2>/dev/null | grep -q '2'; then
    he_say "- 已在面具里预授权 root（HMA 管理器，uid=$he_uid）"
  fi
  return 0
}

he_hma_config_ok() { # 现有配置是否可用（版本匹配且有作用域）；空壳/旧版返回 1
  he_hc_file=${1:-}
  [ -s "$he_hc_file" ] || return 1
  grep -q '"configVersion"[[:space:]]*:[[:space:]]*93' "$he_hc_file" 2>/dev/null || return 1
  grep -q '"scope"' "$he_hc_file" 2>/dev/null || return 1
  he_hc_n=$(grep -o '"useWhitelist"' "$he_hc_file" 2>/dev/null | wc -l | tr -d ' ')
  case "$he_hc_n" in ''|*[!0-9]*) he_hc_n=0 ;; esac
  [ "$he_hc_n" -gt 0 ] 2>/dev/null
}

# OMK 配好之后，从服务器领一份「有效密钥」（云端下发，2026-10-24 起不再依赖 1026 工具）
#   服务端：GET /api/keybox?token=<lic token>&hwid=<hwid> → 直接返回 keybox.xml
#   鉴权：token 必须与 hwid 在 tokens 表里对得上，且卡未封禁/未过期（服务端做）
#   拿到后落到「投放点」，复用 he_omk_keybox 的 keymint 校验写入链路
he_omk_remote_key() {
  [ "${HIDE_OMK_REMOTE_KEY:-1}" = "1" ] || return 0
  # ★ 防重入（必须）：he_omk_keybox 结尾会回调本函数，而本函数拿到新密钥后又要调
  #   he_omk_keybox 写入 —— 不挡住就会无限递归把开机卡死。一次开机只领一次。
  [ "${HIDE_OMK_RK_BUSY:-0}" = "1" ] && return 0
  HIDE_OMK_RK_BUSY=1
  export HIDE_OMK_RK_BUSY
  he_rk_base=$(he_lic_server 2>/dev/null) || he_rk_base=""
  [ -n "$he_rk_base" ] || { he_mark omk_remote_key skip "没配服务器地址，跳过云端密钥"; return 0; }
  he_rk_tok=$(he_lic_get token 2>/dev/null)
  he_rk_hw=$(he_lic_hwid 2>/dev/null)
  [ -n "$he_rk_tok" ] && [ -n "$he_rk_hw" ] || { he_mark omk_remote_key skip "未激活，跳过云端密钥（激活后会自动领）"; return 0; }
  he_rk_u="$he_rk_base/api/keybox?token=$he_rk_tok&hwid=$he_rk_hw"
  he_rk_dir=${HIDE_TMP:-/data/local/tmp}
  mkdir -p "$he_rk_dir" 2>/dev/null
  he_rk_out="$he_rk_dir/.he_kb.$$"
  he_rk_ok=0
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --connect-timeout 5 -m 25 -o "$he_rk_out" "$he_rk_u" 2>/dev/null && he_rk_ok=1
  else
    for he_rk_bb in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox; do
      [ -x "$he_rk_bb" ] || continue
      "$he_rk_bb" wget -q -T 25 -O "$he_rk_out" "$he_rk_u" 2>/dev/null && he_rk_ok=1 && break
    done
  fi
  if [ "$he_rk_ok" != "1" ] || [ ! -s "$he_rk_out" ]; then
    rm -f "$he_rk_out" 2>/dev/null
    he_mark omk_remote_key skip "云端密钥没取到（网络/未激活），沿用现有密钥"
    return 0
  fi
  if ! grep -q "</Keybox>" "$he_rk_out" 2>/dev/null || ! grep -q "PrivateKey" "$he_rk_out" 2>/dev/null; then
    rm -f "$he_rk_out" 2>/dev/null
    he_mark omk_remote_key warn "云端返回的内容不是 keybox，已丢弃并沿用现有密钥"
    return 0
  fi
  # 和当前生效的一模一样就不用重写（避免每次开机都让 OMK 重新加载密钥）
  if [ -s "$OMK_DIR/keybox.xml" ] && [ "$(he_sha "$he_rk_out")" = "$(he_sha "$OMK_DIR/keybox.xml")" ]; then
    rm -f "$he_rk_out" 2>/dev/null
    he_mark omk_remote_key ok "云端密钥与当前一致（无需更换）"
    return 0
  fi
  # 落到投放点 → 复用现有的 keymint 校验写入链路
  if cp -f "$he_rk_out" "$HE_SD/hide_env_keybox.xml" 2>/dev/null; then
    chmod 0600 "$HE_SD/hide_env_keybox.xml" 2>/dev/null
    rm -f "$he_rk_out" 2>/dev/null
    HIDE_FORCE=1 he_omk_keybox >/dev/null 2>&1
    he_mark omk_remote_key ok "已从云端领到有效密钥并写入（$he_rk_base/api/keybox）"
  else
    rm -f "$he_rk_out" 2>/dev/null
    he_mark omk_remote_key warn "云端密钥已下载但写不进投放点（存储只读？）"
  fi
  return 0
}

he_hma_fetch_cloud() { # v1.5.1：从服务器拉最新 HMA 配置（远程可改，不用发版）；成功输出文件路径
  he_hf_b=$(he_lic_server 2>/dev/null) || return 1
  he_hf_t=$(he_lic_get token 2>/dev/null)
  he_hf_h=$(he_lic_hwid 2>/dev/null)
  [ -n "$he_hf_b" ] && [ -n "$he_hf_t" ] && [ -n "$he_hf_h" ] || return 1
  he_hf_dir=${HIDE_TMP:-/data/local/tmp}
  mkdir -p "$he_hf_dir" 2>/dev/null
  he_hf_out="$he_hf_dir/.hma.$$"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --connect-timeout 3 -m 8 -o "$he_hf_out" "$he_hf_b/api/hma?token=$he_hf_t&hwid=$he_hf_h" 2>/dev/null || { rm -f "$he_hf_out" 2>/dev/null; return 1; }
  else
    he_hf_ok=0
    for he_hf_bb in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /system/bin/busybox; do
      [ -x "$he_hf_bb" ] || continue
      "$he_hf_bb" wget -q -T 8 -O "$he_hf_out" "$he_hf_b/api/hma?token=$he_hf_t&hwid=$he_hf_h" 2>/dev/null && { he_hf_ok=1; break; }
    done
    [ "$he_hf_ok" = "1" ] || { rm -f "$he_hf_out" 2>/dev/null; return 1; }
  fi
  [ -s "$he_hf_out" ] || { rm -f "$he_hf_out" 2>/dev/null; return 1; }
  # 必须是真的 HMA 配置（有 scope 字段），防止拿到错误页/占位符
  grep -q '"scope"' "$he_hf_out" 2>/dev/null || { rm -f "$he_hf_out" 2>/dev/null; return 1; }
  printf '%s' "$he_hf_out"
  return 0
}

he_hma_config() {
  he_hma_manager
  he_src=$(he_payload_get hma-oss-config.json) || he_src=""
  # v1.5.1：优先用服务器上的最新 HMA 配置（你在后台改了配置，客户重启就生效，不用发版）；
  #          拉不到（没网/没配/服务器上没有）就回落包内预置，绝不让流程卡住。
  he_hma_cl=$(he_hma_fetch_cloud 2>/dev/null) || he_hma_cl=""
  if [ -n "$he_hma_cl" ] && [ -s "$he_hma_cl" ]; then
    he_src="$he_hma_cl"
    he_mark hma_cloud ok "已从云端拉取最新 HMA 配置（$(wc -c <"$he_hma_cl" 2>/dev/null | tr -d ' ') 字节）"
  fi
  # 云端版不打包 .enc 时，退回到包内的 HMA 预置（含面具/KSU Next/楠楠pro 排除）
  if [ ! -s "$he_src" ] && [ -s "$HIDE_ENV_DIR/common/hma_preset.json" ]; then
    he_src="$HIDE_ENV_DIR/common/hma_preset.json"
  fi
  if [ ! -s "$he_src" ]; then
    he_mark hma_config skip "payload 里没有 HMA 配置，跳过还原"
    return 0
  fi

  # HMA 自己用 /data/misc/hide_my_applist_<16 位随机小写> 作数据目录；
  # 已存在就用它的，不存在就按同样的命名规则建一个，服务启动时会认领。
  he_dir=$(ls -d ${HMA_PREFIX}* 2>/dev/null | head -n 1)
  if [ -z "$he_dir" ]; then
    he_dir=${HMA_PREFIX}$(he_hma_rand16)
    mkdir -p "$he_dir" 2>/dev/null
  fi
  if [ ! -d "$he_dir" ]; then
    he_mark hma_config fail "无法创建 HMA 数据目录 $he_dir"
    return 1
  fi

  # v1.5.1：云端配置版本比本地新 → 强制覆盖（否则保留用户在 HMA 里的手工调整）
  if [ -n "$he_hma_cl" ] && [ -s "$he_hma_cl" ] && [ -s "$he_dir/config.json" ]; then
    he_cv_c=$(grep -o '"configVersion"[[:space:]]*:[[:space:]]*[0-9]*' "$he_hma_cl" 2>/dev/null | grep -o '[0-9]*$')
    he_cv_l=$(grep -o '"configVersion"[[:space:]]*:[[:space:]]*[0-9]*' "$he_dir/config.json" 2>/dev/null | grep -o '[0-9]*$')
    case "${he_cv_c:-0}" in ''|*[!0-9]*) he_cv_c=0 ;; esac
    case "${he_cv_l:-0}" in ''|*[!0-9]*) he_cv_l=0 ;; esac
    if [ "$he_cv_c" -gt "$he_cv_l" ] 2>/dev/null; then
      HIDE_FORCE=1
      echo "- 云端 HMA 配置更新（v$he_cv_l → v$he_cv_c），本次强制下发"
    fi
    unset he_cv_c he_cv_l 2>/dev/null
  fi

  # 旧配置升级：必须把 WGN TOOL / 根工具加进隐藏模板，并清掉会让包名隐藏失效的
  # disabledHooks。只针对这两个特征做一次强制重配，不动用户其它自定义项。
  if [ -s "$he_dir/config.json" ]; then
    if ! grep -q 'com.wgntool.app' "$he_dir/config.json" 2>/dev/null \
       || ! grep -q '"disabledHooks": *\[\]' "$he_dir/config.json" 2>/dev/null; then
      HIDE_FORCE=1
      echo "- HMA 配置缺少 WGN TOOL 隐藏项/仍有禁用钩子 → 本次强制重配"
    fi
  fi

  # 已有配置：版本匹配且有作用域 → 保留（不覆盖用户自己的调整）；
  # 空壳/旧版本 → 重建推荐配置（这是「一键隐藏」后 HMA 没生效的常见原因）。
  if [ "$HIDE_FORCE" != "1" ] && [ -s "$he_dir/config.json" ]; then
    if he_hma_config_ok "$he_dir/config.json"; then
      he_cv0=$(grep -o '"configVersion"[[:space:]]*:[[:space:]]*[0-9]*' "$he_dir/config.json" 2>/dev/null | grep -o '[0-9]*$')
      he_mark hma_config ok "HMA 已有可用配置（configVersion=${he_cv0:-未知}），保留不动"
      he_payload_wipe "$he_src"
      return 0
    fi
    echo "- HMA 现有配置为空/版本不符 → 重建推荐范围配置"
  fi

  mkdir -p "$he_dir/log" 2>/dev/null
  cp -f "$he_src" "$he_dir/config.json" 2>/dev/null

  # HMA 的服务跑在 system_server（uid 1000）里，文件归它读写
  chown 1000:1000 "$he_dir" "$he_dir/config.json" "$he_dir/log" 2>/dev/null
  chmod 0755 "$he_dir" "$he_dir/log" 2>/dev/null
  chmod 0644 "$he_dir/config.json" 2>/dev/null

  # 顺手修一下 SELinux 标签（有 restorecon 才做）
  for he_rc in /system/bin/restorecon /vendor/bin/restorecon; do
    [ -x "$he_rc" ] && "$he_rc" -R "$he_dir" >/dev/null 2>&1 && break
  done

  # 再放一份到「下载」目录，万一自动加载没生效，用 HMA 的「备份与还原」手动导入即可
  for he_dl in /sdcard/Download /storage/emulated/0/Download; do
    if [ -d "$he_dl" ]; then
      cp -f "$he_dir/config.json" "$he_dl/HMA-OSS_config.json" 2>/dev/null
      chown 1023:1023 "$he_dl/HMA-OSS_config.json" 2>/dev/null
      chmod 0664 "$he_dl/HMA-OSS_config.json" 2>/dev/null
      break
    fi
  done
  he_payload_wipe "$he_src"

  if [ ! -s "$he_dir/config.json" ]; then
    he_mark hma_config fail "HMA 配置写入失败"
    return 1
  fi

  # 配置版本必须和模块自带的一致，否则 HMA 会拒绝加载（这里是 93）
  he_cv=$(grep -o '"configVersion"[[:space:]]*:[[:space:]]*[0-9]*' "$he_dir/config.json" 2>/dev/null | grep -o '[0-9]*$')
  he_mark hma_config ok "HMA 配置已还原到 $he_dir/config.json（configVersion=${he_cv:-未知}；重复一份在 下载/HMA-OSS_config.json）"
  return 0
}

# ---------------------------------------------------------------
# 7.1) HMA-OSS 自动配置/启动（2026-10-18 用户要求）
#   · 模块缺失或版本落后 → 刷入 payload 里的最新版
#   · 强制写入推荐范围配置（112 个常见检测/游戏包 + 「黑」模板）
#   · 安装/打开管理器，用户点开即已是推荐配置
# ---------------------------------------------------------------
he_hma_auto() {
  command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 900 "hma auto"
  he_ha_mod=${HE_MODBASE:-/data/adb/modules}/hma_oss_zygisk
  he_ha_pv=""
  he_ha_pvn=""
  if [ -s "$HIDE_PAYLOAD/hma-oss.zip" ] && command -v unzip >/dev/null 2>&1; then
    he_ha_pv=$(unzip -p "$HIDE_PAYLOAD/hma-oss.zip" module.prop 2>/dev/null | sed -n 's/^versionCode=//p' | tr -d '\r' | head -n 1)
    he_ha_pvn=$(unzip -p "$HIDE_PAYLOAD/hma-oss.zip" module.prop 2>/dev/null | sed -n 's/^version=//p' | tr -d '\r' | head -n 1)
  fi
  he_ha_iv=$(sed -n 's/^versionCode=//p' "$he_ha_mod/module.prop" 2>/dev/null | tr -d '\r' | head -n 1)
  he_ha_ivn=$(sed -n 's/^version=//p' "$he_ha_mod/module.prop" 2>/dev/null | tr -d '\r' | head -n 1)
  he_ha_changed=0
  if [ -n "$he_ha_pv" ] && [ "$he_ha_iv" != "$he_ha_pv" ]; then
    he_ha_changed=1
  fi
  # 官方 oss-173 与 future-b9554518 的 versionCode 相同（都是 7304656），
  # 所以 versionCode 相同也要按 version 名判：只要名字不一样就按"包内为准"刷一次。
  if [ -n "$he_ha_pvn" ] && [ -n "$he_ha_ivn" ] && [ "$he_ha_ivn" != "$he_ha_pvn" ]; then
    he_ha_changed=1
  fi
  echo "== HMA-OSS 自动配置 =="
  if [ ! -d "$he_ha_mod" ] || [ "$he_ha_changed" = "1" ]; then
    echo "- 模块未安装/版本落后（当前=${he_ha_ivn:-无}/${he_ha_iv:-?}，包内=${he_ha_pvn:-未知}/${he_ha_pv:-?}）→ 刷入最新版"
    if command -v he_sc_install >/dev/null 2>&1; then
      he_sc_install hma-oss.zip hma_oss_zygisk || { echo "! HMA-OSS 模块刷入失败"; return 1; }
    elif command -v pack_install_one >/dev/null 2>&1; then
      pack_install_one hma-oss.zip "HMA-OSS Zygisk" || { echo "! HMA-OSS 模块刷入失败"; return 1; }
    else
      echo "! 安装库不可用"; return 1
    fi
  else
    echo "- 模块已安装（${he_ha_ivn:-?}/${he_ha_iv:-?}），无需重复刷入"
  fi
  rm -f "$he_ha_mod/disable" 2>/dev/null
  he_hma_manager
  HIDE_FORCE=1 he_hma_config
  he_hma_grant_root >/dev/null 2>&1
  he_hma_open
  he_ha_iv=$(sed -n 's/^versionCode=//p' "$he_ha_mod/module.prop" 2>/dev/null | tr -d '\r' | head -n 1)
  he_ha_dir=$(ls -d ${HMA_PREFIX}* 2>/dev/null | head -n 1)
  he_ha_cv=""; he_ha_n=0
  if [ -n "$he_ha_dir" ] && [ -s "$he_ha_dir/config.json" ]; then
    he_ha_cv=$(grep -o '"configVersion"[[:space:]]*:[[:space:]]*[0-9]*' "$he_ha_dir/config.json" 2>/dev/null | grep -o '[0-9]*$')
    he_ha_n=$(grep -o '"useWhitelist"' "$he_ha_dir/config.json" 2>/dev/null | wc -l | tr -d ' ')
  fi
  echo "[√] HMA-OSS 已启用并打开：版本 versionCode=${he_ha_iv:-未知}，配置版本 ${he_ha_cv:-未知}，推荐范围 ${he_ha_n:-0} 个应用"
  echo "    （如果界面仍显示旧配置：在 HMA 里退出重进，或重启一次；配置副本在 下载/HMA-OSS_config.json）"
  he_mark hma_auto ok "HMA-OSS 自动配置已应用（推荐范围 ${he_ha_n:-0} 个应用）"
  return 0
}

# FuseFixer 一键修复：确保 App + LSPosed 启用 + 推荐作用域 MediaProvider
he_fuse_auto() {
  echo "== FuseFixer 自动配置 =="
  he_fuse_app_ensure
  he_lsposed_fusefixer
  if [ "${HE_FUSE_RC:-9}" = "0" ]; then
    echo "[√] FuseFixer 已启用，作用域=MediaProvider（推荐；$(cat "${HIDE_STATE_DIR:-/data/adb/hide_env_pack/state}/.lsp_schema" 2>/dev/null)）"
    echo "    若 LSPosed 界面还显示未勾选：重启一次让配置库生效"
  else
    echo "[!] FuseFixer 配置库写入返回 ${HE_FUSE_RC:-9}"
    echo "    重启一次后再点「修复 FuseFixer 作用域」；仍不行就在 LSPosed 里点「使用模块建议的范围」"
  fi
  return 0
}

# ---------------------------------------------------------------
# 7.5) 面具侧内核特性（KernelSU）：把「隐藏 SELinux 修改」这类开关显式打上
#   2026-10-07 实测：安卓 16 上 KernelSU 的 selinux_hide（SELinux Hide，对 app UID
#   清洗 /sys/fs/selinux 读取结果）默认就是开的，但 App 界面偶尔显示不一致。
#   这里每次开机用 ksud 显式 set 一次并 save，体检里单独出一行，免得靠猜。
# ---------------------------------------------------------------
he_ksu_features() {
  he_kf_ksud=""
  for he_kf_c in /data/adb/ksu/bin/ksud /data/adb/ksud; do
    [ -x "$he_kf_c" ] && { he_kf_ksud=$he_kf_c; break; }
  done
  if [ -z "$he_kf_ksud" ]; then
    he_mark ksu_features skip "不是 KernelSU 环境（没有 ksud），跳过内核特性"
    return 0
  fi
  # 春秋等检测会把 selinux_hide 认成"异常环境"，这里改成默认关闭
  # 正式版：按楠楠要求打开「隐藏 SELinux 修改」（KSU / KSU Next 通用）
  he_kf_out=$("$he_kf_ksud" feature set selinux_hide 1 2>&1 | head -n 1)
  "$he_kf_ksud" feature save >/dev/null 2>&1
  he_kf_now=$("$he_kf_ksud" feature list 2>/dev/null | grep -A1 -i 'selinux_hide' | head -n 1)
  case "$he_kf_now" in
    *ENABLED*) he_mark ksu_features ok "面具内核特性：隐藏 SELinux 修改（selinux_hide）已开启" ;;
    *DISABLED*) he_mark ksu_features todo "selinux_hide 未开启（部分检测会报 SELinux Policy 可疑）" ;;
    *) he_mark ksu_features todo "selinux_hide 没确认上（ksud 回：$(printf '%s' "$he_kf_out" | cut -c1-60)）" ;;
  esac
  return 0
}

# ---------------------------------------------------------------
# 7.6) 换 Vector 之后，清掉 LSPosed 的"可检测痕迹"
#   2026-10-07 实测：桌面图标藏了没用 —— 检测器读的是
#     ① pm list packages 里的 org.lsposed.manager
#     ② /data/adb/modules/zygisk_lsposed
#     ③ /data/adb/lspd
#   所以换到 Vector 且它的守护进程（vectord）确实在跑之后，按需清掉这三样。
#   想保留：config/lsp_keep.txt 里写 keep。
# ---------------------------------------------------------------
he_vector_cleanup() {
  he_vc_mod=${HE_MODBASE:-/data/adb/modules}/zygisk_lsposed
  he_vc_vmod=${HE_MODBASE:-/data/adb/modules}/zygisk_vector
  he_vc_cfg=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/lsp_keep.txt
  if [ -s "$he_vc_cfg" ] && grep -qs -i 'keep' "$he_vc_cfg" 2>/dev/null; then
    he_mark lsp_clean skip "配置要求保留 LSPosed 痕迹（config/lsp_keep.txt=keep），跳过清理"
    return 0
  fi
  # 只在安卓 16+（SDK≥36）做：那儿 LSPosed 守护进程本来就崩（实测段错误），
  # 留着它只会让检测器报"发现 RSP 应用"。安卓 15 及以下 LSPosed 正常，不动。
  he_vc_sdk=$(getprop ro.build.version.sdk 2>/dev/null)
  case "$he_vc_sdk" in ''|*[!0-9]*) he_vc_sdk=0 ;; esac
  if [ "$he_vc_sdk" -lt 36 ]; then
    # 安卓15 及以下：只有 Vector 真的接管了才清（否则保留可用的 LSPosed）
    if ! ps -A 2>/dev/null | grep -qE 'org\.matrix\.vector\.daemon\.VectorDaemon|[v]ectord'; then
      he_mark lsp_clean skip "安卓 $he_vc_sdk < 16 且 Vector 未接管：保留 LSPosed（不清理痕迹）"
      return 0
    fi
  fi
  he_vc_n=0
  if he_pkg_installed org.lsposed.manager; then
    pm uninstall --user 0 org.lsposed.manager >/dev/null 2>&1 && he_vc_n=$((he_vc_n+1))
    for he_vc_u in $(he_clean_users 2>/dev/null); do
      pm uninstall --user "$he_vc_u" org.lsposed.manager >/dev/null 2>&1
    done
  fi
  if [ -d "$he_vc_mod" ]; then
    touch "$he_vc_mod/remove" 2>/dev/null && he_vc_n=$((he_vc_n+1))
  fi
  # ★ 不能整目录删：Vector 的配置库硬编码在 /data/adb/lspd/config/modules_config.db。
  #   2026-10-20 实测：删掉后 FuseFixer 永远“无库可写”。只清日志/锁/socket，
  #   保留 config/modules_config.db（检测面关心的是包、桌面图标、通知，不是这个库）。
  if [ -d /data/adb/lspd ]; then
    he_vc_rm=0
    for he_vc_t in log log.old lock .cli_sock; do
      if [ -e "/data/adb/lspd/$he_vc_t" ]; then
        rm -rf "/data/adb/lspd/$he_vc_t" 2>/dev/null && he_vc_rm=$((he_vc_rm+1))
      fi
    done
    [ "$he_vc_rm" -gt 0 ] && he_vc_n=$((he_vc_n+1))
  fi
  if [ -x /data/adb/ksu/bin/lspctl ]; then rm -f /data/adb/ksu/bin/lspctl 2>/dev/null; fi
  if [ "$he_vc_n" = "0" ]; then
    he_mark lsp_clean ok "安卓 16：管理器包/旧模块/日志已清，仅保留 Vector 必需的 /data/adb/lspd/config/modules_config.db"
  else
    he_mark lsp_clean ok "已清掉 LSPosed 可检测痕迹 $he_vc_n 处（管理器包+旧模块+日志），保留 Vector 配置库；模块下次开机彻底移除"
  fi
  return 0
}

# ---------------------------------------------------------------
# 8) LSPosed：安装并启用 FuseFixer
#    FuseFixer 是"已安装应用形态"的 LSPosed 模块（APK 里带 assets/xposed_init，
#    LSPosed 2.x 会按"已安装应用"把它认成模块）。所以分两步：
#      装 APK   —— 和卡密无关：刷入就装、每次开机兜底补装（he_fuse_app_ensure）
#      勾选启用 —— 属于"生效"：卡密一键启动后由 he_lsposed_fusefixer 写配置库
# ---------------------------------------------------------------
HE_FUSE_PM_OUT=""

he_fuse_install_apk() {
  he_apk=$HIDE_PAYLOAD/fusefixer.apk
  [ -s "$he_apk" ] || { HE_FUSE_PM_OUT="payload 里没有 fusefixer.apk"; return 1; }
  # 走公共安装件：先搬到 /data/local/tmp 再装（/data/adb 下会被 SELinux 挡住）
  if he_apk_install "$he_apk" "$FUSE_PKG"; then
    return 0
  fi
  HE_FUSE_PM_OUT=$HE_APK_PM_OUT
  return 1
}

# 只保证"装上"（与卡密无关）：刷入时 + 每次开机兜底
he_fuse_app_ensure() {
  if he_pkg_installed "$FUSE_PKG"; then
    he_mark fuse_app ok "防护组件已安装（$FUSE_PKG）"
    return 0
  fi
  if he_fuse_install_apk; then
    he_mark fuse_app ok "防护组件已安装（$FUSE_PKG）"
    return 0
  fi
  case "$HE_FUSE_PM_OUT" in
    *OLDER_SDK*|*"newer sdk"*)
      he_mark fuse_app skip "本机系统版本低于 FuseFixer 的要求（Android 11+），已跳过安装" ;;
    *)
      # pm 偶发“无输出但安装未生效”（SELinux 拦截/package manager 忙），
      # 空原因会让汇总只剩一个冒号；这里补一条可执行提示。
      [ -n "$HE_FUSE_PM_OUT" ] || HE_FUSE_PM_OUT="pm 未返回结果（可能被 SELinux 拦截或 package manager 忙）"
      he_mark fuse_app fail "FuseFixer App 安装失败：$(printf '%s' "$HE_FUSE_PM_OUT" | tr -d '\n' | cut -c1-110)" ;;
  esac
  return 1
}

# ---------------- 框架管理器：默认「隐藏模式」 ----------------
# 管理器只是一个普通 APK，框架（lspd/vectord）运行不依赖它。
# 隐藏模式下：不在设备上常驻 —— pm 包列表里查不到、桌面没有图标、通知栏/悬浮窗全关；
# 要用时由面具「动作」按钮（或 install.sh lsp）临时装、打开，界面关闭后自动卸载。
# 想恢复老行为（常驻安装 + 只藏图标）：config/lsp_hidden.txt 写 off，
# 或 config/lsp_keep.txt 写 keep（明确要求保留）。
he_lsp_hidden_mode() {
  he_lhm_hide=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/lsp_hidden.txt
  he_lhm_keep=${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/lsp_keep.txt
  if [ -s "$he_lhm_hide" ] && grep -qs -i '^[[:space:]]*off' "$he_lhm_hide" 2>/dev/null; then
    return 1
  fi
  if [ -s "$he_lhm_keep" ] && grep -qs -i 'keep' "$he_lhm_keep" 2>/dev/null; then
    return 1
  fi
  return 0
}

he_lsp_active_pkg() {   # 当前框架对应的管理器包名
  he_lap_mb=${HE_MODBASE:-/data/adb/modules}
  if [ -d "$he_lap_mb/zygisk_vector" ]; then
    printf '%s' org.matrix.vector.manager
    return 0
  fi
  if [ -d "$he_lap_mb/zygisk_lsposed" ]; then
    printf '%s' org.lsposed.manager
    return 0
  fi
  he_lap_sdk=$(getprop ro.build.version.sdk 2>/dev/null)
  case "$he_lap_sdk" in ''|*[!0-9]*) he_lap_sdk=0 ;; esac
  if [ "$he_lap_sdk" -ge 36 ]; then
    printf '%s' org.matrix.vector.manager
  else
    printf '%s' org.lsposed.manager
  fi
}

he_lsp_manager_apk() {   # he_lsp_manager_apk <包名> → 打印可用的 manager.apk 路径
  he_lma_pkg=$1
  he_lma_mb=${HE_MODBASE:-/data/adb/modules}
  he_lma_pl=${HIDE_PAYLOAD:-/data/adb/hide_env_pack/payload}
  he_lma_direct=""
  he_lma_zip=""
  case "$he_lma_pkg" in
    org.matrix.vector.manager)
      he_lma_direct="$he_lma_mb/zygisk_vector/manager.apk"
      if [ -s "$he_lma_pl/vector.zip" ]; then he_lma_zip="$he_lma_pl/vector.zip"
      elif [ -s "$he_lma_pl/alt/vector.zip" ]; then he_lma_zip="$he_lma_pl/alt/vector.zip"
      fi
      ;;
    *)
      he_lma_direct="$he_lma_mb/zygisk_lsposed/manager.apk"
      he_lma_zip="$he_lma_pl/lsposed.zip"
      ;;
  esac
  if [ -s "$he_lma_direct" ]; then
    printf '%s' "$he_lma_direct"
    return 0
  fi
  [ -s "$he_lma_zip" ] || return 1
  mkdir -p "${HIDE_TMP:-/data/adb/hide_env_pack/tmp}/lspm" 2>/dev/null
  unzip -o -j "$he_lma_zip" manager.apk -d "${HIDE_TMP:-/data/adb/hide_env_pack/tmp}/lspm" >/dev/null 2>&1
  he_lma_x="${HIDE_TMP:-/data/adb/hide_env_pack/tmp}/lspm/manager.apk"
  [ -s "$he_lma_x" ] || return 1
  printf '%s' "$he_lma_x"
}

he_lsp_lock_surface() {   # 关通知栏 + 悬浮窗（临时管理器也保持安静）
  he_lls_pkg=$1
  appops set "$he_lls_pkg" POST_NOTIFICATION deny >/dev/null 2>&1 || \
  appops set "$he_lls_pkg" POST_NOTIFICATION ignore >/dev/null 2>&1 || \
  cmd appops set "$he_lls_pkg" POST_NOTIFICATION deny >/dev/null 2>&1
  appops set "$he_lls_pkg" SYSTEM_ALERT_WINDOW deny >/dev/null 2>&1 || \
  cmd appops set "$he_lls_pkg" SYSTEM_ALERT_WINDOW deny >/dev/null 2>&1
  pm revoke "$he_lls_pkg" android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
  pm revoke "$he_lls_pkg" android.permission.SYSTEM_ALERT_WINDOW >/dev/null 2>&1
  return 0
}

he_lsp_proc_alive() {   # 0=管理器进程还在（排除看护脚本自己的命令行）
  he_lpa_pkg=$1
  if command -v pidof >/dev/null 2>&1 && pidof "$he_lpa_pkg" >/dev/null 2>&1; then
    return 0
  fi
  ps -A -o PID,NAME 2>/dev/null | awk -v p="$he_lpa_pkg" \
    '$2==p || index($2,p)==1 || index($2,p":")==1 {f=1} END{exit !f}' && return 0
  return 1
}

he_lsp_manager_watch() {   # 管理器关闭后自动卸载（保持"包列表里查不到"）
  he_lmw_pkg=$1
  he_lmw_temp=${2:-0}
  he_lmw_state=${HIDE_STATE_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state}
  he_lmw_log="$he_lmw_state/lsp_manager.log"
  he_lmw_lock="$he_lmw_state/lsp_manager_watch.lock"
  mkdir -p "$he_lmw_state" 2>/dev/null
  if ! mkdir "$he_lmw_lock" 2>/dev/null; then
    he_lmw_old=$(cat "$he_lmw_lock/pid" 2>/dev/null)
    if [ -n "$he_lmw_old" ] && kill -0 "$he_lmw_old" 2>/dev/null; then
      return 0
    fi
    rm -rf "$he_lmw_lock" 2>/dev/null
    mkdir "$he_lmw_lock" 2>/dev/null || return 0
  fi
  echo $$ >"$he_lmw_lock/pid" 2>/dev/null
  printf '%s [watch] 看护启动：%s\n' "$(date '+%m-%d %H:%M:%S' 2>/dev/null)" "$he_lmw_pkg" >>"$he_lmw_log" 2>/dev/null
  # 给界面 8 秒站稳，再把桌面入口收掉（已经打开的界面不受影响）
  # 时序可用环境变量覆盖（仅用于沙盒回归，真机保持默认）
  he_lmw_first=${HE_LSP_WATCH_FIRST:-8}
  he_lmw_poll=${HE_LSP_WATCH_POLL:-5}
  he_lmw_max=${HE_LSP_WATCH_MAX:-1800}
  sleep "$he_lmw_first"
  he_lmw_c=$(he_lsp_comp "$he_lmw_pkg")
  pm disable --user 0 "$he_lmw_c" >/dev/null 2>&1
  he_lmw_gone=0
  he_lmw_start=$(date +%s 2>/dev/null || echo 0)
  while :; do
    sleep "$he_lmw_poll"
    if he_lsp_proc_alive "$he_lmw_pkg"; then
      he_lmw_gone=0
    else
      he_lmw_gone=$((he_lmw_gone + 1))
    fi
    [ "$he_lmw_gone" -ge 2 ] && break
    he_lmw_now=$(date +%s 2>/dev/null || echo 0)
    if [ "$he_lmw_start" -gt 0 ] && [ "$he_lmw_now" -gt 0 ]; then
      [ $((he_lmw_now - he_lmw_start)) -ge "$he_lmw_max" ] && break
    fi
    [ -f "$he_lmw_state/lsp_manager_open" ] || break
  done
  if [ "$he_lmw_temp" = "1" ] || he_lsp_hidden_mode; then
    am force-stop "$he_lmw_pkg" >/dev/null 2>&1
    pm uninstall --user 0 "$he_lmw_pkg" >/dev/null 2>&1
    for he_lmw_u in $(he_clean_users 2>/dev/null); do
      pm uninstall --user "$he_lmw_u" "$he_lmw_pkg" >/dev/null 2>&1
    done
    printf '%s [watch] %s 已卸载（界面关闭/超时）\n' "$(date '+%m-%d %H:%M:%S' 2>/dev/null)" "$he_lmw_pkg" >>"$he_lmw_log" 2>/dev/null
  else
    am force-stop "$he_lmw_pkg" >/dev/null 2>&1
    printf '%s [watch] %s 已关闭（常驻模式，保留安装）\n' "$(date '+%m-%d %H:%M:%S' 2>/dev/null)" "$he_lmw_pkg" >>"$he_lmw_log" 2>/dev/null
  fi
  rm -f "$he_lmw_state/lsp_manager_open" 2>/dev/null
  rm -rf "$he_lmw_lock" 2>/dev/null
  return 0
}

# LSPosed / Vector 管理器（开机/安装阶段）：
#   隐藏模式 → 清掉所有遗留管理器（上次异常退出/重启前没来得及卸载的），不新装；
#   常驻模式 → 保持旧逻辑，缺了补装。
# 管理器包"包列表隐身"：pm hide 比卸载安全（管理器还能用，只是别的 APP 查不到）
he_mgr_mask_pkgs() { echo "me.weishu.kernelsu org.frknkrc44.hma_oss"; }
he_mgr_mask() { # on|off|status
  he_mm_act="${1:-status}"
  he_mm_state="${HIDE_STATE_DIR:-/data/adb/hide_env_pack/state}/mgr_masked"
  case "$he_mm_act" in
    off|unmask|show)
      for he_p in $(he_mgr_mask_pkgs); do
        pm unhide "$he_p" >/dev/null 2>&1
      done
      rm -f "$he_mm_state" 2>/dev/null
      echo "[√] 管理器包已恢复可见"
      ;;
    status|状态)
      for he_p in $(he_mgr_mask_pkgs); do
        if pm list packages 2>/dev/null | grep -q "^$he_p$"; then echo "  $he_p = 可见"; else echo "  $he_p = 已隐藏"; fi
      done
      ;;
    *)
      he_mm_n=0
      for he_p in $(he_mgr_mask_pkgs); do
        if pm list packages 2>/dev/null | grep -q "^$he_p$"; then
          pm hide "$he_p" >/dev/null 2>&1 && he_mm_n=$((he_mm_n+1))
        fi
      done
      mkdir -p "${HIDE_STATE_DIR:-/data/adb/hide_env_pack/state}" 2>/dev/null
      : > "$he_mm_state" 2>/dev/null
      echo "[√] 管理器包已包列表隐身（${he_mm_n} 个）"
      ;;
  esac
}

he_lsp_manager() {
  if he_lsp_hidden_mode; then
    he_lm_n=0
    for he_lm_p in org.lsposed.manager org.matrix.vector.manager; do
      he_pkg_installed "$he_lm_p" || continue
      pm uninstall --user 0 "$he_lm_p" >/dev/null 2>&1 && he_lm_n=$((he_lm_n+1))
      for he_lm_u in $(he_clean_users 2>/dev/null); do
        pm uninstall --user "$he_lm_u" "$he_lm_p" >/dev/null 2>&1
      done
    done
    rm -f "${HIDE_STATE_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state}/lsp_manager_open" 2>/dev/null
    rm -rf "${HIDE_STATE_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state}/lsp_manager_watch.lock" 2>/dev/null
    # 回读：包列表里不能还剩管理器；残留就再藏图标/掐通知并报失败
    he_lm_left=""
    for he_lm_p in org.lsposed.manager org.matrix.vector.manager; do
      if he_pkg_installed "$he_lm_p"; then
        he_lm_left="$he_lm_left $he_lm_p"
        command -v he_hide_one_icon >/dev/null 2>&1 && he_hide_one_icon "$he_lm_p"
        command -v he_lsp_lock_surface >/dev/null 2>&1 && he_lsp_lock_surface "$he_lm_p"
      fi
    done
    if [ -n "$he_lm_left" ]; then
      he_mark lsp_manager fail "隐藏模式未完成：包列表仍能看到$he_lm_left（已强制藏图标/关通知，重启后再清）"
      he_mark lsp_icon fail "管理器包仍在，图标/通知已强制关闭但包列表未隐身"
    elif [ "$he_lm_n" -gt 0 ]; then
      he_mark lsp_manager ok "隐藏模式：已移除常驻管理器 $he_lm_n 个，回读包列表无残留（打开：面具「动作」按钮，关闭后自动移除）"
      he_mark lsp_icon ok "管理器不常驻：桌面图标、通知栏、pm 包列表均无（临时打开才安装，关闭即卸载）"
    else
      he_mark lsp_manager skip "隐藏模式：管理器不常驻，桌面/通知栏/包列表都没有；打开：面具「动作」按钮"
      he_mark lsp_icon ok "管理器不常驻：桌面图标、通知栏、pm 包列表均无（临时打开才安装，关闭即卸载）"
    fi
    return 0
  fi
  he_lm_pkg=$(he_lsp_active_pkg)
  if he_pkg_installed "$he_lm_pkg"; then
    he_mark lsp_manager ok "框架管理器已安装（$he_lm_pkg）"
    return 0
  fi
  he_lm_apk=$(he_lsp_manager_apk "$he_lm_pkg") || he_lm_apk=""
  if [ -z "$he_lm_apk" ]; then
    he_mark lsp_manager todo "找不到管理器 APK（manager.apk；$he_lm_pkg 的模块目录与 payload 里都没有），下次开机重试"
    return 1
  fi
  if he_apk_install "$he_lm_apk" "$he_lm_pkg"; then
    he_mark lsp_manager ok "框架管理器已补装（$he_lm_pkg，常驻模式）"
    return 0
  fi
  he_mark lsp_manager fail "框架管理器安装失败：$(printf '%s' "$HE_APK_PM_OUT" | tr -d '\n' | cut -c1-110)"
  return 1
}

# Vector 守护进程启动器（带退让链；体检和开机都会调一次）
#   原版 service.sh 在个别 Android 16（toybox unshare 不认 --propagation）上起不来，
#   所以这里不依赖它，自己按可用性依次试。
he_vector_daemon_start() {
  he_vd_m=${HE_MODBASE:-/data/adb/modules}/zygisk_vector
  [ -f "$he_vd_m/daemon" ] || return 1
  ps -A 2>/dev/null | grep -qE 'org.matrix.vector.daemon.VectorDaemon|[v]ectord' && return 0
  he_vd_bb=""
  for he_vd_c in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox; do
    [ -x "$he_vd_c" ] && { he_vd_bb=$he_vd_c; break; }
  done
  (
    cd "$he_vd_m" || exit 1
    if [ -n "$he_vd_bb" ] && "$he_vd_bb" unshare --propagation slave -m true >/dev/null 2>&1; then
      nohup "$he_vd_bb" unshare --propagation slave -m ./daemon --system-server-max-retry=3 >/dev/null 2>&1 &
    elif unshare -m true >/dev/null 2>&1; then
      nohup unshare -m ./daemon --system-server-max-retry=3 >/dev/null 2>&1 &
    else
      nohup ./daemon --system-server-max-retry=3 >/dev/null 2>&1 &
    fi
  ) >/dev/null 2>&1 &
  sleep 6
  ps -A 2>/dev/null | grep -qE 'org.matrix.vector.daemon.VectorDaemon|[v]ectord'
}

# MIUI/HyperOS：lspd 初始化 SQLite 时会触发 MIUI ThemeCompatibility，读取
# /data/system/theme_config/theme_compatibility.xml；某些 ROM 该目录/文件缺失 →
# FileNotFoundException，lspd 直接退出，管理器永远显示未启用。
# 2026-10-18 真机实证：Redmi K50 Ultra / MIUI 13 / Android 12，系统模板在
# /system/media/theme/theme_compatibility.xml，补一份到数据目录后 lspd 正常。
# 路径可用 HE_MIUI_THEME_SRC/DST 覆盖（仅沙盒测试）。
he_lsp_miui_theme_fix() {
  he_mt_dst=${HE_MIUI_THEME_DST:-/data/system/theme_config/theme_compatibility.xml}
  [ -f "$he_mt_dst" ] && return 0
  he_mt_src=""
  for he_mt_c in ${HE_MIUI_THEME_SRC:-/system/media/theme/theme_compatibility.xml} \
                 /system/etc/theme_compatibility.xml /product/media/theme/theme_compatibility.xml; do
    [ -f "$he_mt_c" ] && { he_mt_src=$he_mt_c; break; }
  done
  [ -n "$he_mt_src" ] || return 0
  mkdir -p "$(dirname "$he_mt_dst")" 2>/dev/null
  cp -f "$he_mt_src" "$he_mt_dst" 2>/dev/null || return 0
  chown system:system "$he_mt_dst" 2>/dev/null
  chmod 0644 "$he_mt_dst" 2>/dev/null
  restorecon "$he_mt_dst" 2>/dev/null
  he_mark lsp_theme ok "已补 MIUI 主题兼容配置（$he_mt_dst；lspd 缺少它会启动失败）"
  return 0
}

# 把框架补齐并拉起（「LSP 打不开/未激活」的根治入口）：
#   SDK≥36：LSPosed 2.2.1 的 lspd 在安卓16 必段错误 → 自动装/拉起 Vector（同源续作）；
#   SDK<36 ：用 LSPosed；两次拉不起来就覆盖安装再拉，仍不行则由包内 Vector 接手。
#   返回 0 = 守护进程确实在跑。
he_lsp_ensure_framework() {
  command -v he_lsp_miui_theme_fix >/dev/null 2>&1 && he_lsp_miui_theme_fix
  he_lef_sdk=$(getprop ro.build.version.sdk 2>/dev/null)
  case "$he_lef_sdk" in ''|*[!0-9]*) he_lef_sdk=0 ;; esac
  he_lef_mb=${HE_MODBASE:-/data/adb/modules}

  if [ "$he_lef_sdk" -ge 36 ]; then
    he_lef_vmod="$he_lef_mb/zygisk_vector"
    # 被管理器禁用 / 装坏（缺 daemon）都按“需要补装”处理
    [ -f "$he_lef_vmod/disable" ] && rm -f "$he_lef_vmod/disable" 2>/dev/null
    if [ ! -d "$he_lef_vmod" ] || [ ! -f "$he_lef_vmod/daemon" ]; then
      echo "- 安卓 $he_lef_sdk：LSPosed 守护进程在安卓16 会崩，改用 Vector（同源续作）"
      if ! command -v pack_install_one >/dev/null 2>&1 || ! command -v pack_vector_ready >/dev/null 2>&1; then
        echo "! 包内安装库不可用，无法自动补装 Vector"
        return 1
      fi
      pack_vector_ready || { echo "! 包里没有 Vector（payload/vector.zip）"; return 1; }
      pack_init keep >/dev/null 2>&1
      pack_install_one "vector.zip" "Vector（安卓16兼容版）" || { echo "! Vector 安装失败"; return 1; }
    fi
    # 不管新装还是已有，启动前都确保 service.sh 的 unshare 兼容补丁在
    command -v pack_patch_vector_service >/dev/null 2>&1 && pack_patch_vector_service >/dev/null 2>&1
    he_lef_try=0
    while [ "$he_lef_try" -lt 2 ]; do
      he_lef_try=$((he_lef_try+1))
      if ps -A 2>/dev/null | grep -qE 'org\.matrix\.vector\.daemon\.VectorDaemon|[v]ectord'; then
        command -v he_vector_cleanup >/dev/null 2>&1 && he_vector_cleanup >/dev/null 2>&1
        return 0
      fi
      command -v he_vector_daemon_start >/dev/null 2>&1 && he_vector_daemon_start >/dev/null 2>&1
      sleep 3
    done
    echo "! Vector 守护进程起不来：看 /data/adb/vector/log/ 或 install.sh lsp-doctor"
    return 1
  fi

  # Android 15 及以下：LSPosed
  he_lef_mod="$he_lef_mb/zygisk_lsposed"
  if [ -d "$he_lef_mod" ] && [ -f "$he_lef_mod/remove" ]; then
    rm -f "$he_lef_mod/remove" 2>/dev/null
  fi
  if [ ! -d "$he_lef_mod" ] || { [ ! -f "$he_lef_mod/lspd" ] && [ ! -x "$he_lef_mod/lspd" ]; }; then
    if ! command -v pack_install_one >/dev/null 2>&1; then
      echo "! LSPosed 模块不在，且安装库不可用"
      return 1
    fi
    echo "- LSPosed 模块不完整：用包内版本补装"
    pack_init keep >/dev/null 2>&1
    pack_install_one "lsposed.zip" "LSPosed" || { echo "! LSPosed 安装失败"; return 1; }
  fi
  mkdir -p "${HE_LSPD_DIR:-/data/adb/lspd}" 2>/dev/null
  : >"${HE_LSPD_DIR:-/data/adb/lspd}/skip_online_request" 2>/dev/null

  if ! ps -A 2>/dev/null | grep -q '[l]spd'; then
    he_lef_try=0
    while [ "$he_lef_try" -lt 2 ]; do
      he_lef_try=$((he_lef_try+1))
      ( cd "$he_lef_mod" 2>/dev/null && sh ./lspd >/dev/null 2>&1 & ) >/dev/null 2>&1
      sleep 6
      ps -A 2>/dev/null | grep -q '[l]spd' && return 0
    done
    if command -v pack_install_one >/dev/null 2>&1; then
      echo "- LSPosed 守护进程两次没起来：覆盖安装后再拉一次"
      pack_init keep >/dev/null 2>&1
      pack_install_one "lsposed.zip" "LSPosed（覆盖修复）" >/dev/null 2>&1
      sleep 2
      ( cd "$he_lef_mod" 2>/dev/null && sh ./lspd >/dev/null 2>&1 & ) >/dev/null 2>&1
      sleep 6
      ps -A 2>/dev/null | grep -q '[l]spd' && return 0
    fi
    # 最后手段：Vector 接手（包内自带；管理器随之换成 org.matrix.vector.manager）
    if command -v pack_vector_ready >/dev/null 2>&1 && pack_vector_ready; then
      echo "- LSPosed 仍起不来：用包内 Vector 接手（同源续作）"
      pack_init keep >/dev/null 2>&1
      if pack_install_one "vector.zip" "Vector（接管）" >/dev/null 2>&1; then
        command -v pack_patch_vector_service >/dev/null 2>&1 && pack_patch_vector_service >/dev/null 2>&1
        if command -v he_vector_daemon_start >/dev/null 2>&1 && he_vector_daemon_start >/dev/null 2>&1; then
          command -v he_vector_cleanup >/dev/null 2>&1 && he_vector_cleanup >/dev/null 2>&1
          echo "[√] Vector 已接管（LSPosed 痕迹会自动清理）"
          return 0
        fi
      fi
    fi
    echo "! LSPosed 守护进程起不来；崩溃日志：/data/adb/lspd/log/daemon-*-crash-*.log"
    return 1
  fi
  return 0
}

he_lsp_health() { # 框架守护进程看护（安卓 16+ 是 Vector 的 vectord；以下才是 LSPosed 的 lspd）
  command -v he_lsp_miui_theme_fix >/dev/null 2>&1 && he_lsp_miui_theme_fix
  he_lh_mod=${HE_MODBASE:-/data/adb/modules}/zygisk_lsposed
  he_lh_vmod=${HE_MODBASE:-/data/adb/modules}/zygisk_vector
  he_lh_sdk=$(getprop ro.build.version.sdk 2>/dev/null)
  case "$he_lh_sdk" in ''|*[!0-9]*) he_lh_sdk=0 ;; esac

  # ★ 安卓 16（SDK 36）：LSPosed 2.2.1(7912) 的 lspd 一启动就段错误（2026-10-07 实测 5/5 台），
  #   所以 16+ 用同源续作 Vector（守护进程 vectord）。体检看 Vector，不再拿 LSPosed 报错。
  if [ "$he_lh_sdk" -ge 36 ]; then
    if ps -A 2>/dev/null | grep -qE 'org.matrix.vector.daemon.VectorDaemon|[v]ectord'; then
      he_mark lspd ok "框架：Vector（安卓 16 兼容版）守护进程在跑"
      return 0
    fi
    # 没在跑：不管设备上有没有 Vector/LSPosed，都走“补齐 + 拉起”。
    # 之前这里只打 todo/skip，全新刷入的安卓16机器永远没有框架（LSP 管理器一直未启动）。
    if command -v he_lsp_ensure_framework >/dev/null 2>&1 && he_lsp_ensure_framework >/dev/null 2>&1; then
      he_mark lspd ok "Vector 已补齐并拉起（安卓 16 兼容版）"
    else
      he_mark lspd fail "Vector 起不来（看 /data/adb/vector/log/ 或 install.sh lsp-doctor）"
    fi
    return 0
  fi

  # ★ 版本检查（2026-10-07 真机实证）：设备上如果是老版 LSPosed（2.0.4 那套），
  #   它的守护进程在安卓 14+ 上会**一启动就段错误**（真机测：service.sh → Segmentation fault）
  #   → 管理端永远显示"未激活"。以前包只看"装没装"，不看版本，所以一直没修。
  #   这里比对 payload 里的 versionCode，比 payload 老就排进补装队列（重启时自动覆盖升级）。
  if [ -f "$he_lh_mod/module.prop" ] && [ -s "${HIDE_PAYLOAD:-/data/adb/hide_env_pack/payload}/lsposed.zip" ]; then
    he_lh_cur=$(sed -n 's/^versionCode=//p' "$he_lh_mod/module.prop" 2>/dev/null | tr -d '\n' | head -n 1)
    he_lh_new=$(unzip -p "${HIDE_PAYLOAD:-/data/adb/hide_env_pack/payload}/lsposed.zip" module.prop 2>/dev/null | sed -n 's/^versionCode=//p' | tr -d '\n' | head -n 1)
    case "$he_lh_cur" in ''|*[!0-9]*) he_lh_cur=0 ;; esac
    case "$he_lh_new" in ''|*[!0-9]*) he_lh_new=0 ;; esac
    if [ "$he_lh_new" -gt 0 ] && [ "$he_lh_cur" -lt "$he_lh_new" ]; then
      he_mark lspd todo "LSPosed 是旧版（$he_lh_cur < 包内 $he_lh_new）：旧版守护进程在安卓 14+ 会段错误 → 显示未激活。已排进补装队列，重启后自动升级；想立刻升级：install.sh lsp-upgrade"
      he_lh_pend=${PACK_DIR:-/data/adb/hide_env_pack}/pending
      grep -qs '^zygisk_lsposed$' "$he_lh_pend" 2>/dev/null || printf '%s\n' zygisk_lsposed >>"$he_lh_pend" 2>/dev/null
      return 0
    fi
  fi

  if ps -A 2>/dev/null | grep -q '[l]spd'; then
    he_mark lspd ok "LSPosed 守护进程在跑"
    return 0
  fi
  # 兜底检测（有些设备没有 ps -A）
  if [ -r /proc/$(pgrep -f '^lspd$' 2>/dev/null | head -n 1)/comm ] 2>/dev/null; then
    he_mark lspd ok "LSPosed 守护进程在跑"
    return 0
  fi
  if [ ! -x "$he_lh_mod/lspd" ] && [ ! -f "$he_lh_mod/lspd" ]; then
    if [ "${PACK_SKIP_LSPOSED:-0}" = "1" ]; then
      he_mark lspd skip "天玑方案：不装 LSPosed（要装就 install.sh lsp-upgrade）"
    else
      # 模块整个不在了（被删/离线刷入时没装上）：排进补装队列，重启时自动装回
      he_lh_pend=${PACK_DIR:-/data/adb/hide_env_pack}/pending
      grep -qs '^zygisk_lsposed$' "$he_lh_pend" 2>/dev/null || printf '%s\n' zygisk_lsposed >>"$he_lh_pend" 2>/dev/null
      he_mark lspd todo "LSPosed 模块不在了：已排进补装队列（重启自动装回）；想立刻装：install.sh lsp-upgrade"
    fi
    return 0
  fi
  ( cd "$he_lh_mod" 2>/dev/null && sh ./lspd >/dev/null 2>&1 & ) >/dev/null 2>&1
  sleep 4
  if ps -A 2>/dev/null | grep -q '[l]spd'; then
    he_mark lspd ok "LSPosed 守护进程没在跑，已拉起（重启后仍崩就去升级 LSPosed 版本）"
    return 0
  fi
  he_mark lspd fail "LSPosed 守护进程起不来（会自动覆盖安装并拉起，不用你动手；连续几轮仍不行才需要看日志）。崩溃日志在 /data/adb/lspd/log/daemon-*-crash-*.log"
  return 1
}

he_lsp_comp() { # 打印 LSPosed 管理器的桌面入口组件（pkg/activity）
  he_lc_pkg=${1:-org.lsposed.manager}
  he_lc_c=$(cmd package resolve-activity --brief -c android.intent.category.LAUNCHER "$he_lc_pkg" 2>/dev/null | tail -n 1 | tr -d '\r')
  case "$he_lc_c" in
    */*) printf '%s' "$he_lc_c" ;;
    *) printf '%s/.ui.activity.MainActivity' "$he_lc_pkg" ;;
  esac
}

he_lsp_hide_icon() { # 隐藏 LSPosed / Vector 的桌面图标并关掉通知（要打开走模块页面/终端）
  # 安卓 16 上框架是 Vector（管理器 org.matrix.vector.manager），两个都处理
  he_hi_any=0
  for he_hi_pkg in org.lsposed.manager org.matrix.vector.manager; do
    he_pkg_installed "$he_hi_pkg" || continue
    he_hi_any=1
    he_hide_one_icon "$he_hi_pkg"
  done
  if [ "$he_hi_any" = "0" ]; then
    he_mark lsp_icon skip "没装框架管理器（LSPosed / Vector 都没有），跳过隐藏图标"
    return 0
  fi
  he_mark lsp_icon ok "框架管理器桌面图标已隐藏、通知栏已关闭（打开：模块页面按钮 或 install.sh lsp）"
  return 0
}

he_hide_one_icon() {   # he_hide_one_icon <管理器包名>
  he_hi_pkg="$1"
  he_hi_c=$(he_lsp_comp "$he_hi_pkg")
  # ★ 安卓 16 实测（2026-10-07）：`pm disable-user <组件>` 会静默失败
  #   （回 "Component ... new state: enabled"，桌面图标照旧）——必须用 `pm disable`。
  #   所以先 pm disable，再用 resolve-activity 复核；还认得出来才退回 disable-user。
  pm disable --user 0 "$he_hi_c" >/dev/null 2>&1
  he_hi_st=$(cmd package resolve-activity --brief -c android.intent.category.LAUNCHER "$he_hi_pkg" 2>/dev/null | tail -n 1)
  case "$he_hi_st" in
    */*) pm disable-user --user 0 "$he_hi_c" >/dev/null 2>&1 ;;
  esac
  # 少数版本入口在 alias 上，一并处理
  pm disable --user 0 "$he_hi_pkg/.LauncherActivity" >/dev/null 2>&1
  pm disable-user --user 0 "$he_hi_pkg/.LauncherActivity" >/dev/null 2>&1
  # 通知栏也别出现：先掐掉它的发通知权限，再 force-stop 一次
  # （已经挂在通知栏里的那条只有进程被杀才会消失）
  he_hi_note=""
  if appops set "$he_hi_pkg" POST_NOTIFICATION deny >/dev/null 2>&1; then
    he_hi_note="、通知栏已关闭"
  elif appops set "$he_hi_pkg" POST_NOTIFICATION ignore >/dev/null 2>&1; then
    he_hi_note="、通知栏已关闭"
  elif cmd appops set "$he_hi_pkg" POST_NOTIFICATION deny >/dev/null 2>&1; then
    he_hi_note="、通知栏已关闭"
  fi
  # 悬浮窗也一并关掉（部分 ROM 的 LSPosed 管理器会申请 SAW）
  appops set "$he_hi_pkg" SYSTEM_ALERT_WINDOW deny >/dev/null 2>&1 || \
  cmd appops set "$he_hi_pkg" SYSTEM_ALERT_WINDOW deny >/dev/null 2>&1
  pm revoke "$he_hi_pkg" android.permission.SYSTEM_ALERT_WINDOW >/dev/null 2>&1
  if [ -n "$he_hi_note" ]; then
    am force-stop "$he_hi_pkg" >/dev/null 2>&1   # 清掉已经弹出来的那条
  fi
  return 0
}

he_hma_open() { # 打开「隐藏应用列表」(HMA-OSS) 的管理器
  he_ho_pkg=org.frknkrc44.hma_oss
  if ! he_pkg_installed "$he_ho_pkg"; then
    command -v he_hma_manager >/dev/null 2>&1 && he_hma_manager >/dev/null 2>&1
  fi
  if ! he_pkg_installed "$he_ho_pkg"; then
    echo "! 「隐藏应用列表」管理器没装上：install.sh apps 先补装"
    return 1
  fi
  monkey -p "$he_ho_pkg" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1
  echo "[√] 已尝试打开「隐藏应用列表」"
  return 0
}

he_lsp_open() { # 打开框架管理器（隐藏模式：临时安装 → 打开 → 关闭后自动卸载）
  # 1) 框架先补齐并拉起（修「点开显示未激活 / 打不开」）
  if command -v he_lsp_ensure_framework >/dev/null 2>&1; then
    he_lsp_ensure_framework || echo "[!] 框架没完全就绪：下面仍尝试打开管理器；打开后若显示未激活，再点一次"
  elif command -v he_lsp_health >/dev/null 2>&1; then
    he_lsp_health >/dev/null 2>&1
  fi
  # 框架可能在上面刚换成 Vector，包名以“现在实际装的”为准
  he_lo_pkg=$(he_lsp_active_pkg)
  # 2) 管理器不在（隐藏模式的常态）→ 临时装
  he_lo_temp=0
  if ! he_pkg_installed "$he_lo_pkg"; then
    he_lo_apk=$(he_lsp_manager_apk "$he_lo_pkg") || he_lo_apk=""
    if [ -z "$he_lo_apk" ]; then
      echo "! 找不到 $he_lo_pkg 的管理器 APK（模块目录与 payload 都没有）"
      return 1
    fi
    echo "- 管理器不在（隐藏模式）：临时安装 $he_lo_pkg …"
    if ! he_apk_install "$he_lo_apk" "$he_lo_pkg"; then
      echo "! 管理器安装失败：$(printf '%s' "$HE_APK_PM_OUT" | tr -d '\n' | cut -c1-110)"
      return 1
    fi
    he_lo_temp=1
  fi
  he_lo_state=${HIDE_STATE_DIR:-${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state}
  mkdir -p "$he_lo_state" 2>/dev/null
  printf '%s %s\n' "$he_lo_pkg" "$he_lo_temp" >"$he_lo_state/lsp_manager_open" 2>/dev/null
  he_lsp_lock_surface "$he_lo_pkg"

  # 3) 打开：入口恢复（上次可能被禁）→ 逐个候选组件试 → monkey 兜底
  he_lo_c=$(he_lsp_comp "$he_lo_pkg")
  pm enable --user 0 "$he_lo_c" >/dev/null 2>&1
  he_lo_ok=0
  he_lo_out=""
  for he_lo_try in "$he_lo_c" "$he_lo_pkg/.ui.activity.MainActivity" "$he_lo_pkg/.ui.activity.SplashActivity" "$he_lo_pkg/.MainActivity"; do
    [ -n "$he_lo_try" ] || continue
    he_lo_out=$(am start --user 0 -n "$he_lo_try" 2>&1)
    case "$he_lo_out" in
      *Error*|*error*|*Exception*|*not\ found*|*does\ not\ exist*|*Unable*) continue ;;
    esac
    he_lo_ok=1
    break
  done
  if [ "$he_lo_ok" = "0" ]; then
    he_lo_out=$(monkey -p "$he_lo_pkg" -c android.intent.category.LAUNCHER 1 2>&1)
    case "$he_lo_out" in
      *No\ activities*|*Error*|*error*|*not\ found*) : ;;
      *) he_lo_ok=1 ;;
    esac
  fi
  if [ "$he_lo_ok" = "1" ]; then
    echo "[√] 已打开框架管理器（隐藏安装；界面关闭后自动卸载，桌面/通知栏/悬浮窗都不留）"
  else
    echo "[!] 打开失败：$(printf '%s' "$he_lo_out" | head -n 2 | tr '\n' ' ')"
    echo "    把 install.sh lsp-doctor 的输出发回来"
  fi

  # 4) 看护：界面关闭（或 30 分钟上限）后自动卸载
  ( he_lsp_manager_watch "$he_lo_pkg" "$he_lo_temp" ) >/dev/null 2>&1 &

  # 5) 只有显式 am start 失败才打暗码广播兜底（避免重复开两个界面）
  if [ "$he_lo_ok" = "0" ]; then
    he_lo_api=$(getprop ro.build.version.sdk 2>/dev/null)
    case "$he_lo_api" in ''|*[!0-9]*) he_lo_api=30 ;; esac
    if [ "$he_lo_api" -ge 29 ]; then
      ( am broadcast -a android.telephony.action.SECRET_CODE -d android_secret_code://5776733 android >/dev/null 2>&1 ) >/dev/null 2>&1 &
    else
      ( am broadcast -a android.provider.Telephony.SECRET_CODE -d android_secret_code://5776733 android >/dev/null 2>&1 ) >/dev/null 2>&1 &
    fi
  fi
  return 0
}


# 附加 App（FuseFixer + HMA 管理器 + LSPosed 管理器）：装不装与卡密无关 —— 刷入/每次开机都装；
# 未授权时不会去写 LSPosed 配置库（等于没勾选、不生效），语义仍是"摆设"
# 阿灵游戏助手 · Whitelist520「解决设备标记」里必须删掉 dfm 包名
# （原作者思路：骁龙步骤 5/7、天玑步骤 4 —— 把 com.tencent.tmgp.dfm 从配置里删掉再保存）
# 这步原作者是手拿 MT 管理器改的；这里做成幂等自动：刷入时 + 每次开机都过一遍，
# 改前留 .bak 备份，只摘掉 dfm 那一段，其它内容原样保留。
he_aling_dfm_fix() {
  he_wl="${HE_MODBASE:-/data/adb/modules}/Tenc-ano_tmp/Whitelist520"
  if [ ! -d "$he_wl" ]; then
    he_mark aling_dfm skip "未装阿灵游戏助手（没有 Whitelist520 目录），跳过 dfm 清理"
    return 0
  fi
  he_done=""
  he_left=0
  for he_f in "$he_wl"/*; do
    [ -f "$he_f" ] || continue
    case "$he_f" in *.bak|*.tmp) continue ;; esac
    grep -qs "tmgp\.dfm" "$he_f" 2>/dev/null || continue
    [ -f "$he_f.bak" ] || cp -f "$he_f" "$he_f.bak" 2>/dev/null
    # 1) 列表型：整行删
    grep -v "tmgp\.dfm" "$he_f" >"$he_f.tmp" 2>/dev/null
    if [ -s "$he_f.tmp" ] && ! grep -qs "tmgp\.dfm" "$he_f.tmp"; then
      mv -f "$he_f.tmp" "$he_f" 2>/dev/null
    else
      # 2) 单行型（JSON 或一行里塞了多个包名）：精确摘掉那一段
      sed -e 's/,\s*"\?com\.tencent\.tmgp\.dfm"\?//g' \
          -e 's/"\?com\.tencent\.tmgp\.dfm"\?,\s*//g' \
          -e 's/"\?com\.tencent\.tmgp\.dfm"\?//g' "$he_f" >"$he_f.tmp" 2>/dev/null && mv -f "$he_f.tmp" "$he_f" 2>/dev/null
    fi
    rm -f "$he_f.tmp" 2>/dev/null
    chmod 0666 "$he_f" 2>/dev/null
    if grep -qs "tmgp\.dfm" "$he_f" 2>/dev/null; then
      he_left=1
      he_done="$he_done $(basename "$he_f")(没删净!)"
    else
      he_done="$he_done $(basename "$he_f")"
    fi
  done
  if [ -n "$he_done" ]; then
    if [ "$he_left" = "1" ]; then
      he_mark aling_dfm fail "Whitelist520 里的 dfm 没删净（$he_done）；可在 MT 管理器里手动删掉 com.tencent.tmgp.dfm"
    else
      he_mark aling_dfm ok "已从 Whitelist520 删掉 dfm 包名（$he_done，原文件备份为 .bak）"
    fi
  else
    he_mark aling_dfm ok "Whitelist520 里没有 dfm 包名（已是干净状态）"
  fi
  return 0
}

he_apps_ensure() {
  he_init
  command -v he_aling_dfm_fix >/dev/null 2>&1 && he_aling_dfm_fix
  # 天玑方案：不装 LSPosed / FuseFixer（原方案的天玑清单里没有它们），
  # 也就没有 LSPosed 管理器与图标要处理；HMA 管理器照装。
  he_apps_has_fw=0
  [ -d "${HE_MODBASE:-/data/adb/modules}/zygisk_lsposed" ] && he_apps_has_fw=1
  [ -d "${HE_MODBASE:-/data/adb/modules}/zygisk_vector" ] && he_apps_has_fw=1
  if [ "${PACK_SKIP_FUSE:-0}" = "1" ] || pack_soc_is_mtk 2>/dev/null || [ "$he_apps_has_fw" = "0" ]; then
    he_mark fuse_app skip "当前方案不需要 FuseFixer（天玑 / 无 LSPosed 框架 / 四合一）"
  else
    he_fuse_app_ensure
  fi
  he_hma_manager
  if command -v he_lsp_hidden_mode >/dev/null 2>&1 && he_lsp_hidden_mode; then
    # 隐藏模式：管理器不常驻（只清上次异常退出/重启前的残留），打开走面具「动作」按钮
    he_lsp_manager
  elif [ "${PACK_SKIP_LSPOSED:-0}" = "1" ] || [ "$he_apps_has_fw" = "0" ]; then
    # 天玑方案不装 LSPosed —— 但旧版本刷进去的残留可能还在（图标还在桌面、
    # 检测也看得见）。这里对残留做"能藏就藏"，并提示怎么彻底移除。
    if he_pkg_installed org.lsposed.manager; then
      command -v he_lsp_hide_icon >/dev/null 2>&1 && he_lsp_hide_icon >/dev/null 2>&1
      he_mark lsp_manager skip "天玑方案不装 LSPosed；检测到机器上还留着旧版，已隐藏图标与通知并保留可用（要用就 install.sh lsp；不建议删）"
    else
      he_mark lsp_manager skip "天玑方案：不装 LSPosed 与其管理器"
    fi
  else
    he_lsp_manager
    command -v he_lsp_hide_icon >/dev/null 2>&1 && he_lsp_hide_icon   # 桌面不留 LSPosed 图标
  fi
  # 管理器"包列表隐身"会让人打不开面具，默认不自动执行；需要时手动 mask on
  he_write_report >/dev/null 2>&1
  return 0
}

# ---------------------------------------------------------------
# OMK 接管状态采样（排查「每次重启报告都不一样」）
#   记录一行：时间|keystore进程|注入是否活着|keybox|soter|pif|verifiedboot
#   「注入是否活着」= keystore 进程的 maps 里有 OMK 的 inject/keymint，
#   或独立 keymint 进程在跑 —— 检测读到的是「接管后的样子」还是「真机」就看这个。
# ---------------------------------------------------------------
HE_OMK_PROC=${HE_OMK_PROC:-/proc}

he_omk_state_line() {
  he_os_ts=$(date '+%m-%d %H:%M:%S' 2>/dev/null)
  he_os_ks="无"
  for he_os_n in keystore2 keystore; do
    if pidof "$he_os_n" >/dev/null 2>&1; then
      he_os_ks="$he_os_n:$(pidof $he_os_n 2>/dev/null | tr ' ' ',')"
      break
    fi
  done
  he_os_inj="否"
  if command -v pidof >/dev/null 2>&1; then
    for he_os_n in keystore2 keystore; do
      for he_os_pid in $(pidof "$he_os_n" 2>/dev/null); do
        if grep -qs -i 'omk\|oh_my_keymint' "$HE_OMK_PROC/$he_os_pid/maps" 2>/dev/null; then
          he_os_inj="是"
          break 2
        fi
      done
    done
  fi
  pidof keymint >/dev/null 2>&1 && he_os_inj="是(keymint)"
  he_os_kb=$([ -s "$OMK_DIR/keybox.xml" ] && echo "$(wc -c <"$OMK_DIR/keybox.xml" 2>/dev/null | tr -d ' ')B" || echo 无)
  he_os_st=$([ -s "$OMK_DATA/soterta/enabled" ] && echo 开 || echo 关)
  he_os_pf=$([ -s "$OMK_DATA/pif_fingerprint.json" ] && echo 有 || echo 无)
  he_os_vb=""
  command -v getprop >/dev/null 2>&1 && he_os_vb=$(getprop ro.boot.verifiedbootstate 2>/dev/null)
  printf '%s|keystore=%s|注入=%s|keybox=%s|soter=%s|pif=%s|vb=%s' \
    "$he_os_ts" "$he_os_ks" "$he_os_inj" "$he_os_kb" "$he_os_st" "$he_os_pf" "${he_os_vb:-?}"
}

he_omk_verify() {   # 硬验收：keybox hash + scoop 条数 + soter/pif 合成一行
  he_ov_scheme=$(cat "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/scheme.txt" 2>/dev/null | tr -d ' \r\n')
  if [ "$he_ov_scheme" = "b" ]; then
    he_mark omk_verify skip "方案 B（四合一）：OMK 不参与，验收看 TrickyStore 两项"
    return 0
  fi
  # keybox：生效文件必须与模块副本 / 隐藏镜像 / 上次记录三选一完全一致
  he_ov_kb="✗"
  he_ov_live="$OMK_DIR/keybox.xml"
  if [ -s "$he_ov_live" ] && grep -q '</Keybox>' "$he_ov_live" 2>/dev/null; then
    he_ov_lh=$(he_sha "$he_ov_live" 2>/dev/null)
    for he_ov_ref in "$OMK_MOD/keybox.xml" "$HE_KB_MIRROR" "$HIDE_STATE_DIR/keybox.expected"; do
      [ -s "$he_ov_ref" ] || continue
      he_ov_rh=$(he_sha "$he_ov_ref" 2>/dev/null)
      if [ -n "$he_ov_lh" ] && [ "$he_ov_lh" = "$he_ov_rh" ]; then
        he_ov_kb="✓"
        printf '%s\n' "$he_ov_lh" >"$HIDE_STATE_DIR/keybox.expected" 2>/dev/null
        break
      fi
    done
  fi
  # scoop：直接数 injector.toml 实际生效的数组行，不信缓存
  he_ov_n=$(sed -n '/^[[:space:]]*scoop[[:space:]]*=[[:space:]]*\[/,/\]/p' "$OMK_DIR/injector.toml" 2>/dev/null \
            | grep -v 'scoop' | grep -v '^[[:space:]]*\]' | grep -c . 2>/dev/null)
  case "$he_ov_n" in ''|*[!0-9]*) he_ov_n=0 ;; esac
  he_ov_sc="✗"; [ "$he_ov_n" -ge 3 ] 2>/dev/null && he_ov_sc="✓"
  # soter：A 线看状态，兼容旧版 soterta 文件
  he_ov_so="✗"
  case "$(he_state_of omk_soter 2>/dev/null)" in ok*) he_ov_so="✓" ;; esac
  [ -s "$OMK_DATA/soterta/enabled" ] && he_ov_so="✓"
  # pif：ok 与 ok(offline) 都算配置完成；离线明确标注
  he_ov_pf="✗"
  case "$(he_state_of omk_pif 2>/dev/null)" in
    ok)          he_ov_pf="✓" ;;
    "ok(offline)") he_ov_pf="✓(offline)" ;;
  esac
  he_ov_line="OMK: keybox${he_ov_kb} scoop ${he_ov_n}${he_ov_sc} soter${he_ov_so} pif${he_ov_pf}"
  case "${he_ov_kb}${he_ov_sc}${he_ov_so}" in
    *✗*) he_mark omk_verify fail "$he_ov_line" ;;
    *) case "$he_ov_pf" in ✗) he_mark omk_verify fail "$he_ov_line" ;; *) he_mark omk_verify ok "$he_ov_line" ;; esac ;;
  esac
  return 0
}

he_omk_state_log() {   # 追加一笔（滚动保留 200 行）
  he_ol_dir=${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}
  mkdir -p "$he_ol_dir" 2>/dev/null
  printf '%s\n' "$(he_omk_state_line)" >>"$he_ol_dir/omk_boot.log" 2>/dev/null
  he_ol_n=$(wc -l <"$he_ol_dir/omk_boot.log" 2>/dev/null | tr -d ' ')
  case "$he_ol_n" in
    ''|*[!0-9]*) : ;;
    *) [ "$he_ol_n" -gt 200 ] && tail -n 200 "$he_ol_dir/omk_boot.log" >"$he_ol_dir/omk_boot.log.t" 2>/dev/null && mv -f "$he_ol_dir/omk_boot.log.t" "$he_ol_dir/omk_boot.log" 2>/dev/null ;;
  esac
  return 0
}

he_omk_report_notlive() {   # 注入没活 → 把最近采样传上云（控制台「看排查报告」能看到）
  he_or_dir=${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}
  he_or_txt="【OMK 接管异常】开机后 2 分钟内没检测到注入活着 ——
检测读到的是真机状态（BL 锁/密钥会直接暴露），这正是「报告每次重启都不一样」的典型现象。
最近采样（时间|keystore|注入|keybox|soter|pif|vb）：
$(tail -n 8 "$he_or_dir/omk_boot.log" 2>/dev/null)
处理：跑 install.sh omk-reinject（重启 keystore 让接管重来），再进检测看一次。"
  command -v he_lic_http_post >/dev/null 2>&1 || return 0
  he_or_tok=$(he_lic_get token 2>/dev/null)
  [ -n "$he_or_tok" ] || return 0
  he_or_url=$(he_lic_server 2>/dev/null)
  [ -n "$he_or_url" ] || return 0
  he_or_hw=$(he_lic_hwid 2>/dev/null)
  he_or_b64=$(printf '%s' "$he_or_txt" | he_b64 2>/dev/null | tr -d '\n\r')
  [ -n "$he_or_b64" ] || return 0
  he_or_body=$(printf '{"token":"%s","hwid":"%s","rep_b64":"%s"}' "$he_or_tok" "$he_or_hw" "$he_or_b64")
  he_lic_http_post "$he_or_url/api/diag" "$he_or_body" >/dev/null 2>&1
  return 0
}

he_lspd_running() {   # 0 = 框架守护进程在跑（LSPosed 的 lspd 或 Vector 的 daemon）
  if [ -n "${HE_LSPD_RUN_OVERRIDE:-}" ]; then
    [ "$HE_LSPD_RUN_OVERRIDE" = "1" ]
    return $?
  fi
  # 自测钩子：读一个文件当状态（『修好』后把里面写 1 即可模拟）
  if [ -n "${HE_LSPD_RUN_FILE:-}" ]; then
    grep -qs 1 "$HE_LSPD_RUN_FILE" 2>/dev/null
    return $?
  fi
  command -v ps >/dev/null 2>&1 || return 1
  ps -A 2>/dev/null | grep -q '[l]spd' && return 0
  ps -A 2>/dev/null | grep -qE 'org.matrix.vector.daemon.VectorDaemon|[v]ectord' && return 0
  return 1
}

he_lsp_report_heal() {   # 自愈结果传上云（和 OMK 自愈同一条通道）
  he_lr_txt="【框架自愈】$(date '+%m-%d %H:%M:%S' 2>/dev/null)
$(tail -n 8 "${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}/lsp_heal.log" 2>/dev/null)"
  command -v he_lic_http_post >/dev/null 2>&1 || return 0
  he_lr_tok=$(he_lic_get token 2>/dev/null)
  [ -n "$he_lr_tok" ] || return 0
  he_lr_url=$(he_lic_server 2>/dev/null)
  [ -n "$he_lr_url" ] || return 0
  he_lr_hw=$(he_lic_hwid 2>/dev/null)
  he_lr_b64=$(printf '%s' "$he_lr_txt" | he_b64 2>/dev/null | tr -d '\n\r')
  [ -n "$he_lr_b64" ] || return 0
  he_lic_http_post "$he_lr_url/api/diag" "$(printf '{"token":"%s","hwid":"%s","rep_b64":"%s"}' "$he_lr_tok" "$he_lr_hw" "$he_lr_b64")" >/dev/null 2>&1
  return 0
}

he_lsp_selfheal() {   # 框架守护进程自愈（SDK 感知：16+ 自动用 Vector 接手）
  command -v he_lsp_miui_theme_fix >/dev/null 2>&1 && he_lsp_miui_theme_fix
  he_ls_mb=${HE_MODBASE:-/data/adb/modules}
  he_ls_sdk=$(getprop ro.build.version.sdk 2>/dev/null)
  case "$he_ls_sdk" in ''|*[!0-9]*) he_ls_sdk=0 ;; esac
  if [ "$he_ls_sdk" -ge 36 ]; then
    # 安卓16：LSPosed 2.2.1 的 lspd 一启动就段错误 → 用包内 Vector 接管。
    # 不再要求设备上已有框架：两个目录都不存在时也要补装（全新刷入的 16 机器就靠这里）。
    he_ls_dir=${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}
    mkdir -p "$he_ls_dir" 2>/dev/null
    printf '%s [框架自愈] 安卓16：检查/补装 Vector\n' "$(date '+%m-%d %H:%M:%S')" >>"$he_ls_dir/lsp_heal.log" 2>/dev/null
    if command -v he_lsp_ensure_framework >/dev/null 2>&1 && he_lsp_ensure_framework >/dev/null 2>&1; then
      printf '%s [框架自愈] Vector 已就绪\n' "$(date '+%m-%d %H:%M:%S')" >>"$he_ls_dir/lsp_heal.log" 2>/dev/null
      he_lsp_report_heal 2>/dev/null
    else
      printf '%s [框架自愈] Vector 补装/拉起失败（下次开机再试）\n' "$(date '+%m-%d %H:%M:%S')" >>"$he_ls_dir/lsp_heal.log" 2>/dev/null
    fi
    return 0
  fi
  if [ -d "$he_ls_mb/zygisk_vector" ]; then
    # 非 16 但已有 Vector：vectord 没跑就拉起（静默，不写 LSPosed 自愈日志）
    if ! ps -A 2>/dev/null | grep -qE 'org\.matrix\.vector\.daemon\.VectorDaemon|[v]ectord'; then
      command -v he_vector_daemon_start >/dev/null 2>&1 && he_vector_daemon_start >/dev/null 2>&1
    fi
    return 0
  fi
  [ -d "$he_ls_mb/zygisk_lsposed" ] || return 0   # 不是 16 且两个框架都没有：不管
  he_ls_dir=${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}
  mkdir -p "$he_ls_dir" 2>/dev/null
  he_ls_mark="$he_ls_dir/lsp_heal_tries"
  if he_lspd_running; then
    rm -f "$he_ls_mark" 2>/dev/null
    return 0
  fi
  he_ls_n=0
  [ -s "$he_ls_mark" ] && he_ls_n=$(cat "$he_ls_mark" 2>/dev/null | tr -d '\n\r')
  case "$he_ls_n" in ''|*[!0-9]*) he_ls_n=0 ;; esac
  # 2026-10-15：不再"修两次就算了"——要求是「一次性通关、别让客户再刷一次」，
  # 所以每次调用都继续修（动作是幂等的：覆盖安装 + 拉起），次数只用于记账/观察。
  he_ls_n=$((he_ls_n + 1))
  printf '%s' "$he_ls_n" >"$he_ls_mark" 2>/dev/null
  if [ "$he_ls_n" -ge 3 ]; then
    printf '%s [框架自愈] 第 %s 次覆盖安装（仍起不来就继续修；状态见体检 lspd 一行）\n' \
      "$(date '+%m-%d %H:%M:%S')" "$he_ls_n" >>"$he_ls_dir/lsp_heal.log" 2>/dev/null
  fi
  printf '%s [框架自愈] 第 %s 次：lspd 没在跑 → 覆盖安装框架（同 install.sh lsp-upgrade）\n' \
    "$(date '+%m-%d %H:%M:%S')" "$he_ls_n" >>"$he_ls_dir/lsp_heal.log" 2>/dev/null
  if [ -n "${HE_LSP_UPGRADE_CMD:-}" ]; then
    sh -c "$HE_LSP_UPGRADE_CMD" >/dev/null 2>&1
  else
    command -v pack_init >/dev/null 2>&1 && pack_init keep >/dev/null 2>&1
    command -v pack_install_one >/dev/null 2>&1 && pack_install_one "lsposed.zip" "LSPosed（自愈·覆盖安装）" >/dev/null 2>&1
  fi
  sleep 3
  if he_lspd_running; then
    printf '%s [框架自愈] 修好了（守护进程已在跑）\n' "$(date '+%m-%d %H:%M:%S')" >>"$he_ls_dir/lsp_heal.log" 2>/dev/null
    rm -f "$he_ls_mark" 2>/dev/null
    he_lsp_report_heal
  else
    printf '%s [框架自愈] 还是没起来（下次开机再试一次）\n' "$(date '+%m-%d %H:%M:%S')" >>"$he_ls_dir/lsp_heal.log" 2>/dev/null
  fi
  return 0
}

he_omk_report_heal() {   # 自愈前后对照传上云
  he_hr_txt="【OMK 接管自愈】$(date '+%m-%d %H:%M:%S' 2>/dev/null)
处理前：$1
处理后：$2
（用来对照"手动配置为什么能修好"：处理后注入=是 → 关键动作就是重装密钥/重启 keystore）
最近采样：
$(tail -n 6 "${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}/omk_boot.log" 2>/dev/null)"
  command -v he_lic_http_post >/dev/null 2>&1 || return 0
  he_hr_tok=$(he_lic_get token 2>/dev/null)
  [ -n "$he_hr_tok" ] || return 0
  he_hr_url=$(he_lic_server 2>/dev/null)
  [ -n "$he_hr_url" ] || return 0
  he_hr_hw=$(he_lic_hwid 2>/dev/null)
  he_hr_b64=$(printf '%s' "$he_hr_txt" | he_b64 2>/dev/null | tr -d '\n\r')
  [ -n "$he_hr_b64" ] || return 0
  he_lic_http_post "$he_hr_url/api/diag" "$(printf '{"token":"%s","hwid":"%s","rep_b64":"%s"}' "$he_hr_tok" "$he_hr_hw" "$he_hr_b64")" >/dev/null 2>&1
  return 0
}

he_omk_selfheal() {   # 接管没活 → 自动重做"手动配置"那几步（每次开机最多一次）
  he_sh_dir=${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}
  mkdir -p "$he_sh_dir" 2>/dev/null
  he_sh_mark="$he_sh_dir/omk_heal_done"
  he_sh_boot=${HE_OMK_BOOT_ID:-}
  if [ -z "$he_sh_boot" ]; then
    he_sh_boot=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d '\n\r')
  fi
  [ -n "$he_sh_boot" ] || he_sh_boot=$(cut -d' ' -f1 /proc/uptime 2>/dev/null | cut -d. -f1)
  [ -n "$he_sh_boot" ] || he_sh_boot=unknown
  if [ -s "$he_sh_mark" ] && [ "$(cat "$he_sh_mark" 2>/dev/null | tr -d '\n\r')" = "$he_sh_boot" ]; then
    return 0   # 这次开机已经自愈过，别反复折腾
  fi
  he_sh_before=$(he_omk_state_line)
  case "$he_sh_before" in
    *"注入=否"*) : ;;
    *) return 0 ;;   # 已经好的不动它
  esac
  printf '%s' "$he_sh_boot" >"$he_sh_mark" 2>/dev/null
  printf '  [自愈] 接管没活 → 重做授权相关配置（强制重装密钥 / 重开 Soter / 必要时重启 keystore）\n' >>"$he_sh_dir/omk_boot.log" 2>/dev/null

  he_sh_old_force=$HIDE_FORCE
  HIDE_FORCE=1
  command -v he_omk_keybox >/dev/null 2>&1 && he_omk_keybox >/dev/null 2>&1
  command -v he_omk_soter >/dev/null 2>&1 && he_omk_soter >/dev/null 2>&1
  HIDE_FORCE=$he_sh_old_force
  sleep 4
  he_sh_mid=$(he_omk_state_line)
  case "$he_sh_mid" in
    *"注入=否"*) command -v he_omk_reinject >/dev/null 2>&1 && he_omk_reinject >/dev/null 2>&1 ;;
  esac
  sleep 2
  he_sh_after=$(he_omk_state_line)
  printf '  [自愈结果] 处理前：%s\n             处理后：%s\n' "$he_sh_before" "$he_sh_after" >>"$he_sh_dir/omk_boot.log" 2>/dev/null
  he_omk_report_heal "$he_sh_before" "$he_sh_after"
  # 自愈后的状态也进采样流（便于下一次对照）
  he_omk_state_log
  return 0
}

he_omk_boot_watch() {   # service.sh 里后台跑：分 4 个时间点采样，最后判定
  # 等待点可在自测里覆盖（HE_OMK_WATCH_WAITS="1 1"），正常用默认
  he_ow_waits=${HE_OMK_WATCH_WAITS:-"5 40 75 60"}
  he_ow_i=0
  for he_ow_w in $he_ow_waits; do
    sleep "$he_ow_w"
    he_omk_state_log
    he_ow_i=$((he_ow_i + 1))
    # 第二次采样后（约 45 秒，接管该起来了）：没活就自动重做"手动配置"那几步
    [ "$he_ow_i" = "2" ] && he_omk_selfheal
  done
  he_ow_last=$(tail -n 1 "${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}/omk_boot.log" 2>/dev/null)
  case "$he_ow_last" in
    *"注入=否"*) he_omk_report_notlive ;;
  esac
  return 0
}

he_omk_status() {   # 看历史采样（终端/控制台都能用）
  he_oy_dir=${HIDE_STATE_DIR:-$HIDE_ENV_DIR/state}
  echo "- OMK 接管状态（当前）："
  echo "  $(he_omk_state_line)"
  if [ -s "$he_oy_dir/omk_boot.log" ]; then
    echo "- 最近几次开机采样（注入=否 说明那次开机接管没起来 → 检测会看到真机）："
    tail -n 12 "$he_oy_dir/omk_boot.log" | sed 's/^/  /'
  else
    echo "  （还没有采样记录：升级到本版后重启一次即开始记录）"
  fi
}

he_omk_reinject() {   # 让 OMK 重新接管：优先用 OMK 自带的热重启，兜底才重启 keystore
  # ★ 2026-10-11：OMK 官方文档给了热重启开关（resetprop persist.sys.omk.restart.*，
  #   还有 /data/adb/omk/ 下的同名触发文件）——只重启 OMK 自己的 keymint/injector，
  #   比 ctl.restart keystore 轻得多（不动系统服务、不打断其它 App）。
  echo "- 让 OMK 重新接管（优先热重启）"
  he_ok=0
  for he_p in persist.sys.omk.restart.keymint persist.sys.omk.restart.injector persist.sys.omk.restart.all; do
    if command -v resetprop >/dev/null 2>&1; then
      resetprop "$he_p" 1 2>/dev/null && he_ok=1
    else
      setprop "$he_p" 1 2>/dev/null && he_ok=1
    fi
  done
  mkdir -p /data/adb/omk 2>/dev/null
  for he_t in /data/adb/omk/restart.keymint /data/adb/omk/restart.injector /data/adb/omk/restart.all; do
    : >"$he_t" 2>/dev/null && he_ok=1
  done
  if [ "$he_ok" = "1" ]; then
    sleep 6
    case "$(he_omk_state_line)" in
      *"注入=是"*)
        echo "  [√] OMK 已重新接管（热重启，未动系统服务）"
        he_omk_state_log
        return 0 ;;
    esac
    echo "  [~] 热重启后还没看到接管，再走 keystore 重启兜底"
  fi
  echo "- 重启 keystore 服务（接管会重来；密钥与数据不受影响）"
  for he_oz_svc in keystore2 keystore; do
    setprop "ctl.restart" "$he_oz_svc" 2>/dev/null && echo "  · 已请求重启 $he_oz_svc"
  done
  command -v setprop >/dev/null 2>&1 || echo "  ! 没有 setprop，改用 stop/start"
  sleep 6
  echo "- 重启后状态："
  echo "  $(he_omk_state_line)"
  he_omk_state_log
  case "$(he_omk_state_line)" in
    *"注入=否"*) echo "  [×] 还是没看到注入活着 —— 再重启一次手机；仍不行跑 install.sh diag 后把这台设备卡号发我" ;;
    *) echo "  [√] 注入已在（现在进检测看一下）" ;;
  esac
}

# 用自带的静态 sqlite3 往 LSPosed 配置库里写入启用状态与作用域
#
# 表结构按上游源码实证（LSPosed 2.0.4 daemon/ConfigManager.java + 1.9.x/1.8.x 两代）：
#   v2      2.0.x（本包自带的就是它）：
#           modules(mid INTEGER PRIMARY KEY AUTOINCREMENT, module_pkg_name UNIQUE,
#                   apk_path, enabled DEFAULT 0)
#           scope(mid, app_pkg_name, user_id, PRIMARY KEY(mid,app_pkg_name,user_id),
#                 FOREIGN KEY(mid) REFERENCES modules(mid) ON DELETE CASCADE)
#           加载规则：daemon 从库里读 enabled=1 的模块；模块按"已安装应用"识别
#           （APK 含 META-INF/xposed/java_init.list 或 assets/xposed_init）
#   classic 1.9.x：modules(module_pkg_name, apk_path)
#                 modules_state(module_pkg_name, user_id, enabled, scope_request_blocked)
#                 scope(module_pkg_name, app_pkg_name, user_id)
#   legacy  1.8.x 及更早：没有 modules_state/enabled，scope 直接挂包名（在库里=启用）
# 判定方式：modules 有 mid 列 → v2；否则有 modules_state → classic；否则 scope 有
#           module_pkg_name 列 → legacy；都不认 → 返回 7（提示手动勾选）。
he_fuse_framework_ok() {   # 有没有可用的 Xposed 框架（LSPosed 的 lspd 或 Vector 的 vectord 在跑）
  ps -A 2>/dev/null | grep -q '[l]spd' && return 0
  ps -A 2>/dev/null | grep -qE 'org.matrix.vector.daemon.VectorDaemon|[v]ectord' && return 0
  return 1
}

he_fuse_db_patch() {
  he_lite=$HIDE_BIN/sqlite3
  [ -x "$he_lite" ] || he_lite=$(command -v sqlite3 2>/dev/null)
  [ -n "$he_lite" ] && [ -x "$he_lite" ] || return 2

  # Vector 的 daemon 硬编码读 /data/adb/lspd/config/modules_config.db
  # （jadx 实证：qa.java 静态常量 + t8.java 建表，DATABASE_VERSION=4）。
  # 库不存在时按同一份 v4 结构建出来，避免“首次开机才有库”的死循环。
  he_db=""
  if [ -s "$LSP_DB" ]; then
    he_db=$LSP_DB
  else
    for he_cand in $(ls /data/adb/lspd/config/*.db /data/adb/vector/config/*.db 2>/dev/null); do
      case "$he_cand" in
        *-wal|*-shm) continue ;;
      esac
      he_db=$he_cand
      break
    done
  fi
  if [ -z "$he_db" ] || [ ! -s "$he_db" ]; then
    mkdir -p /data/adb/lspd/config 2>/dev/null || return 3
    chmod 0700 /data/adb/lspd /data/adb/lspd/config 2>/dev/null
    chcon u:object_r:system_file:s0 /data/adb/lspd /data/adb/lspd/config 2>/dev/null
    he_db=$LSP_DB
    he_sql_init="PRAGMA user_version=4;
CREATE TABLE IF NOT EXISTS modules (
    mid integer PRIMARY KEY AUTOINCREMENT,
    module_pkg_name text NOT NULL UNIQUE,
    apk_path text NOT NULL,
    enabled BOOLEAN DEFAULT 0 CHECK (enabled IN (0, 1)),
    auto_include BOOLEAN DEFAULT 0 CHECK (auto_include IN (0, 1))
);
CREATE TABLE IF NOT EXISTS scope (
    mid integer,
    app_pkg_name text NOT NULL,
    user_id integer NOT NULL,
    PRIMARY KEY (mid, app_pkg_name, user_id),
    CONSTRAINT scope_module_constraint FOREIGN KEY (mid) REFERENCES modules (mid) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS configs (
    module_pkg_name text NOT NULL,
    user_id integer NOT NULL,
    \`group\` text NOT NULL,
    \`key\` text NOT NULL,
    data blob NOT NULL,
    PRIMARY KEY (module_pkg_name, user_id, \`group\`, \`key\`),
    CONSTRAINT config_module_constraint FOREIGN KEY (module_pkg_name) REFERENCES modules (module_pkg_name) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS configs_idx ON configs (module_pkg_name, user_id);
INSERT OR IGNORE INTO modules (module_pkg_name, apk_path) VALUES ('lspd', '/data/adb/modules/zygisk_vector/manager.apk');"
    if ! printf '%s\n' "$he_sql_init" | "$he_lite" "$he_db" >/dev/null 2>&1; then
      rm -f "$he_db" "$he_db-wal" "$he_db-shm" 2>/dev/null
      return 3
    fi
    chmod 0600 "$he_db" 2>/dev/null
    chown 0:0 "$he_db" 2>/dev/null
  fi
  [ -n "$he_db" ] && [ -s "$he_db" ] || return 3
  # 旧版本可能残留 user_version=0；补到 4，避免 Vector 触发 onDowngrade 清库
  he_uv=$("$he_lite" "$he_db" "PRAGMA user_version;" 2>/dev/null | tr -d '\r')
  case "$he_uv" in 0|'') "$he_lite" "$he_db" "PRAGMA user_version=4;" >/dev/null 2>&1 ;; esac

  # 结构判定（三套，来源见上方注释）
  he_cols=$("$he_lite" "$he_db" "SELECT name FROM pragma_table_info('modules');" 2>/dev/null | tr -d '\r' | tr '\n' ' ')
  case "$he_cols" in
    *"mid "*)
      he_schema="v2"
      ;;
    *)
      he_has=$("$he_lite" "$he_db" "SELECT name FROM sqlite_master WHERE type='table' AND name='modules_state';" 2>/dev/null | tr -d '\r')
      if [ "$he_has" = "modules_state" ]; then
        he_schema="classic"
      else
        he_has=$("$he_lite" "$he_db" "SELECT name FROM pragma_table_info('scope') WHERE name='module_pkg_name';" 2>/dev/null | tr -d '\r')
        if [ "$he_has" = "module_pkg_name" ]; then
          he_schema="legacy"
        else
          return 7
        fi
      fi
      ;;
  esac

  he_apath=$(pm path $FUSE_PKG 2>/dev/null | head -n 1 | sed 's/^package://')
  [ -n "$he_apath" ] || return 4

  he_scope_list=$(printf '%s\n' $FUSE_SCOPE_DEFAULT)
  if [ -s "$HIDE_CFG_DIR/lsposed_scope.txt" ]; then
    he_scope_list=$(printf '%s\n%s\n' "$he_scope_list" "$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HIDE_CFG_DIR/lsposed_scope.txt" | grep -v '^$')")
  fi

  # 回读用的作用域清单（拼成 SQL 的 IN 列表）
  he_scope_in=""
  for he_s in $he_scope_list; do
    he_scope_in="${he_scope_in}'$he_s',"
  done
  he_scope_in=${he_scope_in%,}

  if [ "$he_schema" = "v2" ]; then
    # 2.0.x：先登记模块行（apk_path 是 NOT NULL 必填），再 enabled=1；
    # 作用域行靠 mid 关联（外键 ON DELETE CASCADE，回滚删模块行即可连带清掉）
    he_sql="BEGIN;
INSERT OR IGNORE INTO modules(module_pkg_name, apk_path, enabled) VALUES('$FUSE_PKG','$he_apath',1);
UPDATE modules SET enabled=1 WHERE module_pkg_name='$FUSE_PKG';"
    for he_s in $he_scope_list; do
      he_sql="$he_sql
INSERT OR IGNORE INTO scope(mid, app_pkg_name, user_id) SELECT mid, '$he_s', 0 FROM modules WHERE module_pkg_name='$FUSE_PKG';"
    done
    he_sql="$he_sql
COMMIT;"
    he_readback="SELECT enabled FROM modules WHERE module_pkg_name='$FUSE_PKG';"
    he_scopeback="SELECT count(*) FROM scope, modules WHERE scope.mid=modules.mid AND modules.module_pkg_name='$FUSE_PKG' AND scope.user_id=0 AND scope.app_pkg_name IN ($he_scope_in);"
  elif [ "$he_schema" = "legacy" ]; then
    # 1.8.x：库里登记 + 作用域挂包名；没有 enabled 列，登记即启用
    he_sql="BEGIN;
INSERT OR IGNORE INTO modules(module_pkg_name, apk_path) VALUES('$FUSE_PKG','$he_apath');"
    for he_s in $he_scope_list; do
      he_sql="$he_sql
INSERT OR IGNORE INTO scope(module_pkg_name, app_pkg_name, user_id) VALUES('$FUSE_PKG','$he_s',0);"
    done
    he_sql="$he_sql
COMMIT;"
    he_readback="SELECT count(*) FROM modules WHERE module_pkg_name='$FUSE_PKG';"
    he_scopeback="SELECT count(*) FROM scope WHERE module_pkg_name='$FUSE_PKG' AND user_id=0 AND app_pkg_name IN ($he_scope_in);"
  else
    # 1.9.x：modules 登记 + modules_state.enabled=1 + scope
    he_sql="BEGIN;
INSERT OR REPLACE INTO modules(module_pkg_name, apk_path) VALUES('$FUSE_PKG','$he_apath');
INSERT OR REPLACE INTO modules_state(module_pkg_name, user_id, enabled, scope_request_blocked) VALUES('$FUSE_PKG', 0, 1, 0);"
    for he_s in $he_scope_list; do
      he_sql="$he_sql
INSERT OR IGNORE INTO scope(module_pkg_name, app_pkg_name, user_id) VALUES('$FUSE_PKG','$he_s',0);"
    done
    he_sql="$he_sql
COMMIT;"
    he_readback="SELECT enabled FROM modules_state WHERE module_pkg_name='$FUSE_PKG' AND user_id=0;"
    he_scopeback="SELECT count(*) FROM scope WHERE module_pkg_name='$FUSE_PKG' AND user_id=0 AND app_pkg_name IN ($he_scope_in);"
  fi

  he_out=$(printf '%s\n' "$he_sql" | "$he_lite" "$he_db" 2>&1)
  if [ -n "$he_out" ]; then
    printf '[cfg] lsposed db(%s): %s\n' "$he_schema" "$he_out" >>"$HIDE_LOG" 2>/dev/null
    case "$he_out" in
      *"Error"*|*"error"*|*"unable"*) return 5 ;;
    esac
  fi

  # 回读两件事：启用状态 + 作用域行数（只写一半也能被发现）
  he_en=$("$he_lite" "$he_db" "$he_readback" 2>/dev/null | tr -d '\r' | head -n 1)
  case "$he_schema" in
    v2|classic)
      [ "$he_en" = "1" ] || return 6
      ;;
    *)
      case "$he_en" in ''|0) return 6 ;; esac
      ;;
  esac
  he_sc=$("$he_lite" "$he_db" "$he_scopeback" 2>/dev/null | tr -d '\r' | head -n 1)
  case "$he_sc" in ''|*[!0-9]*) he_sc=0 ;; esac
  [ "$he_sc" -gt 0 ] || return 8
  printf '%s' "$he_schema" >"$HIDE_STATE_DIR/.lsp_schema" 2>/dev/null
  return 0
}

he_lsposed_fusefixer() {
  # 沙盒/自测模式：不装 APK、不动真实的 LSPosed 配置库
  if [ "${HIDE_SKIP_APK:-}" = "1" ]; then
    he_mark fuse_fixer skip "沙盒模式：已跳过 FuseFixer 的安装与 LSPosed 启用"
    return 0
  fi
  he_via=""

  # 先确保 App 装上（装不上就谈不上勾选；失败原因在 fuse_app 一行里能直接看到）
  if pm path $FUSE_PKG >/dev/null 2>&1; then
    he_via="APK 已存在"
  elif he_fuse_install_apk; then
    he_via="本次补装 APK"
  else
    he_mark fuse_fixer fail "FuseFixer App 没装上（看 fuse_app 一行）：$(printf '%s' "$HE_FUSE_PM_OUT" | tr -d '\n' | cut -c1-100)"
    return 1
  fi
  he_fuse_app_ensure >/dev/null 2>&1   # 同步刷新 fuse_app 状态行

  he_fuse_db_patch
  he_rc=$?
  HE_FUSE_RC=$he_rc
  case "$he_rc" in
    0) he_mark fuse_fixer ok "FuseFixer 已在 LSPosed 里启用并勾选作用域=MediaProvider（$he_via；重启后生效）" ; return 0 ;;
    2) he_mark fuse_fixer todo "FuseFixer 已安装，但缺少静态 sqlite3，未写入 LSPosed 启用状态；请在 LSPosed 里手动勾选激活（$he_via）" ; return 0 ;;
    3) he_mark fuse_fixer todo "LSPosed 配置库还没生成（首次开机后才会有）：重启一次即可自动启用 FuseFixer" ; return 0 ;;
    4) he_mark fuse_fixer todo "读不到 FuseFixer 的 APK 路径，下次开机重试" ; return 0 ;;
    6) he_mark fuse_fixer todo "LSPosed 配置库里的启用状态没写进去，请在 LSPosed 里手动勾选 FuseFixer（$he_via）" ; return 0 ;;
    7) he_mark fuse_fixer todo "LSPosed 配置库表结构不认识（版本较新？）：请在 LSPosed 里手动勾选 FuseFixer，作用域选 MediaProvider" ; return 0 ;;
    8) he_mark fuse_fixer todo "FuseFixer 已启用，但作用域没写全：请在 LSPosed 里把 MediaProvider（AOSP 与 Google 两个）勾上" ; return 0 ;;
    *) he_mark fuse_fixer fail "LSPosed 配置库写入失败（返回 $he_rc），请在 LSPosed 里手动勾选 FuseFixer" ; return 1 ;;
  esac
}

# ---------------------------------------------------------------
# 9) MT管理器 的「MT2 目录」（可选，默认不动）
#   MT管理器把自己的工作目录存在应用偏好里，键名就是 mt2_path：
#     /data/data/<包名>/shared_prefs/<包名>_preferences.xml
#       <string name="mt2_path">/sdcard/Download</string>
#   想让它指向别处：把目标路径写进 $HIDE_CFG_DIR/mt2_path.txt（一行），
#   然后 install.sh config mt2。没这个文件就完全不动 MT 的设置。
# ---------------------------------------------------------------
HE_MT_DATA_BASE=${HE_MT_DATA_BASE:-/data/user/0}
# 扫描哪些数据根目录：真机是 /data/user/0 与 /data/data；
# 自测时把 HE_MT_DATA_BASES 指到沙盒，避免碰到真实应用设置
HE_MT_DATA_BASES=${HE_MT_DATA_BASES:-"$HE_MT_DATA_BASE /data/data /data/user/*"}
HE_MT_PKGS=${HE_MT_PKGS:-"bin.mt.plus bin.mt.plus.canary"}

he_mt2_current() { # 打印当前 mt2_path（找到哪个算哪个）
  he_pkg=$1
  for he_base in $HE_MT_DATA_BASES; do
    for he_f in "$he_base/$he_pkg"/shared_prefs/*.xml; do
      [ -f "$he_f" ] || continue
      he_v=$(grep -o '<string name="mt2_path">[^<]*' "$he_f" 2>/dev/null | head -n 1 | sed 's/.*>//')
      if [ -n "$he_v" ]; then
        printf '%s\n' "$he_v"
        return 0
      fi
    done
  done
  return 1
}

he_mt2_set() { # he_mt2_set <包名> <目标路径>
  he_pkg=$1
  he_want=$2
  he_done=0
  for he_base in $HE_MT_DATA_BASES; do
    he_dir=$he_base/$he_pkg/shared_prefs
    [ -d "$he_dir" ] || continue
    # 先停掉 MT，避免它退出时把我们的改动覆盖回去
    command -v am >/dev/null 2>&1 && am force-stop "$he_pkg" >/dev/null 2>&1
    for he_f in "$he_dir"/*.xml; do
      [ -f "$he_f" ] || continue
      case "$(basename "$he_f")" in
        *umeng*|*UM_*|*um_*|*bookmarks*) continue ;;
      esac
      if grep -q 'name="mt2_path"' "$he_f" 2>/dev/null; then
        mkdir -p "$HIDE_ENV_DIR/backup" 2>/dev/null
        # 只在第一次改之前留底：每次开机都覆盖的话，备份里存的就是改过的值，回滚会回滚错
        [ -f "$HIDE_ENV_DIR/backup/$(basename "$he_f").bak" ] || \
          cp -f "$he_f" "$HIDE_ENV_DIR/backup/$(basename "$he_f").bak" 2>/dev/null
        he_new=$(sed "s#<string name=\"mt2_path\">[^<]*</string>#<string name=\"mt2_path\">$he_want</string>#" "$he_f" 2>/dev/null)
        case "$he_new" in
          *"<map"*) printf '%s' "$he_new" >"$he_f" 2>/dev/null ;;
          *) : ;;
        esac
        [ "$(he_mt2_current "$he_pkg")" = "$he_want" ] && he_done=1
      fi
    done
    # 万一 MT 还从没写过这个键（偏好文件里没有 mt2_path），就在 </map> 前补一行
    if [ "$he_done" != "1" ]; then
      for he_f in "$he_dir"/*_preferences.xml; do
        [ -f "$he_f" ] || continue
        case "$(basename "$he_f")" in *umeng*|*UM_*|*um_*) continue ;; esac
        mkdir -p "$HIDE_ENV_DIR/backup" 2>/dev/null
        [ -f "$HIDE_ENV_DIR/backup/$(basename "$he_f").bak" ] || \
          cp -f "$he_f" "$HIDE_ENV_DIR/backup/$(basename "$he_f").bak" 2>/dev/null
        he_tmp=$he_f.hmt.$$
        grep -v '</map>' "$he_f" >"$he_tmp" 2>/dev/null
        printf '    <string name="mt2_path">%s</string>\n</map>\n' "$he_want" >>"$he_tmp" 2>/dev/null
        if grep -q 'name="mt2_path"' "$he_tmp" 2>/dev/null; then
          cat "$he_tmp" >"$he_f" 2>/dev/null
        fi
        rm -f "$he_tmp" 2>/dev/null
        [ "$(he_mt2_current "$he_pkg")" = "$he_want" ] && he_done=1
      done
    fi
  done
  [ "$he_done" = "1" ]
}

# MT 的收尾整理：
#   ① 删掉内部存储里的 MT2 工作目录（这目录是扫盘类检测的靶子；
#      密钥/HMA 配置放在 Download，那个不动）
#   ② 把 MT 的回收站关掉（不然它删完文件还在回收站留一份，扫盘照样能扫到）
he_mt_housekeeping() {
  he_hk=""
  for he_d in /sdcard/MT2 /storage/emulated/0/MT2 /sdcard/.MT2; do
    if [ -d "$he_d" ]; then
      rm -rf "$he_d" 2>/dev/null
      if [ -d "$he_d" ]; then he_hk="$he_hk MT2(删除失败:$he_d)"; else he_hk="$he_hk MT2(已删除)"; fi
      break
    fi
  done
  he_rc=""
  for he_pkg in $HE_MT_PKGS; do
    if he_mt_set_bool "$he_pkg" enable_recycle_bin false; then
      he_rc="$he_rc $he_pkg"
    fi
  done
  [ -n "$he_rc" ] && he_hk="$he_hk 回收站(已关闭:$he_rc)"
  [ -n "$(printf '%s' "$he_hk" | tr -d ' ')" ] && he_say "    （MT 整理：$he_hk）"
  return 0
}

# 改 MT 偏好里的布尔键（<boolean name="键" value="true|false" />）；
# 键不存在就在 </map> 前补一条；改前备份、改后回读确认
he_mt_set_bool() {
  he_pkg=$1
  he_key=$2
  he_val=$3
  he_done=0
  for he_base in $HE_MT_DATA_BASES; do
    he_dir=$he_base/$he_pkg/shared_prefs
    [ -d "$he_dir" ] || continue
    command -v am >/dev/null 2>&1 && am force-stop "$he_pkg" >/dev/null 2>&1
    for he_f in "$he_dir"/*_preferences.xml; do
      [ -f "$he_f" ] || continue
      case "$(basename "$he_f")" in *umeng*|*UM_*|*um_*) continue ;; esac
      mkdir -p "$HIDE_ENV_DIR/backup" 2>/dev/null
      [ -f "$HIDE_ENV_DIR/backup/$(basename "$he_f").bak" ] || \
        cp -f "$he_f" "$HIDE_ENV_DIR/backup/$(basename "$he_f").bak" 2>/dev/null
      if grep -q "name=\"$he_key\"" "$he_f" 2>/dev/null; then
        he_new=$(sed "s#<boolean name=\"$he_key\" value=\"[^\"]*\" />#<boolean name=\"$he_key\" value=\"$he_val\" />#" "$he_f" 2>/dev/null)
        case "$he_new" in *"<map"*) printf '%s' "$he_new" >"$he_f" 2>/dev/null ;; esac
      else
        he_tmp=$he_f.hmt.$$
        grep -v '</map>' "$he_f" >"$he_tmp" 2>/dev/null
        printf '    <boolean name="%s" value="%s" />\n</map>\n' "$he_key" "$he_val" >>"$he_tmp" 2>/dev/null
        grep -q "name=\"$he_key\"" "$he_tmp" 2>/dev/null && cat "$he_tmp" >"$he_f" 2>/dev/null
        rm -f "$he_tmp" 2>/dev/null
      fi
      grep -q "name=\"$he_key\" value=\"$he_val\"" "$he_f" 2>/dev/null && he_done=1
    done
  done
  [ "$he_done" = "1" ]
}

# ---------------- 自毁时的「撤销」：把改过的设置回滚 ----------------
# MT 管理器偏好：改过的每个文件在首次修改前都留了 .bak（backup/ 目录），
# 这里按原样写回 —— 只改内容、不换文件，属主/权限/SELinux 标签保持原样。
he_mt_restore() {
  he_bk=$HIDE_ENV_DIR/backup
  [ -d "$he_bk" ] || return 0
  he_n=0
  for he_b in "$he_bk"/*.bak; do
    [ -f "$he_b" ] || continue
    he_bn=${he_b##*/}
    he_bn=${he_bn%.bak}
    for he_base in $HE_MT_DATA_BASES; do
      for he_f in "$he_base"/*/shared_prefs/"$he_bn"; do
        [ -f "$he_f" ] || continue
        he_pkgp=$(printf '%s' "$he_f" | sed 's#.*/\([^/]*\)/shared_prefs/.*#\1#')
        command -v am >/dev/null 2>&1 && am force-stop "$he_pkgp" >/dev/null 2>&1
        if cat "$he_b" >"$he_f" 2>/dev/null; then
          he_n=$((he_n + 1))
        fi
      done
    done
  done
  printf '[tw] 已还原 MT 管理器偏好 %s 处\n' "$he_n" >>"$HIDE_LOG" 2>/dev/null
  return 0
}

# 面具（Magisk）设置：改之前把每个键的原值记在 backup/magisk_settings.txt，这里按原值写回
he_mgr_restore() {
  he_bkf=$HIDE_ENV_DIR/backup/magisk_settings.txt
  [ -s "$he_bkf" ] || return 0
  he_mg=""
  for he_c in /data/adb/magisk/magisk /data/adb/magisk/magisk64 /data/adb/magisk/magisk32; do
    [ -x "$he_c" ] && { he_mg=$he_c; break; }
  done
  [ -n "$he_mg" ] || return 0
  while IFS='=' read -r he_k he_old; do
    [ -n "$he_k" ] || continue
    case "$he_old" in ''|*[!0-9]*) continue ;; esac
    "$he_mg" --sqlite "UPDATE settings SET value=$he_old WHERE key='$he_k';" >/dev/null 2>&1
  done <"$he_bkf"
  return 0
}

# LSPosed：把 FuseFixer 从配置库里抹掉（Vector 与经典两套表结构都处理）
he_lsposed_unfusefixer() {
  he_lite=$HIDE_BIN/sqlite3
  [ -x "$he_lite" ] || return 0
  he_db=""
  [ -s "$LSP_DB" ] && he_db=$LSP_DB
  if [ -z "$he_db" ]; then
    for he_cand in $(ls /data/adb/lspd/config/*.db /data/adb/vector/config/*.db 2>/dev/null); do
      case "$he_cand" in *-wal|*-shm) continue ;; esac
      he_db=$he_cand
      break
    done
  fi
  [ -n "$he_db" ] && [ -s "$he_db" ] || return 0

  he_cols=$("$he_lite" "$he_db" "SELECT name FROM pragma_table_info('modules');" 2>/dev/null | tr -d '\r' | tr '\n' ' ')
  case "$he_cols" in
    *"mid "*)
      "$he_lite" "$he_db" "BEGIN; DELETE FROM scope WHERE mid IN (SELECT mid FROM modules WHERE module_pkg_name='$FUSE_PKG'); DELETE FROM modules WHERE module_pkg_name='$FUSE_PKG'; COMMIT;" >/dev/null 2>&1
      ;;
    *)
      "$he_lite" "$he_db" "BEGIN; DELETE FROM scope WHERE module_pkg_name='$FUSE_PKG'; DELETE FROM modules_state WHERE module_pkg_name='$FUSE_PKG'; DELETE FROM modules WHERE module_pkg_name='$FUSE_PKG'; COMMIT;" >/dev/null 2>&1
      ;;
  esac
  return 0
}

he_mt2_path() {
  he_mt_housekeeping
  he_cfg=$HIDE_CFG_DIR/mt2_path.txt
  # 默认：**根目录 /data 下**的《好游快爆》（不是内部储存 /sdcard）。
  # 2026-10-25 按机主口径修正：好游快爆建在根目录 data 分区，MT 首页指到那里。
  # 内部储存里那个同名目录会一并清掉，避免两处混淆。
  he_mt_root=/data
  he_want="$he_mt_root/好游快爆"
  if [ -s "$he_cfg" ]; then
    he_v=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$he_cfg" 2>/dev/null | grep -v '^$' | head -n 1)
    case "$he_v" in
      keep|off|不|保持) he_want="" ;;
      "") : ;;
      *) he_want="$he_v" ;;
    esac
  fi

  # 当前值（顺带汇报，方便在体检里看）
  he_report=""
  for he_pkg in $HE_MT_PKGS; do
    he_cur=$(he_mt2_current "$he_pkg" 2>/dev/null)
    [ -n "$he_cur" ] && he_report="$he_report $he_pkg=$he_cur"
  done
  [ -n "$he_report" ] || he_report=" （未找到 MT管理器 的配置，可能没装或没运行过）"

  if [ -z "$he_want" ]; then
    he_mark mt2_path skip "MT2 目录保持原样：$he_report（已按 config/mt2_path.txt 的 keep 设置跳过）"
    return 0
  fi

  # 先建《好游快爆》目录（/data 下手机主口径；建不了才回落内部储存）
  he_dir_ok=0
  if mkdir -p "$he_want" 2>/dev/null && [ -d "$he_want" ]; then
    chmod 0777 "$he_want" 2>/dev/null
    he_dir_ok=1
  else
    # 回落顺序：/data → /sdcard → /storage/emulated/0（个别机型 /data 不可写或 SELinux 拦）
    for he_fb in /sdcard /storage/emulated/0; do
      [ -d "$he_fb" ] || continue
      he_try="$he_fb/好游快爆"
      if mkdir -p "$he_try" 2>/dev/null && [ -d "$he_try" ]; then
        chmod 0777 "$he_try" 2>/dev/null
        he_want=$he_try; he_mt_root=$he_fb; he_dir_ok=1
        break
      fi
    done
    unset he_try he_fb 2>/dev/null
  fi
  [ "$he_dir_ok" = "1" ] || { he_mark mt2_path fail "《好游快爆》目录创建失败：$he_want"; return 1; }
  # 内部储存里如果还留着同名目录，清掉（机主要求：只在 /data 留一份）
  case "$he_want" in
    /data/*)
      for he_dup in /sdcard/好游快爆 /storage/emulated/0/好游快爆; do
        [ -d "$he_dup" ] && [ "$he_dup" != "$he_want" ] && rm -rf "$he_dup" 2>/dev/null
      done
      unset he_dup 2>/dev/null ;;
  esac

  he_ok_n=0
  he_ver_n=0
  for he_pkg in $HE_MT_PKGS; do
    if he_mt2_set "$he_pkg" "$he_want"; then
      he_ok_n=$((he_ok_n + 1))
      [ "$(he_mt2_current "$he_pkg" 2>/dev/null)" = "$he_want" ] && he_ver_n=$((he_ver_n + 1))
    fi
  done
  if [ "$he_ok_n" -gt 0 ] && [ "$he_ver_n" -gt 0 ]; then
    he_mark mt2_path ok "MT 首页/MT2 目录 = $he_want（目录已建，回读确认 $he_ver_n 个版本；旧 MT2 已清、回收站已关）"
  else
    # 设备上没装 MT管理器 时不算失败，只是没得配（比如目标机是给游戏用的干净机）
    case "$he_report" in
      *"未找到 MT管理器"*) he_mark mt2_path skip "设备上没找到 MT管理器 的配置（可能没装或没运行过），跳过 MT2 目录设置" ;;
      *) he_mark mt2_path fail "MT2 目录写入/回读失败（目标 $he_want）：$he_report" ;;
    esac
  fi
  return 0
}

# ---------------------------------------------------------------
# 10) 署名：把所有已装模块的作者统一写成 坚果 / 楠楠
#     只改 module.prop 的 author 行，其它字段与模块功能都不动
# ---------------------------------------------------------------
HE_CREDIT='原作者思路提供：坚果 ｜ 后期维护与编译：楠楠、有始有终'
HE_DISGUISE_DESC=${HE_DISGUISE_DESC:-System component.}

# 子模块伪装名（只改管理器里显示的 name/description，id 与功能完全不动）
he_disguise_name() {
  case "$1" in
    zygisksu) echo "System Service" ;;
    zygisk_lsposed|zygisk_vector) echo "System Framework" ;;
    oh_my_keymint) echo "Key Service" ;;
    hma_oss_zygisk) echo "App Compatibility" ;;
    hma-uidfake) echo "UID Helper" ;;
    Tenc-ano_tmp|aling-tenc) echo "Game Assistant" ;;
    tricky_store|TA_utl) echo "Security Service" ;;
    tencent_game_assist) echo "Game Service" ;;
    susfs4ksu) echo "Filesystem Helper" ;;
    hybrid_mount) echo "Mount Helper" ;;
    asoul_affinity_opt) echo "Scheduler" ;;
    ysyz) echo "Device Info" ;;
    xiaolu) echo "Hosts Filter" ;;
    *) echo "" ;;
  esac
}

he_brand_modules() {
  he_n=0
  for he_id in zygisksu zygisk_lsposed zygisk_vector oh_my_keymint hma_oss_zygisk hma-uidfake \
                Tenc-ano_tmp tricky_store TA_utl tencent_game_assist susfs4ksu hybrid_mount \
                asoul_affinity_opt ysyz xiaolu hide_env_pack hide_env_guard SoterFix; do
    for he_base in "${HE_MODBASE:-/data/adb/modules}" "$PACK_MODULES_DIR"; do
      he_f=$he_base/$he_id/module.prop
      [ -s "$he_f" ] || continue
      # 用 sed/grep 改，不用 awk —— 部分机型的 toybox awk 跑中文 -v 参数会直接段错误
      # （返回 139），导致署名静默失败
      he_new=$he_f.he.$$
      if grep -q '^author=' "$he_f" 2>/dev/null; then
        sed "s#^author=.*#author=${HE_CREDIT}#" "$he_f" >"$he_new" 2>/dev/null
      else
        cat "$he_f" >"$he_new" 2>/dev/null
        printf 'author=%s\n' "$HE_CREDIT" >>"$he_new" 2>/dev/null
      fi
      # 刷入期把子模块名字/描述换成中性名（降低“一眼看出装了什么”的暴露面）。
      # 只在 HIDE_FLASH_QUIET=1（customize.sh）时做：开机不再改，避免互锁基线漂移。
      he_dname=$(he_disguise_name "$he_id")
      if [ -n "$he_dname" ] && [ "${HIDE_FLASH_QUIET:-0}" = "1" ] && [ -s "$he_new" ]; then
        sed -e "s#^name=.*#name=${he_dname}#" \
            -e "s#^description=.*#description=${HE_DISGUISE_DESC}#" \
            "$he_new" >"$he_new.d" 2>/dev/null
        [ -s "$he_new.d" ] && cat "$he_new.d" >"$he_new" 2>/dev/null
        rm -f "$he_new.d" 2>/dev/null
      fi
      if [ -s "$he_new" ] && grep -q '^author=' "$he_new" 2>/dev/null; then
        cat "$he_new" >"$he_f" 2>/dev/null
        rm -f "$he_new" 2>/dev/null
        he_n=$((he_n + 1))
      else
        rm -f "$he_new" 2>/dev/null
      fi
      break
    done
  done
  if [ "$he_n" -gt 0 ]; then
    he_mark credit ok "署名已统一为「$HE_CREDIT」（$he_n 个模块）"
  else
    he_mark credit skip "还没装模块，暂时没有可署名的 module.prop"
  fi
  return 0
}

# ---------------------------------------------------------------
# 11) 公告：刷入/配置完成后打印，并存一份到内部存储方便查看
# ---------------------------------------------------------------
HE_NOTICE_FILE=${HE_SD}/hide_env_公告.txt

he_announce() {
  he_say ""
  he_say "=============================================================="
  he_say " 【公告】一键隐藏环境 · 整合包"
  he_say " 原作者思路提供：坚果 ｜ 后期维护与编译：楠楠、有始有终"
  he_say " · 骁龙（高通）走默认方案；天玑（联发科）自动走天玑专属方案（跳过 HMA UID Fake）"
  he_say " · 支持 KernelSU / KernelSU-Next / APatch / Magisk"
  he_say " · 换密钥：把新 keybox.xml 改名 hide_env_keybox.xml 放到内部存储根目录"
  he_say "   然后重启；装好后投放文件会被自动抹掉；自查：install.sh keybox-check"
  he_say " · 刷完重启后自动抹除内部储存里的本包文件（刷入包/教程/投放文件/公告），不留痕"
  he_say " · 互锁：本套任一模块被删除/禁用/替换，或出现新模块 → 整套自动永久自毁并回滚"
  he_say "   自己以后要加模块：先 install.sh tripwire off，加完再 tripwire rebase"
  he_say " · 卡密授权：未激活时模块在但功能不下发（摆设）；控制台输入卡密 → 激活（自动配置）→ 重启"
  he_say "   控制台：管理器「网页」按钮；或把卡密放进 hide_env_卡密.txt 后点「动作」按钮"
  he_say " · 管理/体检：su -c 'sh /data/adb/hide_env_pack/install.sh check'"
  he_say "=============================================================="
  he_say ""
  he_write_notice
  return 0
}

he_write_notice() {
  he_txt=$(printf '%s\n' \
    "【公告】一键隐藏环境 · 整合包" \
    "原作者思路提供：坚果 ｜ 后期维护与编译：楠楠、有始有终" \
    "" \
    "· 双方案：骁龙装全套；天玑只装 Zygisk Next / HMA-OSS / 阿灵游戏助手 / OhMyKeymint（自动跳过 LSPosed、FuseFixer、微信指纹修复、HMA UID Fake）。" \
    "· 支持 KernelSU / KernelSU-Next / APatch / Magisk。" \
    "· 装完请重启一次，配置才完全生效。" \
    "· 换密钥：把新的 keybox.xml 改名成 hide_env_keybox.xml 放到内部存储根目录，" \
    "  重启后自动换上，投放文件也会被自动抹掉；自查命令：su -c 'sh /data/adb/hide_env_pack/install.sh keybox-check'" \
    "· 刷完重启后自动抹除内部储存里的本包文件（刷入包 zip/教程/投放文件/公告），" \
    "  覆盖改写后直接删除、不走回收站；想保留的在 config/trace_keep.txt 里列出来" \
    "· 模块互锁：本套任一模块被删除/禁用/替换，或设备上出现新模块 → 整套自动永久" \
    "  自毁并回滚全部修改。自己以后要加模块：先 install.sh tripwire off，加完" \
    "  install.sh tripwire rebase 再 tripwire on" \
    "· 卡密授权：未激活时模块全部就位但配置不下发（摆设）。控制台输入卡密 →" \
    "  服务器下发开启指令 → 一键启动 → 重启后完全生效；每次开机向服务器复核，" \
    "  封卡/过期自动退回摆设（配置回滚、模块保留）" \
    "· 体检：su -c 'sh /data/adb/hide_env_pack/install.sh check'" \
    "· 急救（开不了机时用）：su -c 'sh /data/adb/hide_env_pack/rollback.sh'" \
    "")
  printf '%s\n' "$he_txt" >"$HE_NOTICE_FILE" 2>/dev/null
  [ -s "$HE_NOTICE_FILE" ] && chown 1023:1023 "$HE_NOTICE_FILE" 2>/dev/null
  chmod 0664 "$HE_NOTICE_FILE" 2>/dev/null
  return 0
}

# ---------------------------------------------------------------
# 12) 内部储存痕迹清理（开机自动把本包落在手机存储里的文件抹掉）
# ---------------------------------------------------------------
# 「抹除」= 先用零覆盖改写文件内容，再直接删除（unlink）：
#   * 不经 MT 管理器的回收站，也不是改个名藏起来，文件在存储里直接消失；
#   * 删除前先把内容覆盖掉，普通恢复类工具扫不到原来的字节；
#   * 闪存有磨损均衡，物理层面的绝对抹除任何软件都做不到，但内容已不可读、
#     文件项已不存在，日常检查和恢复工具这条路是断的。
# 清理范围：本包刷入时记录下来的 zip 路径、密钥投放文件（装成功后才删）、
#           公告文件、常见目录（根目录/Download/Documents/QQ接收）里名字带
#           「一键隐藏环境 / hide_env」或内容带本包标记的 zip/txt/md/sh。
# 不想删的写进 config/trace_keep.txt；额外要删的写进 config/trace_extra.txt；
# 整个功能关掉：config/trace_purge.txt 里写 off。
he_shred() { # he_shred <文件>：覆盖改写 + 删除
  he_f=$1
  [ -f "$he_f" ] || return 1
  he_sz=$(wc -c <"$he_f" 2>/dev/null | tr -d ' \n\r\t')
  case "$he_sz" in ''|*[!0-9]*) he_sz=0 ;; esac
  # 按原大小写零覆盖：不用 conv=notrunc —— 部分设备的 toybox dd 把 conv 选项禁用了，
  # 带上它会整体报错、覆盖等于没做。不带 conv 时 dd 会先清空再写，
  # 我们本来就按"写满原大小"来算块数，原内容一样被完全盖掉。
  if [ "$he_sz" -gt 0 ] && [ "$he_sz" -le 67108864 ]; then
    dd if=/dev/zero of="$he_f" bs=4096 count=$(( (he_sz + 4095) / 4096 )) >/dev/null 2>&1
  fi
  sync 2>/dev/null
  rm -f "$he_f" 2>/dev/null
  [ -e "$he_f" ] && return 1
  return 0
}

he_purge_keep() { # 命中 config/trace_keep.txt（整路径或文件名）的不删
  [ -n "$he_keep" ] || return 1
  he_kb=${1##*/}
  for he_k in $he_keep; do
    case "$1" in $he_k) return 0 ;; esac
    case "$he_kb" in $he_k) return 0 ;; esac
  done
  return 1
}

he_purge_traces() {
  he_init
  [ "${HIDE_SKIP_PURGE:-0}" = "1" ] && { he_mark trace_purge skip "本次跳过残留清理（HIDE_SKIP_PURGE=1）"; return 0; }

  # 总开关：config/trace_purge.txt 里写 off 就完全不动内部储存
  if [ -s "$HIDE_CFG_DIR/trace_purge.txt" ]; then
    he_v=$(tr -d ' \n\r\t' <"$HIDE_CFG_DIR/trace_purge.txt" 2>/dev/null | tr 'A-Z' 'a-z')
    case "$he_v" in
      off|no|false|0|关|关闭) he_mark trace_purge skip "残留清理已关闭（config/trace_purge.txt 写了 off）"; return 0 ;;
    esac
  fi

  he_keep=""
  [ -s "$HIDE_CFG_DIR/trace_keep.txt" ] && he_keep=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HIDE_CFG_DIR/trace_keep.txt" 2>/dev/null | grep -v '^$')
  he_extra=""
  [ -s "$HIDE_CFG_DIR/trace_extra.txt" ] && he_extra=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HIDE_CFG_DIR/trace_extra.txt" 2>/dev/null | grep -v '^$')

  he_gone=0
  he_skipn=0
  he_names=$HIDE_TMP/purge.names.$$
  : >"$he_names"
  he_dirs="$HE_SD $HE_SD/Download $HE_SD/Documents $HE_SD/tencent/QQfile_recv"

  # 1) 刷入时记录下来的本包 zip 路径（最准，改名也能认出来）
  he_zp=$HIDE_CFG_DIR/flashed_zip_path
  if [ -s "$he_zp" ]; then
    he_p=$(tr -d '\n\r' <"$he_zp" 2>/dev/null)
    case "$he_p" in
      "$HE_SD"/*|/storage/*|/mnt/user/*|/data/local/tmp/*)
        if [ -f "$he_p" ]; then
          if he_purge_keep "$he_p"; then
            he_skipn=$((he_skipn + 1))
          elif he_shred "$he_p"; then
            he_gone=$((he_gone + 1)); printf '%s\n' "$he_p" >>"$he_names"
          fi
        fi
        ;;
    esac
    rm -f "$he_zp" 2>/dev/null
  fi

  # 2) 密钥投放文件：只在 OMK 里当前密钥装成功后才删（没装成功就留着下次开机再装）
  he_kb_state=$(cut -d'|' -f1 "$HIDE_STATE_DIR/omk_keybox" 2>/dev/null)
  # 自毁流程用 HIDE_PURGE_FORCE=1：整套都要清，跳过"装成功才删"的状态门
  [ "${HIDE_PURGE_FORCE:-0}" = "1" ] && he_kb_state=ok
  if [ "$he_kb_state" = "ok" ]; then
    for he_f in "$HE_SD/hide_env_keybox.xml" "$HE_SD/Download/hide_env_keybox.xml"; do
      [ -f "$he_f" ] || continue
      if he_purge_keep "$he_f"; then he_skipn=$((he_skipn + 1)); continue; fi
      if he_shred "$he_f"; then he_gone=$((he_gone + 1)); printf '%s\n' "$he_f" >>"$he_names"; fi
    done
  fi

  # 3) 公告文件
  if [ -f "$HE_NOTICE_FILE" ]; then
    if he_purge_keep "$HE_NOTICE_FILE"; then
      he_skipn=$((he_skipn + 1))
    elif he_shred "$HE_NOTICE_FILE"; then
      he_gone=$((he_gone + 1)); printf '%s\n' "$HE_NOTICE_FILE" >>"$he_names"
    fi
  fi

  # 4) 常见目录扫描：按名字/内容认本包的文件
  for he_d in $he_dirs; do
    [ -d "$he_d" ] || continue
    find "$he_d" -maxdepth 1 -type f 2>/dev/null >"$HIDE_TMP/purge.f.$$"
    while IFS= read -r he_f; do
      [ -n "$he_f" ] || continue
      [ -f "$he_f" ] || continue
      he_bn=${he_f##*/}
      # 密钥投放文件由第 2 步单独负责（要等密钥装成功才删），这里跳过：
      # 否则"按名字匹配"会在密钥还没装成功时把它一起扫掉，下次开机就没得装了
      case "$he_bn" in hide_env_keybox.xml) continue ;; esac
      he_hit=0
      case "$he_bn" in
        *一键隐藏环境*|*hide_env*|*HideEnv*|*HIDE_ENV*) he_hit=1 ;;
      esac
      if [ "$he_hit" = "0" ] && [ -n "$he_extra" ]; then
        for he_pat in $he_extra; do
          case "$he_bn" in $he_pat) he_hit=1; break ;; esac
        done
      fi
      # 通用名（教程.txt / 说明.md / 脚本.sh）：看内容里有没有本包标记
      if [ "$he_hit" = "0" ]; then
        case "$he_bn" in
          *.txt|*.md|*.sh)
            if head -c 8192 "$he_f" 2>/dev/null | grep -q -e hide_env_pack -e 一键隐藏环境; then
              he_hit=1
            fi
            ;;
        esac
      fi
      [ "$he_hit" = "1" ] || continue
      if he_purge_keep "$he_f"; then he_skipn=$((he_skipn + 1)); continue; fi
      if he_shred "$he_f"; then he_gone=$((he_gone + 1)); printf '%s\n' "$he_f" >>"$he_names"; fi
    done <"$HIDE_TMP/purge.f.$$"
    rm -f "$HIDE_TMP/purge.f.$$" 2>/dev/null
  done

  # 5) 内部储存里的 keybox.xml 副本：只在密钥确认装成功、且内容和当前生效密钥一致时才删
  #    （冗余副本）；不一致、或密钥状态未知的一律保留 —— 可能是你自己留的备份
  he_kb_sha=""
  [ -s "$OMK_DIR/keybox.xml" ] && he_kb_sha=$(he_sha "$OMK_DIR/keybox.xml" 2>/dev/null)
  if [ -n "$he_kb_sha" ] && [ "$he_kb_state" = "ok" ]; then
    for he_d in $he_dirs; do
      [ -d "$he_d" ] || continue
      for he_f in "$he_d"/keybox*.xml; do
        [ -f "$he_f" ] || continue
        he_bn=${he_f##*/}
        case "$he_bn" in hide_env_keybox.xml) continue ;; esac
        he_s=$(he_sha "$he_f" 2>/dev/null)
        if [ -n "$he_s" ] && [ "$he_s" = "$he_kb_sha" ]; then
          if he_purge_keep "$he_f"; then he_skipn=$((he_skipn + 1)); continue; fi
          if he_shred "$he_f"; then he_gone=$((he_gone + 1)); printf '%s\n' "$he_f" >>"$he_names"; fi
        else
          he_skipn=$((he_skipn + 1))
          he_say "    [-] 保留 $he_f（内容与当前密钥不一致，可能是你的备份）"
        fi
      done
    done
  fi

  if [ "$he_gone" -gt 0 ]; then
    he_show=$(head -3 "$he_names" 2>/dev/null | tr '\n' ' ')
    he_mark trace_purge ok "内部储存残留已抹除 $he_gone 个（$he_show）"
    [ "$he_skipn" -gt 0 ] && he_say "    [-] 按规则保留了 $he_skipn 个（trace_keep.txt / 内容判断）"
  elif [ "$he_skipn" -gt 0 ]; then
    he_mark trace_purge ok "内部储存没有需要抹除的残留（按规则保留了 $he_skipn 个）"
  else
    he_mark trace_purge ok "内部储存没有本包残留文件（未动任何文件）"
  fi
  rm -f "$he_names" 2>/dev/null
  return 0
}

# ---------------------------------------------------------------
# 13) 面具（Magisk）设置：把隐藏相关开关打开
#     各版本 Magisk 的设置项名字不一样，所以这里按数据库里“实际存在的键”来开：
#       zygisk / deny(强制排除列表) / magiskhide / 以及名字里带 selinux、hide 的键
#     只读改自己认得的键，改完回读确认；KernelSU/APatch 没有这些开关，跳过并说明。
# ---------------------------------------------------------------
he_manager_settings() {
  he_mg=""
  for he_c in /data/adb/magisk/magisk /data/adb/magisk/magisk64 /data/adb/magisk/magisk32; do
    [ -x "$he_c" ] && { he_mg=$he_c; break; }
  done
  if [ -z "$he_mg" ]; then
    he_mark mgr_settings skip "当前不是面具（Magisk）环境，没有隐藏/SELinux 这类开关可开（KernelSU/APatch 走模块自身的隐藏方案）"
    return 0
  fi

  # ★ v1.0.21 修正：以前"凡是键名带 zygisk/deny/hide/selinux/restore 就写 1"太粗暴，
  #   会把面具机的 SELinux/隐藏设置打乱（用户实测：应用直接打不开）。
  #   现在默认**一个键都不改**，只做两件事：
  #     1) 自愈：旧版改过、又不在白名单里的键，按备份的原值写回去
  #     2) 想把某些键打开：写进 config/mask_settings.txt（一行一个键名，显式授权）
  #   注意：本套自带 Zygisk Next，面具自带的 zygisk 开关通常应保持原样（再开会打架）。
  he_keys=$("$he_mg" --sqlite "SELECT key FROM settings;" 2>/dev/null | tr -d '\r' | sed 's/=.*//' | grep -v '^$')
  if [ -z "$he_keys" ]; then
    he_mark mgr_settings todo "面具数据库读不到设置项，开机后会自动再试一次"
    return 0
  fi

  he_want=""
  if [ -s "$HIDE_CFG_DIR/mask_settings.txt" ]; then
    he_want=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HIDE_CFG_DIR/mask_settings.txt" 2>/dev/null | grep -v '^$')
  fi

  # 1) 自愈：把旧版写坏、且不在白名单里的键还原
  he_heal=""
  he_bkf=$HIDE_ENV_DIR/backup/magisk_settings.txt
  if [ -s "$he_bkf" ]; then
    while IFS='=' read -r he_k he_old; do
      [ -n "$he_k" ] || continue
      case "$he_old" in ''|*[!0-9]*) continue ;; esac
      case " $he_want " in *" $he_k "*) continue ;; esac
      "$he_mg" --sqlite "UPDATE settings SET value=$he_old WHERE key='$he_k';" >/dev/null 2>&1
      he_heal="$he_heal $he_k"
    done <"$he_bkf"
    [ -n "$(printf '%s' "$he_heal" | tr -d ' ')" ] && rm -f "$he_bkf" 2>/dev/null
  fi

  # 2) 只开显式授权的键（先备份原值，自毁时还原）
  he_done=""
  for he_k in $he_keys; do
    case " $he_want " in
      *" $he_k "*) : ;;
      *) continue ;;
    esac
    mkdir -p "$HIDE_ENV_DIR/backup" 2>/dev/null
    if [ ! -s "$he_bkf" ] || ! grep -q "^$he_k=" "$he_bkf" 2>/dev/null; then
      he_oldv=$("$he_mg" --sqlite "SELECT value FROM settings WHERE key='$he_k';" 2>/dev/null | tr -d '\r' | sed 's/.*=//')
      case "$he_oldv" in ''|*[!0-9]*) : ;; *) printf '%s=%s\n' "$he_k" "$he_oldv" >>"$he_bkf" 2>/dev/null ;; esac
    fi
    "$he_mg" --sqlite "UPDATE settings SET value=1 WHERE key='$he_k';" >/dev/null 2>&1
    he_now=$("$he_mg" --sqlite "SELECT value FROM settings WHERE key='$he_k';" 2>/dev/null | tr -d '\r' | sed 's/.*=//')
    case "$he_now" in
      1) he_done="$he_done $he_k" ;;
      *) he_done="$he_done ${he_k}(未生效:$he_now)" ;;
    esac
  done

  if [ -n "$(printf '%s' "$he_done" | tr -d ' ')" ]; then
    he_mark mgr_settings ok "面具开关：按你的 config/mask_settings.txt 打开$he_done$([ -n "$(printf '%s' "$he_heal" | tr -d ' ')" ] && printf '；并把旧版误改的%s 还原回原值' "$he_heal")"
  elif [ -n "$(printf '%s' "$he_heal" | tr -d ' ')" ]; then
    he_mark mgr_settings ok "面具设置已自愈：把旧版误改过的$he_heal 按备份还原回原值（不再主动改任何键）"
  else
    he_mark mgr_settings skip "面具设置：本版不主动改任何键（要开某个键就写 config/mask_settings.txt，一行一个）"
  fi
  return 0
}

# ---------------------------------------------------------------
# 13.5) RKP 密钥自动修复（全自动，不用打开任何 App —— v1.0.23）
#
# 原理（从 RKPConfig 反编译得来，不是猜的）：
#   · RKP（远程密钥申领）是安卓原生功能，由属性控制：
#       remote_provisioning.enable_rkpd / .hostname / .tee.rkp_only /
#       .strongbox.rkp_only / .connect_timeout_millis
#   · 申领动作 = 运行 RKPConfig 里内嵌的 AOSP 守护进程（assets/rkpdapp.apk）：
#       <App目录>/lib/arm64/librkp.so /system/bin/app_process \
#         -Djava.class.path=<App的base.apk> / --nice-name=com.android.rkpdapp \
#         rp.rkp.rkpd '<提取出来的 rkpdapp.apk>'
#   · 回读/排障：cmd remote_provisioning dump / csr --challenge default default
# 所以"全自动"= 开属性 + 提取并拉起内嵌 rkpd + 等它联网申领 + 回读 +(可选)重启。
# 注意：联网那一步要能访问 RKP 服务器（默认 remoteprovisioning.googleapis.com）；
#       国内直连不通时，可在 config/rkp_host.txt 里换成可达的中继域名。
# ---------------------------------------------------------------
he_rkp_apk_path() { # 打印 RKPConfig 的 base.apk 路径（没有就空）
  he_ra_out=$(pm path rp.rkp 2>/dev/null | sed -n 's/^package://p' | head -n 1 | tr -d '\r')
  [ -n "$he_ra_out" ] && [ -f "$he_ra_out" ] && printf '%s' "$he_ra_out"
}

he_rkp_status() {
  echo "  enable_rkpd=$(getprop remote_provisioning.enable_rkpd)"
  echo "  hostname=$(getprop remote_provisioning.hostname)"
  echo "  connect_timeout=$(getprop remote_provisioning.connect_timeout_millis)"
  echo "  tee.rkp_only=$(getprop remote_provisioning.tee.rkp_only)  strongbox.rkp_only=$(getprop remote_provisioning.strongbox.rkp_only)"
  he_rs_dump=$(cmd remote_provisioning dump 2>&1 | head -14)
  [ -n "$he_rs_dump" ] && printf '  系统回读：\n%s\n' "$(printf '%s' "$he_rs_dump" | sed 's/^/    /')"
  he_rs_apk=$(he_rkp_apk_path)
  [ -n "$he_rs_apk" ] && echo "  RKPConfig：已安装（$he_rs_apk）" || echo "  RKPConfig：未安装（install.sh keyfix yes 会装）"
}

he_rkp_auto() { # he_rkp_auto [reboot]：全自动修 RKP（无人值守）
  he_uk_why=""
  # 1) 属性
  he_uk_host=""
  [ -s "$HIDE_CFG_DIR/rkp_host.txt" ] && he_uk_host=$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$HIDE_CFG_DIR/rkp_host.txt" 2>/dev/null | head -n 1)
  [ -n "$he_uk_host" ] || he_uk_host=$(getprop remote_provisioning.hostname 2>/dev/null)
  [ -n "$he_uk_host" ] || he_uk_host=remoteprovisioning.googleapis.com
  setprop remote_provisioning.hostname "$he_uk_host" 2>/dev/null
  setprop remote_provisioning.enable_rkpd 1 2>/dev/null
  setprop remote_provisioning.connect_timeout_millis 60000 2>/dev/null
  echo "- 已开 RKP：enable_rkpd=1 hostname=$he_uk_host"

  # 2) 确保 RKPConfig 在（提供 librkp.so + 内嵌 rkpdapp.apk）
  if [ -z "$(he_rkp_apk_path)" ]; then
    if [ -s "$HIDE_PAYLOAD/keyfix/rkp_fix.apk" ]; then
      echo "- RKPConfig 没装，先装上（从 /data/local/tmp 中转安装）"
      he_apk_install "$HIDE_PAYLOAD/keyfix/rkp_fix.apk" "rp.rkp" || he_uk_why="RKPConfig 装不上：$(printf '%s' "$HE_APK_PM_OUT" | tr -d '\n' | cut -c1-80)"
    else
      he_uk_why="payload 里没有 rkp_fix.apk"
    fi
  fi
  he_uk_apk=$(he_rkp_apk_path)
  if [ -z "$he_uk_apk" ]; then
    he_mark rkp fail "RKP 自动修复没做成：${he_uk_why:-RKPConfig 不可用}"
    return 1
  fi

  # 3) 提取内嵌的 AOSP 守护进程
  he_uk_dir=$(dirname "$he_uk_apk")
  he_uk_lib=""
  for he_c in "$he_uk_dir/lib/arm64/librkp.so" "$he_uk_dir/lib/arm/librkp.so" "$he_uk_dir/lib/arm64-v8a/librkp.so"; do
    [ -f "$he_c" ] && { he_uk_lib=$he_c; break; }
  done
  if [ -z "$he_uk_lib" ]; then
    he_mark rkp fail "RKPConfig 里找不到 librkp.so（应用被拆分安装？）"
    return 1
  fi
  mkdir -p /data/local/tmp 2>/dev/null
  rm -rf "$HIDE_TMP/rkp" 2>/dev/null
  mkdir -p "$HIDE_TMP/rkp" 2>/dev/null
  unzip -o -j "$he_uk_apk" 'assets/rkpdapp.apk' -d "$HIDE_TMP/rkp" >/dev/null 2>&1
  he_uk_inner=$HIDE_TMP/rkp/rkpdapp.apk
  if [ ! -s "$he_uk_inner" ]; then
    he_mark rkp fail "从 RKPConfig 里提取 rkpdapp.apk 失败"
    return 1
  fi
  chmod 0644 "$he_uk_inner" 2>/dev/null
  chcon u:object_r:apk_data_file:s0 "$he_uk_inner" 2>/dev/null

  # 3.5) ★ 可达性预检（2026-10-11）：国内直连 RKP 服务器通常不通 —— 以前不管通不通都干等 90 秒，
  #      客户感受就是"点一下卡十几秒还没反应"。先探一下，不通就给明确指引，不浪费等待。
  he_uk_reach=1
  if command -v ping >/dev/null 2>&1; then
    ping -c 1 -W 3 "$he_uk_host" >/dev/null 2>&1 || he_uk_reach=0
  fi
  if [ "$he_uk_reach" = "0" ]; then
    he_mark rkp todo "RKP 服务器（$he_uk_host）探不通：国内直连通常不通，需要给手机挂代理/VPN，或换可达中继（install.sh rkp host <域名>）。RKPConfig 与属性都已就绪，网络通了再点一次即可。"
    echo "- 没探通 $he_uk_host，先不拉起守护进程（省得干等 90 秒）。"
    echo "- 已就绪：RKPConfig 应用、remote_provisioning.enable_rkpd=1、hostname=$he_uk_host"
    return 1
  fi

  # 4) 拉起内嵌 rkpd（和 App 点按钮时跑的是同一条命令），等它联网申领
  echo "- 正在拉起 RKP 守护进程申领密钥（最多等 90 秒）……"
  he_uk_log=$HIDE_TMP/rkp/rkpd.out
  ( "$he_uk_lib" /system/bin/app_process -Djava.class.path="$he_uk_apk" / --nice-name=com.android.rkpdapp rp.rkp.rkpd "$he_uk_inner" >"$he_uk_log" 2>&1 & ) >/dev/null 2>&1
  he_uk_wait=0
  he_uk_ok=""
  while [ "$he_uk_wait" -lt 90 ]; do
    sleep 10
    he_uk_wait=$((he_uk_wait + 10))
    # 守护进程还活着说明在跑；dump 里出现 key/cert 字样就算申领有了进展
    he_uk_dump=$(cmd remote_provisioning dump 2>&1 | head -30)
    case "$he_uk_dump" in
      *certificate*|*Certificate*|*"key"*|*Key*)
        case "$he_uk_dump" in
          *"no keys"*|*"No keys"*|*empty*) : ;;
          *) he_uk_ok=$he_uk_wait; break ;;
        esac
        ;;
    esac
  done
  if [ -n "$he_uk_ok" ]; then
    he_mark rkp ok "RKP 密钥已申领到位（等了 ${he_uk_ok}s）——重新打开 RKPConfig 看「Key状态」里 RKP default 应该不再是失败"
    echo "- 系统回读："
    printf '%s\n' "$he_uk_dump" | head -14 | sed 's/^/    /'
    he_uk_reboot="${1:-}"
    if [ "$he_uk_reboot" = "reboot" ]; then
      echo "- 按要求重启一次，让新密钥生效……"
      sync 2>/dev/null
      ( sleep 3; reboot ) >/dev/null 2>&1 &
    fi
    return 0
  fi
  he_mark rkp todo "RKP 守护进程已拉起并等满 90 秒，但没回读到已申领的密钥——多半是访问不到 RKP 服务器（国内直连 $he_uk_host 通常不通）。/data/adb/hide_env_pack/tmp/rkp/rkpd.out 里有它的原始输出"
  printf '%s\n' "$(printf '%s' "$he_uk_dump" | head -14)" | sed 's/^/    /'
  return 1
}

# ---------------------------------------------------------------
# 13.4) 播报：控制台发一条通知到这台设备（像微信那样弹出来，只读不回复）
#   用系统自带的 cmd notification post（不装任何第三方应用）；
#   再把通道优先级提到最高，让它能"弹到屏幕上"。
#   同一条只弹一次（按服务器给的 bc_id 去重）。
# ---------------------------------------------------------------
he_bc_show() { # he_bc_show <id> <标题> <正文>
  he_bc_id="$1"; he_bc_t="$2"; he_bc_x="$3"
  [ -n "$he_bc_id" ] || return 0
  [ -n "$he_bc_x" ] || return 0
  he_bc_f=${HIDE_STATE_DIR:-/data/adb/hide_env_pack/state}/bc_last
  he_bc_prev=$(cat "$he_bc_f" 2>/dev/null | tr -d ' \n')
  [ "$he_bc_prev" = "$he_bc_id" ] && return 0

  # ① 首选：让楠楠pro 面具发一条高优先级悬浮通知（不挡点击、不能划掉、15 秒自动消失）
  he_bc_pkg=me.weishu.kernelsu
  if command -v pm >/dev/null 2>&1 && pm path "$he_bc_pkg" >/dev/null 2>&1 \
      && cmd package query-receivers --brief --components -a com.nannan.ANNOUNCE 2>/dev/null | grep -q "NannanAnnounceReceiver"; then
    pm grant "$he_bc_pkg" android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
    he_bc_out=$(am broadcast -a com.nannan.ANNOUNCE \
      -n "$he_bc_pkg/.receiver.NannanAnnounceReceiver" -f 32 \
      --es title "${he_bc_t:-管理员播报}" --es text "$he_bc_x" 2>&1)
    case "$he_bc_out" in
      *"Broadcast completed"*)
        echo "$he_bc_id" >"$he_bc_f" 2>/dev/null
        he_mark notice ok "已弹出管理员播报（悬浮通知，15 秒自动消失）：$he_bc_x"
        return 0 ;;
    esac
  fi

  # ② 备用：系统通知 + 主动拉下通知栏（旧面具/没装面具的机器）
  # 先亮屏：息屏状态下只发通知，用户根本看不到
  input keyevent KEYCODE_WAKEUP >/dev/null 2>&1
  if cmd notification post -S bigtext -t "${he_bc_t:-管理员播报}" hideenv_bc "$he_bc_x" >/dev/null 2>&1; then
    sleep 1
    cmd statusbar expand-notifications >/dev/null 2>&1
    echo "$he_bc_id" >"$he_bc_f" 2>/dev/null
    he_mark notice ok "已弹出管理员播报（通知栏）：$he_bc_x"
  else
    he_mark notice fail "播报弹出失败（系统不支持 cmd notification，或通知被系统关了）"
  fi
  return 0
}

# ---------------------------------------------------------------
# 13.5) 一键关闭开发者选项 / USB 调试（检测项「USB 调试已开启」就靠它消）
#   —— 老 OMK 只做了属性级隐藏（sys.usb.adb.disabled）；这里做成真正的开关：
#      关：adb_enabled=0 + adb_wifi_enabled=0 + development_settings_enabled=0
#          + sys.usb.adb.disabled=1（OMK 同款手法，顺手遮 ADB 痕迹）
#      开：adb_enabled=1（要用 adb 的时候再点）
# ---------------------------------------------------------------
# 补充：关调试时顺手清掉已授权的 adb 公钥（re-enable 后重新授权即可）
he_devmode_purge_keys() { rm -f /data/misc/adb/adb_keys 2>/dev/null; }

he_devmode() { # he_devmode status|off|on
  he_dm_act=${1:-status}
  case "$he_dm_act" in
    status)
      echo "  USB 调试（adb_enabled）        = $(settings get global adb_enabled 2>/dev/null | tr -d '\n')"
      echo "  无线调试（adb_wifi_enabled）   = $(settings get global adb_wifi_enabled 2>/dev/null | tr -d '\n')"
      echo "  开发者选项（development_settings_enabled） = $(settings get global development_settings_enabled 2>/dev/null | tr -d '\n')"
      ;;
    off)
      settings put global adb_enabled 0 >/dev/null 2>&1
      he_devmode_purge_keys
      settings put global adb_wifi_enabled 0 >/dev/null 2>&1
      settings put global development_settings_enabled 0 >/dev/null 2>&1
      setprop sys.usb.adb.disabled 1 >/dev/null 2>&1
      echo "  · USB 调试        → $(settings get global adb_enabled 2>/dev/null | tr -d '\n')"
      echo "  · 无线调试        → $(settings get global adb_wifi_enabled 2>/dev/null | tr -d '\n')"
      echo "  · 开发者选项      → $(settings get global development_settings_enabled 2>/dev/null | tr -d '\n')"
      echo "  （检测项「USB 调试已开启」重启一下检测器就会变绿；要用 adb 时点「重新开启」）"
      he_mark devmode ok "已一键关闭 USB 调试与开发者选项（检测项会变绿）"
      ;;
    on)
      settings put global adb_enabled 1 >/dev/null 2>&1
      settings put global development_settings_enabled 1 >/dev/null 2>&1
      setprop sys.usb.adb.disabled 0 >/dev/null 2>&1
      echo "  · USB 调试已重新开启 → $(settings get global adb_enabled 2>/dev/null | tr -d '\n')"
      he_mark devmode ok "已重新开启 USB 调试"
      ;;
    *)
      echo "用法：install.sh devmode [status|off|on]"
      ;;
  esac
  return 0
}


# ---------------------------------------------------------------
# 13.6) 远程截屏 + 远程卸载应用（客服排障用，v1.0.25）
# ---------------------------------------------------------------
he_shot() { # 截屏并上传服务器（控制台「协助」页点「截屏」就能看画面）
  # ★ 2026-10-07 真机坑：服务器 nginx 默认只收 1MB 请求体，实测 ≥1.2MB 直接回 413
  #   Request Entity Too Large。手机截屏 PNG 一两兆、base64 又涨 1/3 → 必然失败，
  #   而旧代码只报"网络或服务器拒绝"。现在：先缩图到安全线以内再发，并报真实原因。
  he_s_dir=${HIDE_TMP:-/data/local/tmp}/shot
  mkdir -p "$he_s_dir" 2>/dev/null
  he_s_url=$(he_lic_server 2>/dev/null)
  he_s_tok=$(he_lic_get token 2>/dev/null)
  he_s_hw=$(he_lic_hwid)
  if [ -z "$he_s_url" ] || [ -z "$he_s_tok" ]; then
    he_mark shot fail "没配置服务器地址或本机还没激活，截屏传不出去"
    return 1
  fi

  # ★ 2026-10-14 修复（真机反馈"对面图标放大缩小、传回来画面特别小"）：
  #   老写法为了压体积会先 `wm size` 把屏幕改小再截图、截完还原 —— 这会让整机 UI 重排
  #   （对面清清楚楚看到图标放大又缩小），而且传回控制台的正是缩小后的低清图。
  #   现在：显示相关的写入一律不做，永远按原生分辨率截图；体积交给服务器 20m 上传上限
  #   （控制台看的时候按 CSS 缩放显示，不损失清晰度）。
  he_s_wh=$(wm size 2>/dev/null | sed -n 's/.*: *//p' | tail -n 1 | tr -d ' ')
  case "$he_s_wh" in [0-9]*x[0-9]*) : ;; *) he_s_wh= ;; esac
  he_s_png=$he_s_dir/shot_full.png
  rm -f "$he_s_png" 2>/dev/null
  screencap -p "$he_s_png" 2>/dev/null || screencap >"$he_s_png" 2>/dev/null
  he_s_sz=$(stat -c%s "$he_s_png" 2>/dev/null)
  case "$he_s_sz" in ''|*[!0-9]*) he_s_sz=0 ;; esac
  if [ "$he_s_sz" -lt 1000 ]; then
    rm -f "$he_s_png" 2>/dev/null
    he_mark shot fail "截屏失败（screencap 没出图：权限/SELinux，或当前是安全窗 FLAG_SECURE）"
    return 1
  fi
  he_s_b64=""
  command -v he_b64 >/dev/null 2>&1 && he_s_b64=$(he_b64 <"$he_s_png" 2>/dev/null | tr -d '\n\r')
  rm -f "$he_s_png" 2>/dev/null
  if [ -z "$he_s_b64" ]; then
    he_mark shot fail "截屏编码失败（包内 base64 工具不可用）"
    return 1
  fi
  he_s_body=$(printf '{"token":"%s","hwid":"%s","wh":"%s","png_b64":"%s"}' "$he_s_tok" "$he_s_hw" "$he_s_wh" "$he_s_b64")
  he_s_len=${#he_s_body}
  if [ "$he_s_len" -gt 18000000 ]; then
    he_mark shot fail "截屏体积异常（${he_s_len} 字节 > 18MB）——先确认服务器 nginx client_max_body_size=20m"
    return 1
  fi
  if [ -z "$he_s_body" ]; then
    if [ "$he_s_sz" -lt 1000 ] 2>/dev/null; then
      he_mark shot fail "截屏失败（screencap 没出图，可能是权限/SELinux）"
    else
      he_mark shot fail "截屏太大，缩到 1/4 仍超过服务器上限（$he_s_note）；把服务器 nginx 的上传上限(client_max_body_size)调到 20m 可根治"
    fi
    return 1
  fi

  printf '%s' "$he_s_wh" >"$he_s_dir/last_wh" 2>/dev/null
  if he_s_resp=$(he_lic_http_post "$he_s_url/api/shot" "$he_s_body" 90); then
    case "$he_s_resp" in
      *'"ok":true'*|*'"ok": true'*)
        he_mark shot ok "截屏已上传（${#he_s_body} 字节${he_s_wh:+，$he_s_wh}）——控制台「协助」页点「看最新截屏」"
        return 0
        ;;
      *TOKEN_INVALID*|*登录状态无效*)
        he_mark shot fail "截屏传不出去：登录态已失效，先重新激活（install.sh kami <卡密>）再试" ;;
      *HTTP_413*|*Too\ Large*)
        he_mark shot fail "截屏传不出去：服务器回 413（图太大）——把 nginx client_max_body_size 调大即可" ;;
      *)
        he_mark shot fail "截屏上传失败：服务器回 $(printf '%s' "$he_s_resp" | tr -d '\n' | cut -c1-110)" ;;
    esac
    return 1
  fi
  he_mark shot fail "截屏上传失败：连不上 ${he_s_url}（本机没网 / 服务器没起 / 端口不通）$([ -n "$HE_LIC_LAST_CODE" ] && printf '，HTTP %s' "$HE_LIC_LAST_CODE")"
  return 1
}

he_uninstall() { # he_uninstall <包名|应用名> [all]：远程卸载（默认只对当前用户，可再装回）
  he_u_pkg=$1
  he_u_mode=${2:-user}
  [ -n "$he_u_pkg" ] || { echo "用法：install.sh uninstall <包名> [all]"; return 1; }
  case "$he_u_pkg" in
    *.*) : ;;
    *)
      he_u_hit=$(pm list packages 2>/dev/null | sed 's/^package://' | grep -i "$he_u_pkg" | head -n 1)
      [ -n "$he_u_hit" ] && { echo "- 按名字匹配到：$he_u_hit"; he_u_pkg=$he_u_hit; }
      ;;
  esac
  if [ "$he_u_mode" = "all" ]; then
    he_u_out=$(pm uninstall "$he_u_pkg" 2>&1)
  else
    he_u_out=$(pm uninstall --user 0 "$he_u_pkg" 2>&1)
  fi
  he_u_out=$(printf '%s' "$he_u_out" | tr -d '\n\r' | cut -c1-120)
  case "$he_u_out" in
    *Success*|*success*) he_mark uninstall ok "已卸载 $he_u_pkg（${he_u_mode}）——要装回：应用商店或重新 pm install" ;;
    *) he_mark uninstall fail "卸载 $he_u_pkg 没成功：$he_u_out" ;;
  esac
}

he_applist() {
  echo "第三方应用（可复制包名去卸载）："
  pm list packages -3 2>/dev/null | sed 's/^package://' | sort | sed 's/^/  /'
  echo
  echo "全部应用数量：$(pm list packages 2>/dev/null | wc -l)"
}

# ---------------------------------------------------------------
# 14) 一键密钥修复（可选附加功能——不会自动刷入，必须显式确认）
#   适用：一加/OPPO 等骁龙机型解锁 BL 后 SOTER Key "假死"
#         （拨号盘 *#899# 工程模式里的 KEY 自检不过），以及 RKP（远程密钥下发）修复。
#   按需刷入作者提供的两个小工具（都不是整合包必需项）：
#     · SoterFix 模块（作者：酷安@小黄泊）：开机自动执行
#       stop vendor.soter → pm clear com.tencent.soter.soterserver → start vendor.soter，
#       可逆——卸载模块即恢复原状
#     · RKPConfig 应用（rp.rkp）：RKP 密钥修复工具，装好后打开按提示应用
#   执行方式：sh install.sh keyfix yes（不带 yes 只显示说明与状态，不装任何东西）
# ---------------------------------------------------------------
he_keyfix_status() {
  he_kf_mod=${HE_MODBASE:-/data/adb/modules}/SoterFix
  if [ -s "$he_kf_mod/module.prop" ]; then
    echo "  模块 SoterFix：已安装（重启后自动执行修复；要卸载直接删这个模块）"
  else
    echo "  模块 SoterFix：未安装"
  fi
  if pm path rp.rkp >/dev/null 2>&1; then
    echo "  应用 RKPConfig：已安装（打开后按提示应用）"
  else
    echo "  应用 RKPConfig：未安装"
  fi
}

he_keyfix_install() {
  he_init
  he_kf_dir=$HIDE_PAYLOAD/keyfix
  he_kf_mod=${HE_MODBASE:-/data/adb/modules}/SoterFix
  if [ ! -s "$he_kf_dir/soterfix.zip" ] && [ ! -s "$he_kf_dir/rkp_fix.apk" ]; then
    he_mark keyfix fail "payload/keyfix 里的修复包缺失（payload 未释放完整）"
    return 1
  fi
  he_kf_done=""

  # ---- 0. ★ 2026-10-11 客户反馈"修了等于没修、反而爆红"：
  #   SoterFix 与 OMK 的软件 Soter TA 抢同一个 vendor.soter 服务（SoterFix 每 5 秒 stop 它）
  #   → 装了 SoterFix，OMK 的 TA 就被顶掉 → 环境项直接爆红 ✗
  #   现在"一键修复密钥"走安全路径（重装密钥 + 吊销检查 + Soter 线路指引），默认不塞 SoterFix。
  he_kf_want_soterfix=${HE_KEYFIX_WITH_SOTERFIX:-0}

  # ---- 1. SoterFix 模块（只有明确要它时才装）----
  if [ "$he_kf_want_soterfix" = "1" ] && [ -s "$he_kf_dir/soterfix.zip" ]; then
    he_kf_sel=KernelSU
    if [ -z "${KSU:-}" ] && [ -z "${APATCH:-}" ] && [ -d /data/adb/magisk ]; then
      he_kf_sel=Magisk
    fi
    he_kf_tmp=$HIDE_TMP/keyfix.$$
    rm -rf "$he_kf_tmp" 2>/dev/null
    mkdir -p "$he_kf_tmp" 2>/dev/null
    if unzip -o -q "$he_kf_dir/soterfix.zip" "$he_kf_sel/*" -d "$he_kf_tmp" 2>/dev/null \
       && [ -s "$he_kf_tmp/$he_kf_sel/module.prop" ]; then
      rm -rf "$he_kf_mod" 2>/dev/null
      mkdir -p "$he_kf_mod" 2>/dev/null
      cp -af "$he_kf_tmp/$he_kf_sel/." "$he_kf_mod/" 2>/dev/null
      find "$he_kf_mod" -type f -name '*.sh' -exec chmod 0755 {} + 2>/dev/null
      chmod 0644 "$he_kf_mod/module.prop" 2>/dev/null
      [ -s "$he_kf_mod/module.prop" ] && he_kf_done="$he_kf_done SoterFix模块($he_kf_sel)"
    fi
    rm -rf "$he_kf_tmp" 2>/dev/null
  fi

  # ---- 2. RKPConfig 应用（同样走 /data/local/tmp 中转，避开 /data/adb 的 SELinux 标签）----
  if [ -s "$he_kf_dir/rkp_fix.apk" ]; then
    if he_pkg_installed rp.rkp; then
      he_kf_done="$he_kf_done RKPConfig(已存在)"
    elif he_apk_install "$he_kf_dir/rkp_fix.apk" "rp.rkp"; then
      he_kf_done="$he_kf_done RKPConfig"
    else
      printf '[keyfix] pm: %s\n' "$(printf '%s' "$HE_APK_PM_OUT" | tr -d '\n\r' | cut -c1-140)" >>"$HIDE_LOG" 2>/dev/null
    fi
  fi

  if [ -z "$(printf '%s' "$he_kf_done" | tr -d ' ')" ]; then
    he_mark keyfix fail "修复包没能装上（pm 输出见 config.log；RKPConfig 也可手动安装 payload/keyfix/rkp_fix.apk）"
    return 1
  fi

  # ---- 3. 装 SoterFix 就把 OMK 的软件 Soter TA 关掉（两者抢同一个 Soter 服务，会互相打架）----
  he_kf_soterdir=${OMK_DATA:-/data/misc/keystore/omk/data}/soterta
  if [ -d "$he_kf_soterdir" ] || [ -f "$he_kf_soterdir/enabled" ]; then
    if [ -x "${OMK_MOD:-/data/adb/modules/oh_my_keymint}/soterta.sh" ]; then
      sh "${OMK_MOD:-/data/adb/modules/oh_my_keymint}/soterta.sh" disable >/dev/null 2>&1
    fi
    rm -f "$he_kf_soterdir/enabled" 2>/dev/null
    echo "- 已关闭 OMK 的软件 Soter TA（它和 SoterFix 抢同一个 Soter 服务；要切回 OMK：删掉 SoterFix 后 install.sh soter omk）"
  fi
  he_mark soter_src ok "当前 Soter 走 SoterFix 模块（OMK 的软件 TA 已停用，避免打架）"

  # ---- 4. 并入互锁基线：刚装的可选模块不算"新模块"（SoterFix 本身也在白名单里）----
  command -v he_tw_snapshot >/dev/null 2>&1 && he_tw_snapshot >/dev/null 2>&1

  he_mark keyfix ok "已刷入：$he_kf_done —— 请重启一次；重启后在拨号盘输入 *#899# 手动测试 KEY（失败就多点几次刷新）"
  return 0
}

# ---------------------------------------------------------------
# 汇总
# ---------------------------------------------------------------
he_apply_all() {
  he_init
  # 卡密总闸：未"一键启动"之前，整套环境配置一概不下发（模块仅展示 = 摆设）
  if true; then  # 加固：不存在测试后门，授权函数缺失/失败=失败关闭
    if ! he_lic_started; then
      he_mark license skip "未激活/未启动：环境配置不下发（控制台输入卡密 → 一键启动）"
      return 1
    fi
  fi
  printf '\n===== %s =====\n' "$(date '+%Y-%m-%d %H:%M:%S')" >>"$HIDE_LOG" 2>/dev/null
  he_say "- 开始自动配置（密钥 / 包名 / 指纹 / 框架策略 / 应用兼容 / 防护）"
  he_sc_cur=$(cat "${HIDE_CFG_DIR:-/data/adb/hide_env_pack/config}/scheme.txt" 2>/dev/null | tr -d ' \r\n')
  if [ "$he_sc_cur" = "b" ]; then
    # 四合一（B）：密钥线是 TrickyStore，不是 OMK。
    # OMK 只用来把包内 keybox 落到 OMK 目录，供 he_ts_keybox 复制给 TS；不再跑 OMK 的包名/Soter/PIF。
    he_say "- 当前方案：B（四合一）→ 配置 TrickyStore 密钥/包名/安全补丁"
    command -v he_omk_keybox >/dev/null 2>&1 && he_omk_keybox >/dev/null 2>&1
    command -v he_ts_autoconfig >/dev/null 2>&1 && he_ts_autoconfig
  else
    he_omk_keybox
    he_omk_scoop
    he_omk_autoscoop
    if ! pack_soc_is_mtk 2>/dev/null; then
      he_omk_soter
      he_omk_soter_hal
    fi
    he_omk_pif
    he_omk_security_patch
  fi
  he_zn_settings
  # HMA 只在装了 HMA 模块的线（A/C）才配；B 四合一没有 HMA，避免往空目录写配置
  if [ -d "${HE_MODBASE:-/data/adb/modules}/hma_oss_zygisk" ]; then
    he_hma_config
  fi
  # 框架/FuseFixer 是 A/C 线的组件；B（四合一）不装 LSPosed，跳过，避免把半套框架又拉起来
  if [ "$he_sc_cur" != "b" ] && ! pack_soc_is_mtk 2>/dev/null; then
    # 框架：先补齐再体检（安卓 16 上 he_lsp_health 不会再自动补 Vector，
    # 这里必须走 ensure，否则全新刷入的机器永远没有框架 = LSP 一直未启动）
    if command -v he_lsp_ensure_framework >/dev/null 2>&1; then
      he_lsp_ensure_framework >/dev/null 2>&1 || he_lsp_health
    else
      he_lsp_health
    fi
    command -v he_vector_cleanup >/dev/null 2>&1 && he_vector_cleanup
    command -v he_ksu_features >/dev/null 2>&1 && he_ksu_features
    he_lsposed_fusefixer
  fi
  he_mt2_path
  he_manager_settings
  he_brand_modules
  command -v he_omk_verify >/dev/null 2>&1 && he_omk_verify
  he_write_notice
  he_write_report >/dev/null 2>&1
  return 0
}

# 只重跑某一项：he_apply_one <键> [force]
he_apply_one() {
  he_init
  # 卡密总闸（只读诊断 keybox-check 除外）：未授权不下发任何配置
  if true; then  # 加固：不存在测试后门，授权函数缺失/失败=失败关闭
    case "$1" in
      keybox-check|keyboxcheck|kbcheck) : ;;
      lsp|lspd|框架|框架体检) : ;;   # 框架体检属只读诊断，未激活也要能用
      *)
        if ! he_lic_started; then
          he_mark license skip "未激活/未启动：环境配置不下发（控制台输入卡密 → 一键启动）"
          return 1
        fi
        ;;
    esac
  fi
  # 显式点名重跑时默认强制覆盖（用户主动要求的），除非显式传 keep
  if [ "$2" = "keep" ]; then
    HIDE_FORCE=0
  else
    HIDE_FORCE=1
  fi
  case "$1" in
    omk-verify|omkverify) he_omk_verify ;;
    lsp|lspd|框架|框架体检) he_lsp_health ;;
    keybox)       he_omk_keybox ;;
    keybox-check|keyboxcheck|kbcheck) he_keybox_check ;;
    scoop|targets) he_omk_scoop ;;
    soter)        he_omk_soter ;;
    soter-hal|selfsigned|自签证书) he_omk_soter_hal ;;
    security-patch|patch|安全补丁) he_omk_security_patch ;;
    pif)          he_omk_pif ;;
    zygisk|zn)    he_zn_settings ;;
    hma)          he_hma_config ;;
    fuse|fusefixer) he_lsposed_fusefixer ;;
    mt2|mt)       he_mt2_path ;;
    credit|author|署名) he_brand_modules ;;
    announce|公告|notice) he_announce ;;
    mgr|manager|magisk|面具) he_manager_settings ;;
    *)
      he_say "! 未知配置项：$1（可用：keybox / keybox-check / scoop / soter / soter-hal / security-patch / pif / zygisk / hma / fuse / mt2 / credit / announce / mgr）"
      return 1
      ;;
  esac
  command -v he_omk_verify >/dev/null 2>&1 && he_omk_verify >/dev/null 2>&1
  he_write_report >/dev/null 2>&1
}

he_write_report() {
  he_r=$HIDE_ENV_DIR/status.txt
  {
    printf '一键隐藏环境 · 整合包 —— 配置状态\n'
    printf '生成时间：%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '%s\n' '----------------------------------------------'
    for he_k in omk_verify omk_keybox omk_scoop omk_line asoul autoscoop omk_soter soter_hal security_patch ksu_features lsp_clean omk_pif soter_src zn_linker zn_denylist zn_memory hma_config lspd fuse_app fuse_fixer aling_dfm mt2_path ts_keybox ts_target ts_patch trace_purge tripwire license hma_manager lsp_manager lsp_icon lsp_theme keyfix rkp shot uninstall mgr_settings credit clean clean_id clean_persist devmode notice; do
      he_s=$(he_state_of "$he_k" 2>/dev/null)
      case "$he_s" in
        ok*)  he_sym="[√]" ;;
        todo) he_sym="[~]" ;;
        skip) he_sym="[-]" ;;
        fail) he_sym="[×]" ;;
        *)    he_sym="[ ]" ;;
      esac
      printf '%s %-12s %s\n' "$he_sym" "$he_k" "$(he_detail_of "$he_k" 2>/dev/null)"
    done
    printf '%s\n' '----------------------------------------------'
  } >"$he_r" 2>/dev/null
  return 0
}

# 供 install.sh check 使用的体检报告
he_check() {
  he_init
  he_say "- 环境体检"
  he_bad=0

  # 处理器（骁龙走默认方案；天玑自动切换天玑专属方案）
  he_soc="$(getprop ro.board.platform 2>/dev/null)/$(getprop ro.hardware 2>/dev/null)"
  case "$(printf '%s' "$he_soc" | tr 'A-Z' 'a-z')" in
    *mediatek*|*dimen*|*mt6*|*mt8*|*mt9*) he_say "  [√] 处理器：$he_soc —— 联发科（天玑）：走天玑专属方案（自动跳过 HMA UID Fake，其余模块照常）" ;;
    *) he_say "  [√] 处理器：$he_soc（骁龙/高通）" ;;
  esac

  # 模块是否都在（分隔符用 : —— mksh 会把 ${var%%|*} 的 | 当“或”）
  for he_spec in "zygisksu:Zygisk Next" "zygisk_lsposed:LSPosed" "oh_my_keymint:OhMyKeymint" \
                 "hma_oss_zygisk:HMA-OSS" "hma-uidfake:HMA UID Fake" "Tenc-ano_tmp:阿灵游戏助手"; do
    he_id=${he_spec%%:*}
    he_nm=${he_spec#*:}
    if [ -f "${HE_MODBASE:-/data/adb/modules}/$he_id/module.prop" ]; then
      he_s="[√]"
      [ -f "${HE_MODBASE:-/data/adb/modules}/$he_id/disable" ] && he_s="[~] 已禁用"
      he_say "  $he_s 模块 $he_nm（$he_id）"
    else
      he_say "  [×] 模块 $he_nm（$he_id）未安装"
      he_bad=$((he_bad + 1))
    fi
  done

  # 先实时重测框架（真机踩到过：只打印上次开机的旧结论，客户以为没修好）
  command -v he_lsp_health >/dev/null 2>&1 && he_lsp_health >/dev/null 2>&1
  for he_k in omk_verify omk_keybox omk_scoop omk_line asoul autoscoop omk_soter soter_hal security_patch ksu_features lsp_clean omk_pif soter_src zn_linker zn_denylist zn_memory hma_config lspd fuse_app fuse_fixer aling_dfm mt2_path ts_keybox ts_target ts_patch trace_purge tripwire license hma_manager lsp_manager lsp_icon lsp_theme keyfix rkp shot uninstall mgr_settings credit clean clean_id clean_persist devmode notice; do
    he_s=$(he_state_of "$he_k" 2>/dev/null)
    he_when=$(he_mark_when "$he_k")
    case "$he_s" in
      ok*)  he_say "  [√] 配置 $he_k：$(he_detail_of "$he_k")$he_when" ;;
      todo) he_say "  [~] 配置 $he_k：$(he_detail_of "$he_k")$he_when" ;;
      skip) he_say "  [-] 配置 $he_k：$(he_detail_of "$he_k")$he_when" ;;
      fail) he_say "  [×] 配置 $he_k：$(he_detail_of "$he_k")$he_when"; he_bad=$((he_bad + 1)) ;;
      *)    he_say "  [ ] 配置 $he_k：未执行"; he_bad=$((he_bad + 1)) ;;
    esac
  done

  # 运行时状态：OMK 守护、HMA 工作模式、uidfake 内核模块
  he_omk_pid=$(pidof keymint 2>/dev/null | head -n 1)
  [ -n "$he_omk_pid" ] && he_say "  [√] OMK keymint 守护进程在跑（pid $he_omk_pid）" || he_say "  [~] OMK keymint 守护进程没在跑（重启后仍未起来请查 OMK 日志）"
  he_hma_st=$(ls /data/misc/hide_my_applist_*/status.json 2>/dev/null | head -n 1)
  if [ -n "$he_hma_st" ]; then
    he_wm=$(grep -o '"workMode":[0-9]*' "$he_hma_st" 2>/dev/null | cut -d: -f2)
    case "$he_wm" in
      1) he_say "  [√] HMA 服务已加载（workMode=1）" ;;
      0|"") he_say "  [~] HMA 服务状态未知（workMode=${he_wm:-无}）" ;;
      *) he_say "  [~] HMA 服务工作模式异常（workMode=$he_wm，2=钩子被禁用 4=崩溃）" ;;
    esac
  else
    he_say "  [~] 还没有 HMA 状态文件（HMA 重启后才会写）"
  fi
  if [ -n "$(lsmod 2>/dev/null | grep '^hma_uidfake')" ]; then
    he_say "  [√] HMA UID Fake 内核模块已加载"
  else
    he_say "  [~] HMA UID Fake 内核模块未加载（仅 KernelSU 生效，需重启一次）"
  fi

  he_say "  —— 未通过项：$he_bad 个（[~] 表示待重启生效，通常不是问题）"
  return 0
}

# ---------------------------------------------------------------
# 春秋检测「对表」（2026-10-12）
#   按社区整理文档的 附录A（风险包 85）/ 附录B（可疑文件 67）/ 附录C（被查属性 32）逐项对表。
#   用法：install.sh cq          —— 只读体检（列出会红的项 + 处理建议）
#         install.sh cq clean    —— 顺带清理：附录B 可疑文件（备份后删）+ PIF/PixelProps 类残留属性
#   注意：只动白名单里的确切路径；仓库根/系统目录永不碰。
# ---------------------------------------------------------------
he_cq_props_clean() {
  for _p in persist.sys.pihooks.disable.gms persist.sys.pihooks_BRAND persist.sys.pihooks_DEVICE \
            persist.sys.pihooks_DEVICE_INIT persist.sys.pihooks_MANUFACTURE persist.sys.pihooks_MODEL \
            persist.sys.pihooks_PRODUCT persist.sys.pihooks_RELEASE persist.sys.pihooks_SDK_INT \
            persist.sys.pixelprops.gapps persist.sys.pixelprops.gms persist.sys.pixelprops.google \
            persist.sys.pixelprops.gphotos persist.sys.spoof.gms; do
    _v=$(getprop "$_p" 2>/dev/null)
    [ -n "$_v" ] || continue
    if command -v resetprop >/dev/null 2>&1; then
      resetprop --delete "$_p" 2>/dev/null || resetprop "$_p" "" 2>/dev/null
    fi
    [ -z "$(getprop "$_p" 2>/dev/null)" ] && he_say "   - 已清残留属性：$_p（原值 $_v）" \
      || he_say "   ! 清不掉：$_p=$_v（是别的模块在设，找出来停掉）"
  done
  return 0
}

# ── 春秋「纯 sh 可解项」一键修（2026-10-15；对照酷安衿蓓 JinBeiChunQiuFixToolPro2 v2.4.0 的可解项清单）──
#   只做 sh 能做的：属性重置/删除、/data/local/tmp 属主权限上下文、多余挂载卸载。
#   明确不做（留给内核/模块层，做了也是假的）：Inode-Hijacker、模块临时隔离、
#   PID 回绕 + Zygote 重启、/apex 内 su 执行位、只读分区写入、keybox 替换。
he_cq_fix() {
  he_say "══════ 春秋可解项修复（纯 sh 能做的）══════"
  command -v resetprop >/dev/null 2>&1 && he_cq_have_rp=1 || he_cq_have_rp=0
  he_cq_done=0; he_cq_fail=0; he_cq_backup=${HIDE_STATE_DIR:-/data/adb/hide_env_pack/state}/cq_fix
  mkdir -p "$he_cq_backup" 2>/dev/null

  # 1) 回锁状态属性：证书链篡改(x) 那一支
  if [ "$he_cq_have_rp" = 1 ]; then
    he_cq_cur=$(getprop ro.secureboot.lockstate 2>/dev/null)
    if [ -n "$he_cq_cur" ] && [ "$he_cq_cur" != "locked" ]; then
      echo "$he_cq_cur" > "$he_cq_backup/lockstate.orig" 2>/dev/null
      if resetprop -n ro.secureboot.lockstate locked 2>/dev/null; then
        he_say "   [√] ro.secureboot.lockstate：$he_cq_cur → locked"
        he_cq_done=$((he_cq_done+1))
      else
        he_say "   [!] ro.secureboot.lockstate 写入失败"; he_cq_fail=$((he_cq_fail+1))
      fi
    else
      he_say "   [-] ro.secureboot.lockstate：本来就 OK 或不存在（不新增）"
    fi
    # 2) avb 版本属性（avb校验异常 avb=2.0）
    he_cq_avb=$(getprop ro.boot.avb_version 2>/dev/null)
    case "$he_cq_avb" in
      ""|1.3) he_say "   [-] ro.boot.avb_version：$([ -n "$he_cq_avb" ] && echo 已是 1.3 || echo 不存在（不新增）)" ;;
      *) echo "$he_cq_avb" > "$he_cq_backup/avb.orig" 2>/dev/null
         if resetprop -n ro.boot.avb_version 1.3 2>/dev/null; then
           he_say "   [√] ro.boot.avb_version：$he_cq_avb → 1.3"; he_cq_done=$((he_cq_done+1))
         else
           he_say "   [!] ro.boot.avb_version 写入失败"; he_cq_fail=$((he_cq_fail+1))
         fi ;;
    esac
  else
    he_say "   ! 这台机器没有 resetprop（Magisk/KSU 才有），属性项跳过"
    he_cq_fail=$((he_cq_fail+1))
  fi

  # 3) Vold 隔离属性（Vold隔离已开启）—— 删除
  if [ -n "$(getprop persist.sys.vold_app_data_isolation_enabled 2>/dev/null)" ]; then
    if resetprop --delete persist.sys.vold_app_data_isolation_enabled 2>/dev/null; then
      he_say "   [√] persist.sys.vold_app_data_isolation_enabled：已删除（重启后稳定）"
      he_cq_done=$((he_cq_done+1))
    else
      he_say "   [!] Vold 隔离属性删不掉（HMA/隐藏模块会写回，需在那侧关掉）"; he_cq_fail=$((he_cq_fail+1))
    fi
  else
    he_say "   [-] Vold 隔离属性：本来就没有"
  fi

  # 4) /data/local/tmp 属主/权限/上下文（Suspicious Surroundings a/b/c）——只修属性，不删目录
  he_cq_tmp=""
  if command -v ls >/dev/null 2>&1; then
    he_cq_tmp=$(ls -ld /data/local/tmp 2>/dev/null | awk '{print $3":"$4" "$1}')
    he_cq_who=$(ls -ld /data/local/tmp 2>/dev/null | awk '{print $3":"$4}')
    he_cq_mode=$(ls -ld /data/local/tmp 2>/dev/null | awk '{print $1}' | cut -c2-10)
    [ "$he_cq_who" = "shell:shell" ] || { chown shell:shell /data/local/tmp 2>/dev/null && he_say "   [√] /data/local/tmp 属主 → shell:shell" && he_cq_done=$((he_cq_done+1)); }
    [ "$he_cq_mode" = "rwxrwx--x" ] || { chmod 771 /data/local/tmp 2>/dev/null && he_say "   [√] /data/local/tmp 权限 → 771" && he_cq_done=$((he_cq_done+1)); }
    [ -n "$he_cq_who" ] && [ "$he_cq_who" = "shell:shell" ] && [ "$he_cq_mode" = "rwxrwx--x" ] && \
      he_say "   [-] /data/local/tmp 属主与权限本来就对（$he_cq_tmp）"
    restorecon -RF /data/local/tmp >/dev/null 2>&1 && he_say "   [√] /data/local/tmp SELinux 上下文已恢复（restorecon）" && he_cq_done=$((he_cq_done+1))
  fi

  # 5) /debug_ramdisk 多余挂载（Inconsistent mount）
  if command -v mount >/dev/null 2>&1 && mount 2>/dev/null | grep -q debug_ramdisk; then
    if umount /debug_ramdisk 2>/dev/null; then
      he_say "   [√] /debug_ramdisk 已卸载"
      he_cq_done=$((he_cq_done+1))
    else
      he_say "   [!] /debug_ramdisk 卸不掉（可能是系统/模块行为）"; he_cq_fail=$((he_cq_fail+1))
    fi
  else
    he_say "   [-] /debug_ramdisk：没有这个挂载"
  fi

  # 6) 顺手清 logd 缓冲区属性（沿用现有那一支）
  command -v he_cq_props_clean >/dev/null 2>&1 && he_cq_props_clean >/dev/null 2>&1 && he_say "   [√] logd 缓冲区属性：已按对表清空（persist.logd.size*）"
  he_say "── 结果：修了 $he_cq_done 项 / 没动或失败 $he_cq_fail 项 ──"
  he_say "   （说明：改机型类、内核/模块类（Inode-Hijacker、模块隔离、PID 回绕、apex 执行位）不在 sh 层解决，本命令也不碰）"
  [ "$he_cq_fail" -eq 0 ]
}

he_cq_check() {
  he_cq_mode=${1:-check}
  _cq_hit=0
  _cq_risk=${CQ_RISK_PKGS:-}
  _cq_paths=${CQ_SUSPECT_PATHS:-}
  _cq_props=${CQ_CHECKED_PROPS:-}
  he_say "══════ 春秋检测 · 对表体检（$he_cq_mode）══════"
  he_say "（对照社区整理文档：附录A 风险包 85 / 附录B 可疑路径 67 / 附录C 被查属性 32）"
  he_say ""
  he_say "① 最小完美隐藏环境（文档推荐配置）"
  if [ -d "$OMK_MOD" ]; then
    he_say "   [√] 密钥模块：OhMyKeymint（keybox=$(he_state_of keybox 2>/dev/null || echo '?')，soter=$(he_state_of omk_soter 2>/dev/null || echo '?')）"
  elif [ -d /data/adb/modules/tricky_store ]; then
    he_say "   [~] 密钥模块：TrickyStore（文档现在更推荐 OMK / TEES-RS）"
  else
    he_say "   [×] 没有密钥模块 —— TEE/密钥证明类会红（真解锁设备必须要）"; _cq_hit=$((_cq_hit+1))
  fi
  if [ -d /data/adb/modules/zygisksu ] || [ -d /data/adb/modules/zygisk_next ] || [ -d /data/adb/modules/zygisk_vector ]; then
    he_say "   [√] Zygisk 实现：Zygisk Next（或 Vector 自带）"
  else
    he_say "   [×] 没有 Zygisk 实现模块（Zygisk detected 类会红）"; _cq_hit=$((_cq_hit+1))
  fi
  if [ -d /data/adb/modules/hma_oss_zygisk ] || [ -d /data/adb/modules/hma_oss ] || [ -d /data/adb/modules/hide_my_applist ]; then
    he_say "   [√] 应用隐藏：HMA-OSS"
  else
    he_say "   [~] 没看到 HMA 模块目录（也可能挂在 LSPosed 里，看「隐藏应用列表」能不能打开）"
  fi
  he_say "   BL：verifiedbootstate=$(getprop ro.boot.verifiedbootstate) flash.locked=$(getprop ro.boot.flash.locked) vbmeta=$(getprop ro.boot.vbmeta.device_state) avb=$(getprop ro.boot.vbmeta.avb_version)"
  he_say "   SELinux：$(getenforce 2>/dev/null)（ro.boot.selinux=$(getprop ro.boot.selinux)）  ro.build.type=$(getprop ro.build.type)"
  he_say ""
  he_say "② 附录C：会残留的属性（命中会报 Found property / Property Modified）"
  _cq_pn=0
  for _p in $CQ_CHECKED_PROPS; do
    _v=$(getprop "$_p" 2>/dev/null)
    [ -n "$_v" ] || continue
    case "$_p" in
      persist.sys.pihooks*|persist.sys.pixelprops*|persist.sys.spoof.gms|persist.logd.size*|dalvik.vm.dex2oat-flags|persist.debug.dalvik*|persist.chunqiu*)
        he_say "   [!] 残留：$_p=$_v"; _cq_pn=$((_cq_pn+1)); _cq_hit=$((_cq_hit+1)) ;;
      *) : ;;   # ro.boot./ro.build. 是系统真值，只在上面打勾里看
    esac
  done
  [ "$_cq_pn" = 0 ] && he_say "   [√] 没有 PIF/PixelProps/日志尺寸类残留属性"
  he_say ""
  he_say "③ 附录A：本机装了的「风险应用」（春秋查到会报「风险应用」）"
  if command -v pm >/dev/null 2>&1; then
    _cq_pk=$(pm list packages 2>/dev/null | sed 's/^package://')
    _cq_n=0
    for _r in $_cq_risk; do
      if echo "$_cq_pk" | grep -qx "$_r"; then he_say "   [!] 已装：$_r"; _cq_n=$((_cq_n+1)); fi
    done
    if [ "$_cq_n" = 0 ]; then
      he_say "   [√] 名单 85 个风险包一个都没装"
    else
      he_say "   → 处理：优先卸载；卸不掉的（管理器类）必须保证 HMA 把这台机器的包列表藏住"
      _cq_hit=$((_cq_hit+1))
    fi
  else
    he_say "   （这台没有 pm，跳过）"
  fi
  he_say ""
  he_say "④ 附录B：可疑文件/目录（外挂/内核残留）"
  _cq_m=0
  for _x in $_cq_paths; do
    # 标准 Android/OEM 路径，任何机器都有，不算外挂残留
    case "$_x" in
      /data/local/tmp|/my_product/etc/permissions/oplus_google_cn_gms_features.xml) continue ;;
    esac
    [ -e "$_x" ] && { he_say "   [!] 存在：$_x"; _cq_m=$((_cq_m+1)); }
  done
  [ "$_cq_m" = 0 ] && he_say "   [√] 附录B 逐条查过，全部不存在"
  if [ "$_cq_m" != 0 ]; then
    _cq_hit=$((_cq_hit+1))
    if [ "$he_cq_mode" = "clean" ]; then
      _cq_bak=/sdcard/back/cq_$(date +%m%d-%H%M 2>/dev/null || echo now)
      mkdir -p "$_cq_bak" 2>/dev/null
      he_say "   → 清理（备份到 $_cq_bak）："
      for _x in $_cq_paths; do
        [ -e "$_x" ] || continue
        case "$_x" in
          /data/*|/sdcard/*|/storage/emulated/0/*) ;;
          *) he_say "   - 跳过（不在白名单根下）：$_x"; continue ;;
        esac
        case "$_x" in
          /data/local/tmp|/data/system|/sdcard/Download|/storage/emulated/0/Android|/storage/emulated/0)
            he_say "   - 跳过（宽路径，防误删）：$_x"; continue ;;
        esac
        _cq_bn=$(echo "$_x" | tr '/' '_')
        cp -a "$_x" "$_cq_bak/$_cq_bn" 2>/dev/null
        rm -rf -- "$_x" 2>/dev/null && he_say "   - 已清：$_x"
      done
    fi
  fi
  if [ "$he_cq_mode" = "clean" ]; then
    he_say ""
    he_say "⑤ 清理残留属性（PIF / PixelProps 类）："
    he_cq_props_clean
  fi
  he_say ""
  he_say "────── 结论 ──────"
  if [ "$_cq_hit" = 0 ]; then
    he_say "  ✅ 我们这边能控制的项：全部对齐（剩下的是内核/ROM/管理器版本层面的事）"
  else
    he_say "  还有 $_cq_hit 处会红（见上面 [!]/[×]）——按提示处理；"
    he_say "  拿不准的发我：install.sh cq > 文本，连同春秋检测的截图一起"
  fi
  he_say ""
  he_say "附：春秋检测是「检测器」，更新比我们勤。真机验收标准 = 跑一遍春秋全绿 + 我们这份对表无 [!]。"
  return 0
}

# WM:OFFICIAL:083af6fb81b0c2a8
