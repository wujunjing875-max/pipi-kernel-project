#!/system/bin/sh
#############################################################
# hide_env_assist.sh —— 远程协助：控制台下命令，本机执行并把输出回传
#
# 三层门禁（缺一不可，全部满足才会执行任何东西）：
#   1) 本机开关：config/assist.txt 写 off → 彻底不理会（install.sh assist off）
#   2) 必须是"已激活 + 已一键启动"的设备（摆设状态不接受命令）
#   3) 服务端的「协助窗口」开着（控制台开，或机主自己在本机页面开，默认 15 分钟、到点自动停）
#
# 设计要点：
#   · 平时 90 秒探一次；开窗后 12 秒一次；未激活 5 分钟一次
#   · 命令 base64 传输（避免引号/换行/中文在 shell 里被转义搞坏）
#   · 单条命令超时封顶 300 秒，输出封顶 64KB
#   · 每条命令与执行结果都写本机日志 $HIDE_ENV_DIR/assist/assist.log（root 可查）
#############################################################

HE_AS_DIR=${HE_AS_DIR:-$HIDE_ENV_DIR/assist}
HE_AS_LOG=$HE_AS_DIR/assist.log
HE_AS_PIDF=$HE_AS_DIR/poller.pid
HE_AS_BEAT=$HE_AS_DIR/poller.beat
HE_AS_NOTE=$HE_AS_DIR/note.txt
HE_AS_MAXOUT=65536

he_as_log() {
  mkdir -p "$HE_AS_DIR" 2>/dev/null
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >>"$HE_AS_LOG" 2>/dev/null
  chmod 0600 "$HE_AS_LOG" 2>/dev/null
}

he_as_b64e() { # stdin → base64（调用方负责再 tr -d '\n\r' 防折行污染 JSON）
  if command -v he_b64 >/dev/null 2>&1; then
    he_b64 && return 0
  fi
  # 独立 base64 本体（GNU/toybox 独立版都是直接读 stdin）
  for he_c in /system/bin/base64 /system/xbin/base64 /usr/bin/base64 /bin/base64; do
    [ -x "$he_c" ] || continue
    "$he_c" 2>/dev/null && return 0
  done
  # busybox / toybox 的子命令形式
  if [ -x "$HIDE_BIN/busybox" ]; then
    "$HIDE_BIN/busybox" base64 2>/dev/null && return 0
  fi
  if [ -x /system/bin/toybox ]; then
    /system/bin/toybox base64 2>/dev/null && return 0
  fi
  return 1
}

he_as_b64d() { # he_as_b64d <base64> → stdout 原文
  he_ad_in=$1
  for he_c in "$HIDE_BIN/busybox" /system/bin/toybox /system/bin/base64 /system/xbin/base64 /usr/bin/base64 /bin/base64; do
    [ -x "$he_c" ] || continue
    case "$he_c" in
      *busybox|*toybox)
        printf '%s' "$he_ad_in" | "$he_c" base64 -d 2>/dev/null && return 0 ;;
      *)
        printf '%s' "$he_ad_in" | "$he_c" -d 2>/dev/null && return 0 ;;
    esac
  done
  return 1
}

he_as_exec() { # he_as_exec <命令> <超时秒>；rc 写 $HE_AS_DIR/last_rc，输出写 $HE_AS_DIR/last_out
  he_ax_cmd=$1
  he_ax_to=${2:-60}
  case "$he_ax_to" in ''|*[!0-9]*) he_ax_to=60 ;; esac
  [ "$he_ax_to" -lt 5 ] && he_ax_to=5
  [ "$he_ax_to" -gt 300 ] && he_ax_to=300
  mkdir -p "$HE_AS_DIR" 2>/dev/null
  he_ax_sh=$HE_AS_DIR/run.$$.sh
  printf '%s\n' "$he_ax_cmd" >"$he_ax_sh" 2>/dev/null
  chmod 0700 "$he_ax_sh" 2>/dev/null
  # ★ 输出不能直接重定向到 /data/adb（2026-10-23 真机：input tap 会报
  #   "Failure calling service input: Failed transaction"）——app_process 继承
  #   指向 ksu_file 的 stdout 后注入事件失败。先写 /data/local/tmp，再拷回。
  he_ax_out=/data/local/tmp/.he_as_out.$$
  : >"$he_ax_out" 2>/dev/null
  : >"$HE_AS_DIR/last_out" 2>/dev/null
  # 明确 PATH：有些 root 环境给模块的 PATH 很短，reboot/svc/am/pm 会"command not found"(127)
  ( export PATH="/system/bin:/system/xbin:/system/sbin:/vendor/bin:/odm/bin:/sbin:${PATH:-}"; sh "$he_ax_sh" ) >"$he_ax_out" 2>&1 &
  he_ax_pid=$!
  rm -f "$HE_AS_DIR/killed.$$" 2>/dev/null
  ( sleep "$he_ax_to"; kill -9 "$he_ax_pid" 2>/dev/null; printf 1 >"$HE_AS_DIR/killed.$$" 2>/dev/null ) >/dev/null 2>&1 &
  he_ax_wd=$!
  wait "$he_ax_pid" 2>/dev/null
  he_ax_rc=$?
  kill "$he_ax_wd" 2>/dev/null
  wait "$he_ax_wd" 2>/dev/null
  if [ -s "$HE_AS_DIR/killed.$$" ]; then
    he_ax_rc=124
    printf '\n[已超时 %ss，被强制结束]\n' "$he_ax_to" >>"$he_ax_out" 2>/dev/null
  fi
  cp -f "$he_ax_out" "$HE_AS_DIR/last_out" 2>/dev/null
  rm -f "$he_ax_sh" "$he_ax_out" "$HE_AS_DIR/killed.$$" 2>/dev/null
  printf '%s' "$he_ax_rc" >"$HE_AS_DIR/last_rc" 2>/dev/null
  return 0
}

he_as_once() { # 一轮：心跳复核 + 领命令 + 执行 + 回传。0=本轮跑过；1=跳过
  he_aw_iv=0
  he_as_window_cache=0
  he_urlbase=$(he_lic_server 2>/dev/null)
  [ -n "$he_urlbase" ] || return 1
  he_a_tok=$(he_lic_get token 2>/dev/null)
  [ -n "$he_a_tok" ] || return 1
  he_a_hw=$(he_lic_hwid)
  he_a_mem=$(he_lic_member 2>/dev/null)
  he_a_int=1
  command -v he_lic_int_check >/dev/null 2>&1 && { he_lic_int_check || he_a_int=0; }
  he_a_ver=$(sed -n 's/^versionCode=//p' /data/adb/modules/hide_env_pack/module.prop 2>/dev/null | tr -d '\r' | head -n 1)
  he_a_dev=""
  command -v he_lic_dev_json >/dev/null 2>&1 && he_a_dev=$(he_lic_dev_json 2>/dev/null)
  # 长轮询：把请求挂住等命令（服务器一下发立刻返回 → 秒级执行，不用等下一轮）
  he_a_wait=${HE_AS_WAIT:-8}
  case "$he_a_wait" in ''|*[!0-9]*) he_a_wait=25 ;; esac
  [ "$he_a_wait" -gt 8 ] && he_a_wait=8
  he_body=$(printf '{"token":"%s","hwid":"%s","hwid_old":"%s","member":"%s","int":%s,"ver":"%s","started":1,"wait":%s,%s}' \
    "$he_a_tok" "$he_a_hw" "$(he_lic_hwid_legacy)" "$he_a_mem" "$he_a_int" "${he_a_ver:-0}" "$he_a_wait" "$he_a_dev")
  he_resp=$(he_lic_http_post "$he_urlbase/api/poll" "$he_body" $((he_a_wait + 15)) 2>/dev/null) || return 1
  he_lic_jok "$he_resp" || return 1

  # 顺手吸收服务端状态（与开机心跳同款：到期时间 / 刷入授权窗口 / 解除限制开关）
  he_a_exp=$(he_lic_jget "$he_resp" expire_at); case "$he_a_exp" in ''|*[!0-9]*) he_a_exp=0 ;; esac
  [ "$he_a_exp" -gt 0 ] 2>/dev/null && he_lic_save expire_at "$he_a_exp"
  he_a_fu=$(he_lic_jget "$he_resp" flash_until); case "$he_a_fu" in ''|*[!0-9]*) he_a_fu=0 ;; esac
  if [ "$he_a_fu" -gt 0 ] 2>/dev/null && command -v he_lic_flash_absorb >/dev/null 2>&1; then
    he_lic_flash_absorb "$he_a_fu"
  fi
  he_a_go=$(he_lic_jget "$he_resp" guard_off)
  if command -v he_lic_relax_set >/dev/null 2>&1; then
    case "$he_a_go" in
      1) he_lic_relax_set 1 ;;
      0) he_lic_relax_set 0 ;;
    esac
  fi

  # 协助窗口剩余（决定下一轮快慢）；控制台开了「常开协助」也按开窗算
  he_a_au=$(he_lic_jget "$he_resp" assist_until)
  # 控制台播报：长轮询在跑时几乎秒到
  command -v he_bc_show >/dev/null 2>&1 && he_bc_show "$(he_lic_jget "$he_resp" bc_id)" "$(he_lic_jget "$he_resp" bc_title)" "$(he_lic_jget "$he_resp" bc_text)"
  case "$he_a_au" in ''|*[!0-9]*) he_a_au=0 ;; esac
  he_as_window_cache=$he_a_au
  he_a_al=$(he_lic_jget "$he_resp" assist_always)
  case "$he_a_al" in 1|2|3|4|5|6|7|8|9) he_as_window_cache=1 ;; esac

  # 领命令
  he_a_id=$(he_lic_jget "$he_resp" cmd_id)
  case "$he_a_id" in ''|*[!0-9]*) return 0 ;; esac
  he_a_b64=$(he_lic_jget "$he_resp" cmd_b64)
  [ -n "$he_a_b64" ] || return 0
  he_a_cmd=$(he_as_b64d "$he_a_b64")
  [ -n "$he_a_cmd" ] || return 0
  he_a_to=$(he_lic_jget "$he_resp" cmd_timeout)
  case "$he_a_to" in ''|*[!0-9]*) he_a_to=60 ;; esac

  he_as_log "执行命令 #$he_a_id（超时 ${he_a_to}s）：$(printf '%s' "$he_a_cmd" | head -c 200 | tr '\n' ' ')"
  he_as_exec "$he_a_cmd" "$he_a_to"
  he_a_rc=$(cat "$HE_AS_DIR/last_rc" 2>/dev/null)
  case "$he_a_rc" in ''|*[!0-9]*) he_a_rc=1 ;; esac
  he_a_out=$(head -c "$HE_AS_MAXOUT" "$HE_AS_DIR/last_out" 2>/dev/null)
  he_a_outb64=$(printf '%s' "$he_a_out" | he_as_b64e | tr -d '\n\r')
  he_rbody=$(printf '{"token":"%s","hwid":"%s","hwid_old":"%s","id":%s,"rc":%s,"out_b64":"%s"}' \
    "$he_a_tok" "$he_a_hw" "$(he_lic_hwid_legacy)" "$he_a_id" "$he_a_rc" "$he_a_outb64")
  # 先补发上一次没送出去的结果（网络抖动/断网时不丢输出）
  if [ -s "$HE_AS_DIR/pending_result" ]; then
    he_pr=$(cat "$HE_AS_DIR/pending_result" 2>/dev/null)
    if [ -n "$he_pr" ] && he_lic_http_post "$he_urlbase/api/result" "$he_pr" >/dev/null 2>&1; then
      rm -f "$HE_AS_DIR/pending_result" 2>/dev/null
      he_as_log "补发上一次未送达的结果成功"
    fi
  fi
  he_a_try=0
  he_a_got=0
  while [ "$he_a_try" -lt 3 ]; do
    he_a_try=$((he_a_try + 1))
    he_rresp=$(he_lic_http_post "$he_urlbase/api/result" "$he_rbody" 2>/dev/null) && he_a_got=1 && break
    sleep 3
  done
  if [ "$he_a_got" = "1" ]; then
    rm -f "$HE_AS_DIR/pending_result" 2>/dev/null
    he_as_log "命令 #$he_a_id 结束 rc=$he_a_rc（回传成功）"
  else
    printf '%s' "$he_rbody" >"$HE_AS_DIR/pending_result" 2>/dev/null
    he_as_log "命令 #$he_a_id 结束 rc=$he_a_rc（回传失败，已暂存待补发）"
  fi
  return 0
}

he_as_loop() { # 常驻轮询（由 he_as_spawn 后台拉起）：只要有授权 token 就保持在线
  he_as_log "轮询器启动"
  mkdir -p "$HE_AS_DIR" 2>/dev/null
  date +%s >"$HE_AS_BEAT" 2>/dev/null
  sleep 5
  while :; do
    date +%s >"$HE_AS_BEAT" 2>/dev/null
    [ -d "$HIDE_ENV_DIR" ] || exit 0
    he_a_iv=15
    he_lic_load 2>/dev/null
    if [ -n "$he_lv_token" ]; then
      he_as_once
      # 一条命令最长 300 秒；执行完再写一次心跳，避免看护把“正在跑长命令”误判成卡死
      date +%s >"$HE_AS_BEAT" 2>/dev/null
      if [ "${he_as_window_cache:-0}" -gt 0 ] 2>/dev/null; then
        he_a_iv=1    # 全时/窗口内：长轮询背靠背（挂 25 秒 + 歇 1 秒）→ 指令秒级到达
      else
        he_a_iv=15
      fi
    else
      he_a_iv=300     # 还没激活（没 token）：慢速等，激活后不用重启也能接上
    fi
    sleep "$he_a_iv"
  done
}

he_as_spawn() { # 拉起轮询器（已在跑且 480 秒内有动作就不重复起）
  mkdir -p "$HE_AS_DIR" 2>/dev/null
  he_as_now=$(date +%s 2>/dev/null)
  case "$he_as_now" in ''|*[!0-9]*) he_as_now=0 ;; esac
  if [ -s "$HE_AS_PIDF" ]; then
    he_asp=$(cat "$HE_AS_PIDF" 2>/dev/null)
    case "$he_asp" in
      ''|*[!0-9]*) : ;;
      *)
        if kill -0 "$he_asp" 2>/dev/null; then
          he_as_beat=$(cat "$HE_AS_BEAT" 2>/dev/null)
          case "$he_as_beat" in ''|*[!0-9]*) he_as_beat=0 ;; esac
          if [ "$he_as_now" -gt 0 ] && [ "$he_as_beat" -gt 0 ] && \
             [ $((he_as_now - he_as_beat)) -lt 120 ]; then
            return 0
          fi
          kill -9 "$he_asp" 2>/dev/null
          he_as_log "轮询器 120 秒无动作，重启（旧 pid $he_asp）"
        fi
        ;;
    esac
  fi
  rm -f "$HE_AS_PIDF" 2>/dev/null
  ( he_as_loop ) >/dev/null 2>&1 &
  printf '%s\n' "$!" >"$HE_AS_PIDF" 2>/dev/null
  return 0
}

he_as_kill() {
  if [ -s "$HE_AS_PIDF" ]; then
    he_ask=$(cat "$HE_AS_PIDF" 2>/dev/null)
    case "$he_ask" in
      ''|*[!0-9]*) : ;;
      *) kill -9 "$he_ask" 2>/dev/null ;;
    esac
  fi
  rm -f "$HE_AS_PIDF" 2>/dev/null
  return 0
}

he_as_window() { # he_as_window <分钟>（0=关窗）：本机页面/终端开协助窗口
  he_aw_min=${1:-15}
  case "$he_aw_min" in ''|*[!0-9]*) he_aw_min=15 ;; esac
  [ "$he_aw_min" -gt 120 ] && he_aw_min=120
  he_lic_load 2>/dev/null
  if [ "$he_lv_activated" != "1" ]; then
    echo "! 还没激活：先输入卡密激活后再开协助窗口"
    return 1
  fi
  he_aw_url=$(he_lic_server 2>/dev/null)
  [ -n "$he_aw_url" ] || { echo "! 没配置卡密服务器地址"; return 1; }
  he_aw_hw=$(he_lic_hwid)
  he_body=$(printf '{"token":"%s","hwid":"%s","minutes":%s}' "$he_lv_token" "$he_aw_hw" "$he_aw_min")
  if ! he_resp=$(he_lic_http_post "$he_aw_url/api/assist" "$he_body"); then
    echo "! 连不上服务器，开窗失败"
    return 1
  fi
  if he_lic_jok "$he_resp"; then
    he_aw_until=$(he_lic_jget "$he_resp" until)
    if [ "$he_aw_min" = "0" ]; then
      echo "[√] 协助窗口已关闭（对方再下发命令也不会执行）"
      he_as_log "机主关闭协助窗口"
    else
      echo "[√] 协助窗口已开 $he_aw_min 分钟（客服可在控制台远程执行命令）"
      [ -n "$he_aw_until" ] && [ "$he_aw_until" -gt 0 ] 2>/dev/null && \
        echo "    窗口到期：$(date -d @$he_aw_until '+%Y-%m-%d %H:%M' 2>/dev/null || echo "$he_aw_until（unix 秒）")"
      echo "    随时可关：install.sh assist close（或本机页面「关闭协助」）；彻底禁用：install.sh assist off"
      he_as_log "机主开协助窗口 ${he_aw_min} 分钟"
    fi
    he_as_spawn
    return 0
  fi
  echo "! 服务器拒绝：$(he_lic_jget "$he_resp" msg)"
  return 1
}

he_as_status() {
  echo "客服排障通道（随模块装入，无需任何本机操作）"
  he_lic_load 2>/dev/null
  if [ -n "$he_lv_token" ]; then
    echo "  设备状态：已激活并在线（客服随时可以远程执行命令帮你排障）"
  else
    echo "  设备状态：还没激活（激活后这条通道自动上线，不用再操作）"
  fi
  [ -s "$HE_AS_NOTE" ] && echo "  说明：$HE_AS_NOTE"
  he_asp=$(cat "$HE_AS_PIDF" 2>/dev/null)
  if [ -n "$he_asp" ] && kill -0 "$he_asp" 2>/dev/null; then
    echo "  轮询器：在跑（pid $he_asp）"
  else
    echo "  轮询器：没在跑（开机或 install.sh assist on 会自动拉起）"
  fi
  he_ab=$(cat "$HE_AS_BEAT" 2>/dev/null)
  he_an=$(date +%s 2>/dev/null)
  case "$he_ab" in ''|*[!0-9]*) he_ab=0 ;; esac
  case "$he_an" in ''|*[!0-9]*) he_an=0 ;; esac
  if [ "$he_ab" -gt 0 ] && [ "$he_an" -ge "$he_ab" ]; then
    echo "  轮询器最后动作：$((he_an - he_ab)) 秒前（超过 480 秒会被看护重启）"
  fi
  if [ -s "$HE_AS_LOG" ]; then
    echo "  最近记录（$HE_AS_LOG）："
    tail -n 5 "$HE_AS_LOG" 2>/dev/null | sed 's/^/    /'
  fi
  return 0
}
