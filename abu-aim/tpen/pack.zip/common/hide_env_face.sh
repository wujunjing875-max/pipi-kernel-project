#!/system/bin/sh
# hide_env_face.sh —— 「有始有终」方案的实现（方案 C；2026-10-17 对齐 ARMIAS 10.5 口径）
#
#   来源：酷安/朋友包 ARMIAS（作者 有始有终 & AuroraNasa & KOWX712）里那套环境。
#   我们落成两件事：
#     1) 人脸/验证域名拦截（照他包里的「小鹿防人脸模块 v19」）——走模块 hosts 覆盖，
#        不动 /system、可一键还原；域名表在 payload/face_hosts.txt（885 条，去重后）。
#     2) 他清单里的那批组件：Zygisk Next(我们 1.5.2) + HMA-OSS + OMK + susfs4ksu
#        + Hybrid-Mount + AsoulOpt + 解设备标记(ysyz) + 小鹿(xiaolu)；
#        只做"补装 + 启用"，从不卸载（与 A/B 方案同一规矩）。
#   用法： install.sh face on|off|status   ／  install.sh scheme c （走下面 he_friend_apply）
#
#   关于他包里的附加件（2026-10-17 起随包放在 payload/armias/，手动取用，不自动装）：
#     · 设备信息检测v10.sh（QA 探针：改机型后校验底层身份没变，思路可借鉴）
#     · data_local_{1,t,x}（arm64 内存工具：ptrace + /proc/pid/as，属另一条技术线）
#     · NativeTest.apk、model_spoof_huawei2.zip（全局机型模拟）、keybox_huawei.xml
#   仍不入包：MT2.26.4-clone-target28.apk（30MB，客户自装即可，原 zip 里有）

HE_FRIEND_MODBASE=${HE_MODBASE:-/data/adb/modules}
HE_FRIEND_MODID=${HE_FRIEND_MODID:-hide_env_pack}
HE_FRIEND_STATE=${HIDE_STATE_DIR:-/data/adb/hide_env_pack/state}
HE_FRIEND_HOSTS_SRC=${HE_FRIEND_HOSTS_SRC:-${HIDE_PAYLOAD:-/data/adb/hide_env_pack/payload}/face_hosts.txt}

he_fr_say() { if command -v he_say >/dev/null 2>&1; then he_say "$@"; else echo "$@"; fi; }

he_fr_modpath() {
  for d in "$HE_FRIEND_MODBASE/$HE_FRIEND_MODID" /data/adb/modules_update/$HE_FRIEND_MODID; do
    [ -d "$d" ] && { echo "$d"; return 0; }
  done
  echo "$HE_FRIEND_MODBASE/$HE_FRIEND_MODID"
}

# ── 人脸/验证域名拦截（模块 hosts 覆盖；重启生效）────────────────
he_face_on() {
  mp=$(he_fr_modpath)
  [ -d "$mp" ] || { he_fr_say "   ! 找不到模块目录（$mp），先刷一次本包"; return 1; }
  [ -s "$HE_FRIEND_HOSTS_SRC" ] || { he_fr_say "   ! 没有域名表（$HE_FRIEND_HOSTS_SRC）"; return 1; }
  mkdir -p "$mp/system/etc" "$HE_FRIEND_STATE" 2>/dev/null
  # 已有我们的 hosts 就备份一次（原始文件优先，别覆盖掉备份）
  [ -f "$mp/system/etc/hosts" ] && [ ! -f "$HE_FRIEND_STATE/hosts.orig" ] && \
    cp -f "$mp/system/etc/hosts" "$HE_FRIEND_STATE/hosts.orig" 2>/dev/null
  n=0
  {
    printf '# 有始有终方案 · 人脸/验证域名拦截（%s）\n' "$(date '+%Y-%m-%d' 2>/dev/null)"
    printf '127.0.0.1 localhost\n'
    while IFS= read -r d; do
      case "$d" in ''|'#'*|localhost) continue ;; esac
      printf '127.0.0.1 %s\n' "$d"
      n=$((n + 1))
    done < "$HE_FRIEND_HOSTS_SRC"
  } > "$mp/system/etc/hosts.tmp" 2>/dev/null && mv -f "$mp/system/etc/hosts.tmp" "$mp/system/etc/hosts" 2>/dev/null
  : > "$HE_FRIEND_STATE/face"
  he_fr_say "   [√] 人脸/验证域名拦截：写入 $n 条（模块 hosts 覆盖，重启生效；face off 可还原）"
  return 0
}

he_face_off() {
  mp=$(he_fr_modpath)
  if [ -s "$HE_FRIEND_STATE/hosts.orig" ]; then
    cp -f "$HE_FRIEND_STATE/hosts.orig" "$mp/system/etc/hosts" 2>/dev/null
    he_fr_say "   [-] 已还原成原来的 hosts"
  else
    rm -f "$mp/system/etc/hosts" 2>/dev/null
    he_fr_say "   [-] 已撤掉模块 hosts 覆盖"
  fi
  rm -f "$HE_FRIEND_STATE/face" 2>/dev/null
  return 0
}

he_face_status() {
  mp=$(he_fr_modpath)
  cnt=0
  [ -f "$mp/system/etc/hosts" ] && cnt=$(grep -c '^127\.0\.0\.1 ' "$mp/system/etc/hosts" 2>/dev/null)
  printf '   %-16s %s（表里 %s 条；模块 hosts 现有 %s 条）\n' "人脸域名拦截" \
    "$([ -f "$HE_FRIEND_STATE/face" ] && echo 已开 || echo 未开)" \
    "$(grep -c -v -E '^\s*$|^#' "$HE_FRIEND_HOSTS_SRC" 2>/dev/null)" "${cnt:-0}"
}

he_face() {
  case "${1:-status}" in
    on) he_face_on ;;
    off) he_face_off ;;
    *) he_face_status ;;
  esac
}

# ── 方案 C：有始有终那套 ────────────────────────────────────────
he_friend_apply() {
  he_fr_say "══════ 切换环境方案：C · 有始有终（ARMIAS 那套）══════"
  # 组件：补装缺件 → 启用（和 A/B 同规矩；框架按安卓版本分流见 A 方案说明）
  if command -v he_sc_install >/dev/null 2>&1; then
    he_sc_install zygisk-next.zip zygisksu
    he_sc_install hma-oss.zip hma_oss_zygisk
    he_sc_install omk.zip oh_my_keymint
    he_sc_install susfs.zip susfs4ksu
    # Hybrid Mount 6.x 是"元模块(metamodule)"：只能由管理器官方流程安装，
# 用本包的通用解压安装会生成残缺元模块，开机后会把其它模块全部吞掉。
# 所以这里不再自动安装，需要的话在管理器里手动刷 hybrid-mount.zip。
echo "  [-] Hybrid Mount 是元模块，跳过自动安装（请在管理器里手动刷）"
# he_sc_install hybrid-mount.zip hybrid_mount
    he_sc_install asoulopt.zip asoul_affinity_opt
    he_sc_install ysyz.zip ysyz
    he_sc_install xiaolu.zip xiaolu
    for m in zygisksu hma_oss_zygisk oh_my_keymint susfs4ksu hybrid_mount asoul_affinity_opt ysyz xiaolu; do
      command -v he_sc_en >/dev/null 2>&1 && he_sc_en "$m"
    done
    command -v he_sc_dis >/dev/null 2>&1 && { he_sc_dis tricky_store; he_sc_dis TA_utl; he_sc_dis tencent_game_assist; }
  fi
  he_fr_say "── 按他这套的口径逐项执行 ──"
  he_fr_say "   · 人脸/验证域名拦截（小鹿那套）：写模块 hosts"
  he_face_on
  command -v he_aling_dfm_fix >/dev/null 2>&1 && he_fr_say "   · 阿灵 Whitelist520 去 dfm" && he_aling_dfm_fix >/dev/null 2>&1
  command -v he_zn_settings >/dev/null 2>&1 && he_zn_settings >/dev/null 2>&1
  command -v he_omk_keybox >/dev/null 2>&1 && he_omk_keybox >/dev/null 2>&1
  command -v he_omk_pif >/dev/null 2>&1 && he_omk_pif >/dev/null 2>&1
  he_fr_say "- 密钥线：OMK；隐藏：HMA-OSS + SUSFS（要内核支持）+ Hybrid-Mount；标记/人脸：小鹿 hosts + 解设备标记"
  he_fr_say "   （附加件在 payload/armias/：QA 探针 / 内存工具 / NativeTest / 机型模拟 / keybox，手动取用）"
  return 0
}
