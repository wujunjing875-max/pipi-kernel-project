#!/system/bin/sh
#############################################################
# hide_env_trust.sh —— 绿色通行证（官网直链 / 123 网盘仓库）
#
# 规则（2026-10-22 用户定）：
#   · 只有「官网直链」或「123 网盘仓库」由管理器下载并安装的模块才有通行证；
#   · 同一份源码从第三方渠道安装（本地 zip、别的仓库、别的 App）没有通行证，
#     互锁按拆包处理，直接回滚；
#   · 通行证由服务器核心 RSA 私钥签名，绑定 设备码 + 账号 + 卡密 + 模块 id + zip 指纹；
#     设备端用 heguard coreverify 验签，改一个字节都过不了。
#
# 回执格式（单行，无结尾换行）：
#   NNR1|kind|hwid|account|card|module_id|zip_sha256|channel|issued_at
#   kind    = module / pack / bind
#   channel = official / 123pan
#############################################################

HE_TRUST_DIR=${HE_TRUST_DIR:-$HIDE_ENV_DIR/state/trust}
HE_TRUST_MAX_AGE=${HE_TRUST_MAX_AGE:-15552000}     # 180 天（和服务器回执有效期一致）
HE_TRUST_GUARD=${HE_TRUST_GUARD:-}

he_trust_guard() {
  if [ -n "$HE_TRUST_GUARD" ] && [ -x "$HE_TRUST_GUARD" ]; then return 0; fi
  if [ -x "$HIDE_ENV_DIR/bin/heguard" ]; then
    HE_TRUST_GUARD=$HIDE_ENV_DIR/bin/heguard
  elif [ -x /data/local/tmp/heguard ]; then
    HE_TRUST_GUARD=/data/local/tmp/heguard
  else
    HE_TRUST_GUARD=""
  fi
  [ -n "$HE_TRUST_GUARD" ]
}

he_trust_lic_ready() {
  command -v he_lic_get >/dev/null 2>&1 && return 0
  [ -f "$HIDE_ENV_DIR/common/hide_env_license.sh" ] || return 1
  . "$HIDE_ENV_DIR/common/hide_env_license.sh" 2>/dev/null
  command -v he_lic_get >/dev/null 2>&1
}

he_trust_hwid() {
  he_th=""
  if he_trust_lic_ready; then he_th=$(he_lic_get hwid 2>/dev/null); fi
  [ -n "$he_th" ] || he_th=$(he_lic_hwid 2>/dev/null)
  printf '%s' "$he_th"
}

he_trust_card() {
  he_tc=""
  if he_trust_lic_ready; then he_tc=$(he_lic_get card 2>/dev/null); fi
  printf '%s' "$he_tc" | tr 'a-z' 'A-Z'
}

he_trust_verify() { # <rcpt> <sig>
  [ -s "$1" ] || return 1
  [ -s "$2" ] || return 1
  he_tv_sig=$(tr -d ' \t\r\n' <"$2" 2>/dev/null)
  [ ${#he_tv_sig} -eq 512 ] || return 1
  he_trust_guard || return 1
  "$HE_TRUST_GUARD" coreverify "$1" "$he_tv_sig" 2>/dev/null | grep -q '^HEG|coreverify|ok$'
}

he_trust_parse() { # <rcpt> → he_tp_*；成功 0
  he_tp_line=$(sed -n '1p' "$1" 2>/dev/null | tr -d '\r')
  case "$he_tp_line" in NNR1\|*) : ;; *) return 1 ;; esac
  he_tp_kind=$(printf '%s' "$he_tp_line" | cut -d'|' -f2)
  he_tp_hwid=$(printf '%s' "$he_tp_line" | cut -d'|' -f3)
  he_tp_account=$(printf '%s' "$he_tp_line" | cut -d'|' -f4)
  he_tp_card=$(printf '%s' "$he_tp_line" | cut -d'|' -f5)
  he_tp_module=$(printf '%s' "$he_tp_line" | cut -d'|' -f6)
  he_tp_sha=$(printf '%s' "$he_tp_line" | cut -d'|' -f7)
  he_tp_channel=$(printf '%s' "$he_tp_line" | cut -d'|' -f8)
  he_tp_ts=$(printf '%s' "$he_tp_line" | cut -d'|' -f9)
  case "$he_tp_ts" in ''|*[!0-9]*) return 1 ;; esac
  [ -n "$he_tp_kind" ] || return 1
  [ -n "$he_tp_module" ] || return 1
  return 0
}

he_trust_receipt() { # <module_id> <kind> → 0 通过
  he_tr_id=$1
  he_tr_kind=$2
  he_tr_f=$HE_TRUST_DIR/$he_tr_id.rcpt
  he_tr_s=$HE_TRUST_DIR/$he_tr_id.sig
  he_trust_verify "$he_tr_f" "$he_tr_s" || return 1
  he_trust_parse "$he_tr_f" || return 1
  [ "$he_tp_kind" = "$he_tr_kind" ] || return 1
  if [ "$he_tr_kind" = "bind" ]; then
    [ "$he_tp_module" = "manager" ] || return 1
  else
    [ "$he_tp_module" = "$he_tr_id" ] || return 1
  fi
  case "$he_tp_channel" in official|123pan) : ;; *) return 1 ;; esac
  he_tr_hwid=$(he_trust_hwid)
  [ -n "$he_tr_hwid" ] && [ "$he_tp_hwid" = "$he_tr_hwid" ] || return 1
  # 不比对卡密：账号绑的卡不一定是本机激活用的那张卡（实测 nn 账号卡 ≠ 设备激活卡）。
  # 通行证已经绑定设备码 + 服务器签名 + 模块 id，换机/伪造仍然过不了。
  he_tr_now=$(date +%s 2>/dev/null || echo 0)
  case "$he_tr_now" in ''|*[!0-9]*) return 1 ;; esac
  he_tr_age=$((he_tr_now - he_tp_ts))
  [ "$he_tr_age" -ge -86400 ] 2>/dev/null || return 1
  [ "$he_tr_age" -le "$HE_TRUST_MAX_AGE" ] 2>/dev/null || return 1
  return 0
}

he_trust_module_ok() { # <module_id>：官网/123 安装的模块 → 0
  he_tm_id=$1
  [ -n "$he_tm_id" ] || return 1
  # 环境必须先和管理器绑定：没绑定就不发绿色通行证
  he_trust_bind_ok || return 1
  if [ "$he_tm_id" = "hide_env_pack" ]; then
    he_trust_receipt "$he_tm_id" pack && return 0
  fi
  he_trust_receipt "$he_tm_id" module
}

he_trust_bind_ok() { # 环境与管理器绑定回执 → 0
  he_trust_receipt "bind" bind
}

he_trust_module_channel() { # 给状态页显示：official / 123pan / 空
  he_tc_id=$1
  he_tc_f=$HE_TRUST_DIR/$he_tc_id.rcpt
  he_tc_s=$HE_TRUST_DIR/$he_tc_id.sig
  he_trust_verify "$he_tc_f" "$he_tc_s" 2>/dev/null || return 1
  he_trust_parse "$he_tc_f" 2>/dev/null || return 1
  [ "$he_tp_module" = "$he_tc_id" ] || return 1
  printf '%s' "$he_tp_channel"
}

he_trust_status() {
  echo "通行证目录：$HE_TRUST_DIR"
  if he_trust_bind_ok; then
    echo "  环境绑定：已绑定（${he_tp_channel} / ${he_tp_account}）"
  else
    echo "  环境绑定：未绑定（在管理器里登录后点「绑定本机环境」）"
  fi
  he_ts_n=0
  he_ts_bad=0
  for he_ts_f in "$HE_TRUST_DIR"/*.rcpt; do
    [ -s "$he_ts_f" ] || continue
    he_ts_id=${he_ts_f##*/}
    he_ts_id=${he_ts_id%.rcpt}
    [ "$he_ts_id" = "bind" ] && continue
    he_ts_n=$((he_ts_n + 1))
    if ! he_trust_module_ok "$he_ts_id"; then
      he_ts_bad=$((he_ts_bad + 1))
      echo "  ! 通行证无效：$he_ts_id"
    fi
  done
  echo "  模块通行证：$he_ts_n 张（无效 $he_ts_bad）"
}
