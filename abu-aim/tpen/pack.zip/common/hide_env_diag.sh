#!/system/bin/sh
#############################################################
# hide_env_diag.sh —— 一键排查「为什么被下发设备标记」
#
# 思路（照社区那套扫描的思路，但把重点从"有没有"改成"为什么"）：
#   ① 设备/环境基线          —— 机型、SoC、安卓版本、root 方案、用户空间（含分身）
#   ② 本套模块是否完好        —— 缺了/被禁用/被删 = 环境损坏的第一来源
#   ③ 关键守护进程           —— ZN / 框架(lspd 或 Vector) / OMK keymint / HMA
#   ④ OMK 关键项             —— 密钥在不在、撤销没、拦截名单有没有这个游戏、PIF、Soter
#   ⑤ 游戏侧                 —— 装在哪个用户空间、在跑吗、登录态、下发目录内容
#   ⑥ 设备标记 mrpcs*        —— 全盘扫（内部数据 + 外部 Android/data + persist），分级 + 时间
#   ⑦ 下发脚本 / 配置 / 残留  —— ano_tmp 里的脚本与配置、ACE 残留、旧模块残留、tmp 脚本
#   ⑧ 标识与防护             —— android_id / SSAID 是否重置过、看护在跑吗、persist 锁了吗
#   ⑨ 结论                   —— 分四类判定（有标记 / 无标记但被罚 / 环境损坏 / 未发现异常）
#                             每一类给出"为什么"和"该怎么办"
#
# 用法：
#   sh hide_env_diag.sh           完整排查
#   sh hide_env_diag.sh --brief   只看结论
# 只读脚本：不动任何文件、不改任何设置。
#############################################################

BRIEF=0
[ "${1:-}" = "--brief" ] && BRIEF=1
say()  { [ "$BRIEF" = "1" ] || printf '%s\n' "$*"; }
head1() { [ "$BRIEF" = "1" ] || { echo; echo "── $* ──"; }; }
have() { command -v "$1" >/dev/null 2>&1; }

# 结论收集
FIND_MARKS=""        # 发现的标记（每行：级别|名字|路径）
FIND_ENV_BAD=""      # 环境异常项
FIND_SUSPECT=""      # 下发脚本/配置/残留
FIND_GAMES=""        # 检测到的目标游戏
GAME_RUNNING=0
GAME_USERSPACES=""

# 路径根：真机就是 /data、/data/adb；沙盒自测用 HE_DIAG_ROOT / NVBASE 指到临时目录
D=${HE_DIAG_ROOT:-/data}
NVBASE=${NVBASE:-/data/adb}
PKGS="com.tencent.tmgp.dfm com.tencent.mf.uam com.proximabeta.mf.uamo com.garena.game.df com.proxima.dfm com.tencent.rmcn"
PERSIST_DIRS=${HE_PERSIST_DIRS:-"/mnt/vendor/persist/data /persist/data /data/vendor/persist/data"}
ANO_DIRS="files/ano_tmp files/ano_tmp/custom_cache files/cache/ano_tmp files/.ano_cache files/ano_cache"

# 标记分级（和社区/我们清理器一致的对照表）
mark_level() {
  case "$1" in
    mrpcs_a_v.data)   echo "中|A_v 环境监测（系统环境异常被记了一笔）" ;;
    mrpcs_a_cd.data)  echo "中|A_cd 行为监测（内存读取/辅助行为被记了一笔）" ;;
    mrpcs_a_h*.data)  echo "低|A_h 数据异常" ;;
    mrpcs_a_s.data)   echo "极高|A_s 强标设备标记（有传染性：换号也会被连坐）" ;;
    mrpcs_a_r.data)   echo "极高|A_r 处罚下发（反作弊已判定）" ;;
    mrpcs_vm_*.data)  echo "高|VM 虚拟机/容器特征" ;;
    mrpcs_m.data|mrpcs-android*.data|mrpcs_iarm*.data|mrpcs-*.data) echo "高|云下发可疑设备标记" ;;
    mrpcs.data|mrpcs_c.data|mrpcs_[0-9A-Za-z]*.data) echo "高|反作弊下发标记（退出游戏时落盘）" ;;
    *)                echo "中|未知 mrpcs 系列标记" ;;
  esac
}

users_all() {
  u=$(pm list users 2>/dev/null | sed -n 's/.*UserInfo{\([0-9]*\):.*/\1/p' | sort -un | tr '\n' ' ')
  for d in $D/user/*; do
    [ -d "$d" ] || continue
    n=${d##*/}
    case "$n" in ''|*[!0-9]*) continue ;; esac
    case " $u " in *" $n "*) ;; *) u="$u $n" ;; esac
  done
  [ -n "$u" ] || u=0
  printf '%s' "$u"
}

# ───────────────────────── 开始 ─────────────────────────
echo "=============================================="
echo " 一键排查：为什么被下发设备标记"
echo " 时间：$(date '+%Y-%m-%d %H:%M:%S')"
echo "=============================================="

USERS=$(users_all)
say "用户空间：$USERS（多个 = 有分身/多用户，检测和清理都要覆盖到）"

head1 "① 设备与环境"
say "  机型      ：$(getprop ro.product.brand) $(getprop ro.product.model)$(getprop ro.vendor.oplus.market.name)"
say "  处理器    ：$(getprop ro.soc.model)$(getprop ro.board.platform)  安卓$(getprop ro.build.version.release)（SDK $(getprop ro.build.version.sdk)）"
say "  指纹      ：$(getprop ro.build.fingerprint)"
RK="未知"
[ -d "$NVBASE/ksu" ] && RK="KernelSU"
[ -d "$NVBASE/magisk" ] && RK="Magisk"
[ -d "$NVBASE/ap" ] && RK="APatch"
say "  root 方案 ：$RK"
say "  内核      ：$(uname -r 2>/dev/null)"

head1 "② 本套模块是否完好"
MODS=""
for id in zygisksu zygisk_lsposed zygisk_vector oh_my_keymint hma_oss_zygisk hma-uidfake Tenc-ano_tmp hide_env_pack; do
  d=$NVBASE/modules/$id
  if [ -d "$d" ]; then
    mark=""
    [ -f "$d/disable" ] && mark="${mark}(已禁用)"
    [ -f "$d/remove" ] && mark="${mark}(待删除)"
    say "  [√] $id $mark"
    [ -n "$mark" ] && FIND_ENV_BAD="$FIND_ENV_BAD
  · 模块 $id $mark"
  else
    case "$id" in
      zygisk_vector|zygisk_lsposed|hma-uidfake) say "  [-] $id 没装（按平台方案可能正常）" ;;
      *)
        say "  [×] $id 缺失"
        FIND_ENV_BAD="$FIND_ENV_BAD
  · 模块 $id 缺失（环境不完整，容易被检测到）" ;;
    esac
  fi
done
say "  其他模块  ：$(ls "$NVBASE/modules" 2>/dev/null | grep -v -E '^(zygisksu|zygisk_lsposed|zygisk_vector|oh_my_keymint|hma_oss_zygisk|hma-uidfake|Tenc-ano_tmp|hide_env_pack)$' | tr '\n' ' ')"

head1 "③ 关键守护进程"
if ps -A 2>/dev/null | grep -q 'zn-zygisk-companion'; then say "  [√] Zygisk Next 在跑"; else say "  [×] Zygisk Next 没在跑"; FIND_ENV_BAD="$FIND_ENV_BAD
  · Zygisk Next 没在跑（Zygisk 模块全部失效）"; fi
if ps -A 2>/dev/null | grep -q '[l]spd'; then say "  [√] LSPosed 守护进程在跑"
elif ps -A 2>/dev/null | grep -qE 'org.matrix.vector.daemon.VectorDaemon|[v]ectord'; then say "  [√] Vector 守护进程在跑（vectord）"
elif [ -d "$NVBASE/modules/zygisk_vector" ] || [ -d "$NVBASE/modules/zygisk_lsposed" ]; then
  say "  [×] 框架守护进程没在跑（管理器会显示未激活）"
  FIND_ENV_BAD="$FIND_ENV_BAD
  · 框架守护进程没在跑（安卓16 上 LSPosed 会段错误，用 Vector 或 install.sh lsp-doctor 看）"
else say "  [-] 没装框架（天玑方案正常）"; fi
if pidof keymint >/dev/null 2>&1; then say "  [√] OMK keymint 守护进程在跑"; else say "  [×] OMK keymint 没在跑"; FIND_ENV_BAD="$FIND_ENV_BAD
  · OMK keymint 没在跑（密钥伪装不生效，检测会直接看真机）"; fi
if ps -A 2>/dev/null | grep -q -i 'hide_my_applist\|hma'; then say "  [√] HMA 服务在跑"; else say "  [~] 看不到 HMA 服务（可能集成在别处）"; fi

head1 "④ OMK 关键项（密钥 / 拦截名单 / 指纹 / Soter）"
INJ=""
for c in "$NVBASE/omk/inject" "$NVBASE/modules/oh_my_keymint/libs/arm64-v8a/inject" "$NVBASE/modules/oh_my_keymint/libs/x86_64/inject"; do
  [ -x "$c" ] && { INJ=$c; break; }
done
KM=""
for c in "$NVBASE/omk/keymint" "$NVBASE/modules/oh_my_keymint/libs/arm64-v8a/keymint" "$NVBASE/modules/oh_my_keymint/libs/x86_64/keymint"; do
  [ -x "$c" ] && { KM=$c; break; }
done
if [ -s $D/misc/keystore/omk/keybox.xml ]; then
  say "  [√] 密钥文件在（$(wc -c < $D/misc/keystore/omk/keybox.xml | tr -d ' ') 字节）"
  if [ -n "$KM" ]; then
    rev=$("$KM" --webui-check-keybox-revocation 2>/dev/null | head -c 200)
    # OMK 的取值（二进制里核实过）：not_listed = 不在吊销名单里 = 正常；suspended/revoked = 真出事了
    case "$rev" in
      ""|*error*|*Error*|*unavailable*)
        say "  [~] 密钥状态读不到（$rev）—— 连不上谷歌时属正常，不影响本地伪装" ;;
      *not_listed*|*"not listed"*|*正常*|*未撤销*)
        say "  [√] 密钥状态：未吊销（not_listed）" ;;
      *revoked*|*suspended*|*"已被撤销"*|*invalid*|*"无效"*)
        say "  [×] 密钥状态：$rev"
        FIND_ENV_BAD="$FIND_ENV_BAD
  · 密钥被吊销/挂起（$rev）—— 检测会认为伪装不合法，比不伪装更可疑；control 台「一键密钥修复」可换密钥" ;;
      *)
        say "  [~] 密钥状态：$(printf '%s' "$rev" | head -c 90)（取值不认识，暂按正常看）" ;;
    esac
  fi
else
  say "  [×] 没找到密钥文件 $D/misc/keystore/omk/keybox.xml"
  FIND_ENV_BAD="$FIND_ENV_BAD
  · 没有密钥文件（OMK 装不上密钥 → 机型指纹伪装不完整）"
fi
if [ -n "$INJ" ]; then
  SCOOP=$("$INJ" --webui-get-scoop 2>/dev/null | tr -d '[]"' | tr ',' '\n' | sed 's/^ *//;s/ *$//' | grep -v '^$')
  SC_N=$(printf '%s\n' "$SCOOP" | grep -c .)
  say "  [√] 拦截包名：$SC_N 项"
  for p in $PKGS; do
    if printf '%s\n' "$SCOOP" | grep -qx "$p"; then say "      · $p 已在拦截名单里 ✓"
    elif pm list packages 2>/dev/null | grep -q "$p"; then
      say "      · $p 装了但**不在**拦截名单里 ✗"
      FIND_ENV_BAD="$FIND_ENV_BAD
  · $p 不在 OMK 拦截名单里（它的密钥读取没被伪装 → 直接看到真机身份）"
    fi
  done
else
  say "  [~] 找不到 inject helper（无法核对拦截名单）"
fi
if [ -n "$KM" ]; then
  pif=$("$KM" --webui-get-pif-fingerprint-state 2>/dev/null | head -c 200)
  case "$pif" in ""|*error*|*Error*) say "  [~] PIF 状态读不到" ;; *) say "  [√] PIF 指纹：$(printf '%s' "$pif" | head -c 110)" ;; esac
fi
if [ -f $D/misc/keystore/omk/data/soterta/enabled ]; then say "  [√] 软件 Soter TA 已开（微信指纹修复）"; else say "  [~] 软件 Soter TA 没开（微信里指纹可能被判异常）"; fi

head1 "⑤ 游戏侧：装在哪、在跑吗、下发目录"
for p in $PKGS; do
  pm list packages 2>/dev/null | grep -q "^package:$p$" || continue
  FIND_GAMES="$FIND_GAMES $p"
  say "  [√] $p（$(pm list packages -f 2>/dev/null | grep -m1 "/$p" | sed 's|package:||;s|/base.apk=.*||' | head -c 40)）"
  pidof "$p" >/dev/null 2>&1 && { GAME_RUNNING=1; say "      · 现在正在运行"; }
  for u in $USERS; do
    base="$D/user/$u/$p"
    [ -d "$base" ] || base="$D/user_de/$u/$p"
    [ -d "$base" ] || continue
    n=0
    for a in $ANO_DIRS; do [ -d "$base/$a" ] && n=$((n + $(ls "$base/$a" 2>/dev/null | wc -l))); done
    sp=$([ -d "$base/shared_prefs" ] && echo "有（已登录过）" || echo "没有（当前是退出登录状态）")
    say "      用户 $u：下发目录 $n 项，登录态 $sp"
    GAME_USERSPACES="$GAME_USERSPACES $u"
  done
done
[ -n "$FIND_GAMES" ] || say "  [-] 没检测到目标游戏（tmgp.dfm / mf.uam / proxima…）"

head1 "⑥ 设备标记 mrpcs*（全盘扫）"
scan_dirs=""
for p in $FIND_GAMES; do
  for u in $USERS; do
    for base in "$D/user/$u/$p" "$D/user_de/$u/$p"; do
      [ -d "$base" ] || continue
      for a in $ANO_DIRS; do [ -d "$base/$a" ] && scan_dirs="$scan_dirs $base/$a"; done
    done
  done
done
scan_dirs="$scan_dirs $PERSIST_DIRS"
MARK_N=0
for d in $scan_dirs; do
  [ -d "$d" ] || continue
  for f in $(find "$d" -maxdepth 2 -type f -name "mrpcs*" 2>/dev/null); do
    lv=$(mark_level "${f##*/}")
    MARK_N=$((MARK_N + 1))
    say "  ✖ [${lv%%|*}] ${f##*/} —— ${lv#*|}"
    say "      路径：$f"
    say "      时间：$(stat -c '%y' "$f" 2>/dev/null | cut -c1-19)"
    FIND_MARKS="$FIND_MARKS
${lv%%|*}|${f##*/}|${f}|$(stat -c '%y' "$f" 2>/dev/null | cut -c1-19)"
  done
done
[ "$MARK_N" = "0" ] && say "  [√] 没发现 mrpcs* 标记文件"

head1 "⑦ 下发脚本 / 配置 / 残留"
SUS_N=0
for d in $scan_dirs; do
  [ -d "$d" ] || continue
  case "$d" in
    *persist*) SUS_MODE=persist ;;   # persist 是原厂数据区：只认"明显是下发/脚本"的名字
    *)         SUS_MODE=game ;;
  esac
  for f in $(find "$d" -maxdepth 2 -type f \( -name "*.sh" -o -name "*.lua" -o -name "*.dex" -o -name "*.so" -o -name "*.jar" -o -name "*.cfg" -o -name "*.ini" -o -name "*script*" -o -name "*config*" \) 2>/dev/null | head -20); do
    # ★ 2026-10-11 真机踩到（一加 Ace 3 Pro 基线）：persist 里全是原厂硬件数据
    #   （gf_* 是 Goodix 指纹校准、*.so 是标定库）——以前被当"下发脚本"报出来，
    #   还写着"deep 清理会一起清掉"，客户照做就把指纹/传感器搞坏 ✗
    #   persist 只报：mrpcs*（标记）、游戏包名相关、或名字里带 ano/anotmp/ace/script/config 的
    if [ "$SUS_MODE" = "persist" ]; then
      case "${f##*/}" in
        mrpcs*|*ano_*|*ano_tmp*|*ace_*|*ACE_*|*script*|*config*) : ;;
        *) continue ;;
      esac
    fi
    SUS_N=$((SUS_N + 1))
    FIND_SUSPECT="$FIND_SUSPECT
  · ${f}（$(stat -c '%y' "$f" 2>/dev/null | cut -c1-16)）"
  done
done
if [ "$SUS_N" -gt 0 ]; then
  say "  ⚠ 下发目录里发现 $SUS_N 个脚本/配置类文件（这通常就是「下发脚本」本体）："
  printf '%s\n' "$FIND_SUSPECT" | grep '·' | sed 's/^ */    /'
else
  say "  [√] 下发目录里没有脚本/配置类文件"
fi
# ACE / 反作弊残留 + 我们自己的备份/tmp
for pat in "$D/local/tmp/*.sh" "$D/local/tmp/*.lua" "$D/local/tmp/ace*" "$D/local/tmp/*.ini"; do
  for f in $pat; do
    [ -f "$f" ] || continue
    case "$f" in */hide_env*|*/apply_model*|*/clean_new*|*lspdiag*|*/diag*.sh|*_diag*.sh|*/sq.py) continue ;; esac
    say "  ⚠ /data/local/tmp 里有脚本：$f（$(stat -c '%y' "$f" 2>/dev/null | cut -c1-16)）"
  done
done
[ -d $D/local/tmp/hide_env_clean_backup ] && say "  [~] 本包清理备份目录还在（正常，里面是被删过的标记副本）"
# 只有在「安卓16+ 已改用 Vector」或「Vector 与 LSPosed 同时存在」时，LSPosed 目录才算残留；
# 安卓 ≤15 上 LSPosed 就是本包的框架本体 —— 以前无条件提示，客户以为装脏了
# （2026-10-11 红米 K50 真机发现：安卓12 上也提示"旧框架残留"，属误报）
DG_SDK=$(getprop ro.build.version.sdk 2>/dev/null)
case "$DG_SDK" in ''|*[!0-9]*) DG_SDK=0 ;; esac
if [ "$DG_SDK" -ge 36 ] || [ -d "$NVBASE/modules/zygisk_vector" ]; then
  for old in "$NVBASE/modules/zygisk_lsposed" "$NVBASE/lspd"; do
    [ -e "$old" ] && say "  ⚠ 旧框架残留：$old"
  done
fi

head1 "⑧ 标识与防护"
AID=$(settings get secure android_id 2>/dev/null)
say "  android_id：$AID"
case "$AID" in
  [0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f])
    if [ -e "$NVBASE/modules/hide_env_pack/module.prop" ]; then
      say "      （16 位 hex：像是重置过的格式；装过本包的话说明标识已换新）"
    else
      say "      （16 位 hex：这台还没装本包，属系统自带）"
    fi ;;
  *) say "      （不是本包重置的格式：可能是原机标识，被标记时容易连坐）" ;;
esac
for u in $USERS; do
  [ -f "$D/system/users/$u/settings_ssaid.xml" ] && say "  SSAID（用户 $u）：还在（没被清过）" || say "  SSAID（用户 $u）：已清"
done
# 换设备/人脸风险提示：标识被重置过 = 在游戏那边看着像"换了台新手机"，
# 这恰恰是触发人脸/换设备验证的常见原因（清理≠能解决人脸）。
case "$AID" in
  [0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f])
    say "  ⓘ 换设备/人脸提示：本机标识被重置过（在游戏那边看着像换了新手机），"
    say "    如果你最近遇到「人脸识别/换设备验证」，先换个号试试定性：换号还弹才是设备侧；"
    say "    换号不弹 = 账号侧（设备清理解决不了，别再反复清）。" ;;
esac
STATE=${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state
if [ -f "$STATE/cleanwatch.pid" ] && kill -0 "$(cat "$STATE/cleanwatch.pid" 2>/dev/null)" 2>/dev/null; then
  say "  [√] 清理看护在跑（游戏一退出就会清下发目录）"
else
  say "  [×] 清理看护没在跑"
  FIND_ENV_BAD="$FIND_ENV_BAD
  · 清理看护没在跑（游戏退出时下发的标记没人清，明天上号就吃连坐）——install.sh clean watch on"
fi
# persist 权限：真机上 toybox 把 000 印成 "0"（不是 "000"），所以按去零后的数值判断
PERSIST_LOCKED=""
for d in $PERSIST_DIRS; do
  [ -d "$d" ] || continue
  p=$(stat -c '%a' "$d" 2>/dev/null)
  case "$p" in
    0|00|000)
      say "  persist $d 权限=$p（已锁 000：标记写不进去）"
      PERSIST_LOCKED="$d" ;;
    "") say "  persist $d 权限读不到" ;;
    *)  say "  persist $d 权限=$p" ;;
  esac
done
if [ -n "$PERSIST_LOCKED" ] && ! { [ -f "$STATE/cleanwatch.pid" ] && kill -0 "$(cat "$STATE/cleanwatch.pid" 2>/dev/null)" 2>/dev/null; }; then
  say "  ⚠ persist 锁着但看护没在跑 —— 没人会自动解锁（别的应用写 persist 也会失败）"
  FIND_ENV_BAD="$FIND_ENV_BAD
  · persist 被锁死但清理看护没在跑 → 锁解不开：install.sh clean watch on（或 clean persist off 立刻解锁）"
fi
[ -f "$STATE/lic" ] && say "  授权：$(sed -n 's/^activated=//p' "$STATE/lic" | head -1)$(grep -q '^token=' "$STATE/lic" && echo '（已激活）')"

# ───────────────────────── 结论 ─────────────────────────
echo
echo "=============================================="
echo " 结论"
echo "=============================================="
ENVN=$(printf '%s' "$FIND_ENV_BAD" | grep -c '·')
SUS_CNT=$(printf '%s' "$FIND_SUSPECT" | grep -c '·')

if [ "$MARK_N" -gt 0 ]; then
  echo "● 有设备标记（$MARK_N 个），这就是「被下发」的直接证据。"
  printf '%s' "$FIND_MARKS" | grep -q '极高' && {
    echo "  其中含【极高】级别的强标/处罚标记 —— 这类有传染性：换号、换设备都可能被连坐。"
    echo "  为什么会出现：反作弊在**那次游戏运行期间**判定成立，退出时把结论落盘；"
    echo "  强标通常已经和账号/设备指纹绑定，所以单清文件不够。"
  }
  if [ "$ENVN" -gt 0 ]; then
    echo "  同时环境里有 $ENVN 项异常 —— 这才是「为什么会被判定」的根因，不修它，清完还会再下发："
    printf '%s\n' "$FIND_ENV_BAD" | grep '·' | sed 's/^ */    /'
  else
    echo "  环境本身没查出异常项 —— 说明这次是**运行中当场判定**（清文件只治标，见下面第 2 条）。"
  fi
  echo
  echo "  怎么办（按顺序做）："
  echo "   1) 先在游戏里正常退出到登录界面（或卸载重装，见 3），把本次会话结束干净"
  echo "   2) 修掉上面列的环境异常项（这是「为什么」的答案）"
  echo "   3) 重度清理（会卸载游戏，重装即可，达到「非永久强标」）：install.sh clean hard"
  echo "      或者深度清理（保留游戏、数据全清）：install.sh clean deep"
  echo "   4) 重置标识并重启：install.sh clean id 然后 install.sh clean restart soft"
  echo "   5) 上号前确认看护在跑：install.sh clean watch status（应为「开」）"
elif [ -n "$FIND_GAMES" ] && [ "$ENVN" -gt 0 ]; then
  echo "● 没扫到 mrpcs* 标记文件，但环境里有 $ENVN 项异常。"
  echo "  这种情况的「被下发」多半不是文件级标记，而是**实时检测**："
  echo "  检测器在游戏里当场读到异常（模块/框架/密钥/名单/root 痕迹）就当场判定，"
  echo "  所以清文件没用 —— 要修的是下面这些："
  printf '%s\n' "$FIND_ENV_BAD" | grep '·' | sed 's/^ */  /'
  echo
  echo "  修完重启一次，再进游戏观察（仍被罚请把游戏里的**提示原文**发出来，不同文案对应不同判定）。"
elif [ "$ENVN" -gt 0 ]; then
  echo "● 没检测到目标游戏，但环境有 $ENVN 项异常："
  printf '%s\n' "$FIND_ENV_BAD" | grep '·' | sed 's/^ */  /'
  echo "  先修环境（install.sh check 可看完整状态）。"
else
  echo "● 没扫到设备标记，环境各项也正常 —— **本次没查出发下发的直接原因**。"
  echo "  可能情况："
  echo "   · 下发发生在**游戏运行中**（当场落盘后又被清掉），下次进游戏前先跑一次本排查；"
  echo "   · 属于账号侧判定（不是设备侧），换号即可验证；"
  echo "   · 检测器读的是运行中特征（内存/进程/网络），设备上不留文件痕迹。"
  echo "  要定位请看游戏里的**提示原文**或截图发出来。"
fi
if [ "$SUS_CNT" -gt 0 ]; then
  echo
  echo "● 另外：下发目录里有 $SUS_CNT 个脚本/配置类文件（可能是「下发脚本」本体）——"
  echo "  install.sh clean deep 会清掉游戏下发目录里的这类文件（删前先备份）。"
  echo "  ⚠ 注意：persist 里原厂的硬件标定文件（如 gf_* 指纹校准）不在清理范围内，千万不要手删。"
fi
if [ "$GAME_USERSPACES" != "" ]; then
  echo
  echo "● 检查覆盖的用户空间：$(printf '%s' "$USERS")（含分身；清理也要在这些空间里执行）"
fi
echo
echo "（本排查只读：没动任何文件。清理/修复命令已列在上面，按需执行。）"
echo "=============================================="
