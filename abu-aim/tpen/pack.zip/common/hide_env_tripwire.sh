#!/system/bin/sh
#############################################################
# hide_env_tripwire.sh —— v1.5.1「反向互锁（反滚）」
#
# 「反滚」= 和以前彻底反过来：
#   ❌ 以前：发现"不对" → 把自己整套删掉、回滚配置、停用框架
#            → 客户看到的是「什么都没动，重启就被回滚、LSP 打不开」
#   ✅ 现在：本套模块永不删、永不关、永不回滚；发现异常时，
#            处理的是【别人的多余模块】，删完自动重启一次让系统干净。
#
# 处理清单（只动这几类，其余一律不碰）：
#   1) 冒充本套的模块（module.prop 提到本套关键词 / 目录里夹带本套脚本）
#      → 默认【直接删除】；config/tripwire_delete.txt 写 keep 则退化为只禁用
#   2) 卸载残留（模块目录里有 remove 标记、却还占着位置的）→ 删除
#   3) 旧随机根（/data/adb/.h* 里不是当前 root.id 指向的那些）→ 删除
#      （几十 MB 的僵尸副本，最容易引起"换了新版本还是老行为"）
#
# 删除动作发生后：写状态 → 8 秒后自动重启一次（10 分钟内不重复重启）。
#
# 不变量（永远成立）：
#   - 本套白名单（8 个）永远不动
#   - 常见第三方（SelinuxFix / PIF / Shamiko / ZygiskNext / TrickyStore …）
#     一律放行，客户自己装的东西不归我们管
#   - 不阻断开机、不改系统属性、不动 SELinux、不写系统分区
#
# 另外：命令前的 A/B 校验（he_tw_ab_guard）是【空操作】——
#       以前它每条命令都遍历模块 + 算哈希 + 重写基线，是"点一下卡两秒"的主因。
#
# 手动 `install.sh wipe` 仍然会真自毁（机主明确要求，另走 he_tw_wipe_exec）。
#############################################################

HE_TW_MODBASE=${HE_TW_MODBASE:-/data/adb/modules}
HIDE_ENV_DIR=${HIDE_ENV_DIR:-/data/adb/hide_env_pack}
HIDE_CFG_DIR=${HIDE_CFG_DIR:-$HIDE_ENV_DIR/config}
HE_TW_SNAP=${HE_TW_SNAP:-$HIDE_ENV_DIR/state/tripwire}
HE_TW_LOG=${HE_TW_LOG:-$HIDE_ENV_DIR/state/tripwire.log}
HE_TW_QUAR=${HE_TW_QUAR:-$HIDE_ENV_DIR/backup/quarantine}

# 本套（永不处理）。框架槽两个都算"本套"：安卓 16 用 Vector，其余用 LSPosed
HE_TW_OURS_DEFAULT="hide_env_pack hide_env_guard zygisksu zygisk_vector zygisk_lsposed oh_my_keymint hma_oss_zygisk hma-uidfake"

# 常见第三方（一律放行，客户自己装的东西不归我们管）
HE_TW_KNOWN="SelinuxFix Trickystore tricky_store TrickyStore PIF PlayIntegrityFix playintegrityfix PIF-Next Shamiko shamiko ZygiskNext zygisk-next Zygisk-Next Zygisk-Assistant AsoulOpt asoulopt fusefixer FuseFixer NoHello nohello susfs susfs4ksu hybrid-mount Hybrid-Mount tsupport TSupport model_spoof Tenc-ano_tmp LSPosed lsposed Vector vector SoterFix rkp RKPConfig keybox updater"

he_tw_cfg_get() { # he_tw_cfg_get <文件名>（文件不存在时静默返回空，不刷 stderr 噪音）
  [ -f "$HIDE_CFG_DIR/$1" ] || return 1
  tr -d ' \n\r\t' <"$HIDE_CFG_DIR/$1" 2>/dev/null | tr 'A-Z' 'a-z'
}

he_tw_on() { # 互锁总开关（config/tripwire.txt 写 off 关闭）
  case "$(he_tw_cfg_get tripwire.txt)" in
    off|0|no|关|关闭) return 1 ;;
  esac
  return 0
}

he_tw_delete_on() { # 默认真删（反滚：删多余模块）；写 keep/off 则只禁用不删
  case "$(he_tw_cfg_get tripwire_delete.txt)" in
    keep|off|0|no|不删|只禁用) return 1 ;;
  esac
  return 0
}

he_tw_reboot_on() { # 删完是否自动重启（默认开）；写 off 只记录不重启
  case "$(he_tw_cfg_get tripwire_reboot.txt)" in
    off|0|no|关|不重启) return 1 ;;
  esac
  return 0
}

he_tw_mark() { # he_tw_mark <ok|todo|fail|warn> <说明>
  mkdir -p "$HIDE_ENV_DIR/state" 2>/dev/null
  printf '%s|%s|%s\n' "$1" "$(date +%s 2>/dev/null)" "$2" >"$HE_TW_SNAP.status" 2>/dev/null
  if command -v he_mark >/dev/null 2>&1; then he_mark tripwire "$1" "$2"; fi
  return 0
}

he_tw_log() {
  mkdir -p "${HE_TW_LOG%/*}" 2>/dev/null
  printf '%s %s\n' "$(date '+%F %T' 2>/dev/null)" "$1" >>"$HE_TW_LOG" 2>/dev/null
}

he_tw_ids() { # 当前设备上的模块 id（跳过隐藏目录）
  for d in "$HE_TW_MODBASE"/*; do
    [ -d "$d" ] || continue
    id=$(basename "$d")
    case "$id" in .*) continue ;; esac
    printf '%s\n' "$id"
  done
}

he_tw_ours() { # 当前白名单（基线里有就用基线的，没有用默认）
  if [ -s "$HE_TW_SNAP" ]; then
    he_ow=$(sed -n 's/^ours //p' "$HE_TW_SNAP" 2>/dev/null | head -n 1)
    [ -n "$he_ow" ] && { printf '%s' "$he_ow"; return 0; }
  fi
  printf '%s' "$HE_TW_OURS_DEFAULT"
}

he_tw_snapshot() { # 记录白名单基线（只记 id，不再算哈希/不写镜像）
  mkdir -p "${HE_TW_SNAP%/*}" 2>/dev/null
  he_sn_ours=""
  for id in $HE_TW_OURS_DEFAULT; do
    [ -d "$HE_TW_MODBASE/$id" ] && he_sn_ours="$he_sn_ours $id"
  done
  he_sn_ours=${he_sn_ours# }
  [ -n "$he_sn_ours" ] || he_sn_ours=$HE_TW_OURS_DEFAULT
  {
    printf '# 一键隐藏环境 · 反向互锁白名单（本套模块，永不处理）\n'
    printf 'v 2\n'
    printf 't %s\n' "$(date '+%F %T' 2>/dev/null)"
    printf 'ours %s\n' "$he_sn_ours"
    printf 'all %s\n' "$(he_tw_ids | tr '\n' ' ' | sed 's/ *$//')"
  } >"$HE_TW_SNAP" 2>/dev/null
  he_tw_log "基线已更新：$he_sn_ours"
  return 0
}

he_tw_rebase() { he_tw_snapshot; he_tw_mark ok "互锁基线已重设（$(he_tw_ours | wc -w | tr -d ' ') 个本套模块）"; }

he_tw_set() { # he_tw_set on|off
  mkdir -p "$HIDE_CFG_DIR" 2>/dev/null
  case "$1" in
    on|1|开)  printf 'on\n'  >"$HIDE_CFG_DIR/tripwire.txt" ;;
    off|0|关) printf 'off\n' >"$HIDE_CFG_DIR/tripwire.txt" ;;
    *) echo "用法：install.sh tripwire on|off"; return 1 ;;
  esac
  he_tw_mark ok "互锁已切换"
}

he_tw_ab_grace() { return 0; }   # 兼容旧调用：不再需要宽限窗口
he_tw_deploy()   { return 0; }   # 兼容旧调用：不再布引信

he_tw_ab_guard() { # 命令前校验 —— v1.5.1 起是空操作（以前这里是卡顿主因）
  return 0
}

he_tw_quarantine() { # he_tw_quarantine <模块id> <文件相对路径>（"只禁用"模式下把夹带文件挪走）
  mkdir -p "$HE_TW_QUAR" 2>/dev/null
  mv -f "$HE_TW_MODBASE/$1/$2" "$HE_TW_QUAR/$1.$2.$(date +%s 2>/dev/null)" 2>/dev/null
}

he_tw_reboot_once() { # 删除动作后自动重启一次（10 分钟内不重复，避免循环重启）
  he_tw_reboot_on || return 0
  he_rb_f="$HIDE_ENV_DIR/state/tw_reboot_ts"
  he_rb_now=$(date +%s 2>/dev/null || echo 0)
  he_rb_last=$(cat "$he_rb_f" 2>/dev/null | tr -dc '0-9')
  [ -n "$he_rb_last" ] || he_rb_last=0
  if [ "$he_rb_now" -gt 0 ] && [ $((he_rb_now - he_rb_last)) -lt 600 ] 2>/dev/null; then
    he_tw_log "10 分钟内已重启过一次（互锁），本次不再重启"
    return 0
  fi
  mkdir -p "${he_rb_f%/*}" 2>/dev/null
  printf '%s\n' "$he_rb_now" >"$he_rb_f" 2>/dev/null
  he_tw_log "互锁清理完成 → 8 秒后自动重启"
  (
    sleep 8
    sync 2>/dev/null
    /system/bin/reboot 2>/dev/null || reboot 2>/dev/null
  ) >/dev/null 2>&1 &
  return 0
}

he_tw_cleanup_old_root() { # 删掉"不是当前 root.id 指向"的旧随机根（僵尸副本，几十 MB）
  he_cr_cur=""
  for he_cr_shell in /data/adb/hide_env_pack "$HIDE_ENV_DIR"; do
    [ -f "$he_cr_shell/root.id" ] || continue
    he_cr_cur=$(sed -n 's/^h=//p' "$he_cr_shell/root.id" 2>/dev/null | tr -dc '0-9a-fA-F' | head -c 32)
    [ -n "$he_cr_cur" ] && break
  done
  [ -n "$he_cr_cur" ] || { printf '0'; return 0; }
  he_cr_n=0
  for he_cr_d in /data/adb/.h*; do
    [ -d "$he_cr_d" ] || continue
    case "$he_cr_d" in *"/.h$he_cr_cur") continue ;; esac
    # 只删"看起来是本套旧副本"的（含 pack_install.sh），别碰别人目录
    [ -f "$he_cr_d/common/pack_install.sh" ] || continue
    rm -rf "$he_cr_d" 2>/dev/null && he_cr_n=$((he_cr_n + 1))
  done
  [ "$he_cr_n" -gt 0 ] && he_tw_log "已清理 $he_cr_n 个旧随机根残留"
  printf '%s' "$he_cr_n"
  return 0
}

he_tw_scan() { # 核心：扫描并【删除多余/可疑模块】，永不碰本套
  he_tw_on || return 0
  he_sc_ours=$(he_tw_ours)
  he_sc_del=""; he_sc_off=""; he_sc_n=0; he_sc_offn=0

  for d in "$HE_TW_MODBASE"/*; do
    [ -d "$d" ] || continue
    he_sc_id=$(basename "$d")
    case "$he_sc_id" in .*) continue ;; esac
    # 1) 本套 → 跳过（永不处理）
    case " $he_sc_ours " in *" $he_sc_id "*) continue ;; esac

    # 2) 卸载残留（有 remove 标记却还占着位置）→ 清掉
    if [ -f "$d/remove" ]; then
      rm -rf "$d" 2>/dev/null
      he_sc_del="$he_sc_del $he_sc_id(残留)"; he_sc_n=$((he_sc_n + 1))
      he_tw_log "已删除卸载残留：$he_sc_id"
      continue
    fi

    # 3) 已知良性第三方 → 跳过
    case " $HE_TW_KNOWN " in *" $he_sc_id "*) continue ;; esac

    # 4) 可疑判定：冒充本套 / 夹带本套脚本
    he_sc_sus=0
    if grep -qiE "hide_env|hide env|隐藏环境|楠楠|nannan" "$d/module.prop" 2>/dev/null; then he_sc_sus=1; fi
    if [ -f "$d/install.sh" ] && head -5 "$d/install.sh" 2>/dev/null | grep -qi "hide_env"; then he_sc_sus=1; fi
    for he_sc_sub in common payload bin; do
      [ -d "$d/$he_sc_sub" ] || continue
      if grep -rqil "hide_env_pack" "$d/$he_sc_sub" 2>/dev/null; then he_sc_sus=1; fi
    done
    [ "$he_sc_sus" = "1" ] || continue

    if he_tw_delete_on; then
      rm -rf "$d" 2>/dev/null
      he_sc_del="$he_sc_del $he_sc_id"; he_sc_n=$((he_sc_n + 1))
      he_tw_log "已删除可疑模块：$he_sc_id"
    else
      : >"$d/disable" 2>/dev/null; chmod 0644 "$d/disable" 2>/dev/null
      [ -f "$d/install.sh" ] && he_tw_quarantine "$he_sc_id" install.sh
      [ -d "$d/common" ] && he_tw_quarantine "$he_sc_id" common
      [ -d "$d/payload" ] && he_tw_quarantine "$he_sc_id" payload
      he_sc_off="$he_sc_off $he_sc_id"; he_sc_offn=$((he_sc_offn + 1))
      he_tw_log "已禁用可疑模块：$he_sc_id（夹带文件已隔离）"
    fi
  done

  # 5) 旧随机根残留（本套自己的僵尸副本）
  he_sc_old=$(he_tw_cleanup_old_root 2>/dev/null | tr -dc '0-9')
  [ -n "$he_sc_old" ] || he_sc_old=0
  if [ "$he_sc_old" -gt 0 ] 2>/dev/null; then
    he_sc_del="$he_sc_del 旧副本x$he_sc_old"; he_sc_n=$((he_sc_n + he_sc_old))
  fi

  if [ "$he_sc_n" -gt 0 ]; then
    he_tw_mark todo "已清理 $he_sc_n 个多余模块：$he_sc_del（本套模块未受影响，稍后自动重启）"
    he_tw_reboot_once
  elif [ "$he_sc_offn" -gt 0 ]; then
    he_tw_mark todo "已禁用 $he_sc_offn 个可疑模块：$he_sc_off（本套模块未受影响）"
  else
    he_tw_mark ok "未发现多余模块（本套 $(printf '%s' "$he_sc_ours" | wc -w | tr -d ' ') 个模块各就各位）"
  fi
  return 0
}

he_tw_boot_check() { # 开机检查：只清理多余模块，永不阻断启动、永不删自己
  he_tw_on || { he_tw_mark ok "互锁已关闭（配置里 off）"; return 0; }
  [ -s "$HE_TW_SNAP" ] || he_tw_snapshot >/dev/null 2>&1
  he_tw_scan
  return 0
}

he_tw_watch_start() { # 低频后台看护（15 分钟一次，几乎无开销）
  he_tw_on || return 0
  (
    sleep 900
    while :; do
      he_tw_scan >/dev/null 2>&1
      sleep 1800
    done
  ) >/dev/null 2>&1 &
  return 0
}

he_tw_status() {
  echo "- 反向互锁（v1.5.1 反滚）：本套模块永不删除/停用/回滚；发现冒充或夹带本套的模块 → 删除（默认）→ 自动重启"
  echo "- 开关：$(he_tw_on && echo 开 || echo 关)  真删：$(he_tw_delete_on && echo 开 || echo 关，仅禁用)  删后重启：$(he_tw_reboot_on && echo 开 || echo 关)"
  echo "- 本套白名单：$(he_tw_ours)"
  echo "- 当前设备模块：$(he_tw_ids | tr '\n' ' ')"
  [ -s "$HE_TW_SNAP.status" ] && echo "- 最近状态：$(cat "$HE_TW_SNAP.status" 2>/dev/null)"
  [ -s "$HE_TW_LOG" ] && { echo "- 最近记录："; tail -n 5 "$HE_TW_LOG" 2>/dev/null | sed 's/^/    /'; }
  return 0
}

he_tw_wipe_exec() { # 手动 install.sh wipe 走这里：真自毁（机主明确要求）
  he_we_reason=${1:-机主手动执行}
  he_tw_log "手动自毁：$he_we_reason"
  he_we_reboot=${HIDE_TW_REBOOT:-/system/bin/reboot}
  rm -rf "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}" 2>/dev/null
  rm -rf /data/adb/modules/hide_env_pack /data/adb/modules/hide_env_guard 2>/dev/null
  rm -f /data/adb/service.d/hide_env_watch.sh 2>/dev/null
  rm -rf /data/adb/.hide_env_* 2>/dev/null
  sync 2>/dev/null
  sleep 2
  $he_we_reboot 2>/dev/null
  return 0
}
