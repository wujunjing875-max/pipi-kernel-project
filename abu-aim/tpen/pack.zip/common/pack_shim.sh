#!/system/bin/sh
#############################################################
# pack_shim.sh —— root 管理器安装环境兼容层
#
# 函数语义与 KernelSU / KernelSU-Next / Magisk 内嵌的
# util_functions.sh 保持一致（u i_print / abort / grep_prop /
# set_perm / set_perm_recursive / mktouch / api_level_arch_detect /
# check_sepolicy），使内层模块自带的 customize.sh 能在本安装器里
# 原样执行，不需要任何改动。
#############################################################

PACK_SHIM_LOADED=1

ui_print() {
  # 与管理器一致：直接写标准输出（刷入时由管理器收集日志）
  printf '%s\n' "$1"
}

abort() {
  # 与管理器一致：打印后终止“当前进程”
  # 内层 customize.sh 跑在独立进程里，因此 abort 只会终止该模块的子安装，
  # 不会影响其它模块。
  ui_print "$1"
  exit 1
}

pack_sh() {
  # 某些 KernelSU/ROM 的 SELinux 策略禁止 `sh /data/adb/.../install.sh`（execute 被拒），
  # 但允许读文件。统一走 `cat 文件 | sh -s -- 参数`，兼容所有管理器。
  pack_sh_f=$1
  shift 2>/dev/null || true
  [ -f "$pack_sh_f" ] || return 127
  cat "$pack_sh_f" | sh -s -- "$@"
}

toupper() {
  echo "$@" | tr '[:lower:]' '[:upper:]'
}

grep_prop() {
  local REGEX="s/$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/system/build.prop'
  if command -v dos2unix >/dev/null 2>&1; then
    cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1 | xargs
  else
    cat $FILES 2>/dev/null | tr -d '\r' | sed -n "$REGEX" | head -n 1 | xargs
  fi
}

grep_get_prop() {
  local result=$(grep_prop $@)
  if [ -z "$result" ]; then
    getprop "$1"
  else
    echo $result
  fi
}

set_perm() {
  chown "$2:$3" "$1" 2>/dev/null || return 1
  chmod "$4" "$1" 2>/dev/null || return 1
  local CON="$5"
  [ -z "$CON" ] && CON=u:object_r:system_file:s0
  # /data/adb 下模块文件的 SELinux 上下文由 root 管理器开机时统一处理，
  # 这里 chcon 失败不视为致命错误（否则在部分设备上会导致安装被误判失败）。
  chcon "$CON" "$1" 2>/dev/null
  return 0
}

set_perm_recursive() {
  find "$1" -type d 2>/dev/null | while read dir; do
    set_perm "$dir" "$2" "$3" "$4" "${6:-}"
  done
  find "$1" -type f -o -type l 2>/dev/null | while read file; do
    set_perm "$file" "$2" "$3" "$5" "${6:-}"
  done
  return 0
}

mktouch() {
  mkdir -p "${1%/*}" 2>/dev/null
  [ -z "$2" ] && touch "$1" || echo "$2" > "$1"
  chmod 644 "$1" 2>/dev/null
  return 0
}

mark_replace() { return 0; }
mark_remove() { return 0; }

request_size_check() {
  reqSizeM=$(du -ms "$1" 2>/dev/null | cut -f1)
}

# 管理器已算过就不重复计算（避免覆盖刷入环境里的 ARCH/API）
api_level_arch_detect() {
  [ -n "${ARCH:-}" ] && [ -n "${API:-}" ] && return 0
  API=$(getprop ro.build.version.sdk)
  ABI=$(getprop ro.product.cpu.abi)
  case "${ABI:-}" in
    x86)       ARCH=x86;   ABI32=x86;         IS64BIT=false ;;
    arm64-v8a) ARCH=arm64; ABI32=armeabi-v7a; IS64BIT=true  ;;
    x86_64)    ARCH=x64;   ABI32=x86;         IS64BIT=true  ;;
    *)         ARCH=arm;   ABI=armeabi-v7a;   ABI32=armeabi-v7a; IS64BIT=false ;;
  esac
  [ -z "${API:-}" ] && API=30
  export ARCH ABI ABI32 IS64BIT API
  return 0
}

check_sepolicy() {
  # KernelSU / KernelSU-Next：交给 ksud 校验内核是否支持 sepolicy 补丁。
  # 未通过不中断安装：sepolicy.rule 会在开机时由管理器加载，这里只做提示。
  if [ -x /data/adb/ksud ]; then
    if /data/adb/ksud sepolicy check "$1" >/dev/null 2>&1; then
      return 0
    fi
    ui_print "! 提示：ksud sepolicy check 未通过 ($1)，继续安装"
    return 0
  fi
  return 0
}
