#!/system/bin/sh
inj=/data/adb/omk/omkdata/injector.toml
list=/data/local/tmp/inj_list.tmp
old=/data/local/tmp/inj_old.tmp
tmp=/data/local/tmp/inj_new.tmp

{ printf '%s\n' com.google.android.gms com.google.android.gsf com.android.vending
  pm list packages -3 | sed 's/package://' | sort -u; } > "$list"

sed -n '/^[[:space:]]*scoop = \[/,/\]/{/^[[:space:]]*scoop = \[/d;/\]/d;s/^[[:space:]]*//;s/[[:space:]]*$//;/^$/d;p}' "$inj" | sort -u > "$old"

echo "新增:$(grep -vxFf "$old" "$list" | wc -l)"
echo "删除:$(grep -vxFf "$list" "$old" | wc -l)"

awk -v list="$list" '
  /^[[:space:]]*scoop = \[/ {
    print "scoop = ["
    while ((getline < list) > 0) print "  " $0
    close(list)
    print "]"
    f=1; next
  }
  f && /\]/ { f=0; next }
  f { next }
  { print }
' "$inj" > "$tmp"

[ -s "$tmp" ] && cat "$tmp" > "$inj"
rm -f "$list" "$old" "$tmp"
