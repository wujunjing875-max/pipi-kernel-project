#!/system/bin/sh
# 改机型控制台 · 状态（WebUI 与「操作」按钮都调它）
D=${0%/*}
CUR=$(getprop ro.product.model 2>/dev/null)
MKT=$(getprop ro.vendor.oplus.market.name 2>/dev/null)
if [ -f "$D/disable" ]; then
  echo "状态：未激活"
  echo "当前机型：$(getprop ro.product.brand) $CUR${MKT:+ / $MKT}"
  echo "说明：在云端控制台点「一键改机型」，会自动写入同处理器的机型配置并启用本模块，重启后生效。"
else
  echo "状态：已激活"
  echo "目标机型：$(sed -n 's/^ro.product.model=//p' "$D/system.prop" 2>/dev/null | head -n1)"
  echo "市场名：$(sed -n 's/^ro.vendor.oplus.market.name=//p' "$D/system.prop" 2>/dev/null | head -n1)"
  echo "属性条数：$(grep -c '^ro\.' "$D/system.prop" 2>/dev/null)"
  echo "本机现在读到：$(getprop ro.product.brand) $CUR${MKT:+ / $MKT}"
  echo "（重启后与目标机型完全一致；要还原就在控制台点「还原机型」）"
fi
