#!/system/bin/sh
# KernelSU 模块列表的「操作」按钮
sh "${0%/*}/status.sh"
