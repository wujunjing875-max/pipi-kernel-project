#!/system/bin/sh
# 远程改机型（属性层）—— 设备端执行体（纯 shell，不依赖 python）
#   sh apply_model.sh            按本机处理器自动挑模板并应用（先备份原值）
#   sh apply_model.sh list       看本机处理器 + 服务器上可用的模板
#   sh apply_model.sh apply <模板文件名>
#   sh apply_model.sh restore    还原到改之前
# 原理：模板 = 目标真机全量包里的属性表（ro.product.* + 各分区 build.fingerprint 等），
#      用 resetprop 覆盖本机属性 → 游戏/App 读到的机型就变了。
# 不做硬件级改动（不碰 keybox/attestation、不改 serial/IMEI）；重启后全局一致。
SRV=${MODEL_SRV:-https://wjntool.top/wanfeng/dl/models}
STATE=/data/adb/hide_env_pack/state
ORIG="$STATE/model_orig.prop"
CUR="$STATE/model_cur.txt"
mkdir -p "$STATE" 2>/dev/null
TMP=${TMPDIR:-/data/local/tmp}/model_spoof
mkdir -p "$TMP" 2>/dev/null

RP=""
for c in /data/adb/ksu/bin/resetprop /data/adb/magisk/resetprop /data/adb/ap/bin/resetprop; do
  [ -x "$c" ] && { RP=$c; break; }
done
[ -n "$RP" ] || RP=$(command -v resetprop 2>/dev/null)
if [ -z "$RP" ]; then echo "!! 找不到 resetprop（需要 KernelSU/Magisk/APatch）"; exit 1; fi

soc_id() {
  s=$(getprop ro.soc.model 2>/dev/null)
  [ -n "$s" ] || s=$(getprop ro.board.platform 2>/dev/null)
  [ -n "$s" ] || s=$(getprop ro.mediatek.platform 2>/dev/null)
  [ -n "$s" ] || s=$(getprop ro.hardware 2>/dev/null)
  printf '%s' "$s" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9'
}

fetch() {   # 支持 http(s) 和本地目录（整合包 payload 里那份，离线也能用）
  case "$1" in
    http*) curl -s -m 60 -o "$2" "$1" 2>/dev/null && [ -s "$2" ] ;;
    *)     [ -f "$1" ] && cp -f "$1" "$2" 2>/dev/null && [ -s "$2" ] ;;
  esac
}

mf_block() {   # 打印 manifest 里该处理器的片段
  sed -n "/\"$1\": \[/,/\]/p" "$TMP/manifest.json" 2>/dev/null
}

pick_template() {   # 优先后缀带 find/oppo 的（你要的 OPPO Find 特供）
  blk=$(mf_block "$1")
  if [ -z "$blk" ]; then
    # 变体退化：sm8750p → 试 sm8750；mt6991x → 试 mt6991
    # ★ 不依赖缩进：manifest 曾被重新排版（indent 4→1），写死 4 空格会把退化匹配整条打哑
    for cand in $(sed -n 's/^[[:space:]]*"\([a-z0-9]*\)": \[/\1/p' "$TMP/manifest.json" 2>/dev/null); do
      case "$1" in "$cand"*) blk=$(mf_block "$cand"); [ -n "$blk" ] && break ;; esac
      case "$cand" in "$1"*) blk=$(mf_block "$cand"); [ -n "$blk" ] && break ;; esac
    done
  fi
  [ -n "$blk" ] || return 0
  f=$(printf '%s\n' "$blk" | grep -i -B3 -A3 '"series": "Find"' | sed -n 's/.*"file": "\([^"]*\)".*/\1/p' | head -n 1)
  [ -n "$f" ] || f=$(printf '%s\n' "$blk" | grep -i '"brand": "OPPO"' -B3 -A3 | sed -n 's/.*"file": "\([^"]*\)".*/\1/p' | head -n 1)
  [ -n "$f" ] || f=$(printf '%s\n' "$blk" | sed -n 's/.*"file": "\([^"]*\)".*/\1/p' | head -n 1)
  printf '%s' "$f"
}

list_all() {
  sed -n 's/^[[:space:]]*"\([a-z0-9]*\)": \[/处理器 \1:/p; s/.*"name": "\([^"]*\)".*/    \1/p; s/.*"file": "\([^"]*\)".*/      模板文件：\1/p' "$TMP/manifest.json" 2>/dev/null
}

do_apply() {
  SOC=$(soc_id)
  echo "== 本机处理器：$SOC =="
  fetch "$SRV/manifest.json" "$TMP/manifest.json" || { echo "!! 取不到模板清单（无网/服务器不通）"; exit 1; }
  if [ -z "${TPL:-}" ]; then
    TPL=$(pick_template "$SOC")
    if [ -z "$TPL" ]; then
      echo "!! 服务器模板库里没有匹配 $SOC 的机型模板"
      echo "   现有："
      list_all
      exit 2
    fi
  fi
  echo "== 选用模板：$TPL =="
  fetch "$SRV/$TPL" "$TMP/tpl.prop" || { echo "!! 模板下载失败"; exit 1; }
  if [ ! -s "$ORIG" ]; then
    : > "$ORIG"
    while IFS= read -r line; do
      case "$line" in ''|'#'*) continue ;; esac
      k=${line%%=*}
      printf '%s=%s\n' "$k" "$(getprop "$k" 2>/dev/null)" >> "$ORIG"
    done < "$TMP/tpl.prop"
    echo "已备份本机原值 → $ORIG（$(wc -l < "$ORIG" | tr -d ' ') 条）"
  fi
  n=0; f=0; skip=0
  while IFS= read -r line; do
    case "$line" in ''|'#'*) continue ;; esac
    k=${line%%=*}; v=${line#*=}
    if [ "$(getprop "$k" 2>/dev/null)" = "$v" ]; then skip=$((skip+1)); continue; fi
    if "$RP" "$k" "$v" >/dev/null 2>&1; then n=$((n+1)); else f=$((f+1)); fi
  done < "$TMP/tpl.prop"
  printf '%s\n' "$TPL" > "$CUR" 2>/dev/null
  echo "== 完成：改 $n 条、跳过 $skip 条（本来就一样）、失败 $f 条 =="
  echo "   型号 = $(getprop ro.product.model)   品牌 = $(getprop ro.product.brand)"
  echo "   市场名 = $(getprop ro.vendor.oplus.market.name)$(getprop ro.vendor.oplus.market.enname)"
  echo "   指纹 = $(getprop ro.build.fingerprint)"
  echo "  ★ 重启后全局一致；还原：sh apply_model.sh restore"
}

do_restore() {
  # 附加模块也打回"不激活"（配置清空 + disable 标记），免得下次开机又按旧配置套上去
  D=/data/adb/modules/model_spoof
  if [ -d "$D" ]; then
    : > "$D/system.prop" 2>/dev/null
    echo "已还原（待激活）" > "$D/disable" 2>/dev/null
    echo "已把「改机型控制台」模块打回不激活"
  fi
  [ -s "$ORIG" ] || { echo "（运行时属性本来就没改过）"; return 0; }
  n=0; f=0
  while IFS= read -r line; do
    case "$line" in ''|'#'*) continue ;; esac
    k=${line%%=*}; v=${line#*=}
    if "$RP" "$k" "$v" >/dev/null 2>&1; then n=$((n+1)); else f=$((f+1)); fi
  done < "$ORIG"
  rm -f "$CUR" 2>/dev/null
  echo "已还原 $n 条属性（失败 $f）——重启后彻底恢复原样"
}

do_cloud() {
  # ★ 手机自己点"一键改机型"走这条：把机型+处理器报给服务器，云端挑同款配置，
  #   设备把它落位到附加的改机型模块（/data/adb/modules/model_spoof），重启后由
  #   KernelSU 在 post-fs-data 阶段应用 —— 不用连电脑、不用控制台。
  SOC=$(soc_id)
  MODEL="$(getprop ro.vendor.oplus.market.name)$(getprop ro.product.marketname)$(getprop ro.product.model)"
  [ -n "$MODEL" ] || MODEL=$(getprop ro.product.model)
  echo "== 上报：机型 $MODEL  处理器 $SOC =="
  # 优先用整合包自己的函数（token/设备码的算法由它维护）；没有包才退回后备写法
  he_tok=""; he_hw=""
  if [ -f "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/common/hide_env_license.sh" ]; then
    . "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/common/pack_shim.sh" 2>/dev/null
    . "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/common/hide_env_license.sh" 2>/dev/null
    he_tok=$(he_lic_get token 2>/dev/null)
    he_hw=$(he_lic_hwid 2>/dev/null)
  fi
  if [ -z "$he_tok" ]; then
    he_tok=$(sed -n 's/^token=//p' "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/state/lic" 2>/dev/null | head -n 1)
  fi
  if [ -z "$he_hw" ]; then
    he_hw=$(printf '%s|%s|%s|%s' "$(getprop ro.serialno)" "$(settings get secure android_id)" "$(getprop ro.product.model)" "$(getprop ro.build.fingerprint)" | md5sum 2>/dev/null | awk '{print $1}')
  fi
  if [ -z "$he_tok" ]; then echo "!! 本机还没激活（没有登录态），先在控制台激活再改机型"; return 1; fi
  SRV_API=${MODEL_API:-https://wjntool.top/lsp/api/model_plan}
  body=$(printf '{"token":"%s","hwid":"%s","soc":"%s","model":"%s"}' "$he_tok" "$he_hw" "$SOC" "$MODEL")
  resp=$(curl -s -m 30 -X POST -H 'Content-Type: application/json' -d "$body" "$SRV_API" 2>/dev/null)
  case "$resp" in
    *'"ok":true'*|*'"ok": true'*) ;;
    *) echo "!! 云端没给配置：$(printf '%s' "$resp" | head -c 200)"; return 1 ;;
  esac
  url=$(printf '%s' "$resp" | sed -n 's/.*"url": *"\([^"]*\)".*/\1/p')
  name=$(printf '%s' "$resp" | sed -n 's/.*"name": *"\([^"]*\)".*/\1/p')
  [ -n "$url" ] || { echo "!! 返回里没有配置地址"; return 1; }
  echo "== 云端给的配置：$name =="
  D=/data/adb/modules/model_spoof
  rm -rf "$D"; mkdir -p "$D"
  curl -s -m 60 -o "$D/module.prop" "$url/module.prop" 2>/dev/null
  curl -s -m 60 -o "$D/system.prop" "$url/system.prop" 2>/dev/null
  chmod 0755 "$D" 0644 "$D/module.prop" "$D/system.prop" 2>/dev/null
  if grep -q '^id=' "$D/module.prop" 2>/dev/null && grep -q '^ro\.' "$D/system.prop" 2>/dev/null; then
    rm -f "$D/disable" 2>/dev/null    # 激活「改机型控制台」模块（默认是带 disable 的）
    echo "== 已激活「改机型控制台」模块（$D，$(grep -c '^ro\.' "$D/system.prop") 条属性）=="
    sh "${HIDE_ENV_DIR:-/data/adb/hide_env_pack}/install.sh" tripwire rebase >/dev/null 2>&1
    echo "★ 重启后生效（重启后机型就变成 $name）"
    return 0
  fi
  rm -rf "$D"
  echo "!! 配置落位失败（下载不到或内容不对）"
  return 1
}

case "${1:-auto}" in
  list)
    echo "本机：$(getprop ro.product.brand) $(getprop ro.product.model)  处理器=$(soc_id)（ro.soc.model=$(getprop ro.soc.model) 平台=$(getprop ro.board.platform)）"
    fetch "$SRV/manifest.json" "$TMP/manifest.json" || { echo "!! 取不到模板清单"; exit 1; }
    echo "服务器可用模板："
    list_all
    ;;
  cloud|云端|一键) do_cloud ;;
  restore) do_restore ;;
  apply)   [ -n "${2:-}" ] && TPL="$2"; do_apply ;;   # 带文件名=指定模板；不带=按处理器自动挑
  *)       do_apply ;;
esac
