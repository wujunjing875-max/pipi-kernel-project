#!/system/bin/sh
#############################################################
# rollback.sh —— 一键回滚（离线可用，不依赖本包其它脚本）
#
# 什么时候用：刷完开不了机 / 无限重启 / 卡 logo，想把这套装的东西全停掉。
#
# 用法：
#   sh /data/adb/hide_env_pack/rollback.sh            停用本包装的全部模块（保留数据）
#   sh /data/adb/hide_env_pack/rollback.sh hard       连模块目录一起删掉
#   sh /data/adb/hide_env_pack/rollback.sh list       只看当前状态，不动任何东西
#   sh /data/adb/hide_env_pack/rollback.sh keep <id>  只停用某一个（例如 keep zygisksu 之外的不动）
#
# 停用的方式是在模块目录里放一个 disable 文件（KernelSU / KernelSU-Next /
# APatch / Magisk 都认这个约定）：下次开机不加载该模块，但配置和数据都还在，
# 想恢复时把 disable 删掉即可。所以默认是「停用」而不是「删除」。
#############################################################

NVBASE=${NVBASE:-/data/adb}
MODDIR_BASE=$NVBASE/modules

# 本包装的 6 个模块 + 本包自己
SELF_ID=hide_env_pack
PACK_IDS="zygisksu zygisk_lsposed oh_my_keymint hma_oss_zygisk hma-uidfake Tenc-ano_tmp hide_env_guard"

say() { echo "$*"; }

# 急救会把模块停用/删除 —— 这本身就是互锁的触发条件，所以**真要动手时**先解锁，
# 避免"急救完成 → 下次开机整套自毁"的连锁。
# ★ 2026-10-11 真机审计发现：这段以前放在文件顶部无条件执行 —— 连 `rollback.sh list`
#   这种只读命令都会把互锁关掉（状态副作用）。现在只在会动手的急救分支里调用 unlock_tw。
unlock_tw() {
  [ -d "$NVBASE/$SELF_ID/config" ] || return 0
  printf 'off\n' >"$NVBASE/$SELF_ID/config/tripwire.txt" 2>/dev/null
  say "- 已关闭模块互锁（急救工具自动解锁；要重新上锁：install.sh tripwire on）"
}

show_state() {
  say "- 模块状态："
  for id in $PACK_IDS $SELF_ID; do
    d="$MODDIR_BASE/$id"
    if [ -d "$d" ]; then
      if [ -f "$d/disable" ]; then
        say "    [已停用] $id"
      else
        say "    [运行中] $id"
      fi
    else
      say "    [不存在] $id"
    fi
  done
  say ""
  say "- 说明：停用只是加 disable 标记，配置和数据都保留；"
  say "  要恢复某个模块：rm -f $MODDIR_BASE/<id>/disable 然后重启。"
  say "- 内核日志里上一次崩溃的原因（如果设备支持）："
  for p in /sys/fs/pstore/console-ramoops-0 /sys/fs/pstore/console-ramoops /proc/last_kmsg; do
    [ -s "$p" ] && { say "    $p （可用 grep -iE 'panic|fault|oom|BUG' 查看）"; break; }
  done
  say "- 本包日志："
  for f in "$NVBASE/$SELF_ID/install.log" "$NVBASE/$SELF_ID/boot.log" "$NVBASE/$SELF_ID/status.txt" "$NVBASE/$SELF_ID/guard.log"; do
    [ -s "$f" ] && say "    $f"
  done
  say "- 如果设备能连电脑：adb logcat -b all -d > /sdcard/logcat.txt 取证最有用。"
}

do_disable() {
  hard="$1"; shift
  n=0
  for id in $@; do
    d="$MODDIR_BASE/$id"
    [ -d "$d" ] || continue
    if [ "$hard" = "hard" ]; then
      rm -rf "$d" 2>/dev/null
      say "    已删除 $id"
    else
      touch "$d/disable" 2>/dev/null
      say "    已停用 $id"
    fi
    n=$((n + 1))
  done
  say "- 共处理 $n 个模块"
}

case "$1" in
  list|status)
    show_state
    ;;
  "")
    # 不带参数 = 直接急救回滚（用户慌起来只会打这一条）
    unlock_tw
    show_state
    say ""
    say "- 开始回滚（软停用）：保留目录和数据，下次开机不加载"
    do_disable soft $PACK_IDS $SELF_ID
    say "- 完成，请重启。想恢复某个模块：rm -f $MODDIR_BASE/<模块id>/disable"
    ;;
  hard)
    unlock_tw
    say "- 回滚（硬删）：删除本包装的全部模块目录"
    do_disable hard $PACK_IDS $SELF_ID
    say "- 完成。重启后即回到未刷本包的状态（写在 /data/misc 里的密钥/包名配置不影响开机）"
    ;;
  keep)
    # 只停用除指定模块之外的：rollback.sh keep zygisksu
    shift
    keep_id="$1"
    list=""
    for id in $PACK_IDS $SELF_ID; do
      [ "$id" = "$keep_id" ] && continue
      list="$list $id"
    done
    unlock_tw
    say "- 回滚：保留 $keep_id，停用其它模块"
    do_disable soft $list
    say "- 完成，重启生效"
    ;;
  *)
    unlock_tw
    say "- 回滚（软停用）：保留目录和数据，只让它们下次开机会加载"
    do_disable soft $PACK_IDS $SELF_ID
    say "- 完成，重启生效。想恢复：rm -f $MODDIR_BASE/<模块id>/disable"
    ;;
esac

exit 0
