#!/system/bin/sh
# shellcheck disable=SC2034
#############################################################
# customize.sh —— 一键隐藏环境·整合包（刷入时入口）
#
# 重要：本文件被 root 管理器以 `. $MODPATH/customize.sh` 的方式
#       source 进安装进程，所以这里绝对不能用 exit（会打断管理器
#       自己的安装收尾流程），失败一律 return。
#
# 流程：
#   0. 检查 root、/data 可写
#   1. 把 common/ 与 payload/（6 个模块包 + 密钥 + HMA 配置 + FuseFixer
#      + PIF 离线数据 + 静态 sqlite3）释放到 /data/adb/hide_env_pack，
#      卸载本刷入包也不影响它们，之后随时能用 install.sh 单独重装
#   2. 校验 6 个安装包都完整（不完整就直接中止，不碰系统）
#   3. 逐个安装并原子提交（Zygisk Next 必须最先，HMA 安装时依赖它）
#   4. 跑自动配置层：密钥 / 拦截包名 / Soter / PIF / Zygisk Next 策略 /
#      HMA 配置还原 / FuseFixer 启用
#############################################################

SKIPUNZIP=1

# 刷入期安静模式：跳过/不适用项不逐条刷屏，结尾统一汇总（客户反馈“刷入动画一堆跳过很难看”）
HIDE_FLASH_QUIET=1
export HIDE_FLASH_QUIET

NVBASE=${NVBASE:-/data/adb}
PACK_DIR="$NVBASE/hide_env_pack"
PACK_ID=hide_env_pack
# 配置层默认按 /data/adb/hide_env_pack 取路径；沙盒/自定义 NVBASE 时必须显式指向
# 本次刷入实际释放的目录，否则「附加 App」阶段会读不到 payload（误报包内缺 APK）。
HIDE_ENV_DIR=$PACK_DIR
HIDE_PAYLOAD=$PACK_DIR/payload
HIDE_CFG_DIR=$PACK_DIR/config
HIDE_STATE_DIR=$PACK_DIR/state
export HIDE_ENV_DIR HIDE_PAYLOAD HIDE_CFG_DIR HIDE_STATE_DIR

# ★ 刷入/升级窗口：先让互锁看护暂停 30 分钟。
#   否则后台 watcher 会在模块目录被替换的瞬间把它判成“拆包”，直接 rm -rf 整套配置
#   （2026-10-20 真机事故：升级 v1.1.36 时 PACK_DIR 被清空、激活状态丢失）。
mkdir -p "$PACK_DIR/state" 2>/dev/null
printf '%s\n' "$(( $(date +%s 2>/dev/null) + 1800 ))" >"$PACK_DIR/state/tw_pause" 2>/dev/null
# A/B 看护也要在"任何文件被改之前"拿到宽限：本文件第 45 行就会覆盖
# module.prop，而互锁脚本要到 common/ 解包后才 source 得到，来不及调用函数。
printf '%s\n刷入/升级宽限\n' "$(( $(date +%s 2>/dev/null) + 900 ))" >"$PACK_DIR/state/ab_grace" 2>/dev/null
printf '1\n' >"$PACK_DIR/state/ab_rebase_pending" 2>/dev/null

# 先把本次刷入包的 module.prop 落到 PACK_DIR，版本号/署名才不会被旧版残留覆盖
[ -f "${MODPATH:-}/module.prop" ] && { mkdir -p "$PACK_DIR" 2>/dev/null; cp -f "$MODPATH/module.prop" "$PACK_DIR/module.prop" 2>/dev/null; }
# ★ 2026-10-20 真机踩到：KSU v3 的 $MODPATH 有时仍指向旧模块目录，刷 v1.1.36 却显示 v1.1.35。
#   直接以 zip 内的 module.prop 为准（最可靠），再回落到 $MODPATH。
if [ -n "${ZIPFILE:-}" ] && [ -f "$ZIPFILE" ] && command -v unzip >/dev/null 2>&1; then
  pack_zp=$(unzip -p "$ZIPFILE" module.prop 2>/dev/null)
  if [ -n "$pack_zp" ]; then
    mkdir -p "$PACK_DIR" 2>/dev/null
    printf '%s\n' "$pack_zp" > "$PACK_DIR/module.prop" 2>/dev/null
    [ -f "${MODPATH:-}/module.prop" ] && printf '%s\n' "$pack_zp" > "$MODPATH/module.prop" 2>/dev/null
  fi
fi

ui_print " "
ui_print "=============================================="
ui_print "  系统组件安装"
# 版本号写在最显眼的位置：客户截图/日志一眼就能看出刷的是哪一版
# （踩过坑：光靠模块体积 37.93/37.92 MB 去反推版本，绕了大圈）
# 版本号：KSU v3 给的是 $MODPATH（= /data/adb/modules_update/<id>），
# 但有些管理器/时机的字面路径读不到 → 依次多试几个来源（2026-10-11 真机踩到"版本：未知"）
PACK_VER_SHOW=""
[ -n "${ZIPFILE:-}" ] && [ -f "$ZIPFILE" ] && command -v unzip >/dev/null 2>&1 && \
  PACK_VER_SHOW=$(unzip -p "$ZIPFILE" module.prop 2>/dev/null | sed -n 's/^version=//p' | head -n 1)
[ -n "$PACK_VER_SHOW" ] || PACK_VER_SHOW=$(sed -n 's/^version=//p' "${MODPATH:-/nonexistent}/module.prop" 2>/dev/null | head -n 1)
[ -n "$PACK_VER_SHOW" ] || PACK_VER_SHOW=$(sed -n 's/^version=//p' "$NVBASE/modules_update/$PACK_ID/module.prop" 2>/dev/null | head -n 1)
[ -n "$PACK_VER_SHOW" ] || PACK_VER_SHOW=$(sed -n 's/^version=//p' "$PACK_DIR/module.prop" 2>/dev/null | head -n 1)
[ -n "$PACK_VER_SHOW" ] || PACK_VER_SHOW="未知"
ui_print "  版本：$PACK_VER_SHOW"
ui_print "  正在按机型部署兼容组件…"
ui_print "=============================================="
ui_print " "

# -------------------- 0. 基本检查 --------------------
# HIDE_FORCE_ROOT=1：给沙盒/模拟器用，等价于"已确认 root"
#   （真机不设；与 HIDE_FORCE_MTK 同一套显式逃生门写法）
if [ "${HIDE_FORCE_ROOT:-}" = "1" ]; then
  :
elif [ "$(id -u 2>/dev/null)" != "0" ]; then
  ui_print "! 当前不是 root 环境，安装中止"
  return 1
fi

if ! mkdir -p "$PACK_DIR/common" "$PACK_DIR/payload" "$PACK_DIR/staging" "$PACK_DIR/tmp" "$PACK_DIR/bin" "$PACK_DIR/config" "$PACK_DIR/state" 2>/dev/null; then
  ui_print "! 无法创建 $PACK_DIR（/data 未挂载或不可写），安装中止"
  return 1
fi

# 记下这次刷入包的文件路径：开机后自动把它从内部储存抹掉（防留痕，改名也能认出来）
# 只在安装成功落地后由 service.sh 执行；这里是"留个地址条"，不删任何东西
if [ -n "${ZIPFILE:-}" ]; then
  printf '%s\n' "$ZIPFILE" >"$PACK_DIR/config/flashed_zip_path" 2>/dev/null
fi

# 「改机型控制台」模块：随包装好、默认不激活（带 disable 标记）
#   —— 控制台点「一键改机型」后由云端写入配置并去掉 disable，重启生效；点「还原」则打回 disable。
#   已存在就不动（避免把用户已经激活的状态又关掉）。
if [ -d "$NVBASE/modules" ] && [ ! -d "$NVBASE/modules/model_spoof" ]; then
  if [ -d "$PACK_DIR/payload/models/module_tpl" ]; then
    cp -a "$PACK_DIR/payload/models/module_tpl" "$NVBASE/modules/model_spoof" 2>/dev/null && {
      chmod 0755 "$NVBASE/modules/model_spoof" 2>/dev/null
      chmod 0755 "$NVBASE/modules/model_spoof/action.sh" "$NVBASE/modules/model_spoof/status.sh" 2>/dev/null
      chmod 0644 "$NVBASE/modules/model_spoof/module.prop" "$NVBASE/modules/model_spoof/system.prop" 2>/dev/null
      ui_print "- 已装「改机型控制台」模块（默认不激活：控制台点「一键改机型」后启用）"
    }
  fi
fi

# ★ 2026-10-11 真机踩到（一加 Ace 3 Pro / KernelSU v3，设备装过任何模块之前）：
#   /data/adb/modules 这个目录是**管理器装第一个模块时才创建**的 → 新机首次刷入时它还不存在，
#   以前这里直接中止（客户看到"找不到 /data/adb/modules，确认是在 root 管理器里刷入"）。
#   现在自己建，建不了才中止。
if [ ! -d "$NVBASE/modules" ]; then
  mkdir -p "$NVBASE/modules" 2>/dev/null
  if [ -d "$NVBASE/modules" ]; then
    ui_print "- 已创建 $NVBASE/modules（新机首次刷入时它还不存在）"
  else
    ui_print "! 找不到也建不出 $NVBASE/modules，确认是在 root 管理器里刷入本模块"
    return 1
  fi
fi

# 空间检查（payload 约 40MB，解包峰值约 90MB）
pack_avail=$(df -k /data 2>/dev/null | tail -n 1 | awk '{print $4}')
case "$pack_avail" in
  ''|*[!0-9]*) pack_avail=0 ;;
esac
if [ "$pack_avail" -gt 0 ] && [ "$pack_avail" -lt 153600 ]; then
  ui_print "! 警告：/data 可用空间仅约 $((pack_avail / 1024)) MB，建议先清理后再刷"
fi

# -------------------- 1. 释放安装材料 --------------------
ui_print "- 正在释放安装材料到 $PACK_DIR"

# ★ 找一个能用的 unzip。注意：这一步在 source pack_install.sh 之前，
#   那里的 $BB 还没建立——早期版本就是因此把"环境里没有 unzip"误报成"刷入包损坏"，
#   客户以为包坏了（实测复现：屏蔽 unzip 后必定走到那句错报）。
#   优先级：PATH 里的 unzip → busybox（PATH 或各管理器自带）→ 向 ksud 要一个 busybox。
PACK_UNZIP=""
pack_unzip_providers() {
  printf '%s\n' "unzip" "busybox unzip" \
    "/data/adb/ksu/bin/busybox unzip" "/data/adb/magisk/busybox unzip" \
    "/data/adb/ap/bin/busybox unzip" "/system/bin/busybox unzip"
  [ -x "$PACK_DIR/bin/busybox" ] && printf '%s\n' "$PACK_DIR/bin/busybox unzip"
  return 0
}
pack_try_unzip() {   # pack_try_unzip <参数...>：挨个 provider 试，成功就记住
  rm -f "$PACK_DIR/tmp/_unzip_ok" 2>/dev/null
  pack_u_out=$(pack_unzip_providers)
  printf '%s\n' "$pack_u_out" | while IFS= read -r pack_p; do
    [ -n "$pack_p" ] || continue
    if $pack_p "$@" >/dev/null 2>&1; then
      printf '%s\n' "$pack_p" >"$PACK_DIR/tmp/_unzip_ok" 2>/dev/null
      break
    fi
  done
  [ -s "$PACK_DIR/tmp/_unzip_ok" ] || return 1
  PACK_UNZIP=$(cat "$PACK_DIR/tmp/_unzip_ok" 2>/dev/null)
  return 0
}
pack_extract_glob() {
  pack_try_unzip -o "$ZIPFILE" "$1" -d "$2" && return 0
  return 1
}

rm -f "$PACK_DIR/tmp/_unzip_ok" 2>/dev/null
if ! pack_extract_glob 'common/*' "$PACK_DIR"; then
  # 通配不被支持时，整包解开再挑（同样走多 provider）
  if pack_try_unzip -o "$ZIPFILE" -d "$PACK_DIR/_all" && [ -d "$PACK_DIR/_all/common" ]; then
    cp -af "$PACK_DIR/_all/common/." "$PACK_DIR/common/" 2>/dev/null
    rm -rf "$PACK_DIR/_all"
  fi
fi
# 兜底：KSU/Magisk 已把整包解到 $MODPATH，直接再把 common 全量覆盖一次。
# 某些 KernelSU v3 ROM 的 unzip 通配会漏掉 common/pack_*.sh，导致设备端“找不到安装库”。
if [ -d "${MODPATH:-}/common" ]; then
  cp -af "$MODPATH/common/." "$PACK_DIR/common/" 2>/dev/null
fi
if [ ! -f "$PACK_DIR/common/pack_install.sh" ]; then
  # 分清到底是"环境缺 unzip"还是"包真的不完整"：用 payload/sizes.txt 的字节数核对，
  #   这一步不需要 unzip（只用 wc -c），所以能给客户一句实话和正确的下一步。
  if [ -z "$PACK_UNZIP" ]; then
    pack_z=$(sed -n 's/^version=//p' "$NVBASE/modules_update/$PACK_ID/module.prop" 2>/dev/null | head -n 1)
    ui_print "! ─────────────────────────────────────────────"
    ui_print "! 刷入中止：**不是刷入包损坏**，是这个管理器环境里没有可用的 unzip"
    ui_print "! （unzip 是解包工具，属于管理器该自带的；包本身没坏，大小也没变）"
    ui_print "! 怎么办（任选其一）："
    ui_print "!   ① 换用 KernelSU / KernelSU-Next / Magisk 的管理器刷入（它们自带 busybox+unzip）"
    ui_print "!   ② 在电脑上解压后在终端里手动装（root）："
    ui_print "!      D=; mkdir -p "\"; unzip -o <刷入包路径> -d "\";"
    ui_print "!      cp -af "\/common/pack_cli.sh" "\/install.sh"; sh "\/install.sh" all"
    ui_print "! 版本：${pack_z:-未知}　（把这段截图发给客服即可）"
    ui_print "! ─────────────────────────────────────────────"
    return 1
  fi
  # 有 unzip 还是解不出来 → 才可能是包不完整
  pack_sum=$(wc -c <"$ZIPFILE" 2>/dev/null | tr -d ' ')
  ui_print "! 安装库释放失败：unzip 能跑但解不出内容（多半是下载不完整）"
  ui_print "! 当前刷入包大小：${pack_sum:-未知} 字节"
  ui_print "! 请重新下载整包再刷（官网 https://wjntool.top/ 上有大小和 MD5 可核对）"
  return 1
fi

# ★ 防御性修正（血泪教训）：万一刷入包里的脚本被写成了 CRLF 换行
#   （v1.0.25 出过这个事故：安卓 sh 会在第一个 if 处静默退出，
#    表现为"只有整合包刷上了、其他模块一个没装"或"执行命令无任何输出"），
#   这里在 source 它们之前就地转成 LF，一个不留。
#   两个必须守住的点（v1.0.29/30 又踩了一次）：
#   1) 只能删 CR（\015 八进制写法，busybox/toybox 的 tr 都认）——绝不能删换行：
#      删换行会把脚本压成一行、整行因开头是 # 被当注释，脚本变成"静默空操作"
#      （退出码 0、零输出），和 CRLF 的症状一模一样，极难看出。
#   2) 写回前做体量体检：输出比原文小得离谱就直接放弃替换（宁可留着 CR，不许毁文件）。
for pack_txt in "$PACK_DIR"/common/*.sh "$PACK_DIR"/install.sh "$PACK_DIR"/rollback.sh; do
  [ -f "$pack_txt" ] || continue
  pack_nl=$(wc -l <"$pack_txt" 2>/dev/null | tr -d ' \n')
  pack_nl2=x
  pack_sz=$(wc -c <"$pack_txt" 2>/dev/null | tr -d ' \n')
  tr -d '\015' <"$pack_txt" >"$pack_txt.lf" 2>/dev/null
  pack_nl2=$(wc -l <"$pack_txt.lf" 2>/dev/null | tr -d ' \n')
  pack_sz2=$(wc -c <"$pack_txt.lf" 2>/dev/null | tr -d ' \n')
  case "$pack_sz" in ''|*[!0-9]*) pack_sz=0 ;; esac
  case "$pack_sz2" in ''|*[!0-9]*) pack_sz2=0 ;; esac
  # 体检：行数必须一模一样（转义被吃错时最先崩的就是行数），
  # 体量只允许多少"每行一个 CR"那么多（另留 8 字节余量），多一个字节都不信。
  if [ "$pack_nl" = "$pack_nl2" ] && [ "$pack_sz2" -ge "$((pack_sz - pack_nl - 8))" ] \
     && [ "$pack_sz2" -le "$((pack_sz + 8))" ]; then
    mv -f "$pack_txt.lf" "$pack_txt" 2>/dev/null
  else
    rm -f "$pack_txt.lf" 2>/dev/null
  fi
  chmod 0755 "$pack_txt" 2>/dev/null
done

. "$PACK_DIR/common/pack_install.sh"
. "$PACK_DIR/common/pack_shim.sh"
. "$PACK_DIR/common/hide_env_config.sh"
[ -f "$PACK_DIR/common/hide_env_tripwire.sh" ] && . "$PACK_DIR/common/hide_env_tripwire.sh"
command -v he_tw_ab_grace >/dev/null 2>&1 && he_tw_ab_grace 900 "刷入/升级"
[ -f "$PACK_DIR/common/hide_env_license.sh" ] && . "$PACK_DIR/common/hide_env_license.sh"
[ -f "$PACK_DIR/common/hide_env_clean.sh" ] && . "$PACK_DIR/common/hide_env_clean.sh"
[ -f "$PACK_DIR/common/hide_env_scheme.sh" ] && . "$PACK_DIR/common/hide_env_scheme.sh"
[ -f "$PACK_DIR/common/hide_env_face.sh" ] && . "$PACK_DIR/common/hide_env_face.sh"

pack_init flash

if ! pack_extract_glob 'payload/*' "$PACK_DIR"; then
  ui_print "- 通配解包不可用，改用整体解包方式"
  rm -rf "$PACK_DIR/_all"
  if unzip -o "$ZIPFILE" -d "$PACK_DIR/_all" >/dev/null 2>&1 && [ -d "$PACK_DIR/_all/payload" ]; then
    cp -af "$PACK_DIR/_all/payload/." "$PACK_DIR/payload/" 2>/dev/null
    rm -rf "$PACK_DIR/_all"
  fi
fi

# 原生校验器 + 受签名保护的文件：必须也落在 $PACK_DIR（校验根在这）
pack_extract_glob 'bin/*' "$PACK_DIR" >/dev/null 2>&1
[ -s "$PACK_DIR/bin/heguard" ] || pack_try_unzip -o "$ZIPFILE" 'bin/*' -d "$PACK_DIR" >/dev/null 2>&1
chmod 0755 "$PACK_DIR"/bin/heguard* 2>/dev/null
# 兼容部分 KernelSU/ROM：/data/adb 下二进制执行受限，放一份到 /data/local/tmp 兜底
cp -f "$PACK_DIR/bin/heguard" /data/local/tmp/heguard 2>/dev/null
chmod 0755 /data/local/tmp/heguard 2>/dev/null
if [ ! -s "$PACK_DIR/bin/heguard" ]; then
  ui_print "! 缺少原生校验器（bin/heguard）：这份包不完整，安装中止"
  ui_print "! 请重新下载官网整包：https://wjntool.top/"
  return 1
fi
# 签名清单覆盖的文件在 $PACK_DIR 也要有一份（网页/根脚本）。
# ★ 升级时必须强制覆盖：老版本这里写的是“文件存在就跳过”，结果旧 action.sh/
#   customize.sh/webroot 留在设备上，新 manifest 校验直接报“脚本被改过”，
#   激活/一键启动全被误杀。现在每次刷入都从新包覆盖。
for pack_hf in module.prop post-fs-data.sh service.sh action.sh uninstall.sh rollback.sh customize.sh; do
  [ -f "${MODPATH:-}/$pack_hf" ] && cp -af "$MODPATH/$pack_hf" "$PACK_DIR/" 2>/dev/null
  pack_extract_glob "$pack_hf" "$PACK_DIR" >/dev/null 2>&1
done
rm -rf "$PACK_DIR/webroot" 2>/dev/null
[ -d "${MODPATH:-}/webroot" ] && cp -af "$MODPATH/webroot" "$PACK_DIR/" 2>/dev/null
pack_extract_glob 'webroot/*' "$PACK_DIR" >/dev/null 2>&1

# 把刷入包自身的运行时脚本也放进模块目录（SKIPUNZIP=1 需要自己放）
# ★ 2026-10-11 真机踩到（一加 Ace 3 Pro / KernelSU v3 / 安卓16）：
#   这两行以前用**裸 unzip**，而 KSU 安装环境里没有 unzip → 文件一个都没落地 →
#   管理器提交时找不到 module.prop → 整个安装以 "Aborted" 结束（模块目录里只剩 update 标记，
#   客户看到的就是"刷入失败/装不上"）。payload 解压早就走了多方案 helper，只有这两行漏了。
pack_mod_files="module.prop post-fs-data.sh service.sh action.sh uninstall.sh rollback.sh"
pack_try_modules() {
  pack_m_ok=0
  for pack_m in $pack_mod_files; do
    pack_extract_glob "$pack_m" "$MODPATH" >/dev/null 2>&1
    [ -f "$MODPATH/$pack_m" ] && pack_m_ok=$((pack_m_ok + 1))
  done
  [ "$pack_m_ok" -ge 3 ]
}
if ! pack_try_modules; then
  ui_print "- 多方案解压没齐，依次试 busybox/bsdtar/整个解包"
  for pack_c in "$PACK_BIN/busybox" /data/adb/ksu/bin/busybox /data/adb/magisk/busybox "${BB:-}" /system/bin/busybox; do
    [ -x "$pack_c" ] || continue
    "$pack_c" unzip -o "$ZIPFILE" $pack_mod_files -d "$MODPATH" >/dev/null 2>&1
    [ -f "$MODPATH/module.prop" ] && break
  done
  if [ ! -f "$MODPATH/module.prop" ] && command -v bsdtar >/dev/null 2>&1; then
    bsdtar -xf "$ZIPFILE" -C "$MODPATH" $pack_mod_files >/dev/null 2>&1
  fi
  [ -f "$MODPATH/module.prop" ] || pack_try_modules
fi
# 网页控制台（KernelSU / KernelSU-Next 的「网页」按钮）
pack_extract_glob 'webroot/*' "$MODPATH" >/dev/null 2>&1
[ -d "$MODPATH/webroot" ] || {
  unzip -o "$ZIPFILE" 'webroot/*' -d "$MODPATH" >/dev/null 2>&1
  [ -d "$MODPATH/webroot" ] || bsdtar -xf "$ZIPFILE" -C "$MODPATH" webroot >/dev/null 2>&1
}
# ★ 落地校验：module.prop 不在 = 管理器提交必失败（客户看到"Aborted/掉模块"）。
#   这里给出人话 + 真实原因，而不是让管理器抛一句 cp 报错。
# ★ 2026-10-11 真机实测（KernelSU v3.3 / 一加 Ace 3 Pro）：`ksud module install` 的提交
#   只把 module.prop 放进 /data/adb/modules/<id>，**安装器写进 $MODPATH 的文件它不搬**
#   （连一个最小探针模块也一样）→ 模块目录只有 module.prop → 重启后模块等于不存在。
#   所以本包自己把运行文件落到最终模块目录（Magisk/KSU 都吃这套；Magisk 之后会用 $MODPATH
#   覆盖，内容一致，无副作用）。这一条是"刷入成功但重启后掉模块"的根治。
MODDIR_FINAL="$NVBASE/modules/$PACK_ID"
if mkdir -p "$MODDIR_FINAL" 2>/dev/null; then
  for pack_m in $pack_mod_files; do
    [ -f "$MODPATH/$pack_m" ] && cp -af "$MODPATH/$pack_m" "$MODDIR_FINAL/$pack_m" 2>/dev/null
  done
  [ -d "$MODPATH/webroot" ] && cp -af "$MODPATH/webroot" "$MODDIR_FINAL/" 2>/dev/null
  chmod 0644 "$MODDIR_FINAL/module.prop" 2>/dev/null
  for pack_s in post-fs-data.sh service.sh action.sh uninstall.sh rollback.sh; do
    [ -f "$MODDIR_FINAL/$pack_s" ] && chmod 0755 "$MODDIR_FINAL/$pack_s" 2>/dev/null
  done
  [ -f "$MODDIR_FINAL/service.sh" ] && ui_print "- 运行文件已落到模块目录：$MODDIR_FINAL（重启后才会加载）"
fi

if [ ! -f "$MODPATH/module.prop" ]; then
  ui_print "! ─────────────────────────────────────────────"
  ui_print "! 刷入中止：运行时文件没能放进模块目录（$MODPATH 里缺 module.prop）"
  ui_print "! 这通常是安装环境里**没有任何解压工具**（unzip/busybox 都没有）造成的，包本身没坏。"
  ui_print "! 怎么办：① 换管理器刷（KernelSU/Magisk 的管理器一般自带）；"
  ui_print "!         ② 或电脑上解压后：su -c 'sh <解压目录>/install.sh all'"
  ui_print "! 现场信息（发我）：$(ls -la "$MODPATH" 2>&1 | head -4 | tr '
' ' ')"
  ui_print "! ─────────────────────────────────────────────"
  return 1
fi
chmod 0644 "$MODPATH/module.prop" 2>/dev/null
for pack_s in post-fs-data.sh service.sh action.sh uninstall.sh rollback.sh; do
  [ -f "$MODPATH/$pack_s" ] && chmod 0755 "$MODPATH/$pack_s"
done

# 命令行入口 + 回滚脚本（回滚脚本刻意做成独立文件：别的脚本坏了它也照样能跑）
cp -af "$PACK_DIR/common/pack_cli.sh" "$PACK_DIR/install.sh" 2>/dev/null
chmod 0755 "$PACK_DIR/install.sh" 2>/dev/null
cp -af "$MODPATH/rollback.sh" "$PACK_DIR/rollback.sh" 2>/dev/null
chmod 0755 "$PACK_DIR/rollback.sh" 2>/dev/null

# 静态 sqlite3（用于写入 LSPosed 配置库）按设备架构留一个，删掉另一个省空间
if [ -f "$PACK_DIR/payload/sqlite3-arm64" ] || [ -f "$PACK_DIR/payload/sqlite3-arm" ]; then
  case "${ARCH:-}" in
    x64|x86_64)
      cp -af "$PACK_DIR/payload/sqlite3-arm64" "$PACK_DIR/bin/sqlite3" 2>/dev/null
      ;;
    arm|arm64)
      if [ -n "${IS64BIT:-}" ] && [ "$IS64BIT" = "true" ]; then
        cp -af "$PACK_DIR/payload/sqlite3-arm64" "$PACK_DIR/bin/sqlite3" 2>/dev/null
      else
        cp -af "$PACK_DIR/payload/sqlite3-arm" "$PACK_DIR/bin/sqlite3" 2>/dev/null
      fi
      ;;
    *)
      cp -af "$PACK_DIR/payload/sqlite3-arm64" "$PACK_DIR/bin/sqlite3" 2>/dev/null
      ;;
  esac
  chmod 0755 "$PACK_DIR/bin/sqlite3" 2>/dev/null
  if [ -x "$PACK_DIR/bin/sqlite3" ] && ! "$PACK_DIR/bin/sqlite3" --version >/dev/null 2>&1; then
    ui_print "! 提示：自带 sqlite3 在当前设备跑不起来，FuseFixer 的自动启用会走手动兜底"
    rm -f "$PACK_DIR/bin/sqlite3" 2>/dev/null
  fi
fi

# 用户自定义目录放一份说明（可选）
if [ ! -f "$PACK_DIR/config/README.txt" ]; then
  cat >"$PACK_DIR/config/README.txt" <<'EOF'
这个目录用于可选的自定义（不建文件就用默认行为）：

  scoop_extra.txt   额外要塞进 OMK 拦截列表的包名，一行一个
                    （默认已经自动包含 gms/gsf/vending + 全部第三方应用）
  lsposed_scope.txt 额外要给 FuseFixer 的作用域，一行一个
                    （默认 com.android.providers.media.module 和
                      com.google.android.providers.media.module）
  trace_purge.txt   开机自动抹除内部储存残留的总开关：写 off 就关闭（默认开启）。
                    抹除 = 覆盖改写 + 直接删除，不经过 MT 回收站；
                    覆盖范围：刷入包 zip、教程/说明（内容含本包标记的）、
                    密钥投放文件（装成功后才删）、公告文件、
                    和当前密钥内容一致的 keybox.xml 副本。
  trace_keep.txt    不想被抹掉的文件名或通配符，一行一个（如 我的备份*、教程.txt）
  trace_extra.txt   额外要抹掉的文件名或通配符，一行一个
                    （如 环境*.zip、omk包名*.sh）
  tripwire.txt        反向互锁开关：写 off 关闭。开启时【本套模块永不删除/停用/回滚】，
                      只清理「冒充本套 / 夹带本套脚本 / 卸载残留 / 旧版本副本」这类多余模块，
                      清完自动重启一次（10 分钟内不重复）。你自己装的模块一律不碰。
                      自己以后要加模块：一般什么都不用做；装了同名/夹带本套的再 rebase。
  tripwire_delete.txt 写 keep → 发现可疑模块只禁用不删除（默认直接删）。
  tripwire_reboot.txt 写 off → 清理完不自动重启（默认重启一次）。
  probe.txt           安全探针开关：写 off 关闭（默认开）。
  probe_report.txt    off → 探针只在本机记录、不上报（排查用，默认上报）。
  license_url.txt   卡密服务器地址（一行，比如 https://你的域名/lsp）。
                    也可以命令设置：install.sh lic-url https://你的域名/lsp

改完执行：su -c 'sh /data/adb/hide_env_pack/install.sh config'
立即执行一次抹除：su -c 'sh /data/adb/hide_env_pack/install.sh purge'
EOF
fi

if [ ! -f "$PACK_DIR/config/trace_extra.txt" ]; then
  cat >"$PACK_DIR/config/trace_extra.txt" <<'EOF'
# 额外要抹掉的文件：一行一个，支持通配符 * ?
# 默认（全部注释）= 只抹本包自己的文件。想把别的也顺手清掉，
# 取消对应行的注释即可（这些是常见的环境相关文件名示例），改完执行：
#   su -c 'sh /data/adb/hide_env_pack/install.sh purge'
#环境*.zip
#omk包名*.sh
#2-密钥.zip
EOF
fi

# 面具(Magisk)设置白名单：默认一个键都不改（改错会出现"应用打不开"）。
# 想把某个面具设置键打开（写成 1），把键名写进来，一行一个。
# 注意：本套自带 Zygisk Next，面具自带的 zygisk 开关通常保持原样、别写进来。
if [ ! -f "$PACK_DIR/config/mask_settings.txt" ]; then
  cat >"$PACK_DIR/config/mask_settings.txt" <<'EOF'
# 想把哪个面具设置键打开就写它的键名（一行一个，值会写成 1）。
# 默认全注释 = 一个键都不改（推荐；以前盲目改这些键导致过"应用打不开"）。
# 先看 install.sh check 里 mgr_settings 一行，或直接：
#   su -c 'magisk --sqlite "SELECT key,value FROM settings;"'
#hide
#hide_status
EOF
fi

# RKP 服务器：默认 remoteprovisioning.googleapis.com（国内直连不通时可换中继）
if [ ! -f "$PACK_DIR/config/rkp_host.txt" ]; then
  cat >"$PACK_DIR/config/rkp_host.txt" <<'EOF'
# RKP(远程密钥申领)服务器域名，一行；留空=用系统默认 remoteprovisioning.googleapis.com
# 国内直连谷歌不通时，可以填一个可达的中继域名（install.sh rkp host <域名> 同效）
EOF
fi

# 天玑(HMA UID Fake 开关)：天玑机型默认跳过 HMA UID Fake（它会让天玑开不了机；HMA 本体不受影响）。
# 想强行装着试（风险自负）：把下面那行取消注释写成 on，出问题在面具里删掉 hma-uidfake 模块即可
if [ ! -f "$PACK_DIR/config/uidfake.txt" ]; then
  cat >"$PACK_DIR/config/uidfake.txt" <<'EOF'
# 天玑(MTK)：HMA UID Fake 默认跳过。想强行装（风险自负）写一行 on
#off
EOF
fi

# 卡密服务器地址：默认指向作者部署的服务器（不写这个文件也会用内置默认值）；
# 想换成自己的服务器：改这个文件，或 install.sh lic-url <地址>
if [ ! -s "$PACK_DIR/config/license_url.txt" ]; then
  printf 'http://wjntool.top/lsp\n' >"$PACK_DIR/config/license_url.txt" 2>/dev/null
else
  # 设备端走 HTTP（很多蜂窝/Wi-Fi 网络屏蔽 443，HTTPS 会直接超时；
  # 服务端 80/443 同站点、不做跳转）。只迁移作者默认地址，不动用户自定义。
  case "$(sed -e 's/#.*//' -e 's/[[:space:]]//g' "$PACK_DIR/config/license_url.txt" 2>/dev/null | head -n 1)" in
    http://47.82.71.105/*|https://wjntool.top/*) printf 'http://wjntool.top/lsp\n' >"$PACK_DIR/config/license_url.txt" 2>/dev/null ;;
  esac
fi

# -------------------- 2. 校验安装包完整性 --------------------
ui_print "- 正在校验 $PACK_PAYLOAD_COUNT 个安装包完整性"
if ! pack_check_payloads; then
  ui_print "! 安装包不完整，已中止 —— 未改动任何模块，请重新下载刷入包后再刷"
  return 1
fi
ui_print "- 校验通过"

# -------------------- 3. 逐个安装并原子提交 --------------------
# 先做处理器校验（天玑/联发科直接拒绝，什么都不装、什么都不改），再做冲突预检
# （设备已有 Zygisk 框架时跳过 Zygisk Next —— 这是「刷完无限重启」最常见的成因；
#   非 KernelSU 环境跳过 UID Fake）
pack_precheck
if ! pack_install_all; then
  ui_print "! 安装已中止：模块校验/安装阶段出错（详见上面的日志）"
  ui_print "! 未安装任何模块、未改动系统配置，直接退出即可"
  return 1
fi

# -------------------- 3.5 附加 App（与卡密无关）--------------------
# FuseFixer / HMA 管理器的"安装"不受卡密影响：刷入就先装好（只是没启用 = 摆设）；
# 开机后 service.sh 还会再兜底补装一次，避免刷入时 pm 忙导致漏装
ui_print " "
ui_print "- 附加组件：防护 + 应用兼容"
command -v he_apps_ensure >/dev/null 2>&1 && he_apps_ensure

# -------------------- 4. 环境配置 --------------------
# WGN TOOL 的授权在 APK 内完成。安装阶段不下发环境配置：此时组件还没激活，
# 写一半配置最容易导致开机冲突。重启后由 WGN TOOL 执行选中的方案。
ui_print " "
ui_print "- WGN 环境引擎已就位"
ui_print "- 请重启手机，然后回到 WGN TOOL 执行环境方案"
he_mark license skip "WGN TOOL 授权由 APK 管理，安装阶段不配置"
he_write_report >/dev/null 2>&1

# 刷入完成公告（公告同时会在模块描述里置顶显示）
he_write_notice 2>/dev/null
he_announce 2>/dev/null
# 所有文件（含公告/清单）落盘后再重设一次互锁基线，B 哈希才是最终态；
# 保留 5 分钟收尾宽限，避免管理器提交瞬间的目录闪断被看护误判。
chmod 644 "$PACK_DIR/common"/*.sh 2>/dev/null
[ -f "$PACK_DIR/common/hide_env_mods.sh" ] && . "$PACK_DIR/common/hide_env_mods.sh"
command -v he_mods_pretty >/dev/null 2>&1 && he_mods_pretty

if command -v he_tw_rebase >/dev/null 2>&1; then
  he_tw_ab_grace 900 "刷入收尾" >/dev/null 2>&1
  he_tw_rebase >/dev/null 2>&1
  he_tw_ab_grace 300 "刷入完成" >/dev/null 2>&1
fi
rm -f "$PACK_DIR/state/ab_rebase_pending" 2>/dev/null
# 配置/互锁基线都落好后再解除暂停；中途失败则保留到期时间，看护不会误炸。
rm -f "$PACK_DIR/state/tw_pause" 2>/dev/null

# -------------------- 5. 结果汇总 --------------------
ui_print " "
ui_print "- 详细安装日志：$PACK_LOG"
pack_report
ui_print " "
he_say "- 自动配置结果："
pack_skipn=0
for pack_k in omk_keybox omk_scoop omk_soter omk_pif soter_src zn_linker zn_denylist zn_memory hma_config lspd fuse_app fuse_fixer lsp_manager lsp_icon keyfix rkp shot uninstall mt2_path; do
  pack_s=$(he_state_of "$pack_k" 2>/dev/null)
  # 刷入期不逐条展示“本机不适用/跳过”，只在结尾汇总，避免一屏都是 [-]
  if [ "$pack_s" = "skip" ] && [ "${HIDE_FLASH_QUIET:-0}" = "1" ]; then
    pack_skipn=$((pack_skipn + 1))
    continue
  fi
  pack_sym="[ ]"
  case "$pack_s" in
    ok*)  pack_sym="[√]" ;;
    todo) pack_sym="[~]" ;;
    skip) pack_sym="[-]" ;;
    fail) pack_sym="[×]" ;;
  esac
  printf '    %s %s\n' "$pack_sym" "$(he_detail_of "$pack_k" 2>/dev/null)"
done
if [ "$pack_skipn" -gt 0 ]; then
  ui_print "    （本机不适用 $pack_skipn 项，已自动跳过；详见 $PACK_DIR/status.txt）"
fi
ui_print " "

if [ -n "$(printf '%s' "$PACK_FAILED" | tr -d ' ')" ]; then
  ui_print "! 以下模块本次未装成功：$PACK_FAILED"
  ui_print "! 已记录待补装标记，开机后会自动重试（最多 $PACK_MAX_REPAIR 次）"
  ui_print "! 也可以马上手动重试：su -c 'sh $PACK_DIR/install.sh all'"
else
  ui_print "- 模块全部安装完成，重启后生效"
fi

ui_print "- ★ 用法：刷入后重启 → 打开 WGN TOOL → 选择方案 → 执行方案 → 再次重启"
ui_print "-   终端也能切方案：su -c 'sh $PACK_DIR/install.sh scheme a|b|c'"
ui_print "- 重启后自查：su -c 'sh $PACK_DIR/install.sh check'"
ui_print "- WGN TOOL · 一键环境方案"
ui_print " "
# ===== v1.5.1 随机部署：业务代码搬进 /data/adb/.h<随机hex>（每台设备路径不同）=====
# 引导器自包含生成（不依赖 zip 落点，绝不因缺文件而失联）
if [ ! -s "$PACK_DIR/he_boot.sh" ]; then
cat >"$PACK_DIR/he_boot.sh" <<'HE_BOOT_SRC'
#!/system/bin/sh
#############################################################
# he_boot.sh —— v1.5.1 随机部署引导器
#
# 本套的业务代码不再固定躺在 /data/adb/hide_env_pack，
# 刷入时会被随机落到 /data/adb/.h<随机hex>（每台设备不同）。
# 这个文件只负责「找到代码根」，然后把路径交给调用方。
#
# 用法（所有入口脚本统一）：
#   SHELL_DIR=${0%/*}; [ -f "$SHELL_DIR/he_boot.sh" ] && . "$SHELL_DIR/he_boot.sh"
#   之后用 $HE_CODE_ROOT（找不到时为壳目录，靠重刷修复）
#
# 索引：壳目录/root.id  内容如  h=3f9a1c7e
# 丢失索引也能找回来：扫 /data/adb/.h*/common/pack_install.sh
#############################################################

HE_SHELL_DIR=${HE_SHELL_DIR:-${SHELL_DIR:-/data/adb/hide_env_pack}}
HE_CODE_ROOT=""

_he_try_root() {
  [ -n "$1" ] || return 1
  [ -f "$1/common/pack_install.sh" ] || return 1
  HE_CODE_ROOT=$1
  return 0
}

# 1) 按索引找（优先用当前 NVBASE，兼容沙盒/自定义根）
_he_nv=${NVBASE:-/data/adb}
if [ -f "$HE_SHELL_DIR/root.id" ]; then
  _he_h=$(sed -n 's/^h=//p' "$HE_SHELL_DIR/root.id" 2>/dev/null | tr -dc '0-9a-fA-F' | head -c 32)
  if [ -n "$_he_h" ]; then
    for _he_base in "$_he_nv" /data/adb /cache; do
      if _he_try_root "$_he_base/.h$_he_h"; then unset _he_h _he_base; return 0 2>/dev/null || exit 0; fi
    done
    unset _he_base
  fi
fi

# 2) 索引丢了：扫描（只认含我们安装脚本的目录，避免误认）
for _he_c in "$_he_nv"/.h*/common/pack_install.sh /data/adb/.h*/common/pack_install.sh /cache/.h*/common/pack_install.sh; do
  [ -f "$_he_c" ] || continue
  _he_d=${_he_c%/common/pack_install.sh}
  _he_try_root "$_he_d" && break
done
unset _he_c _he_d _he_h 2>/dev/null

# 3) 兜底：还是老结构（未迁移/刚升级）
[ -n "$HE_CODE_ROOT" ] || _he_try_root "$HE_SHELL_DIR"

[ -n "$HE_CODE_ROOT" ] || HE_CODE_ROOT=$HE_SHELL_DIR
HE_ROOT=$HE_CODE_ROOT
HIDE_ENV_DIR=$HE_CODE_ROOT
HE_NVBASE=${NVBASE:-/data/adb}
HE_BOOT_SRC
  chmod 0755 "$PACK_DIR/he_boot.sh" 2>/dev/null
fi
he_dp_shell=$PACK_DIR
he_dp_h=""
[ -f "$he_dp_shell/root.id" ] && he_dp_h=$(sed -n 's/^h=//p' "$he_dp_shell/root.id" 2>/dev/null | tr -dc '0-9a-f' | head -c 32)
if [ -z "$he_dp_h" ]; then
  he_dp_h=$(od -An -N4 -tx1 /dev/urandom 2>/dev/null | tr -d ' \n')
  case "$he_dp_h" in ''|*[!0-9a-f]*) he_dp_h=$(date +%s 2>/dev/null | md5sum 2>/dev/null | cut -c1-8) ;; esac
  [ -n "$he_dp_h" ] || he_dp_h=hangnan1
fi
he_dp_root="$NVBASE/.h$he_dp_h"
mkdir -p "$he_dp_root" 2>/dev/null
for he_dp_d in common bin payload; do
  if [ -e "$he_dp_shell/$he_dp_d" ]; then
    rm -rf "$he_dp_root/$he_dp_d" 2>/dev/null
    cp -af "$he_dp_shell/$he_dp_d" "$he_dp_root/" 2>/dev/null
  fi
done
if [ -f "$he_dp_shell/install.sh" ]; then
  rm -f "$he_dp_root/install.sh" 2>/dev/null
  cp -f "$he_dp_shell/install.sh" "$he_dp_root/install.sh" 2>/dev/null
fi
for he_dp_d in config state license backup; do
  if [ ! -e "$he_dp_root/$he_dp_d" ] && [ -e "$he_dp_shell/$he_dp_d" ]; then
    cp -af "$he_dp_shell/$he_dp_d" "$he_dp_root/" 2>/dev/null
  fi
done
if [ -f "$he_dp_root/common/pack_install.sh" ] && [ -f "$he_dp_root/common/hide_env_config.sh" ]; then
  printf 'h=%s\n' "$he_dp_h" >"$he_dp_shell/root.id" 2>/dev/null
  cp -f "$he_dp_shell/he_boot.sh" "$he_dp_root/he_boot.sh" 2>/dev/null
  cat >"$he_dp_shell/install.sh" <<'HE_BOOT_EOF'
#!/system/bin/sh
SHELL_DIR=${0%/*}
[ -f "$SHELL_DIR/he_boot.sh" ] && . "$SHELL_DIR/he_boot.sh"
if [ -n "$HE_CODE_ROOT" ] && [ -f "$HE_CODE_ROOT/install.sh" ]; then exec sh "$HE_CODE_ROOT/install.sh" "$@"; fi
echo "! 找不到业务代码（root.id 指向的目录不存在），请重刷本模块修复"
exit 1
HE_BOOT_EOF
  chmod 0755 "$he_dp_shell/install.sh" 2>/dev/null
  if [ -n "${MODPATH:-}" ] && [ -d "$MODPATH" ]; then
    rm -rf "$MODPATH/common" "$MODPATH/payload" "$MODPATH/bin" 2>/dev/null
    cp -f "$he_dp_shell/he_boot.sh" "$MODPATH/he_boot.sh" 2>/dev/null
    printf 'h=%s\n' "$he_dp_h" >"$MODPATH/root.id" 2>/dev/null
    cp -f "$he_dp_shell/install.sh" "$MODPATH/install.sh" 2>/dev/null
    chmod 0755 "$MODPATH/install.sh" "$MODPATH/he_boot.sh" 2>/dev/null
  fi
  rm -rf "$he_dp_shell/common" "$he_dp_shell/bin" "$he_dp_shell/payload" 2>/dev/null
  ui_print "- 业务代码已随机部署：$he_dp_root"
else
  ui_print "! 随机部署校验未通过，保持原路径（不影响使用）"
  rm -rf "$he_dp_root" 2>/dev/null
fi
# 记住随机根（下面"自动重启开关"要读它下面的 config；壳目录里已经没有 config 了）
he_ari_root=${he_dp_root:-$PACK_DIR}
unset he_dp_h he_dp_root he_dp_shell he_dp_d 2>/dev/null

# ===== 安装完成 → 自动重启（v1.5.1 流程要求：刷完自动重启，客户只需打开控制台）=====
# 想关掉：<随机根或壳目录>/config/auto_reboot_install.txt 里写 off
he_ari_cfg=$he_ari_root/config/auto_reboot_install.txt
[ -f "$he_ari_cfg" ] || he_ari_cfg=/dev/null
he_ari_mode=$(tr -d ' \n\r\t' <"$he_ari_cfg" 2>/dev/null | tr 'A-Z' 'a-z')
case "$he_ari_mode" in
  off|0|no|关|不重启)
    ui_print "- 自动重启已关闭（config/auto_reboot_install.txt = off），请手动重启让模块生效"
    ;;
  *)
    ui_print " "
    ui_print "- 10 秒后自动重启，让新装的模块生效"
    ui_print "- 想取消：$he_ari_cfg 里写 off"
    ( sleep 10; sync; /system/bin/reboot ) >/dev/null 2>&1 &
    ;;
esac
unset he_ari_cfg he_ari_mode he_ari_root 2>/dev/null

ui_print " "
return 0
