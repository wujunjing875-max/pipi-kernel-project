#!/system/bin/sh
# WGN TOOL：模块动作按钮只提供状态提示，授权与方案执行在 APK 内完成。
NVBASE=${NVBASE:-/data/adb}
SHELL_DIR=$NVBASE/hide_env_pack
[ -f "$SHELL_DIR/he_boot.sh" ] && . "$SHELL_DIR/he_boot.sh"
PACK_DIR=${HE_CODE_ROOT:-$SHELL_DIR}

echo "=============================================="
echo " WGN TOOL 环境引擎"
echo "=============================================="
echo "- 授权、方案选择与执行：请打开 WGN TOOL APK"
if [ -f "$SHELL_DIR/install.sh" ]; then
  echo "- 当前状态："
  sh "$SHELL_DIR/install.sh" scheme status 2>/dev/null | sed 's/^/    /'
fi
exit 0
