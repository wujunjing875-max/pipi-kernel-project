#!/system/bin/sh
#############################################################
# he_boot.sh —— v1.5.1 随机部署引导器
#
# 本套的业务代码不再固定躺在 /data/adb/hide_env_pack，
# 刷入时会被随机落到 /data/adb/.h<随机hex>（每台设备不同）。
# 这个文件只负责「找到代码根」，然后把路径交给调用方。
#
# 用法（所有入口脚本统一）：
#   SHELL_DIR=${0%/*}; [ -f "$SHELL_DIR/he_boot.sh" ] && . "$SHELL_DIR/he_boot.sh"
#   之后用 $HE_CODE_ROOT（找不到时为壳目录，靠重刷修复）
#
# 索引：壳目录/root.id  内容如  h=3f9a1c7e
# 丢失索引也能找回来：扫 /data/adb/.h*/common/pack_install.sh
#############################################################

HE_SHELL_DIR=${HE_SHELL_DIR:-${SHELL_DIR:-/data/adb/hide_env_pack}}
HE_CODE_ROOT=""

_he_try_root() {
  [ -n "$1" ] || return 1
  [ -f "$1/common/pack_install.sh" ] || return 1
  HE_CODE_ROOT=$1
  return 0
}

# 1) 按索引找（优先用当前 NVBASE，兼容沙盒/自定义根）
_he_nv=${NVBASE:-/data/adb}
if [ -f "$HE_SHELL_DIR/root.id" ]; then
  _he_h=$(sed -n 's/^h=//p' "$HE_SHELL_DIR/root.id" 2>/dev/null | tr -dc '0-9a-fA-F' | head -c 32)
  if [ -n "$_he_h" ]; then
    for _he_base in "$_he_nv" /data/adb /cache; do
      if _he_try_root "$_he_base/.h$_he_h"; then unset _he_h _he_base; return 0 2>/dev/null || exit 0; fi
    done
    unset _he_base
  fi
fi

# 2) 索引丢了：扫描（只认含我们安装脚本的目录，避免误认）
for _he_c in "$_he_nv"/.h*/common/pack_install.sh /data/adb/.h*/common/pack_install.sh /cache/.h*/common/pack_install.sh; do
  [ -f "$_he_c" ] || continue
  _he_d=${_he_c%/common/pack_install.sh}
  _he_try_root "$_he_d" && break
done
unset _he_c _he_d _he_h 2>/dev/null

# 3) 兜底：还是老结构（未迁移/刚升级）
[ -n "$HE_CODE_ROOT" ] || _he_try_root "$HE_SHELL_DIR"

[ -n "$HE_CODE_ROOT" ] || HE_CODE_ROOT=$HE_SHELL_DIR
HE_ROOT=$HE_CODE_ROOT
HIDE_ENV_DIR=$HE_CODE_ROOT
HE_NVBASE=${NVBASE:-/data/adb}
