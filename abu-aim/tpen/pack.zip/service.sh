#!/system/bin/sh
#############################################################
# service.sh —— 开机后的三件事
#
#   0. 先装「开机看门狗」：这套包里有 Zygisk Next / LSPosed / UID Fake 三个
#      系统级组件，万一和设备的已有框架或内核冲突，会把 zygote/系统服务搞崩，
#      表现就是无限重启。看门狗会在 240 秒内没等到开机完成时，
#      自动把这套装的全部模块停用并重启一次（最多连续 3 次），
#      保证设备一定能回到系统里；开机正常完成则自动解除，之后不再干预。
#   1. 补装：刷入时没装成功的模块（pending 里有记录才动）
#   2. 自动配置的日常维护（全部幂等，且不会覆盖用户在 App 里的改动）：
#        - 刷新 OMK 拦截包名列表（装/卸应用后列表会变，这时才重写）
#        - 确认密钥 / Soter / Zygisk Next 两项策略仍然在
#        - PIF 指纹：还没确认生效时才重试（最多 6 次）
#        - HMA 配置：只在缺失时还原
#        - FuseFixer：LSPosed 配置库首次生成后自动写入启用状态
#   3. 痕迹清理：把本包落在内部储存里的文件（刷入包 zip、教程、密钥投放文件、
#      公告）覆盖改写后直接删除，不经过回收站。可在 config/trace_purge.txt
#      写 off 关闭，或把不想删的写进 config/trace_keep.txt。
#   4. 模块互锁（v1.5.1「反滚」）：本套模块永不删除、永不回滚。只清理
#      冒充/夹带本套的多余模块、卸载残留、旧随机根副本，清完自动重启一次。
#      客户自己装的模块（SelinuxFix / PIF / 双框架等）一律不动。
#   5. C4 探针：5 个分散哨兵（见 hide_env_probe.sh）只做"脱管/假服务器"上报。
#
# 正常情况下只花几百毫秒；联网项有 60 秒上限。
#############################################################

NVBASE=${NVBASE:-/data/adb}
SHELL_DIR=$NVBASE/hide_env_pack
[ -f "$SHELL_DIR/he_boot.sh" ] && . "$SHELL_DIR/he_boot.sh"
PACK_DIR=${HE_CODE_ROOT:-$SHELL_DIR}   # v1.5.1 随机部署：业务代码在 /data/adb/.h<hex>

[ -d "$PACK_DIR" ] || exit 0
if [ ! -f "$PACK_DIR/common/pack_install.sh" ]; then
  echo "$(date '+%F %T' 2>/dev/null) [致命] 找不到业务代码 PACK_DIR=$PACK_DIR root.id=$(cat "$SHELL_DIR/root.id" 2>/dev/null)" >>"$NVBASE/hide_env_pack/boot.log" 2>/dev/null
  exit 0
fi
[ -f "$PACK_DIR/common/hide_env_config.sh" ] || exit 0

(
  HIDE_ENV_DIR=$PACK_DIR
  export HIDE_ENV_DIR

  . "$PACK_DIR/common/pack_shim.sh"
  . "$PACK_DIR/common/pack_install.sh"
  . "$PACK_DIR/common/hide_env_config.sh"
  [ -f "$PACK_DIR/common/hide_env_license.sh" ] && . "$PACK_DIR/common/hide_env_license.sh"
  [ -f "$PACK_DIR/common/hide_env_clean.sh" ] && . "$PACK_DIR/common/hide_env_clean.sh"
  [ -f "$PACK_DIR/common/hide_env_scheme.sh" ] && . "$PACK_DIR/common/hide_env_scheme.sh"
  [ -f "$PACK_DIR/common/hide_env_face.sh" ] && . "$PACK_DIR/common/hide_env_face.sh"

  # WGN_TOOL_EDITION: 授权由 APK 完成。旧看门狗 / 互锁 / 探针 / 远程协助
  # 一律不启动，避免旧服务器不可达时阻塞开机或误停模块。

  pack_i=0
  while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
    sleep 3
    pack_i=$((pack_i + 1))
    [ "$pack_i" -gt 120 ] && exit 0
  done
  sleep 5

  # WGN_TOOL_EDITION: 旧授权服务器不参与开机流程，不再等待其可达。

  pack_init keep

  # WGN TOOL: the APK leaves the selected scheme here before the first reboot.
  for he_wgn_hint in /sdcard/Android/data/com.wgntool.app/files/wgn_scheme /storage/emulated/0/Android/data/com.wgntool.app/files/wgn_scheme; do
    [ -s "$he_wgn_hint" ] || continue
    he_wgn_sc=$(tr -d ' \r\n' < "$he_wgn_hint" 2>/dev/null)
    case "$he_wgn_sc" in
      a|b) mkdir -p "$PACK_DIR/config" 2>/dev/null; printf '%s' "$he_wgn_sc" >"$PACK_DIR/config/scheme.txt" 2>/dev/null ;;
    esac
    rm -f "$he_wgn_hint" 2>/dev/null
    break
  done


  # 框架管理器默认隐藏：开机先清掉上次异常退出/重启前残留的管理器（与卡密无关）。
  # 管理器只在面具「动作」按钮/install.sh lsp 时临时安装，关闭即卸载。
  command -v he_lsp_manager >/dev/null 2>&1 && he_lsp_manager >/dev/null 2>&1

  if [ -f "$PACK_DIR/pending" ]; then
    pack_say "- 一键隐藏环境：检测到未完成的安装，开始自动补装"
    pack_repair
    pack_report
  fi

  # 附加 App 兜底：刷入阶段 pm 忙/被拒的（FuseFixer、HMA 管理器），每次开机再补装
  # 一次；与卡密无关 —— 装上但没授权就不会启用（不写 LSPosed 配置库）
  command -v he_apps_ensure >/dev/null 2>&1 && he_apps_ensure

  # WGN_TOOL_EDITION: 无远程协助、无旧授权闸门、无旧完整性闸门。
  # 环境配置完全由本地方案文件驱动。

  # 开机维护：非强制模式（保留用户自己的改动）
  HIDE_FORCE=0
  he_apply_all

  # WGN 远程控制 agent：APK 登录后把 token/device 写入 config，开机自动续跑。
  if [ -f "$PACK_DIR/common/wgn_remote.sh" ]; then
    HE_CODE_ROOT="$PACK_DIR" PACK_DIR="$PACK_DIR" sh "$PACK_DIR/common/wgn_remote.sh" start >/dev/null 2>&1
  fi

  # RKP：开机后台下发 RKPConfig / 属性并尝试申领，不阻塞开机。
  # 网络不可达时 he_rkp_auto 会快速返回并留下可读状态，下次开机会再试。
  if [ "$(cat "$PACK_DIR/config/scheme.txt" 2>/dev/null | tr -d ' \r\n')" != "b" ] \
     && [ "$(he_state_of rkp 2>/dev/null)" != "ok" ]; then
    ( he_rkp_auto >/dev/null 2>&1 ) &
  fi

  # 清理看护：游戏在跑 → persist 加锁；游戏一退出 → 清下发目录 + 行为日志，再还原权限。
  # （社区那套模块就是这个常驻看护在起作用；只做一次性清理永远追不上反作弊重写）
  command -v he_clean_boot >/dev/null 2>&1 && he_clean_boot

  # OMK 接管状态采样（排查「每次重启报告都不一样」）：开机后分几个点记一笔，
  # 注入没活会自动把采样传上云（控制台「看排查报告」能看到）
  # WGN TOOL: local-only; legacy diagnostics upload disabled.

  # 框架守护进程自愈：lspd 没在跑就自动覆盖安装一次（红米 K50 真机发现：
  # 安卓12 上也会遇到"LSPosed 装坏了、守护进程起不来"，以前只能客户手动跑 lsp-upgrade）
  if command -v he_lsp_selfheal >/dev/null 2>&1 && ! pack_soc_is_mtk 2>/dev/null; then
    he_lsp_selfheal &
  fi

  # 痕迹清理：等配置全部跑完（密钥已装成功）再把内部储存里本包的文件抹掉。
  # 顺序不能提前：密钥投放文件要先被 OMK 装进去，之后才能删手机存储里那份。
  command -v he_purge_traces >/dev/null 2>&1 && he_purge_traces

  he_write_report

  pack_say "- 开机维护完成，详细：$PACK_DIR/status.txt"
) >>"$PACK_DIR/boot.log" 2>&1 &

# WGN TOOL: Soter TA / Soter HAL / PIF / patch are applied by he_apply_all.
exit 0
