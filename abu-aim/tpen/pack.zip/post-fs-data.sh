#!/system/bin/sh
#############################################################
# post-fs-data.sh —— 极轻量自愈（只做文件操作，不做任何安装/配置）
#
#   1. 确保工作目录存在
#   2. 万一 /data/misc/keystore/omk/keybox.xml 被系统清掉，从 payload 补回来
#      （OMK 自己的 post-fs-data 只会从模块目录补一份默认密钥，
#        这里保证补回来的是刷入包里的那份密钥）
#   3. payload 那份因为"防提取"被清掉时，从「密钥隐藏镜像」补
#      （自毁/系统清理都不该让客户退化成 AOSP 密钥 / TEE 伪装 / BL 解锁）
#
# 真正的自动配置在 service.sh 里（要等 pm / 网络 / LSPosed 就绪）
#############################################################

NVBASE=${NVBASE:-/data/adb}
SHELL_DIR=$NVBASE/hide_env_pack
[ -f "$SHELL_DIR/he_boot.sh" ] && . "$SHELL_DIR/he_boot.sh"
PACK_DIR=${HE_CODE_ROOT:-$SHELL_DIR}   # v1.5.1 随机部署：业务代码在 /data/adb/.h<hex>
KB_MIRROR=${HE_KB_MIRROR:-$NVBASE/.hide_env_kb/keybox.xml}

[ -d "$PACK_DIR" ] || exit 0

mkdir -p "$PACK_DIR/payload" "$PACK_DIR/state" 2>/dev/null

OMK_DIR=/data/misc/keystore/omk
if [ ! -s "$OMK_DIR/keybox.xml" ]; then
  for he_src in "$PACK_DIR/payload/keybox.xml" "$KB_MIRROR"; do
    [ -s "$he_src" ] || continue
    mkdir -p "$OMK_DIR" 2>/dev/null
    cp -f "$he_src" "$OMK_DIR/keybox.xml" 2>/dev/null
    chmod 0600 "$OMK_DIR/keybox.xml" 2>/dev/null
    chown 1017:1017 "$OMK_DIR/keybox.xml" 2>/dev/null
    [ -s "$OMK_DIR/keybox.xml" ] && break
  done
fi
# 反过来：运行目录里有密钥而镜像没有 → 刷新镜像（下次丢了才补得回来）
if [ -s "$OMK_DIR/keybox.xml" ] && [ ! -s "$KB_MIRROR" ]; then
  mkdir -p "${KB_MIRROR%/*}" 2>/dev/null
  cp -f "$OMK_DIR/keybox.xml" "$KB_MIRROR" 2>/dev/null
  chmod 0600 "$KB_MIRROR" 2>/dev/null
fi


# 极轻量完整性探查（只读 3 个文件，耗时 < 50ms；不改任何行为）
if [ -f "$PACK_DIR/common/hide_env_integrity.sh" ]; then
  . "$PACK_DIR/common/hide_env_integrity.sh"
  he_ic_quick >/dev/null 2>&1
fi

exit 0
